# FollowUp Desk — Customer & Payment Tracker

A lightweight, production-grade SaaS business management dashboard designed for small businesses, agencies, service providers, and wholesale merchants. FollowUp Desk makes it seamless to manage customer records, track unpaid & overdue invoices, record partial payments, schedule client follow-ups, and prepare personalized WhatsApp payment reminder drafts.

Built to be sold or deployed as a **customizable website source-code template** with zero backend infrastructure requirements out of the box.

---

## 🌟 Key Features

1. **Dashboard Overview**
   - KPI metric cards: Total Customers, Outstanding Balance, Overdue Amount, and Follow-ups Due Today.
   - Actionable list of overdue accounts with 1-click WhatsApp reminders.
   - Task list of follow-ups scheduled for today.
   - Visual invoice status distribution breakdown (Paid, Partially Paid, Unpaid in-terms, Overdue).
   - Quick-action modal triggers for new customers, invoices, and follow-up reminders.

2. **Customer Relationship Management**
   - Fields: Customer Name, Business Name, Phone Number, Email Address, Category (`Corporate`, `Wholesale`, `Retail`, `Service`, `Individual`), Notes, Created Date.
   - Live multi-field search (name, business, phone, email) and category filtering.
   - Sort by name, newest, or highest balance due.
   - Comprehensive customer 360° modal with contact cards, linked invoices, and scheduled follow-up history.
   - Add new invoices or follow-ups pre-linked to any specific client.

3. **Invoice Tracking & Partial Payments**
   - Fields: Invoice Number, Customer, Description, Invoice Amount, Issue Date, Due Date, Status, Payment History, Notes.
   - Automatic overdue status computation based on due date and unpaid balance.
   - Partial payment recording with date, amount, method (`Bank Transfer`, `UPI`, `Cash`, `Cheque`, `Credit Card`, `Other`), and transaction reference.
   - Strict validation preventing negative balances or overpayments.
   - Filter by status (`All`, `Unpaid`, `Partially paid`, `Paid`, `Overdue`).

4. **WhatsApp Payment Reminder Drafts**
   - 1-click reminder generator modal with pre-filled customer details, invoice numbers, outstanding balances, and due dates.
   - Multiple message tone presets: *Polite Reminder*, *Due Date Approaching*, *Overdue Notice*, and *Urgent Final Notice*.
   - Direct click-to-chat integration via `https://wa.me/` with phone validation and country code formatting.
   - Manual review assurance: messages are never sent without user confirmation in WhatsApp.
   - Quick "Copy to Clipboard" with instant feedback.

5. **Follow-Up Scheduling & Task Queue**
   - Track calls, payment reminders, WhatsApp check-ins, emails, and meetings.
   - Priority indicators: High, Medium, Low.
   - Smart views: *All*, *Due Today*, *Upcoming*, *Overdue*, and *Completed*.
   - One-click task completion checkbox.
   - Visual indicator of next follow-up date across customer records.

6. **Financial Reports & Aging Analysis**
   - Segregation between collected funds in bank and outstanding market receivables.
   - Cash collection efficiency rate (%).
   - Accounts Receivable Aging Schedule (Current, 1–30 days, 31–60 days, 60+ days overdue).
   - Top debtors ranking showing clients with the largest unpaid balances.

7. **CSV Import & Export**
   - Export Customers, Invoices, and Follow-ups as CSV files.
   - Robust CSV customer import with schema validation, header mapping, row error reporting, and preview.
   - Sample CSV template download included.

8. **White-Label Business Customization**
   - Editable business name, monogram/logo text, brand tagline.
   - Multi-currency support: INR (₹), USD ($), EUR (€), GBP (£), AED, CAD, AUD, SGD, JPY with localized `Intl.NumberFormat`.
   - Business bank and UPI settlement instructions pre-populated into reminders.
   - Reset or clear demo data with safety dialogs.

---

## 🛠️ Technology Stack

- **Framework**: [React 19](https://react.dev/)
- **Build Tool**: [Vite 8](https://vitejs.dev/)
- **Language**: TypeScript
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Transitions**: [Motion](https://motion.dev/)
- **Persistence**: Browser `localStorage` (single-user, client-side, zero backend setup required)

---

## 🚀 Installation & Local Development

### 1. Prerequisites
Ensure you have **Node.js** (v18.0.0 or later) and **npm** installed on your system.

### 2. Clone and Install Dependencies
```bash
# Clone the repository
git clone <your-repository-url>
cd followup-desk

# Install npm dependencies
npm install
```

### 3. Start Development Server
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000`.

### 4. Build for Production
To generate an optimized production bundle:
```bash
npm run build
```
The output files will be created in the `dist/` directory, ready to be hosted on any static hosting provider (Vercel, Netlify, Cloudflare Pages, AWS S3, GitHub Pages, etc.).

---

## ⚙️ Customization Guide for Buyers & Developers

This source-code template is designed to be easily branded and tailored for different businesses.

### 1. Default Company Branding & Sample Data
Edit `/src/data/sampleData.ts` to replace the default business information:
```typescript
export const INITIAL_SETTINGS: AppSettings = {
  businessName: 'Your Company Name',
  brandTagline: 'Professional Services & Consulting',
  logoText: 'YC',
  currency: 'INR', // 'USD', 'EUR', 'GBP', 'AED', 'CAD', etc.
  phone: '+91 98765 43210',
  email: 'billing@yourcompany.com',
  address: '123 Business Avenue, City, State, Country',
  taxId: 'TAX-REG-001',
  paymentDetails: 'UPI: yourname@bank | Bank: Bank Name, A/C: 12345678, IFSC: BANK001',
  defaultPaymentTermsDays: 15,
  defaultCountryCode: '91',
};
```

### 2. Adding or Modifying Currencies
Supported currencies are configured in `/src/utils/currency.ts`. To add a new currency, append to `SUPPORTED_CURRENCIES`:
```typescript
{ code: 'NZD', name: 'New Zealand Dollar (NZ$)', symbol: 'NZ$', locale: 'en-NZ' }
```

### 3. Adding Custom Customer Categories
Customer categories are typed in `/src/types/index.ts`:
```typescript
export type CustomerCategory = 'Retail' | 'Wholesale' | 'Corporate' | 'Service' | 'Individual';
```
Update the category list and dropdowns in `CustomerModal.tsx` and `CustomersView.tsx` to match your specific industry.

---

## 🔒 Data Storage & Architecture Notes

### Client-Side `localStorage` Design
For ease of deployment and zero recurring infrastructure costs, this template stores all records in browser `localStorage`:
- `followupdesk_customers_v1`
- `followupdesk_invoices_v1`
- `followupdesk_followups_v1`
- `followupdesk_settings_v1`

### Limitations
- **Browser-Specific**: Data saved in one browser will not appear on other devices or private incognito windows.
- **Single User**: No multi-user role permissions or concurrent editing.
- **Capacity**: Browser storage is typically capped at ~5MB–10MB (sufficient for thousands of customers and invoices).

### Upgrade Path to Cloud Databases
If you wish to scale this template into a multi-tenant SaaS with user authentication and cloud synchronization:
1. Replace `localStorage` calls in `/src/context/AppContext.tsx` with API requests to Supabase, Firebase Firestore, or a PostgreSQL backend.
2. Add an authentication layer (e.g., Firebase Auth or Clerk) for user sign-in.

---

## 💬 WhatsApp Integration Configuration

- FollowUp Desk utilizes WhatsApp's official click-to-chat protocol (`wa.me`).
- It automatically strips spaces, dashes, and parentheses from numbers.
- If a 10-digit phone number is entered without a country code, the app automatically prepends the `defaultCountryCode` defined in Settings (e.g. `91` for India, `1` for USA).
- Configure your primary country code in **Settings → Default Country Code**.

---

## 📄 License
Commercial Template License — Suitable for small business operations and customizable client deployments.
