export type CustomerCategory = 'Retail' | 'Wholesale' | 'Corporate' | 'Service' | 'Individual';

export interface Customer {
  id: string;
  name: string;
  businessName: string;
  phone: string;
  email: string;
  category: CustomerCategory;
  notes?: string;
  createdAt: string;
}

export interface InvoicePayment {
  id: string;
  date: string;
  amount: number;
  method: 'Bank Transfer' | 'UPI' | 'Cash' | 'Cheque' | 'Credit Card' | 'Other';
  notes?: string;
  recordedAt: string;
}

export type InvoiceStatus = 'Unpaid' | 'Partially paid' | 'Paid' | 'Overdue';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  description: string;
  amount: number;
  issueDate: string;
  dueDate: string;
  status: InvoiceStatus;
  notes?: string;
  payments: InvoicePayment[];
  createdAt: string;
}

export type FollowUpType = 'Payment Reminder' | 'Phone Call' | 'WhatsApp' | 'Email' | 'Meeting' | 'General';
export type PriorityLevel = 'High' | 'Medium' | 'Low';

export interface FollowUp {
  id: string;
  customerId: string;
  customerName: string;
  invoiceId?: string;
  invoiceNumber?: string;
  date: string;
  type: FollowUpType;
  priority: PriorityLevel;
  notes: string;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
}

export type AccentColor = 'blue' | 'indigo' | 'emerald' | 'teal' | 'slate';

export interface AppSettings {
  businessName: string;
  brandTagline: string;
  logoText: string;
  currency: string;
  accentColor: AccentColor;
  phone: string;
  email: string;
  address: string;
  taxId: string;
  paymentDetails: string;
  defaultPaymentTermsDays: number;
  defaultCountryCode: string;
  defaultReminderTemplate: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
}

export type NavigationTab = 'dashboard' | 'customers' | 'invoices' | 'followups' | 'reports' | 'settings';
