import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Customer,
  Invoice,
  InvoicePayment,
  FollowUp,
  AppSettings,
  ToastMessage,
  NavigationTab,
} from '../types';
import {
  INITIAL_CUSTOMERS,
  INITIAL_INVOICES,
  INITIAL_FOLLOWUPS,
  INITIAL_SETTINGS,
} from '../data/sampleData';
import { getInvoiceBalance, getInvoiceEffectiveStatus } from '../utils/invoiceCalculator';

interface AppContextType {
  customers: Customer[];
  invoices: Invoice[];
  followUps: FollowUp[];
  settings: AppSettings;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;

  // Customer actions
  addCustomer: (data: Omit<Customer, 'id' | 'createdAt'>) => Customer;
  updateCustomer: (id: string, data: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  importCustomers: (imported: Omit<Customer, 'id' | 'createdAt'>[]) => { added: number };

  // Invoice actions
  addInvoice: (
    data: Omit<Invoice, 'id' | 'payments' | 'createdAt' | 'status'> & {
      initialPayment?: number;
      initialPaymentMethod?: InvoicePayment['method'];
    }
  ) => Invoice;
  updateInvoice: (id: string, data: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  recordPayment: (
    invoiceId: string,
    payment: {
      date: string;
      amount: number;
      method: InvoicePayment['method'];
      notes?: string;
    }
  ) => void;

  // Follow-up actions
  addFollowUp: (data: Omit<FollowUp, 'id' | 'createdAt' | 'completed' | 'completedAt'>) => FollowUp;
  updateFollowUp: (id: string, data: Partial<FollowUp>) => void;
  deleteFollowUp: (id: string) => void;
  toggleFollowUpComplete: (id: string) => void;

  // Settings & Reset
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  resetDemoData: () => void;
  clearAllData: () => void;

  // Modal triggers
  openCustomerModal: (mode: 'create' | 'edit' | 'view', customer?: Customer) => void;
  closeCustomerModal: () => void;
  customerModalState: { isOpen: boolean; mode: 'create' | 'edit' | 'view'; customer?: Customer };

  openInvoiceModal: (
    mode: 'create' | 'edit' | 'view',
    invoice?: Invoice,
    preselectedCustomerId?: string
  ) => void;
  closeInvoiceModal: () => void;
  invoiceModalState: {
    isOpen: boolean;
    mode: 'create' | 'edit' | 'view';
    invoice?: Invoice;
    preselectedCustomerId?: string;
  };

  openPaymentModal: (invoice: Invoice) => void;
  closePaymentModal: () => void;
  paymentModalState: { isOpen: boolean; invoice?: Invoice };

  openFollowUpModal: (
    mode: 'create' | 'edit',
    followUp?: FollowUp,
    preselectedCustomerId?: string,
    preselectedInvoiceId?: string
  ) => void;
  closeFollowUpModal: () => void;
  followUpModalState: {
    isOpen: boolean;
    mode: 'create' | 'edit';
    followUp?: FollowUp;
    preselectedCustomerId?: string;
    preselectedInvoiceId?: string;
  };

  openWhatsAppModal: (invoice: Invoice) => void;
  closeWhatsAppModal: () => void;
  whatsAppModalState: { isOpen: boolean; invoice?: Invoice };

  openImportModal: () => void;
  closeImportModal: () => void;
  importModalOpen: boolean;
}

const STORAGE_KEYS = {
  CUSTOMERS: 'followupdesk_customers_v1',
  INVOICES: 'followupdesk_invoices_v1',
  FOLLOWUPS: 'followupdesk_followups_v1',
  SETTINGS: 'followupdesk_settings_v1',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Persistent States
  const [customers, setCustomers] = useState<Customer[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
      return stored ? JSON.parse(stored) : INITIAL_CUSTOMERS;
    } catch {
      return INITIAL_CUSTOMERS;
    }
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.INVOICES);
      return stored ? JSON.parse(stored) : INITIAL_INVOICES;
    } catch {
      return INITIAL_INVOICES;
    }
  });

  const [followUps, setFollowUps] = useState<FollowUp[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.FOLLOWUPS);
      return stored ? JSON.parse(stored) : INITIAL_FOLLOWUPS;
    } catch {
      return INITIAL_FOLLOWUPS;
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return stored ? JSON.parse(stored) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  // Modals state
  const [customerModalState, setCustomerModalState] = useState<{
    isOpen: boolean;
    mode: 'create' | 'edit' | 'view';
    customer?: Customer;
  }>({ isOpen: false, mode: 'create' });

  const [invoiceModalState, setInvoiceModalState] = useState<{
    isOpen: boolean;
    mode: 'create' | 'edit' | 'view';
    invoice?: Invoice;
    preselectedCustomerId?: string;
  }>({ isOpen: false, mode: 'create' });

  const [paymentModalState, setPaymentModalState] = useState<{
    isOpen: boolean;
    invoice?: Invoice;
  }>({ isOpen: false });

  const [followUpModalState, setFollowUpModalState] = useState<{
    isOpen: boolean;
    mode: 'create' | 'edit';
    followUp?: FollowUp;
    preselectedCustomerId?: string;
    preselectedInvoiceId?: string;
  }>({ isOpen: false, mode: 'create' });

  const [whatsAppModalState, setWhatsAppModalState] = useState<{
    isOpen: boolean;
    invoice?: Invoice;
  }>({ isOpen: false });

  const [importModalOpen, setImportModalOpen] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
    } catch (e) {
      console.warn('Failed to save customers to localStorage', e);
    }
  }, [customers]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
    } catch (e) {
      console.warn('Failed to save invoices to localStorage', e);
    }
  }, [invoices]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.FOLLOWUPS, JSON.stringify(followUps));
    } catch (e) {
      console.warn('Failed to save followUps to localStorage', e);
    }
  }, [followUps]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.warn('Failed to save settings to localStorage', e);
    }
  }, [settings]);

  // Toast Helpers
  const addToast = (toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Customer Handlers
  const addCustomer = (data: Omit<Customer, 'id' | 'createdAt'>): Customer => {
    const newCustomer: Customer = {
      ...data,
      id: `cust_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCustomers((prev) => [newCustomer, ...prev]);
    addToast({
      type: 'success',
      title: 'Customer Added',
      message: `${newCustomer.name} (${newCustomer.businessName}) has been added.`,
    });
    return newCustomer;
  };

  const updateCustomer = (id: string, data: Partial<Customer>) => {
    setCustomers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...data } : c))
    );

    // If customer name updated, also update denormalized customerName in invoices and follow-ups
    if (data.name) {
      setInvoices((prev) =>
        prev.map((inv) =>
          inv.customerId === id ? { ...inv, customerName: data.name! } : inv
        )
      );
      setFollowUps((prev) =>
        prev.map((fol) =>
          fol.customerId === id ? { ...fol, customerName: data.name! } : fol
        )
      );
    }

    addToast({
      type: 'success',
      title: 'Customer Updated',
      message: 'Customer profile details updated successfully.',
    });
  };

  const deleteCustomer = (id: string) => {
    const target = customers.find((c) => c.id === id);
    setCustomers((prev) => prev.filter((c) => c.id !== id));
    // Also remove associated invoices and followups to prevent orphaned records
    setInvoices((prev) => prev.filter((inv) => inv.customerId !== id));
    setFollowUps((prev) => prev.filter((fol) => fol.customerId !== id));

    addToast({
      type: 'info',
      title: 'Customer Deleted',
      message: target ? `${target.name} and related records were deleted.` : 'Customer deleted.',
    });
  };

  const importCustomers = (imported: Omit<Customer, 'id' | 'createdAt'>[]): { added: number } => {
    const timestamp = Date.now();
    const today = new Date().toISOString().split('T')[0];

    const newRecords: Customer[] = imported.map((item, index) => ({
      ...item,
      id: `cust_${timestamp}_${index}`,
      createdAt: today,
    }));

    setCustomers((prev) => [...newRecords, ...prev]);
    addToast({
      type: 'success',
      title: 'Import Successful',
      message: `Imported ${newRecords.length} new customer records.`,
    });
    return { added: newRecords.length };
  };

  // Invoice Handlers
  const addInvoice = (
    data: Omit<Invoice, 'id' | 'payments' | 'createdAt' | 'status'> & {
      initialPayment?: number;
      initialPaymentMethod?: InvoicePayment['method'];
    }
  ): Invoice => {
    const now = new Date().toISOString();
    const today = now.split('T')[0];
    const payments: InvoicePayment[] = [];

    if (data.initialPayment && data.initialPayment > 0) {
      payments.push({
        id: `pay_${Date.now()}`,
        date: data.issueDate || today,
        amount: Math.min(data.amount, data.initialPayment),
        method: data.initialPaymentMethod || 'Bank Transfer',
        notes: 'Initial payment recorded during invoice creation',
        recordedAt: now,
      });
    }

    const tempInvoice: Invoice = {
      ...data,
      id: `inv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      payments,
      status: 'Unpaid',
      createdAt: today,
    };

    // Calculate accurate effective status
    const effectiveStatus = getInvoiceEffectiveStatus(tempInvoice);
    const newInvoice: Invoice = {
      ...tempInvoice,
      status: effectiveStatus,
    };

    setInvoices((prev) => [newInvoice, ...prev]);
    addToast({
      type: 'success',
      title: 'Invoice Created',
      message: `Invoice #${newInvoice.invoiceNumber} created for ${newInvoice.customerName}.`,
    });
    return newInvoice;
  };

  const updateInvoice = (id: string, data: Partial<Invoice>) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id !== id) return inv;
        const updated = { ...inv, ...data };
        return {
          ...updated,
          status: getInvoiceEffectiveStatus(updated),
        };
      })
    );
    addToast({
      type: 'success',
      title: 'Invoice Updated',
      message: 'Invoice updated successfully.',
    });
  };

  const deleteInvoice = (id: string) => {
    const target = invoices.find((inv) => inv.id === id);
    setInvoices((prev) => prev.filter((inv) => inv.id !== id));
    // Clear invoice link in followups if matched
    setFollowUps((prev) =>
      prev.map((fol) =>
        fol.invoiceId === id ? { ...fol, invoiceId: undefined, invoiceNumber: undefined } : fol
      )
    );
    addToast({
      type: 'info',
      title: 'Invoice Deleted',
      message: target ? `Invoice #${target.invoiceNumber} deleted.` : 'Invoice deleted.',
    });
  };

  const recordPayment = (
    invoiceId: string,
    payment: {
      date: string;
      amount: number;
      method: InvoicePayment['method'];
      notes?: string;
    }
  ) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id !== invoiceId) return inv;

        const currentBalance = getInvoiceBalance(inv);
        if (currentBalance <= 0) {
          return inv;
        }

        // Clamp payment to remaining balance so balance never becomes negative
        const cleanAmount = Math.min(payment.amount, currentBalance);
        if (cleanAmount <= 0) return inv;

        const newPayment: InvoicePayment = {
          id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          date: payment.date,
          amount: cleanAmount,
          method: payment.method,
          notes: payment.notes,
          recordedAt: new Date().toISOString(),
        };

        const updatedPayments = [...(inv.payments || []), newPayment];
        const updatedInvoice: Invoice = {
          ...inv,
          payments: updatedPayments,
        };

        return {
          ...updatedInvoice,
          status: getInvoiceEffectiveStatus(updatedInvoice),
        };
      })
    );

    addToast({
      type: 'success',
      title: 'Payment Recorded',
      message: 'Payment was successfully applied to the invoice.',
    });
  };

  // Follow-up Handlers
  const addFollowUp = (
    data: Omit<FollowUp, 'id' | 'createdAt' | 'completed' | 'completedAt'>
  ): FollowUp => {
    const newFollowUp: FollowUp = {
      ...data,
      id: `fol_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      completed: false,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setFollowUps((prev) => [newFollowUp, ...prev]);
    addToast({
      type: 'success',
      title: 'Follow-up Scheduled',
      message: `Follow-up set for ${newFollowUp.customerName} on ${newFollowUp.date}.`,
    });
    return newFollowUp;
  };

  const updateFollowUp = (id: string, data: Partial<FollowUp>) => {
    setFollowUps((prev) =>
      prev.map((fol) => (fol.id === id ? { ...fol, ...data } : fol))
    );
    addToast({
      type: 'success',
      title: 'Follow-up Updated',
      message: 'Follow-up task details updated.',
    });
  };

  const deleteFollowUp = (id: string) => {
    setFollowUps((prev) => prev.filter((fol) => fol.id !== id));
    addToast({
      type: 'info',
      title: 'Follow-up Removed',
      message: 'The follow-up schedule was removed.',
    });
  };

  const toggleFollowUpComplete = (id: string) => {
    setFollowUps((prev) =>
      prev.map((fol) => {
        if (fol.id !== id) return fol;
        const newCompleted = !fol.completed;
        return {
          ...fol,
          completed: newCompleted,
          completedAt: newCompleted ? new Date().toISOString() : undefined,
        };
      })
    );
  };

  // Settings Handlers
  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    addToast({
      type: 'success',
      title: 'Settings Saved',
      message: 'Your business profile and preferences have been updated.',
    });
  };

  const resetDemoData = () => {
    setCustomers(INITIAL_CUSTOMERS);
    setInvoices(INITIAL_INVOICES);
    setFollowUps(INITIAL_FOLLOWUPS);
    setSettings(INITIAL_SETTINGS);
    try {
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(INITIAL_CUSTOMERS));
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(INITIAL_INVOICES));
      localStorage.setItem(STORAGE_KEYS.FOLLOWUPS, JSON.stringify(INITIAL_FOLLOWUPS));
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_SETTINGS));
    } catch (e) {
      console.warn('Reset error', e);
    }
    addToast({
      type: 'info',
      title: 'Demo Data Restored',
      message: 'Default sample customers, invoices, and follow-ups have been loaded.',
    });
  };

  const clearAllData = () => {
    setCustomers([]);
    setInvoices([]);
    setFollowUps([]);
    try {
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.FOLLOWUPS, JSON.stringify([]));
    } catch (e) {
      console.warn('Clear error', e);
    }
    addToast({
      type: 'info',
      title: 'Data Cleared',
      message: 'All customer records, invoices, and follow-ups have been erased.',
    });
  };

  // Modal helpers
  const openCustomerModal = (mode: 'create' | 'edit' | 'view', customer?: Customer) => {
    setCustomerModalState({ isOpen: true, mode, customer });
  };
  const closeCustomerModal = () => {
    setCustomerModalState({ isOpen: false, mode: 'create' });
  };

  const openInvoiceModal = (
    mode: 'create' | 'edit' | 'view',
    invoice?: Invoice,
    preselectedCustomerId?: string
  ) => {
    setInvoiceModalState({ isOpen: true, mode, invoice, preselectedCustomerId });
  };
  const closeInvoiceModal = () => {
    setInvoiceModalState({ isOpen: false, mode: 'create' });
  };

  const openPaymentModal = (invoice: Invoice) => {
    setPaymentModalState({ isOpen: true, invoice });
  };
  const closePaymentModal = () => {
    setPaymentModalState({ isOpen: false });
  };

  const openFollowUpModal = (
    mode: 'create' | 'edit',
    followUp?: FollowUp,
    preselectedCustomerId?: string,
    preselectedInvoiceId?: string
  ) => {
    setFollowUpModalState({
      isOpen: true,
      mode,
      followUp,
      preselectedCustomerId,
      preselectedInvoiceId,
    });
  };
  const closeFollowUpModal = () => {
    setFollowUpModalState({ isOpen: false, mode: 'create' });
  };

  const openWhatsAppModal = (invoice: Invoice) => {
    setWhatsAppModalState({ isOpen: true, invoice });
  };
  const closeWhatsAppModal = () => {
    setWhatsAppModalState({ isOpen: false });
  };

  const openImportModal = () => setImportModalOpen(true);
  const closeImportModal = () => setImportModalOpen(false);

  return (
    <AppContext.Provider
      value={{
        customers,
        invoices,
        followUps,
        settings,
        activeTab,
        setActiveTab,
        toasts,
        addToast,
        removeToast,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        importCustomers,
        addInvoice,
        updateInvoice,
        deleteInvoice,
        recordPayment,
        addFollowUp,
        updateFollowUp,
        deleteFollowUp,
        toggleFollowUpComplete,
        updateSettings,
        resetDemoData,
        clearAllData,
        openCustomerModal,
        closeCustomerModal,
        customerModalState,
        openInvoiceModal,
        closeInvoiceModal,
        invoiceModalState,
        openPaymentModal,
        closePaymentModal,
        paymentModalState,
        openFollowUpModal,
        closeFollowUpModal,
        followUpModalState,
        openWhatsAppModal,
        closeWhatsAppModal,
        whatsAppModalState,
        openImportModal,
        closeImportModal,
        importModalOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
