import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/navigation/Sidebar';
import { MobileHeader } from './components/navigation/MobileHeader';
import { DashboardView } from './components/dashboard/DashboardView';
import { CustomersView } from './components/customers/CustomersView';
import { InvoicesView } from './components/invoices/InvoicesView';
import { FollowUpsView } from './components/followups/FollowUpsView';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { CustomerModal } from './components/modals/CustomerModal';
import { InvoiceModal } from './components/modals/InvoiceModal';
import { PaymentModal } from './components/modals/PaymentModal';
import { FollowUpModal } from './components/modals/FollowUpModal';
import { WhatsAppModal } from './components/modals/WhatsAppModal';
import { ImportModal } from './components/modals/ImportModal';
import { ToastContainer } from './components/common/ToastContainer';
import { formatCurrency } from './utils/currency';
import { getInvoiceBalance } from './utils/invoiceCalculator';
import { ChevronRight, Bell, ShieldCheck } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { activeTab, settings, invoices } = useApp();

  const totalOutstanding = invoices.reduce((sum, inv) => sum + getInvoiceBalance(inv), 0);

  const getTabTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return 'Dashboard';
      case 'customers':
        return 'Customers';
      case 'invoices':
        return 'Invoices & Payments';
      case 'followups':
        return 'Follow-up Scheduler';
      case 'reports':
        return 'Reports & Cashflow';
      case 'settings':
        return 'Business Settings';
      default:
        return 'Dashboard';
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 text-slate-900 font-sans">
      {/* Desktop Sidebar (hidden on mobile) */}
      <div className="hidden lg:flex shrink-0">
        <Sidebar />
      </div>

      {/* Main Viewport */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden">
        {/* Mobile Header (visible only on mobile) */}
        <MobileHeader />

        {/* Desktop Top Header Bar Contract */}
        <header className="hidden lg:flex items-center justify-between gap-6 px-8 py-3.5 bg-white border-b border-slate-200 shrink-0">
          {/* Breadcrumb Trail */}
          <div className="flex items-center gap-2 text-xs font-medium text-slate-500 min-w-0">
            <span className="text-slate-900 font-semibold truncate">
              {settings.businessName || 'FollowUp Desk'}
            </span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="text-blue-600 font-semibold">{getTabTitle()}</span>
          </div>

          {/* Right Header Status strip */}
          <div className="flex items-center gap-4 shrink-0">
            <div className="flex items-center gap-2 text-xs py-1 px-2.5 rounded-lg bg-slate-50 border border-slate-200">
              <span className="text-slate-500 font-medium">Currency:</span>
              <span className="font-bold text-slate-900 font-mono">{settings.currency}</span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-500 font-medium">Outstanding:</span>
              <span
                className={`font-bold tabular-nums ${
                  totalOutstanding > 0 ? 'text-rose-600' : 'text-slate-900'
                }`}
              >
                {formatCurrency(totalOutstanding, settings.currency)}
              </span>
            </div>
          </div>
        </header>

        {/* Scrollable Main Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && <DashboardView />}
            {activeTab === 'customers' && <CustomersView />}
            {activeTab === 'invoices' && <InvoicesView />}
            {activeTab === 'followups' && <FollowUpsView />}
            {activeTab === 'reports' && <ReportsView />}
            {activeTab === 'settings' && <SettingsView />}
          </div>
        </main>
      </div>

      {/* Global Modals & Notifications */}
      <CustomerModal />
      <InvoiceModal />
      <PaymentModal />
      <FollowUpModal />
      <WhatsAppModal />
      <ImportModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
