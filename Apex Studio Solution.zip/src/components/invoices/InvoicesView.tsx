import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileText,
  Search,
  Plus,
  Download,
  Filter,
  ArrowUpDown,
  DollarSign,
  MessageSquare,
  Eye,
  Edit2,
  Trash2,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Receipt,
} from 'lucide-react';
import { Invoice, InvoiceStatus } from '../../types';
import { formatCurrency } from '../../utils/currency';
import { formatDate, getDaysOverdue } from '../../utils/date';
import {
  getInvoicePaidAmount,
  getInvoiceBalance,
  getInvoiceEffectiveStatus,
} from '../../utils/invoiceCalculator';
import { exportInvoicesToCSV } from '../../utils/csv';
import { StatusBadge } from '../common/StatusBadge';
import { ConfirmDialog } from '../common/ConfirmDialog';

type InvoiceSortOption =
  | 'due_asc'
  | 'due_desc'
  | 'amount_desc'
  | 'amount_asc'
  | 'issue_desc';

export const InvoicesView: React.FC = () => {
  const {
    invoices,
    settings,
    openInvoiceModal,
    openPaymentModal,
    openWhatsAppModal,
    deleteInvoice,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<InvoiceSortOption>('due_asc');
  const [invoiceToDelete, setInvoiceToDelete] = useState<Invoice | null>(null);

  // Filter & Search
  const filteredInvoices = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();

    return invoices.filter((inv) => {
      const effectiveStatus = getInvoiceEffectiveStatus(inv);

      const matchesSearch =
        !q ||
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.customerName.toLowerCase().includes(q) ||
        inv.description.toLowerCase().includes(q);

      const matchesStatus =
        statusFilter === 'All' || effectiveStatus === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [invoices, searchQuery, statusFilter]);

  // Sort
  const sortedInvoices = useMemo(() => {
    return [...filteredInvoices].sort((a, b) => {
      if (sortBy === 'due_asc') return a.dueDate.localeCompare(b.dueDate);
      if (sortBy === 'due_desc') return b.dueDate.localeCompare(a.dueDate);
      if (sortBy === 'issue_desc') return b.issueDate.localeCompare(a.issueDate);
      if (sortBy === 'amount_desc') return (Number(b.amount) || 0) - (Number(a.amount) || 0);
      if (sortBy === 'amount_asc') return (Number(a.amount) || 0) - (Number(b.amount) || 0);
      return 0;
    });
  }, [filteredInvoices, sortBy]);

  const handleExportCSV = () => {
    exportInvoicesToCSV(invoices);
  };

  const handleDeleteConfirm = () => {
    if (invoiceToDelete) {
      deleteInvoice(invoiceToDelete.id);
      setInvoiceToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Invoices & Payments
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Monitor client billing, record partial settlements, and trigger payment reminders.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export Invoices CSV</span>
          </button>

          <button
            onClick={() => openInvoiceModal('create')}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Invoice</span>
          </button>
        </div>
      </div>

      {/* Search, Filter, and Sort Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by invoice #, customer name, or description..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2 text-slate-400 hover:text-slate-600 text-xs"
            >
              Clear
            </button>
          )}
        </div>

        {/* Status Pills / Dropdown */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Status Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1.5 rounded-lg border border-slate-200">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="All">All Statuses</option>
              <option value="Overdue">Overdue</option>
              <option value="Unpaid">Unpaid</option>
              <option value="Partially paid">Partially Paid</option>
              <option value="Paid">Paid</option>
            </select>
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1.5 rounded-lg border border-slate-200">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as InvoiceSortOption)}
              className="bg-transparent text-xs font-medium text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="due_asc">Due Date (Earliest First)</option>
              <option value="due_desc">Due Date (Latest First)</option>
              <option value="amount_desc">Amount (Highest First)</option>
              <option value="amount_asc">Amount (Lowest First)</option>
              <option value="issue_desc">Recently Issued</option>
            </select>
          </div>
        </div>
      </div>

      {/* Invoice List */}
      {sortedInvoices.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">No Invoices Found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {searchQuery || statusFilter !== 'All'
              ? 'No invoices match the specified criteria. Try clearing filters.'
              : 'You have not created any invoices yet. Generate an invoice to begin tracking payments.'}
          </p>
          <div className="mt-4 flex items-center justify-center gap-3">
            {searchQuery || statusFilter !== 'All' ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('All');
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors"
              >
                Reset Filters
              </button>
            ) : (
              <button
                onClick={() => openInvoiceModal('create')}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer transition-colors"
              >
                + Create First Invoice
              </button>
            )}
          </div>
        </div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">Invoice #</th>
                  <th className="py-3 px-4 font-semibold">Customer / Description</th>
                  <th className="py-3 px-4 font-semibold">Due Date</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Total Amount</th>
                  <th className="py-3 px-4 font-semibold text-right">Balance Due</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedInvoices.map((inv) => {
                  const paid = getInvoicePaidAmount(inv);
                  const balance = getInvoiceBalance(inv);
                  const effectiveStatus = getInvoiceEffectiveStatus(inv);
                  const daysOverdue = getDaysOverdue(inv.dueDate);

                  return (
                    <tr
                      key={inv.id}
                      className="hover:bg-slate-50/70 transition-colors group cursor-pointer"
                      onClick={() => openInvoiceModal('view', inv)}
                    >
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                          #{inv.invoiceNumber}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="min-w-0 max-w-xs">
                          <span className="font-bold text-slate-900 block truncate">
                            {inv.customerName}
                          </span>
                          <span className="text-[11px] text-slate-500 block truncate mt-0.5">
                            {inv.description}
                          </span>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div>
                          <span className="text-slate-800 font-medium block">
                            {formatDate(inv.dueDate)}
                          </span>
                          {effectiveStatus === 'Overdue' && (
                            <span className="text-[10px] text-rose-600 font-semibold block">
                              {daysOverdue}d overdue
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <StatusBadge status={effectiveStatus} size="sm" />
                      </td>

                      <td className="py-3 px-4 text-right">
                        <span className="font-semibold text-slate-900 tabular-nums">
                          {formatCurrency(inv.amount, settings.currency)}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div>
                          <span
                            className={`font-bold tabular-nums ${
                              balance > 0 ? 'text-rose-600' : 'text-slate-800'
                            }`}
                          >
                            {formatCurrency(balance, settings.currency)}
                          </span>
                          {paid > 0 && balance > 0 && (
                            <span className="text-[10px] text-emerald-600 block tabular-nums">
                              Paid {formatCurrency(paid, settings.currency)}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          {balance > 0 && (
                            <>
                              <button
                                onClick={() => openWhatsAppModal(inv)}
                                className="p-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
                                title="Prepare WhatsApp Reminder"
                              >
                                <MessageSquare className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => openPaymentModal(inv)}
                                className="px-2 py-1 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors"
                                title="Record Payment"
                              >
                                Pay
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => openInvoiceModal('edit', inv)}
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
                            title="Edit Invoice"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setInvoiceToDelete(inv)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                            title="Delete Invoice"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile Card List */}
          <div className="md:hidden space-y-3">
            {sortedInvoices.map((inv) => {
              const paid = getInvoicePaidAmount(inv);
              const balance = getInvoiceBalance(inv);
              const effectiveStatus = getInvoiceEffectiveStatus(inv);
              const daysOverdue = getDaysOverdue(inv.dueDate);

              return (
                <div
                  key={inv.id}
                  onClick={() => openInvoiceModal('view', inv)}
                  className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3 cursor-pointer text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-900">
                          #{inv.invoiceNumber}
                        </span>
                        <StatusBadge status={effectiveStatus} size="sm" />
                      </div>
                      <h4 className="font-bold text-slate-800 text-sm mt-1">
                        {inv.customerName}
                      </h4>
                      <p className="text-slate-500 text-[11px] truncate">{inv.description}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block uppercase">Balance</span>
                      <span
                        className={`text-sm font-bold tabular-nums ${
                          balance > 0 ? 'text-rose-600' : 'text-slate-800'
                        }`}
                      >
                        {formatCurrency(balance, settings.currency)}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 rounded-lg text-[11px]">
                    <div>
                      <span className="text-slate-500 block">Due Date</span>
                      <span className="text-slate-800 font-medium">
                        {formatDate(inv.dueDate)}
                        {effectiveStatus === 'Overdue' && ` (${daysOverdue}d)`}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Total Invoiced</span>
                      <span className="text-slate-800 font-semibold tabular-nums">
                        {formatCurrency(inv.amount, settings.currency)}
                      </span>
                    </div>
                  </div>

                  <div
                    className="flex items-center justify-between pt-1 border-t border-slate-100"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <span className="text-[11px] text-slate-400">
                      Issued: {formatDate(inv.issueDate)}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {balance > 0 && (
                        <>
                          <button
                            onClick={() => openWhatsAppModal(inv)}
                            className="p-1.5 text-emerald-600 bg-emerald-50 rounded-md"
                            title="WhatsApp"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => openPaymentModal(inv)}
                            className="px-2.5 py-1 text-xs font-semibold text-white bg-blue-600 rounded-md"
                          >
                            Pay
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => openInvoiceModal('edit', inv)}
                        className="p-1.5 text-slate-500 hover:text-slate-800 rounded"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={Boolean(invoiceToDelete)}
        title="Delete Invoice Record?"
        message={`Are you sure you want to delete Invoice #${invoiceToDelete?.invoiceNumber}? All recorded payment entries for this invoice will be removed.`}
        confirmLabel="Delete Invoice"
        isDestructive
        onConfirm={handleDeleteConfirm}
        onCancel={() => setInvoiceToDelete(null)}
      />
    </div>
  );
};
