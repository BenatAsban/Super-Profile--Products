import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  ArrowUpDown,
  Phone,
  Mail,
  Building,
  Eye,
  Edit2,
  Trash2,
  FilePlus,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Customer, CustomerCategory } from '../../types';
import { formatCurrency } from '../../utils/currency';
import { formatDate } from '../../utils/date';
import { getInvoiceBalance } from '../../utils/invoiceCalculator';
import { exportCustomersToCSV } from '../../utils/csv';
import { ConfirmDialog } from '../common/ConfirmDialog';

type SortOption = 'name_asc' | 'name_desc' | 'balance_desc' | 'date_desc' | 'date_asc';

export const CustomersView: React.FC = () => {
  const {
    customers,
    invoices,
    followUps,
    settings,
    openCustomerModal,
    openInvoiceModal,
    openFollowUpModal,
    openImportModal,
    deleteCustomer,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<SortOption>('name_asc');
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);

  // Compute pending balance per customer
  const customerBalanceMap = useMemo(() => {
    const map = new Map<string, number>();
    customers.forEach((c) => {
      const custInvoices = invoices.filter((i) => i.customerId === c.id);
      const totalBal = custInvoices.reduce((sum, i) => sum + getInvoiceBalance(i), 0);
      map.set(c.id, totalBal);
    });
    return map;
  }, [customers, invoices]);

  // Compute next follow-up per customer
  const customerNextFollowUpMap = useMemo(() => {
    const map = new Map<string, string>();
    customers.forEach((c) => {
      const pendingF = followUps
        .filter((f) => f.customerId === c.id && !f.completed)
        .sort((a, b) => a.date.localeCompare(b.date))[0];
      if (pendingF) {
        map.set(c.id, pendingF.date);
      }
    });
    return map;
  }, [customers, followUps]);

  // Filter & Search
  const filteredCustomers = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();

    return customers.filter((c) => {
      const matchesSearch =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.businessName.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q);

      const matchesCat =
        selectedCategory === 'All' || c.category === selectedCategory;

      return matchesSearch && matchesCat;
    });
  }, [customers, searchQuery, selectedCategory]);

  // Sort
  const sortedCustomers = useMemo(() => {
    return [...filteredCustomers].sort((a, b) => {
      if (sortBy === 'name_asc') return a.name.localeCompare(b.name);
      if (sortBy === 'name_desc') return b.name.localeCompare(a.name);
      if (sortBy === 'balance_desc') {
        const balA = customerBalanceMap.get(a.id) || 0;
        const balB = customerBalanceMap.get(b.id) || 0;
        return balB - balA;
      }
      if (sortBy === 'date_desc') return b.createdAt.localeCompare(a.createdAt);
      if (sortBy === 'date_asc') return a.createdAt.localeCompare(b.createdAt);
      return 0;
    });
  }, [filteredCustomers, sortBy, customerBalanceMap]);

  const handleExportCSV = () => {
    exportCustomersToCSV(customers, invoices);
  };

  const handleDeleteConfirm = () => {
    if (customerToDelete) {
      deleteCustomer(customerToDelete.id);
      setCustomerToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Customer Directory
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Manage client profiles, contact credentials, outstanding debts, and billing history.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={openImportModal}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Upload className="w-3.5 h-3.5 text-slate-500" />
            <span>Import CSV</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => openCustomerModal('create')}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Customer</span>
          </button>
        </div>
      </div>

      {/* Search, Category Filter, and Sorting Controls */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by customer name, business, phone, or email..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2 text-slate-400 hover:text-slate-600 text-xs"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter and Sort Group */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Category Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1.5 rounded-lg border border-slate-200">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="All">All Categories</option>
              <option value="Corporate">Corporate</option>
              <option value="Wholesale">Wholesale</option>
              <option value="Retail">Retail</option>
              <option value="Service">Service</option>
              <option value="Individual">Individual</option>
            </select>
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1.5 rounded-lg border border-slate-200">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="bg-transparent text-xs font-medium text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="name_asc">Name (A → Z)</option>
              <option value="name_desc">Name (Z → A)</option>
              <option value="balance_desc">Highest Balance Due</option>
              <option value="date_desc">Newest Added</option>
              <option value="date_asc">Oldest Added</option>
            </select>
          </div>
        </div>
      </div>

      {/* Customer Records Table / Card Grid */}
      {sortedCustomers.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">No Customers Found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {searchQuery || selectedCategory !== 'All'
              ? 'No customer records match your filter criteria. Try resetting search filters.'
              : 'Your customer database is empty. Add your first customer or import a CSV file to get started.'}
          </p>
          <div className="mt-4 flex items-center justify-center gap-3">
            {searchQuery || selectedCategory !== 'All' ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer transition-colors"
              >
                Reset Filters
              </button>
            ) : (
              <button
                onClick={() => openCustomerModal('create')}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer transition-colors"
              >
                + Add First Customer
              </button>
            )}
          </div>
        </div>
      ) : (
        <>
          {/* Desktop Table View */}
          <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">Customer / Business</th>
                  <th className="py-3 px-4 font-semibold">Contact Info</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold">Next Follow-up</th>
                  <th className="py-3 px-4 font-semibold text-right">Outstanding Balance</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedCustomers.map((c) => {
                  const balance = customerBalanceMap.get(c.id) || 0;
                  const nextDate = customerNextFollowUpMap.get(c.id);

                  return (
                    <tr
                      key={c.id}
                      className="hover:bg-slate-50/70 transition-colors group cursor-pointer"
                      onClick={() => openCustomerModal('view', c)}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {c.name.slice(0, 1)}
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 block truncate group-hover:text-blue-600 transition-colors">
                              {c.name}
                            </span>
                            <span className="text-[11px] text-slate-500 truncate block">
                              {c.businessName}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1.5 text-slate-700 font-mono text-[11px]">
                            <Phone className="w-3 h-3 text-slate-400" />
                            <span>{c.phone || '—'}</span>
                          </div>
                          {c.email && (
                            <div className="flex items-center gap-1.5 text-slate-500 text-[11px] truncate max-w-[180px]">
                              <Mail className="w-3 h-3 text-slate-400" />
                              <span className="truncate">{c.email}</span>
                            </div>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="inline-block px-2 py-0.5 text-[11px] font-medium bg-slate-100 text-slate-700 rounded-md">
                          {c.category}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        {nextDate ? (
                          <span className="text-[11px] text-blue-700 font-medium bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200/50">
                            {formatDate(nextDate)}
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400">None scheduled</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <span
                          className={`font-bold tabular-nums text-xs ${
                            balance > 0 ? 'text-rose-600' : 'text-slate-800'
                          }`}
                        >
                          {formatCurrency(balance, settings.currency)}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openInvoiceModal('create', undefined, c.id)}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                            title="Create Invoice for Customer"
                          >
                            <FilePlus className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => openFollowUpModal('create', undefined, c.id)}
                            className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-md transition-colors"
                            title="Schedule Follow-up"
                          >
                            <Clock className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => openCustomerModal('edit', c)}
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
                            title="Edit Profile"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setCustomerToDelete(c)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                            title="Delete Customer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile Card View */}
          <div className="md:hidden space-y-3">
            {sortedCustomers.map((c) => {
              const balance = customerBalanceMap.get(c.id) || 0;
              const nextDate = customerNextFollowUpMap.get(c.id);

              return (
                <div
                  key={c.id}
                  onClick={() => openCustomerModal('view', c)}
                  className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3 cursor-pointer text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                        {c.name.slice(0, 1)}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm leading-tight">
                          {c.name}
                        </h4>
                        <p className="text-slate-500 text-[11px]">{c.businessName}</p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 text-[10px] font-medium bg-slate-100 text-slate-700 rounded">
                      {c.category}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 rounded-lg text-[11px]">
                    <div>
                      <span className="text-slate-500 block">Phone</span>
                      <span className="text-slate-800 font-mono font-medium truncate block">
                        {c.phone || '—'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Outstanding</span>
                      <span
                        className={`font-bold tabular-nums block ${
                          balance > 0 ? 'text-rose-600' : 'text-slate-800'
                        }`}
                      >
                        {formatCurrency(balance, settings.currency)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-100" onClick={(e) => e.stopPropagation()}>
                    <span className="text-[11px] text-slate-500">
                      {nextDate ? `Follow-up: ${formatDate(nextDate)}` : 'No follow-up set'}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => openInvoiceModal('create', undefined, c.id)}
                        className="px-2 py-1 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-md"
                      >
                        + Invoice
                      </button>
                      <button
                        onClick={() => openCustomerModal('edit', c)}
                        className="p-1 text-slate-500 hover:text-slate-800 rounded"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={Boolean(customerToDelete)}
        title="Delete Customer Account?"
        message={`Are you sure you want to delete ${customerToDelete?.name}? Associated invoices and follow-up tasks will also be erased.`}
        confirmLabel="Delete Customer"
        isDestructive
        onConfirm={handleDeleteConfirm}
        onCancel={() => setCustomerToDelete(null)}
      />
    </div>
  );
};
