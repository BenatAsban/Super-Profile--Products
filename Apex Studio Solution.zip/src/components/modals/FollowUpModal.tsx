import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Clock, Calendar, AlertCircle, Trash2, CheckCircle2 } from 'lucide-react';
import { FollowUp, FollowUpType, PriorityLevel } from '../../types';
import { todayISO } from '../../utils/date';
import { ConfirmDialog } from '../common/ConfirmDialog';

export const FollowUpModal: React.FC = () => {
  const {
    followUpModalState,
    closeFollowUpModal,
    customers,
    invoices,
    addFollowUp,
    updateFollowUp,
    deleteFollowUp,
  } = useApp();

  const { isOpen, mode, followUp, preselectedCustomerId, preselectedInvoiceId } =
    followUpModalState;

  const [customerId, setCustomerId] = useState('');
  const [invoiceId, setInvoiceId] = useState('');
  const [date, setDate] = useState(todayISO());
  const [type, setType] = useState<FollowUpType>('Payment Reminder');
  const [priority, setPriority] = useState<PriorityLevel>('High');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState('');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    if (mode === 'create') {
      const defaultCust = preselectedCustomerId || (customers.length > 0 ? customers[0].id : '');
      setCustomerId(defaultCust);
      setInvoiceId(preselectedInvoiceId || '');
      setDate(todayISO());
      setType('Payment Reminder');
      setPriority('High');
      setNotes('');
      setFormError('');
    } else if (followUp) {
      setCustomerId(followUp.customerId);
      setInvoiceId(followUp.invoiceId || '');
      setDate(followUp.date);
      setType(followUp.type);
      setPriority(followUp.priority);
      setNotes(followUp.notes);
      setFormError('');
    }
  }, [isOpen, mode, followUp, preselectedCustomerId, preselectedInvoiceId, customers]);

  if (!isOpen) return null;

  // Filter invoices for the chosen customer
  const customerInvoices = invoices.filter((i) => i.customerId === customerId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!customerId) {
      setFormError('Please select a customer.');
      return;
    }

    if (!notes.trim()) {
      setFormError('Please enter follow-up task notes or instructions.');
      return;
    }

    const matchedCustomer = customers.find((c) => c.id === customerId);
    const customerName = matchedCustomer ? matchedCustomer.name : 'Unknown';

    let invoiceNumber: string | undefined = undefined;
    if (invoiceId) {
      const matchedInv = invoices.find((i) => i.id === invoiceId);
      if (matchedInv) {
        invoiceNumber = matchedInv.invoiceNumber;
      }
    }

    if (mode === 'create') {
      addFollowUp({
        customerId,
        customerName,
        invoiceId: invoiceId || undefined,
        invoiceNumber,
        date,
        type,
        priority,
        notes: notes.trim(),
      });
      closeFollowUpModal();
    } else if (mode === 'edit' && followUp) {
      updateFollowUp(followUp.id, {
        customerId,
        customerName,
        invoiceId: invoiceId || undefined,
        invoiceNumber,
        date,
        type,
        priority,
        notes: notes.trim(),
      });
      closeFollowUpModal();
    }
  };

  const handleDelete = () => {
    if (followUp) {
      deleteFollowUp(followUp.id);
      setDeleteConfirmOpen(false);
      closeFollowUpModal();
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
        role="dialog"
        aria-modal="true"
      >
        <div className="bg-white rounded-xl max-w-lg w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {mode === 'create' ? 'Schedule Follow-up' : 'Edit Follow-up'}
                </h2>
                <p className="text-xs text-slate-500">
                  Set reminders for overdue invoices, calls, or client meetings
                </p>
              </div>
            </div>
            <button
              onClick={closeFollowUpModal}
              className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
            {formError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Customer & Related Invoice */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Customer <span className="text-rose-500">*</span>
                </label>
                <select
                  required
                  value={customerId}
                  onChange={(e) => {
                    setCustomerId(e.target.value);
                    setInvoiceId(''); // reset invoice link on customer change
                  }}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
                >
                  <option value="" disabled>
                    Select customer...
                  </option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.businessName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Related Invoice (Optional)
                </label>
                <select
                  value={invoiceId}
                  onChange={(e) => setInvoiceId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
                >
                  <option value="">None / General</option>
                  {customerInvoices.map((inv) => (
                    <option key={inv.id} value={inv.id}>
                      #{inv.invoiceNumber} ({inv.status} - {inv.description})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Date, Type & Priority */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Follow-up Date <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Follow-up Channel
                </label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as FollowUpType)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
                >
                  <option value="Payment Reminder">Payment Reminder</option>
                  <option value="WhatsApp">WhatsApp</option>
                  <option value="Phone Call">Phone Call</option>
                  <option value="Email">Email</option>
                  <option value="Meeting">Meeting</option>
                  <option value="General">General Note</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Priority
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
                >
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>

            {/* Notes / Action Items */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Task Instructions / Agenda <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={4}
                required
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Call client regarding overdue balance, confirm NEFT reference, review draft scope"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              {mode === 'edit' ? (
                <button
                  type="button"
                  onClick={() => setDeleteConfirmOpen(true)}
                  className="px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              ) : (
                <div />
              )}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={closeFollowUpModal}
                  className="px-4 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  {mode === 'create' ? 'Schedule Follow-up' : 'Save Changes'}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        isOpen={deleteConfirmOpen}
        title="Delete Follow-up Task?"
        message="Are you sure you want to delete this scheduled follow-up?"
        confirmLabel="Delete Task"
        isDestructive
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirmOpen(false)}
      />
    </>
  );
};
