import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Send,
  Copy,
  Check,
  AlertCircle,
  ExternalLink,
  MessageSquare,
  Sparkles,
  Phone,
} from 'lucide-react';
import {
  generateReminderMessage,
  validateAndCleanPhoneNumber,
  buildWhatsAppUrl,
  ReminderTemplateType,
} from '../../utils/whatsapp';
import { getInvoiceBalance } from '../../utils/invoiceCalculator';
import { formatCurrency } from '../../utils/currency';
import { formatDate } from '../../utils/date';

export const WhatsAppModal: React.FC = () => {
  const { whatsAppModalState, closeWhatsAppModal, settings, customers, addToast } = useApp();
  const { isOpen, invoice } = whatsAppModalState;

  const [template, setTemplate] = useState<ReminderTemplateType>('polite');
  const [customMessage, setCustomMessage] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [copied, setCopied] = useState(false);

  // Sync when invoice changes
  useEffect(() => {
    if (invoice && isOpen) {
      // Find customer phone
      const customer = customers.find((c) => c.id === invoice.customerId);
      const initialPhone = customer?.phone || '';
      setPhoneNumber(initialPhone);

      // Default template based on invoice state
      const balance = getInvoiceBalance(invoice);
      const isOverdue = invoice.status === 'Overdue';
      const initialTpl: ReminderTemplateType = isOverdue ? 'overdue' : 'polite';
      setTemplate(initialTpl);
      setCustomMessage(generateReminderMessage(initialTpl, invoice, settings));
    }
  }, [invoice, isOpen, settings, customers]);

  if (!isOpen || !invoice) return null;

  const balance = getInvoiceBalance(invoice);
  const phoneValidation = validateAndCleanPhoneNumber(phoneNumber, settings.defaultCountryCode);

  const handleTemplateChange = (newTpl: ReminderTemplateType) => {
    setTemplate(newTpl);
    setCustomMessage(generateReminderMessage(newTpl, invoice, settings));
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(customMessage);
      setCopied(true);
      addToast({
        type: 'success',
        title: 'Copied to Clipboard',
        message: 'Reminder message copied.',
      });
      setTimeout(() => setCopied(false), 2500);
    } catch {
      addToast({
        type: 'error',
        title: 'Copy Failed',
        message: 'Please select the text manually and press Ctrl+C / Cmd+C.',
      });
    }
  };

  const handleOpenWhatsApp = () => {
    if (!phoneValidation.isValid) {
      addToast({
        type: 'error',
        title: 'Invalid Phone Number',
        message: phoneValidation.error || 'Please enter a valid phone number with country code.',
      });
      return;
    }

    const url = buildWhatsAppUrl(phoneValidation.rawCleaned, customMessage);
    // WhatsApp click-to-chat must open externally
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white rounded-xl max-w-xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                WhatsApp Payment Reminder
              </h2>
              <p className="text-xs text-slate-500">
                Invoice #{invoice.invoiceNumber} · {invoice.customerName}
              </p>
            </div>
          </div>
          <button
            onClick={closeWhatsAppModal}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          {/* Summary Strip */}
          <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200/70 text-xs">
            <div>
              <span className="text-slate-500 block">Total Due</span>
              <span className="font-semibold text-slate-900 tabular-nums">
                {formatCurrency(balance, settings.currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Due Date</span>
              <span className="font-semibold text-slate-900">
                {formatDate(invoice.dueDate)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Status</span>
              <span
                className={`font-semibold ${
                  invoice.status === 'Overdue' ? 'text-rose-600' : 'text-slate-800'
                }`}
              >
                {invoice.status}
              </span>
            </div>
          </div>

          {/* Recipient Phone */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Recipient WhatsApp Phone
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+91 98765 43210 (include country code)"
                className={`w-full pl-9 pr-3 py-2 text-sm rounded-lg border focus:outline-none transition-colors ${
                  phoneValidation.isValid
                    ? 'border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500'
                    : 'border-rose-300 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 bg-rose-50/20'
                }`}
              />
            </div>
            {!phoneValidation.isValid && phoneNumber.length > 0 && (
              <p className="text-xs text-rose-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {phoneValidation.error}
              </p>
            )}
            {phoneValidation.isValid && (
              <p className="text-[11px] text-slate-500 mt-1">
                Formatted destination: <span className="font-mono text-slate-700 font-semibold">{phoneValidation.displayFormatted}</span>
              </p>
            )}
          </div>

          {/* Template Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
              <span>Message Tone & Template</span>
              <span className="text-[11px] text-slate-500 font-normal">Click to reload preset</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'polite', label: 'Polite' },
                { id: 'due_soon', label: 'Due Soon' },
                { id: 'overdue', label: 'Overdue' },
                { id: 'urgent', label: 'Urgent' },
              ].map((tpl) => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => handleTemplateChange(tpl.id as ReminderTemplateType)}
                  className={`py-1.5 px-3 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                    template === tpl.id
                      ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-2xs font-semibold'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {tpl.label}
                </button>
              ))}
            </div>
          </div>

          {/* Editable Draft */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">
                Draft Message Content
              </label>
              <button
                type="button"
                onClick={handleCopy}
                className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1 cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Text</span>
                  </>
                )}
              </button>
            </div>
            <textarea
              rows={6}
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="w-full p-3 text-xs leading-relaxed font-sans text-slate-800 bg-slate-50/50 border border-slate-200 rounded-lg focus:outline-none focus:bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-y"
              placeholder="Type or customize your payment reminder..."
            />
          </div>

          {/* Verification / Security Notice */}
          <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-lg flex items-start gap-2.5 text-xs text-amber-900 leading-relaxed">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-900">Manual User Review</p>
              <p className="text-amber-800 text-[11px] mt-0.5">
                Clicking &quot;Open WhatsApp Chat&quot; opens WhatsApp with your prefilled message.
                Messages are <strong>never</strong> sent automatically — you retain full control to inspect, edit, and hit send in your WhatsApp client.
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={closeWhatsAppModal}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Cancel
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopy}
              className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenWhatsApp}
              disabled={!phoneValidation.isValid}
              className={`px-4 py-2 text-xs font-semibold rounded-lg text-white flex items-center gap-1.5 transition-colors cursor-pointer ${
                phoneValidation.isValid
                  ? 'bg-emerald-600 hover:bg-emerald-700 shadow-xs shadow-emerald-200'
                  : 'bg-slate-300 cursor-not-allowed text-slate-500'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>Open WhatsApp Chat</span>
              <ExternalLink className="w-3 h-3 opacity-80" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
