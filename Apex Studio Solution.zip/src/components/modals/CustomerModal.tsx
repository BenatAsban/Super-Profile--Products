import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  User,
  Building,
  Phone,
  Mail,
  Tag,
  Plus,
  Trash2,
  Edit2,
  Calendar,
  FileText,
  Clock,
  AlertCircle,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';
import { Customer, CustomerCategory } from '../../types';
import { formatCurrency } from '../../utils/currency';
import { formatDate } from '../../utils/date';
import { getInvoiceBalance, getInvoiceEffectiveStatus } from '../../utils/invoiceCalculator';
import { StatusBadge } from '../common/StatusBadge';
import { ConfirmDialog } from '../common/ConfirmDialog';

export const CustomerModal: React.FC = () => {
  const {
    customerModalState,
    closeCustomerModal,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    invoices,
    followUps,
    openInvoiceModal,
    openFollowUpModal,
    openWhatsAppModal,
    toggleFollowUpComplete,
    settings,
  } = useApp();

  const { isOpen, mode, customer } = customerModalState;

  // Form states
  const [name, setName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState<CustomerCategory>('Corporate');
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState('');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    if (mode === 'create') {
      setName('');
      setBusinessName('');
      setPhone('');
      setEmail('');
      setCategory('Corporate');
      setNotes('');
      setFormError('');
    } else if (customer) {
      setName(customer.name);
      setBusinessName(customer.businessName);
      setPhone(customer.phone);
      setEmail(customer.email);
      setCategory(customer.category);
      setNotes(customer.notes || '');
      setFormError('');
    }
  }, [isOpen, mode, customer]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!name.trim()) {
      setFormError('Customer name is required.');
      return;
    }

    if (!phone.trim()) {
      setFormError('Phone number is required.');
      return;
    }

    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setFormError('Please provide a valid email address.');
      return;
    }

    const payload = {
      name: name.trim(),
      businessName: businessName.trim() || name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      category,
      notes: notes.trim() || undefined,
    };

    if (mode === 'create') {
      addCustomer(payload);
      closeCustomerModal();
    } else if (mode === 'edit' && customer) {
      updateCustomer(customer.id, payload);
      closeCustomerModal();
    }
  };

  const handleDelete = () => {
    if (customer) {
      deleteCustomer(customer.id);
      setDeleteConfirmOpen(false);
      closeCustomerModal();
    }
  };

  // View Mode
  if (mode === 'view' && customer) {
    const custInvoices = invoices.filter((i) => i.customerId === customer.id);
    const custFollowUps = followUps.filter((f) => f.customerId === customer.id);

    const totalInvoiced = custInvoices.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
    const totalBalance = custInvoices.reduce((sum, i) => sum + getInvoiceBalance(i), 0);
    const nextFollowUp = custFollowUps
      .filter((f) => !f.completed)
      .sort((a, b) => a.date.localeCompare(b.date))[0];

    return (
      <>
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl max-w-2xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-base">
                  {customer.name.slice(0, 1)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-900">{customer.name}</h2>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium">
                      {customer.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {customer.businessName} · Client since {formatDate(customer.createdAt)}
                  </p>
                </div>
              </div>
              <button
                onClick={closeCustomerModal}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-5 overflow-y-auto flex-1 text-slate-800">
              {/* Contact & Financial Summary */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200/70 space-y-1.5 text-xs">
                  <span className="font-semibold text-slate-500 uppercase tracking-wider block">
                    Contact Details
                  </span>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{customer.phone || 'No phone'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{customer.email || 'No email'}</span>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200/70 text-xs">
                  <span className="font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                    Financial Balance
                  </span>
                  <div className="flex items-center justify-between py-0.5">
                    <span className="text-slate-500">Total Billed:</span>
                    <span className="font-bold text-slate-900 tabular-nums">
                      {formatCurrency(totalInvoiced, settings.currency)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-0.5">
                    <span className="text-slate-500">Balance Pending:</span>
                    <span
                      className={`font-bold tabular-nums ${
                        totalBalance > 0 ? 'text-rose-600' : 'text-slate-900'
                      }`}
                    >
                      {formatCurrency(totalBalance, settings.currency)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Notes */}
              {customer.notes && (
                <div className="text-xs bg-slate-50/70 p-3 rounded-lg border border-slate-200">
                  <span className="font-semibold text-slate-700 block mb-0.5">Notes & Client Preferences:</span>
                  <p className="text-slate-600 leading-relaxed">{customer.notes}</p>
                </div>
              )}

              {/* Next Scheduled Follow-up Alert */}
              {nextFollowUp && (
                <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-lg flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <Clock className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <span className="font-semibold text-blue-900">
                        Next Follow-up: {formatDate(nextFollowUp.date)} ({nextFollowUp.type})
                      </span>
                      <p className="text-blue-700 text-[11px] mt-0.5">{nextFollowUp.notes}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Invoices List */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-slate-400" />
                    <span>Invoices ({custInvoices.length})</span>
                  </h4>
                  <button
                    onClick={() => {
                      closeCustomerModal();
                      openInvoiceModal('create', undefined, customer.id);
                    }}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Invoice</span>
                  </button>
                </div>

                {custInvoices.length === 0 ? (
                  <div className="text-center py-4 bg-slate-50 rounded-lg border border-dashed border-slate-200 text-xs text-slate-500">
                    No invoices generated for this client yet.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-44 overflow-y-auto">
                    {custInvoices.map((inv) => {
                      const balance = getInvoiceBalance(inv);
                      const status = getInvoiceEffectiveStatus(inv);
                      return (
                        <div
                          key={inv.id}
                          className="flex items-center justify-between p-2.5 bg-white border border-slate-200 rounded-lg text-xs hover:border-slate-300 transition-colors"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900 font-mono">
                                #{inv.invoiceNumber}
                              </span>
                              <StatusBadge status={status} size="sm" />
                            </div>
                            <p className="text-[11px] text-slate-500 truncate mt-0.5">
                              Due: {formatDate(inv.dueDate)} · {inv.description}
                            </p>
                          </div>
                          <div className="flex items-center gap-3 shrink-0 ml-3">
                            <div className="text-right">
                              <div className="font-semibold text-slate-900 tabular-nums">
                                {formatCurrency(inv.amount, settings.currency)}
                              </div>
                              {balance > 0 && (
                                <div className="text-[11px] font-semibold text-rose-600 tabular-nums">
                                  Bal: {formatCurrency(balance, settings.currency)}
                                </div>
                              )}
                            </div>
                            <button
                              onClick={() => {
                                closeCustomerModal();
                                openInvoiceModal('view', inv);
                              }}
                              className="p-1 text-slate-400 hover:text-blue-600 rounded"
                              title="View Invoice"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </button>
                            {balance > 0 && (
                              <button
                                onClick={() => openWhatsAppModal(inv)}
                                className="p-1 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded"
                                title="WhatsApp Reminder"
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Follow-ups Timeline */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-slate-400" />
                    <span>Follow-up History ({custFollowUps.length})</span>
                  </h4>
                  <button
                    onClick={() => {
                      closeCustomerModal();
                      openFollowUpModal('create', undefined, customer.id);
                    }}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Schedule Follow-up</span>
                  </button>
                </div>

                {custFollowUps.length === 0 ? (
                  <div className="text-center py-4 bg-slate-50 rounded-lg border border-dashed border-slate-200 text-xs text-slate-500">
                    No follow-ups recorded.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {custFollowUps.map((fol) => (
                      <div
                        key={fol.id}
                        className={`flex items-start gap-2.5 p-2.5 rounded-lg border text-xs transition-colors ${
                          fol.completed
                            ? 'bg-slate-50/60 border-slate-200/60 text-slate-500'
                            : 'bg-white border-slate-200 text-slate-800'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={fol.completed}
                          onChange={() => toggleFollowUpComplete(fol.id)}
                          className="mt-0.5 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span
                              className={`font-semibold ${
                                fol.completed ? 'line-through text-slate-400' : 'text-slate-900'
                              }`}
                            >
                              {fol.type}
                            </span>
                            <span className="text-[11px] text-slate-500">· {formatDate(fol.date)}</span>
                            {fol.invoiceNumber && (
                              <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded">
                                #{fol.invoiceNumber}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] mt-0.5 leading-relaxed">{fol.notes}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setDeleteConfirmOpen(true)}
                className="px-3 py-2 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Customer</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    closeCustomerModal();
                    setTimeout(() => {
                      updateCustomer(customer.id, {});
                    }, 50);
                  }}
                  className="px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit Profile</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    closeCustomerModal();
                    openInvoiceModal('create', undefined, customer.id);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Invoice</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <ConfirmDialog
          isOpen={deleteConfirmOpen}
          title="Delete Customer & Records?"
          message={`Are you sure you want to delete ${customer.name}? All invoices and follow-ups associated with this customer will also be deleted.`}
          confirmLabel="Delete Customer"
          isDestructive
          onConfirm={handleDelete}
          onCancel={() => setDeleteConfirmOpen(false)}
        />
      </>
    );
  }

  // Create / Edit Form
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white rounded-xl max-w-lg w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {mode === 'create' ? 'Add New Customer' : 'Edit Customer'}
              </h2>
              <p className="text-xs text-slate-500">
                {mode === 'create'
                  ? 'Add a contact to manage invoices & follow-ups'
                  : `Editing ${customer?.name}`}
              </p>
            </div>
          </div>
          <button
            onClick={closeCustomerModal}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* Customer Name & Business Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Customer / Contact Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Vikramaditya Singhania"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Business / Organization Name
              </label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g. Singhania Retail Logistics"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Phone & Email */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Phone Number <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98201 54321"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="billing@example.com"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Customer Category <span className="text-rose-500">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as CustomerCategory)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
            >
              <option value="Corporate">Corporate / Enterprise</option>
              <option value="Wholesale">Wholesale / Distributor</option>
              <option value="Retail">Retail Merchant</option>
              <option value="Service">Service / Agency</option>
              <option value="Individual">Individual / Freelancer</option>
            </select>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Notes & Preferences (Optional)
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Preferred billing cycle, WhatsApp contact preference, PO required"
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={closeCustomerModal}
              className="px-4 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              {mode === 'create' ? 'Add Customer' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
