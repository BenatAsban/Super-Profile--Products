import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Upload,
  Download,
  AlertCircle,
  CheckCircle2,
  FileSpreadsheet,
  AlertTriangle,
} from 'lucide-react';
import { parseCustomerCSV, generateSampleCustomerCSV, CSVParseResult } from '../../utils/csv';

export const ImportModal: React.FC = () => {
  const { importModalOpen, closeImportModal, importCustomers } = useApp();

  const [parseResult, setParseResult] = useState<CSVParseResult | null>(null);
  const [fileName, setFileName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!importModalOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const parsed = parseCustomerCSV(text);
      setParseResult(parsed);
      setIsProcessing(false);
    };
    reader.onerror = () => {
      setIsProcessing(false);
    };
    reader.readAsText(file);
  };

  const handleDownloadSample = () => {
    const csvContent = generateSampleCustomerCSV();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'followupdesk_customers_sample_template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCommitImport = () => {
    if (!parseResult || parseResult.valid.length === 0) return;
    importCustomers(parseResult.valid);
    handleClose();
  };

  const handleClose = () => {
    setParseResult(null);
    setFileName('');
    closeImportModal();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white rounded-xl max-w-2xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Import Customers from CSV
              </h2>
              <p className="text-xs text-slate-500">
                Batch import customer records without overwriting existing data
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1 text-slate-800">
          {/* Instructions & Template Download */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between gap-4">
            <div className="text-xs">
              <h4 className="font-semibold text-slate-900">Required CSV Columns</h4>
              <p className="text-slate-600 mt-0.5">
                Headers supported: <code>Customer Name</code>, <code>Business Name</code>, <code>Phone</code>, <code>Email</code>, <code>Category</code>, <code>Notes</code>.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownloadSample}
              className="px-3 py-1.5 text-xs font-semibold text-blue-600 bg-white border border-blue-200 hover:bg-blue-50 rounded-lg shrink-0 flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Sample CSV</span>
            </button>
          </div>

          {/* File Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Select CSV File
            </label>
            <div className="border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-xl p-6 text-center cursor-pointer transition-colors bg-slate-50/50 hover:bg-slate-50">
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
                id="csv-file-input"
              />
              <label
                htmlFor="csv-file-input"
                className="cursor-pointer flex flex-col items-center justify-center"
              >
                <FileSpreadsheet className="w-8 h-8 text-blue-500 mb-2" />
                <span className="text-xs font-semibold text-slate-800">
                  {fileName ? fileName : 'Click to browse or drop CSV file here'}
                </span>
                <span className="text-[11px] text-slate-500 mt-1">
                  Standard comma-delimited (.csv) files up to 5MB
                </span>
              </label>
            </div>
          </div>

          {/* Parse Results */}
          {parseResult && (
            <div className="space-y-4">
              {/* Status summary */}
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block">Total Rows Found</span>
                  <span className="text-base font-bold text-slate-900 tabular-nums">
                    {parseResult.totalRows}
                  </span>
                </div>
                <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                  <span className="text-emerald-700 block">Valid for Import</span>
                  <span className="text-base font-bold text-emerald-800 tabular-nums">
                    {parseResult.valid.length}
                  </span>
                </div>
                <div className="p-3 bg-rose-50 rounded-lg border border-rose-200">
                  <span className="text-rose-700 block">Errors / Skipped</span>
                  <span className="text-base font-bold text-rose-800 tabular-nums">
                    {parseResult.errors.length}
                  </span>
                </div>
              </div>

              {/* Error messages if any */}
              {parseResult.errors.length > 0 && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs space-y-1 max-h-36 overflow-y-auto">
                  <div className="font-semibold text-rose-800 flex items-center gap-1.5 mb-1">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span>Row Validation Issues:</span>
                  </div>
                  {parseResult.errors.map((err, i) => (
                    <div key={i} className="text-rose-700 text-[11px]">
                      • Row {err.row}: {err.reason}
                    </div>
                  ))}
                </div>
              )}

              {/* Preview of valid rows */}
              {parseResult.valid.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                    Valid Records Preview (First 5 of {parseResult.valid.length})
                  </h4>
                  <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                        <tr>
                          <th className="py-2 px-3 font-semibold">Name</th>
                          <th className="py-2 px-3 font-semibold">Business</th>
                          <th className="py-2 px-3 font-semibold">Phone</th>
                          <th className="py-2 px-3 font-semibold">Category</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {parseResult.valid.slice(0, 5).map((row, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/60">
                            <td className="py-2 px-3 font-medium text-slate-900">{row.name}</td>
                            <td className="py-2 px-3 text-slate-600">{row.businessName}</td>
                            <td className="py-2 px-3 text-slate-600 font-mono text-[11px]">{row.phone}</td>
                            <td className="py-2 px-3 text-slate-600">{row.category}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleCommitImport}
            disabled={!parseResult || parseResult.valid.length === 0}
            className={`px-4 py-2 text-xs font-semibold rounded-lg text-white transition-colors flex items-center gap-1.5 cursor-pointer ${
              parseResult && parseResult.valid.length > 0
                ? 'bg-blue-600 hover:bg-blue-700 shadow-xs shadow-blue-200'
                : 'bg-slate-300 cursor-not-allowed text-slate-500'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>
              {parseResult && parseResult.valid.length > 0
                ? `Import ${parseResult.valid.length} Customers`
                : 'Import Customers'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
