import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  FileText,
  DollarSign,
  Calendar,
  User,
  Plus,
  Trash2,
  Edit2,
  MessageSquare,
  AlertCircle,
  Receipt,
  ArrowRight,
} from 'lucide-react';
import { Invoice, InvoicePayment } from '../../types';
import { getInvoicePaidAmount, getInvoiceBalance, getInvoiceEffectiveStatus } from '../../utils/invoiceCalculator';
import { formatCurrency } from '../../utils/currency';
import { todayISO, addDays, formatDate, getDaysOverdue, isPastDate } from '../../utils/date';
import { StatusBadge } from '../common/StatusBadge';
import { ConfirmDialog } from '../common/ConfirmDialog';

export const InvoiceModal: React.FC = () => {
  const {
    invoiceModalState,
    closeInvoiceModal,
    customers,
    invoices,
    addInvoice,
    updateInvoice,
    deleteInvoice,
    openPaymentModal,
    openWhatsAppModal,
    openCustomerModal,
    settings,
  } = useApp();

  const { isOpen, mode, invoice, preselectedCustomerId } = invoiceModalState;

  // Form states
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [issueDate, setIssueDate] = useState(todayISO());
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [initialPayment, setInitialPayment] = useState('');
  const [initialPaymentMethod, setInitialPaymentMethod] = useState<InvoicePayment['method']>('Bank Transfer');
  const [formError, setFormError] = useState('');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  // Initialize or reset form when modal opens
  useEffect(() => {
    if (!isOpen) return;

    if (mode === 'create') {
      const year = new Date().getFullYear();
      const nextNum = invoices.length + 101;
      setInvoiceNumber(`INV-${year}-${nextNum}`);
      setCustomerId(preselectedCustomerId || (customers.length > 0 ? customers[0].id : ''));
      setDescription('');
      setAmount('');
      const today = todayISO();
      setIssueDate(today);
      setDueDate(addDays(today, settings.defaultPaymentTermsDays || 15));
      setNotes('');
      setInitialPayment('');
      setInitialPaymentMethod('Bank Transfer');
      setFormError('');
    } else if (invoice) {
      setInvoiceNumber(invoice.invoiceNumber);
      setCustomerId(invoice.customerId);
      setDescription(invoice.description);
      setAmount(invoice.amount.toString());
      setIssueDate(invoice.issueDate);
      setDueDate(invoice.dueDate);
      setNotes(invoice.notes || '');
      setInitialPayment('');
      setFormError('');
    }
  }, [isOpen, mode, invoice, preselectedCustomerId, invoices.length, customers, settings]);

  if (!isOpen) return null;

  const currentCustomer = customers.find((c) => c.id === customerId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!invoiceNumber.trim()) {
      setFormError('Invoice number is required.');
      return;
    }

    if (!customerId) {
      setFormError('Please select a customer.');
      return;
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setFormError('Invoice amount must be a positive number.');
      return;
    }

    if (dueDate < issueDate) {
      setFormError('Due date cannot precede the invoice issue date.');
      return;
    }

    const matchedCustomer = customers.find((c) => c.id === customerId);
    const customerName = matchedCustomer ? matchedCustomer.name : 'Unknown Customer';

    if (mode === 'create') {
      const numInitPayment = parseFloat(initialPayment) || 0;
      if (numInitPayment > numAmount) {
        setFormError('Initial payment cannot exceed total invoice amount.');
        return;
      }

      addInvoice({
        invoiceNumber: invoiceNumber.trim(),
        customerId,
        customerName,
        description: description.trim(),
        amount: numAmount,
        issueDate,
        dueDate,
        notes: notes.trim() || undefined,
        initialPayment: numInitPayment > 0 ? numInitPayment : undefined,
        initialPaymentMethod,
      });
      closeInvoiceModal();
    } else if (mode === 'edit' && invoice) {
      updateInvoice(invoice.id, {
        invoiceNumber: invoiceNumber.trim(),
        customerId,
        customerName,
        description: description.trim(),
        amount: numAmount,
        issueDate,
        dueDate,
        notes: notes.trim() || undefined,
      });
      closeInvoiceModal();
    }
  };

  const handleDelete = () => {
    if (invoice) {
      deleteInvoice(invoice.id);
      setDeleteConfirmOpen(false);
      closeInvoiceModal();
    }
  };

  // View Mode Render
  if (mode === 'view' && invoice) {
    const paid = getInvoicePaidAmount(invoice);
    const balance = getInvoiceBalance(invoice);
    const effectiveStatus = getInvoiceEffectiveStatus(invoice);
    const daysOverdue = getDaysOverdue(invoice.dueDate);
    const matchedCustomer = customers.find((c) => c.id === invoice.customerId);

    return (
      <>
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-xl max-w-2xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-blue-50 text-blue-600">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-900">
                      Invoice #{invoice.invoiceNumber}
                    </h2>
                    <StatusBadge status={effectiveStatus} size="sm" />
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Issued {formatDate(invoice.issueDate)} · Due {formatDate(invoice.dueDate)}
                    {effectiveStatus === 'Overdue' && (
                      <span className="text-rose-600 font-semibold ml-1.5">
                        ({daysOverdue} days overdue)
                      </span>
                    )}
                  </p>
                </div>
              </div>
              <button
                onClick={closeInvoiceModal}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* View Body */}
            <div className="p-6 space-y-6 overflow-y-auto flex-1 text-slate-800">
              {/* Customer Banner */}
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200/80 flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    Billed To
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                    {invoice.customerName}
                  </h3>
                  {matchedCustomer && (
                    <p className="text-xs text-slate-600 mt-0.5">
                      {matchedCustomer.businessName} · {matchedCustomer.phone} · {matchedCustomer.email}
                    </p>
                  )}
                </div>
                {matchedCustomer && (
                  <button
                    onClick={() => {
                      closeInvoiceModal();
                      openCustomerModal('view', matchedCustomer);
                    }}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
                  >
                    <span>View Customer</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Financial Metrics */}
              <div className="grid grid-cols-3 gap-3 p-4 bg-white rounded-lg border border-slate-200">
                <div>
                  <span className="text-xs text-slate-500 block">Total Amount</span>
                  <span className="text-lg font-bold text-slate-900 tabular-nums">
                    {formatCurrency(invoice.amount, settings.currency)}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Total Collected</span>
                  <span className="text-lg font-bold text-emerald-600 tabular-nums">
                    {formatCurrency(paid, settings.currency)}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Balance Remaining</span>
                  <span
                    className={`text-lg font-bold tabular-nums ${
                      balance > 0 ? 'text-rose-600' : 'text-slate-900'
                    }`}
                  >
                    {formatCurrency(balance, settings.currency)}
                  </span>
                </div>
              </div>

              {/* Description & Notes */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                  Description / Deliverables
                </h4>
                <p className="text-xs text-slate-800 leading-relaxed bg-slate-50/50 p-3 rounded-lg border border-slate-200/60">
                  {invoice.description || 'No description provided.'}
                </p>
                {invoice.notes && (
                  <div className="mt-2 text-xs text-slate-600 bg-amber-50/40 p-2.5 rounded-lg border border-amber-200/50">
                    <span className="font-semibold text-amber-900">Notes: </span>
                    {invoice.notes}
                  </div>
                )}
              </div>

              {/* Payments History */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                    <Receipt className="w-4 h-4 text-slate-400" />
                    <span>Payment History ({invoice.payments?.length || 0})</span>
                  </h4>
                  {balance > 0 && (
                    <button
                      onClick={() => openPaymentModal(invoice)}
                      className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Record Payment</span>
                    </button>
                  )}
                </div>

                {!invoice.payments || invoice.payments.length === 0 ? (
                  <div className="text-center py-6 bg-slate-50 rounded-lg border border-dashed border-slate-200 text-xs text-slate-500">
                    No payments have been recorded for this invoice yet.
                  </div>
                ) : (
                  <div className="border border-slate-200 rounded-lg overflow-hidden">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                        <tr>
                          <th className="py-2 px-3 font-semibold">Date</th>
                          <th className="py-2 px-3 font-semibold">Method</th>
                          <th className="py-2 px-3 font-semibold">Notes</th>
                          <th className="py-2 px-3 font-semibold text-right">Amount</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {invoice.payments.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-50/60">
                            <td className="py-2 px-3 text-slate-700">{formatDate(p.date)}</td>
                            <td className="py-2 px-3 text-slate-700 font-medium">{p.method}</td>
                            <td className="py-2 px-3 text-slate-500">{p.notes || '—'}</td>
                            <td className="py-2 px-3 text-right font-semibold text-emerald-700 tabular-nums">
                              {formatCurrency(p.amount, settings.currency)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>

            {/* Footer Actions */}
            <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmOpen(true)}
                  className="px-3 py-2 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    closeInvoiceModal();
                    // Re-open in edit mode
                    setTimeout(() => {
                      // Trigger edit
                      updateInvoice(invoice.id, {});
                    }, 50);
                  }}
                  className="px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit Details</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => openWhatsAppModal(invoice)}
                  className="px-3.5 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/60 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp Reminder</span>
                </button>

                {balance > 0 && (
                  <button
                    type="button"
                    onClick={() => openPaymentModal(invoice)}
                    className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>Record Payment</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        <ConfirmDialog
          isOpen={deleteConfirmOpen}
          title="Delete Invoice?"
          message={`Are you sure you want to permanently delete Invoice #${invoice.invoiceNumber}? This action cannot be undone.`}
          confirmLabel="Delete Invoice"
          isDestructive
          onConfirm={handleDelete}
          onCancel={() => setDeleteConfirmOpen(false)}
        />
      </>
    );
  }

  // Create / Edit Form Render
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white rounded-xl max-w-xl w-full border border-slate-200 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {mode === 'create' ? 'Create New Invoice' : 'Edit Invoice'}
              </h2>
              <p className="text-xs text-slate-500">
                {mode === 'create'
                  ? 'Generate invoice and assign credit terms'
                  : `Editing invoice #${invoice?.invoiceNumber}`}
              </p>
            </div>
          </div>
          <button
            onClick={closeInvoiceModal}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* Invoice Number & Customer */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Invoice Number <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                placeholder="INV-2026-001"
                className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  Customer <span className="text-rose-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => openCustomerModal('create')}
                  className="text-[11px] font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-0.5 cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>New Customer</span>
                </button>
              </div>
              <select
                required
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
              >
                <option value="" disabled>
                  Select a customer...
                </option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} {c.businessName ? `(${c.businessName})` : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Description / Services Rendered <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Website development, October retainer, Spare parts order"
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Amount & Issue / Due Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Total Amount ({settings.currency}) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 text-xs font-semibold tabular-nums rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Issue Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                required
                value={issueDate}
                onChange={(e) => {
                  setIssueDate(e.target.value);
                  setDueDate(addDays(e.target.value, settings.defaultPaymentTermsDays || 15));
                }}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Due Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Initial Payment for new invoice */}
          {mode === 'create' && (
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-lg space-y-2.5">
              <span className="text-xs font-semibold text-slate-800 block">
                Record Advance / Initial Payment (Optional)
              </span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Advance Amount ({settings.currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={initialPayment}
                    onChange={(e) => setInitialPayment(e.target.value)}
                    placeholder="0.00 (leave 0 if unpaid)"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Payment Channel
                  </label>
                  <select
                    value={initialPaymentMethod}
                    onChange={(e) =>
                      setInitialPaymentMethod(e.target.value as InvoicePayment['method'])
                    }
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
                  >
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="UPI">UPI</option>
                    <option value="Cash">Cash</option>
                    <option value="Cheque">Cheque</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Internal Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Internal Notes / Terms (Optional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. 50% advance received, balance payable upon milestone sign-off"
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={closeInvoiceModal}
              className="px-4 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              {mode === 'create' ? 'Create Invoice' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
