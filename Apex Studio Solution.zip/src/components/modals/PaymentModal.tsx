import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, DollarSign, CheckCircle2, AlertCircle } from 'lucide-react';
import { InvoicePayment } from '../../types';
import { getInvoicePaidAmount, getInvoiceBalance } from '../../utils/invoiceCalculator';
import { formatCurrency } from '../../utils/currency';
import { todayISO } from '../../utils/date';

export const PaymentModal: React.FC = () => {
  const { paymentModalState, closePaymentModal, recordPayment, settings } = useApp();
  const { isOpen, invoice } = paymentModalState;

  const [amount, setAmount] = useState<string>('');
  const [date, setDate] = useState<string>(todayISO());
  const [method, setMethod] = useState<InvoicePayment['method']>('Bank Transfer');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (invoice && isOpen) {
      const balance = getInvoiceBalance(invoice);
      setAmount(balance > 0 ? balance.toString() : '0');
      setDate(todayISO());
      setMethod('Bank Transfer');
      setNotes('');
      setError('');
    }
  }, [invoice, isOpen]);

  if (!isOpen || !invoice) return null;

  const totalAmount = Number(invoice.amount) || 0;
  const paidAmount = getInvoicePaidAmount(invoice);
  const remainingBalance = getInvoiceBalance(invoice);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setError('Payment amount must be greater than zero.');
      return;
    }

    if (numericAmount > remainingBalance + 0.001) {
      setError(`Payment cannot exceed the remaining balance of ${formatCurrency(remainingBalance, settings.currency)}.`);
      return;
    }

    recordPayment(invoice.id, {
      amount: numericAmount,
      date,
      method,
      notes: notes.trim() || undefined,
    });

    closePaymentModal();
  };

  const handlePayFull = () => {
    setAmount(remainingBalance.toString());
    setError('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white rounded-xl max-w-md w-full border border-slate-200 shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Record Payment</h2>
              <p className="text-xs text-slate-500">
                Invoice #{invoice.invoiceNumber} · {invoice.customerName}
              </p>
            </div>
          </div>
          <button
            onClick={closePaymentModal}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Balance Breakdown Strip */}
          <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 border border-slate-200/80 rounded-lg text-xs">
            <div>
              <span className="text-slate-500 block">Total Invoiced</span>
              <span className="font-semibold text-slate-900 tabular-nums">
                {formatCurrency(totalAmount, settings.currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Already Paid</span>
              <span className="font-semibold text-emerald-700 tabular-nums">
                {formatCurrency(paidAmount, settings.currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Balance Due</span>
              <span className="font-bold text-rose-600 tabular-nums">
                {formatCurrency(remainingBalance, settings.currency)}
              </span>
            </div>
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Amount Input */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">
                Payment Amount ({settings.currency}) <span className="text-rose-500">*</span>
              </label>
              <button
                type="button"
                onClick={handlePayFull}
                className="text-xs font-medium text-blue-600 hover:text-blue-700 cursor-pointer"
              >
                Pay Full Balance
              </button>
            </div>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                min="0.01"
                max={remainingBalance}
                required
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setError('');
                }}
                placeholder="0.00"
                className="w-full px-3 py-2 text-sm font-semibold rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 tabular-nums"
              />
            </div>
          </div>

          {/* Payment Date & Method */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Payment Method <span className="text-rose-500">*</span>
              </label>
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value as InvoicePayment['method'])}
                className="w-full px-2.5 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
              >
                <option value="Bank Transfer">Bank Transfer / NEFT</option>
                <option value="UPI">UPI / QR Code</option>
                <option value="Cash">Cash</option>
                <option value="Cheque">Cheque</option>
                <option value="Credit Card">Credit Card</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          {/* Notes / Reference */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Transaction Notes / Reference (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. UTR / Transaction ID #8812903, Cheque #004312"
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={closePaymentModal}
              className="px-4 py-2 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Record Payment</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
