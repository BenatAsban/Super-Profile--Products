import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  BarChart3,
  DollarSign,
  Users,
  AlertCircle,
  CheckCircle2,
  PieChart,
  TrendingUp,
  Download,
  Calendar,
  ShieldAlert,
} from 'lucide-react';
import { formatCurrency } from '../../utils/currency';
import {
  getInvoiceBalance,
  getInvoicePaidAmount,
  getInvoiceEffectiveStatus,
} from '../../utils/invoiceCalculator';
import { getDaysOverdue, formatDate } from '../../utils/date';
import { exportInvoicesToCSV } from '../../utils/csv';
import { StatCard } from '../common/StatCard';

export const ReportsView: React.FC = () => {
  const { customers, invoices, settings, openInvoiceModal, openCustomerModal } = useApp();

  // Metrics
  const totalInvoiced = invoices.reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
  const totalCollected = invoices.reduce((sum, inv) => sum + getInvoicePaidAmount(inv), 0);
  const totalOutstanding = invoices.reduce((sum, inv) => sum + getInvoiceBalance(inv), 0);

  const collectionRate = totalInvoiced > 0 ? (totalCollected / totalInvoiced) * 100 : 0;

  const overdueInvoices = invoices.filter(
    (inv) => getInvoiceBalance(inv) > 0 && getInvoiceEffectiveStatus(inv) === 'Overdue'
  );
  const totalOverdue = overdueInvoices.reduce((sum, inv) => sum + getInvoiceBalance(inv), 0);

  // Status breakdown
  const statusStats = {
    paid: {
      count: 0,
      amount: 0,
    },
    partiallyPaid: {
      count: 0,
      amount: 0,
      balance: 0,
    },
    unpaid: {
      count: 0,
      amount: 0,
    },
    overdue: {
      count: 0,
      amount: 0,
    },
  };

  invoices.forEach((inv) => {
    const status = getInvoiceEffectiveStatus(inv);
    const bal = getInvoiceBalance(inv);
    const amt = Number(inv.amount) || 0;

    if (status === 'Paid') {
      statusStats.paid.count += 1;
      statusStats.paid.amount += amt;
    } else if (status === 'Partially paid') {
      statusStats.partiallyPaid.count += 1;
      statusStats.partiallyPaid.amount += amt;
      statusStats.partiallyPaid.balance += bal;
    } else if (status === 'Overdue') {
      statusStats.overdue.count += 1;
      statusStats.overdue.amount += bal;
    } else {
      statusStats.unpaid.count += 1;
      statusStats.unpaid.amount += bal;
    }
  });

  // Aging analysis for outstanding balances
  const aging = {
    current: 0,
    days1_30: 0,
    days31_60: 0,
    days60_plus: 0,
  };

  invoices.forEach((inv) => {
    const bal = getInvoiceBalance(inv);
    if (bal <= 0) return;

    const days = getDaysOverdue(inv.dueDate);
    if (days === 0) {
      aging.current += bal;
    } else if (days <= 30) {
      aging.days1_30 += bal;
    } else if (days <= 60) {
      aging.days31_60 += bal;
    } else {
      aging.days60_plus += bal;
    }
  });

  // Top Debtors Ranking
  const customerDebtList = customers
    .map((c) => {
      const custInvoices = invoices.filter((i) => i.customerId === c.id);
      const debt = custInvoices.reduce((sum, i) => sum + getInvoiceBalance(i), 0);
      const totalBilled = custInvoices.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
      return {
        customer: c,
        pendingBalance: debt,
        totalBilled,
        invoiceCount: custInvoices.length,
      };
    })
    .filter((item) => item.pendingBalance > 0)
    .sort((a, b) => b.pendingBalance - a.pendingBalance);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Financial & Receivables Reports
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Audit billing health, cash-inflow efficiency, portfolio aging, and debtor concentrations.
          </p>
        </div>

        <button
          onClick={() => exportInvoicesToCSV(invoices)}
          className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span>Export Detailed Report (CSV)</span>
        </button>
      </div>

      {/* Primary Financial Metric Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total Invoiced"
          value={formatCurrency(totalInvoiced, settings.currency)}
          subtext={`Across ${invoices.length} total invoices`}
          icon={DollarSign}
        />
        <StatCard
          label="Total Collected"
          value={formatCurrency(totalCollected, settings.currency)}
          subtext={`${collectionRate.toFixed(1)}% recovery rate`}
          icon={CheckCircle2}
          variant="success"
        />
        <StatCard
          label="Outstanding Balance"
          value={formatCurrency(totalOutstanding, settings.currency)}
          subtext="Net unpaid ledger balance"
          icon={PieChart}
          variant={totalOutstanding > 0 ? 'warning' : 'default'}
        />
        <StatCard
          label="Overdue Invoices"
          value={overdueInvoices.length}
          subtext={`Valued at ${formatCurrency(totalOverdue, settings.currency)}`}
          icon={AlertCircle}
          variant={overdueInvoices.length > 0 ? 'danger' : 'default'}
        />
      </div>

      {/* Visual Collected vs Outstanding Comparison */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-5">
        <div>
          <h2 className="text-sm font-bold text-slate-900">
            Cash Collection vs. Outstanding Exposure
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Clear segregation between funds in bank and unpaid market receivables.
          </p>
        </div>

        {/* Visual Progress Comparison Bar */}
        <div>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-emerald-700 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
              Collected: {formatCurrency(totalCollected, settings.currency)} ({collectionRate.toFixed(1)}%)
            </span>
            <span className="font-semibold text-rose-700 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
              Outstanding: {formatCurrency(totalOutstanding, settings.currency)} ({((100 - collectionRate) || 0).toFixed(1)}%)
            </span>
          </div>

          <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
            <div
              style={{ width: `${collectionRate}%` }}
              className="bg-emerald-500 h-full transition-all"
            />
            <div
              style={{ width: `${100 - collectionRate}%` }}
              className="bg-rose-500 h-full transition-all"
            />
          </div>
        </div>

        {/* Detailed Breakdown Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t border-slate-100 text-xs">
          <div className="p-3 bg-emerald-50/50 border border-emerald-200/60 rounded-lg">
            <span className="text-slate-600 block">Fully Settled</span>
            <span className="text-base font-bold text-emerald-800 tabular-nums mt-0.5 block">
              {formatCurrency(statusStats.paid.amount, settings.currency)}
            </span>
            <span className="text-[11px] text-emerald-700 mt-1 block">
              {statusStats.paid.count} invoices cleared
            </span>
          </div>

          <div className="p-3 bg-amber-50/50 border border-amber-200/60 rounded-lg">
            <span className="text-slate-600 block">Partially Paid Balances</span>
            <span className="text-base font-bold text-amber-800 tabular-nums mt-0.5 block">
              {formatCurrency(statusStats.partiallyPaid.balance, settings.currency)}
            </span>
            <span className="text-[11px] text-amber-700 mt-1 block">
              {statusStats.partiallyPaid.count} invoices with partial payments
            </span>
          </div>

          <div className="p-3 bg-blue-50/50 border border-blue-200/60 rounded-lg">
            <span className="text-slate-600 block">Unpaid (Within Credit Terms)</span>
            <span className="text-base font-bold text-blue-800 tabular-nums mt-0.5 block">
              {formatCurrency(statusStats.unpaid.amount, settings.currency)}
            </span>
            <span className="text-[11px] text-blue-700 mt-1 block">
              {statusStats.unpaid.count} invoices awaiting due date
            </span>
          </div>

          <div className="p-3 bg-rose-50/50 border border-rose-200/60 rounded-lg">
            <span className="text-slate-600 block">Overdue Exposure</span>
            <span className="text-base font-bold text-rose-800 tabular-nums mt-0.5 block">
              {formatCurrency(statusStats.overdue.amount, settings.currency)}
            </span>
            <span className="text-[11px] text-rose-700 mt-1 block">
              {statusStats.overdue.count} invoices requiring follow-up
            </span>
          </div>
        </div>
      </div>

      {/* Two-Column Section: Aging Schedule & Top Debtors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Aging Schedule */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-slate-600" />
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Accounts Receivable Aging Analysis
              </h2>
              <p className="text-[11px] text-slate-500">
                Classification of unpaid receivables by days past invoice due date
              </p>
            </div>
          </div>

          <div className="space-y-3 pt-2 text-xs">
            {/* Current */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-slate-700">Current (Not Overdue)</span>
                <span className="font-bold text-slate-900 tabular-nums">
                  {formatCurrency(aging.current, settings.currency)}
                </span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  style={{
                    width: totalOutstanding > 0 ? `${(aging.current / totalOutstanding) * 100}%` : '0%',
                  }}
                  className="bg-blue-500 h-full"
                />
              </div>
            </div>

            {/* 1 - 30 days */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-slate-700">1 – 30 Days Overdue</span>
                <span className="font-bold text-amber-700 tabular-nums">
                  {formatCurrency(aging.days1_30, settings.currency)}
                </span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  style={{
                    width: totalOutstanding > 0 ? `${(aging.days1_30 / totalOutstanding) * 100}%` : '0%',
                  }}
                  className="bg-amber-500 h-full"
                />
              </div>
            </div>

            {/* 31 - 60 days */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-slate-700">31 – 60 Days Overdue</span>
                <span className="font-bold text-rose-600 tabular-nums">
                  {formatCurrency(aging.days31_60, settings.currency)}
                </span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  style={{
                    width: totalOutstanding > 0 ? `${(aging.days31_60 / totalOutstanding) * 100}%` : '0%',
                  }}
                  className="bg-rose-500 h-full"
                />
              </div>
            </div>

            {/* 60+ days */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-slate-700">60+ Days Overdue (High Risk)</span>
                <span className="font-bold text-rose-800 tabular-nums">
                  {formatCurrency(aging.days60_plus, settings.currency)}
                </span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div
                  style={{
                    width: totalOutstanding > 0 ? `${(aging.days60_plus / totalOutstanding) * 100}%` : '0%',
                  }}
                  className="bg-rose-700 h-full"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Top Debtors Ranking */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4 flex flex-col">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-600" />
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Top Client Balance Balances
              </h2>
              <p className="text-[11px] text-slate-500">
                Customers with the highest outstanding ledger balances
              </p>
            </div>
          </div>

          <div className="space-y-2.5 flex-1 overflow-y-auto max-h-64 text-xs">
            {customerDebtList.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">
                All customer accounts are currently fully settled.
              </div>
            ) : (
              customerDebtList.map((item, idx) => (
                <div
                  key={item.customer.id}
                  onClick={() => openCustomerModal('view', item.customer)}
                  className="p-3 rounded-lg border border-slate-200/80 hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center font-bold text-[10px] shrink-0 font-mono">
                      {idx + 1}
                    </span>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">
                        {item.customer.name}
                      </span>
                      <span className="text-[11px] text-slate-500 block truncate">
                        {item.customer.businessName} · {item.invoiceCount} invoices
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-bold text-rose-600 tabular-nums block">
                      {formatCurrency(item.pendingBalance, settings.currency)}
                    </span>
                    <span className="text-[10px] text-slate-400 block tabular-nums">
                      of {formatCurrency(item.totalBilled, settings.currency)} billed
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
