import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Clock,
  Plus,
  Filter,
  Search,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Download,
  Edit2,
  Trash2,
  MessageSquare,
  Phone,
  Mail,
  Users,
  FileText,
  ExternalLink,
} from 'lucide-react';
import { FollowUp, PriorityLevel } from '../../types';
import { formatDate, isToday, isPastDate, formatRelativeDays } from '../../utils/date';
import { PriorityBadge } from '../common/StatusBadge';
import { exportFollowUpsToCSV } from '../../utils/csv';
import { ConfirmDialog } from '../common/ConfirmDialog';

type FollowUpFilter = 'all' | 'today' | 'upcoming' | 'overdue' | 'completed';

export const FollowUpsView: React.FC = () => {
  const {
    followUps,
    invoices,
    openFollowUpModal,
    openInvoiceModal,
    openWhatsAppModal,
    toggleFollowUpComplete,
    deleteFollowUp,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<FollowUpFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [taskToDelete, setTaskToDelete] = useState<FollowUp | null>(null);

  // Filter & Search
  const filteredTasks = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();

    return followUps.filter((f) => {
      const matchesSearch =
        !q ||
        f.customerName.toLowerCase().includes(q) ||
        (f.invoiceNumber && f.invoiceNumber.toLowerCase().includes(q)) ||
        f.notes.toLowerCase().includes(q) ||
        f.type.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      const isTaskToday = isToday(f.date);
      const isTaskPast = isPastDate(f.date);

      if (activeFilter === 'today') {
        return !f.completed && isTaskToday;
      }
      if (activeFilter === 'upcoming') {
        return !f.completed && !isTaskToday && !isTaskPast;
      }
      if (activeFilter === 'overdue') {
        return !f.completed && isTaskPast;
      }
      if (activeFilter === 'completed') {
        return f.completed;
      }

      return true; // 'all'
    });
  }, [followUps, searchQuery, activeFilter]);

  // Counts for tabs
  const counts = useMemo(() => {
    return {
      all: followUps.length,
      today: followUps.filter((f) => !f.completed && isToday(f.date)).length,
      upcoming: followUps.filter((f) => !f.completed && !isToday(f.date) && !isPastDate(f.date)).length,
      overdue: followUps.filter((f) => !f.completed && isPastDate(f.date)).length,
      completed: followUps.filter((f) => f.completed).length,
    };
  }, [followUps]);

  const handleExportCSV = () => {
    exportFollowUpsToCSV(followUps);
  };

  const handleDeleteConfirm = () => {
    if (taskToDelete) {
      deleteFollowUp(taskToDelete.id);
      setTaskToDelete(null);
    }
  };

  const getChannelIcon = (type: string) => {
    switch (type) {
      case 'WhatsApp':
        return MessageSquare;
      case 'Phone Call':
        return Phone;
      case 'Email':
        return Mail;
      case 'Meeting':
        return Users;
      case 'Payment Reminder':
      default:
        return Clock;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Follow-Up Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Schedule communication, track overdue payment calls, and log customer engagements.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => openFollowUpModal('create')}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule Follow-up</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs and Search Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
        {/* Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: 'All Tasks', count: counts.all },
            { id: 'today', label: 'Due Today', count: counts.today, badgeColor: 'bg-amber-100 text-amber-800' },
            { id: 'upcoming', label: 'Upcoming', count: counts.upcoming },
            { id: 'overdue', label: 'Overdue', count: counts.overdue, badgeColor: 'bg-rose-100 text-rose-800' },
            { id: 'completed', label: 'Completed', count: counts.completed },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as FollowUpFilter)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeFilter === tab.id
                  ? 'bg-blue-50 text-blue-700 font-semibold border border-blue-200/80 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-md font-mono ${
                  tab.badgeColor || 'bg-slate-100 text-slate-600'
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search follow-ups by customer, notes, or channel..."
            className="w-full pl-9 pr-4 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-slate-50/50"
          />
        </div>
      </div>

      {/* Follow-up Tasks List */}
      {filteredTasks.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Clock className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">No Follow-ups Found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {activeFilter !== 'all' || searchQuery
              ? 'No scheduled follow-up tasks match this view filter. Try switching tabs or clearing your search.'
              : 'You have not scheduled any follow-ups yet. Set a reminder for pending client reviews.'}
          </p>
          <div className="mt-4">
            <button
              onClick={() => openFollowUpModal('create')}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer transition-colors"
            >
              + Schedule Follow-up
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTasks.map((task) => {
            const isTaskToday = isToday(task.date);
            const isTaskOverdue = !task.completed && isPastDate(task.date);
            const Icon = getChannelIcon(task.type);

            // Related invoice lookup
            const linkedInvoice = task.invoiceId
              ? invoices.find((inv) => inv.id === task.invoiceId)
              : undefined;

            return (
              <div
                key={task.id}
                className={`p-4 rounded-xl border transition-all bg-white shadow-2xs flex flex-col sm:flex-row sm:items-start gap-3.5 text-xs ${
                  isTaskOverdue
                    ? 'border-rose-300/80 bg-rose-50/20'
                    : isTaskToday
                    ? 'border-amber-300/80 bg-amber-50/15'
                    : 'border-slate-200'
                } ${task.completed ? 'opacity-70 bg-slate-50/60' : ''}`}
              >
                {/* Complete Checkbox */}
                <div className="pt-0.5">
                  <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => toggleFollowUpComplete(task.id)}
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                    title={task.completed ? 'Mark incomplete' : 'Mark completed'}
                  />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0 space-y-1.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`text-sm font-bold ${
                          task.completed ? 'line-through text-slate-400' : 'text-slate-900'
                        }`}
                      >
                        {task.customerName}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium flex items-center gap-1">
                        <Icon className="w-3 h-3 text-slate-500" />
                        <span>{task.type}</span>
                      </span>
                      <PriorityBadge priority={task.priority} />
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[11px] font-medium ${
                          isTaskOverdue
                            ? 'text-rose-600 font-bold'
                            : isTaskToday
                            ? 'text-amber-700 font-bold'
                            : 'text-slate-500'
                        }`}
                      >
                        {isTaskToday ? 'Due Today' : formatRelativeDays(task.date)} ·{' '}
                        {formatDate(task.date)}
                      </span>
                    </div>
                  </div>

                  {/* Notes / Action instructions */}
                  <p
                    className={`text-xs leading-relaxed ${
                      task.completed ? 'text-slate-400' : 'text-slate-700'
                    }`}
                  >
                    {task.notes}
                  </p>

                  {/* Linked invoice badge & WhatsApp button */}
                  {linkedInvoice && (
                    <div className="flex items-center gap-2 pt-1 text-[11px]">
                      <span className="text-slate-500">Related Invoice:</span>
                      <button
                        onClick={() => openInvoiceModal('view', linkedInvoice)}
                        className="font-mono text-blue-600 hover:underline flex items-center gap-1 font-semibold"
                      >
                        <span>#{linkedInvoice.invoiceNumber}</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                      {linkedInvoice.status !== 'Paid' && (
                        <button
                          onClick={() => openWhatsAppModal(linkedInvoice)}
                          className="px-2 py-0.5 rounded text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 flex items-center gap-1"
                        >
                          <MessageSquare className="w-3 h-3" />
                          <span>WhatsApp Reminder</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* Right Actions */}
                <div className="flex items-center sm:flex-col justify-end gap-1 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                  <button
                    onClick={() => openFollowUpModal('edit', task)}
                    className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
                    title="Edit Follow-up"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setTaskToDelete(task)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                    title="Delete Follow-up"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={Boolean(taskToDelete)}
        title="Delete Follow-up Task?"
        message="Are you sure you want to remove this scheduled follow-up?"
        confirmLabel="Delete Task"
        isDestructive
        onConfirm={handleDeleteConfirm}
        onCancel={() => setTaskToDelete(null)}
      />
    </div>
  );
};
