import React from 'react';
import { useApp } from '../../context/AppContext';
import { NavigationTab } from '../../types';
import {
  LayoutDashboard,
  Users,
  FileText,
  Clock,
  BarChart3,
  Settings,
  Plus,
  Building2,
  HardDrive,
} from 'lucide-react';
import { isToday } from '../../utils/date';
import { getInvoiceBalance } from '../../utils/invoiceCalculator';

interface SidebarProps {
  onNavigate?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onNavigate }) => {
  const {
    activeTab,
    setActiveTab,
    settings,
    invoices,
    followUps,
    openInvoiceModal,
  } = useApp();

  // Overdue invoices count
  const overdueCount = invoices.filter((inv) => {
    const bal = getInvoiceBalance(inv);
    return bal > 0 && inv.status === 'Overdue';
  }).length;

  // Followups due today count
  const todayFollowUpsCount = followUps.filter(
    (f) => !f.completed && isToday(f.date)
  ).length;

  const navItems: {
    id: NavigationTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    badgeVariant?: 'danger' | 'warning' | 'info';
  }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'customers', label: 'Customers', icon: Users },
    {
      id: 'invoices',
      label: 'Invoices',
      icon: FileText,
      badge: overdueCount > 0 ? overdueCount : undefined,
      badgeVariant: 'danger',
    },
    {
      id: 'followups',
      label: 'Follow-ups',
      icon: Clock,
      badge: todayFollowUpsCount > 0 ? todayFollowUpsCount : undefined,
      badgeVariant: 'warning',
    },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (tab: NavigationTab) => {
    setActiveTab(tab);
    if (onNavigate) onNavigate();
  };

  return (
    <aside className="w-64 bg-slate-900 text-slate-200 flex flex-col h-full border-r border-slate-800 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-lg shadow-sm shadow-blue-500/30">
            {settings.logoText.slice(0, 1) || 'F'}
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-sm font-bold text-white tracking-tight truncate">
              {settings.businessName || 'FollowUp Desk'}
            </h1>
            <p className="text-xs text-slate-400 truncate">
              {settings.brandTagline || 'Customer & Payment Tracker'}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Action Button */}
      <div className="px-4 pt-4 pb-2">
        <button
          onClick={() => openInvoiceModal('create')}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Invoice</span>
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          Management
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                isActive
                  ? 'bg-blue-600/20 text-white font-semibold border border-blue-500/30'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-blue-400' : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`px-1.5 py-0.5 text-[10px] font-bold rounded-md tabular-nums ${
                    item.badgeVariant === 'danger'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Sidebar Footer info */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-900/60 text-xs text-slate-400">
        <div className="flex items-center gap-2 mb-1">
          <HardDrive className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="text-[11px] font-medium text-slate-300">
            Local Offline Storage
          </span>
        </div>
        <p className="text-[10px] text-slate-400 leading-tight">
          Client-side database active. Single-user mode.
        </p>
      </div>
    </aside>
  );
};
