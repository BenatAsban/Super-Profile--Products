import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Menu, X, Plus } from 'lucide-react';
import { Sidebar } from './Sidebar';

export const MobileHeader: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { settings, openInvoiceModal } = useApp();

  return (
    <>
      <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsOpen(true)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
              {settings.logoText.slice(0, 1) || 'F'}
            </div>
            <span className="font-semibold text-sm tracking-tight text-white truncate max-w-[170px]">
              {settings.businessName || 'FollowUp Desk'}
            </span>
          </div>
        </div>

        <button
          onClick={() => openInvoiceModal('create')}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Invoice</span>
        </button>
      </header>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsOpen(false)}
          />
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-slate-900 shadow-xl z-50">
            <div className="absolute top-3 right-3">
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <Sidebar onNavigate={() => setIsOpen(false)} />
          </div>
        </div>
      )}
    </>
  );
};
