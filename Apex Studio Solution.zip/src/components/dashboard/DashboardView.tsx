import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  AlertCircle,
  Clock,
  DollarSign,
  Plus,
  ArrowRight,
  MessageSquare,
  CheckCircle2,
  Calendar,
  ExternalLink,
  CreditCard,
  Building2,
} from 'lucide-react';
import { StatCard } from '../common/StatCard';
import { formatCurrency } from '../../utils/currency';
import { isToday, formatDate, getDaysOverdue, formatRelativeDays } from '../../utils/date';
import { getInvoiceBalance, getInvoiceEffectiveStatus, getInvoicePaidAmount } from '../../utils/invoiceCalculator';
import { StatusBadge, PriorityBadge } from '../common/StatusBadge';

export const DashboardView: React.FC = () => {
  const {
    customers,
    invoices,
    followUps,
    settings,
    setActiveTab,
    openCustomerModal,
    openInvoiceModal,
    openFollowUpModal,
    openPaymentModal,
    openWhatsAppModal,
    toggleFollowUpComplete,
  } = useApp();

  // Metrics calculations
  const totalCustomers = customers.length;

  const totalOutstanding = invoices.reduce((sum, inv) => {
    return sum + getInvoiceBalance(inv);
  }, 0);

  const overdueInvoices = invoices.filter((inv) => {
    const bal = getInvoiceBalance(inv);
    const status = getInvoiceEffectiveStatus(inv);
    return bal > 0 && status === 'Overdue';
  });

  const totalOverdue = overdueInvoices.reduce((sum, inv) => {
    return sum + getInvoiceBalance(inv);
  }, 0);

  const followUpsToday = followUps.filter(
    (f) => !f.completed && isToday(f.date)
  );

  const upcomingFollowUps = followUps
    .filter((f) => !f.completed)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 5);

  const overdueList = overdueInvoices
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
    .slice(0, 5);

  // Status breakdown calculations
  const totalInvoiced = invoices.reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
  const totalCollected = invoices.reduce((sum, inv) => sum + getInvoicePaidAmount(inv), 0);
  const paidCount = invoices.filter((inv) => getInvoiceEffectiveStatus(inv) === 'Paid').length;
  const overdueCount = overdueInvoices.length;
  const unpaidCount = invoices.filter((inv) => getInvoiceEffectiveStatus(inv) === 'Unpaid').length;
  const partialCount = invoices.filter((inv) => getInvoiceEffectiveStatus(inv) === 'Partially paid').length;

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Dashboard Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Real-time accounts receivable, pending collections, and scheduled customer follow-ups.
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => openCustomerModal('create')}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Users className="w-3.5 h-3.5 text-slate-500" />
            <span>Add Customer</span>
          </button>

          <button
            onClick={() => openFollowUpModal('create')}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>Schedule Follow-up</span>
          </button>

          <button
            onClick={() => openInvoiceModal('create')}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Invoice</span>
          </button>
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total Customers"
          value={totalCustomers}
          subtext="Active client directories"
          icon={Users}
          onClick={() => setActiveTab('customers')}
        />
        <StatCard
          label="Outstanding Balance"
          value={formatCurrency(totalOutstanding, settings.currency)}
          subtext="Across all pending invoices"
          icon={DollarSign}
          onClick={() => setActiveTab('invoices')}
        />
        <StatCard
          label="Overdue Amount"
          value={formatCurrency(totalOverdue, settings.currency)}
          subtext={`${overdueCount} invoice${overdueCount === 1 ? '' : 's'} past due date`}
          icon={AlertCircle}
          variant={overdueCount > 0 ? 'danger' : 'default'}
          onClick={() => setActiveTab('invoices')}
        />
        <StatCard
          label="Follow-ups Due Today"
          value={followUpsToday.length}
          subtext={
            followUpsToday.length > 0
              ? 'Urgent client follow-up needed'
              : 'All daily reminders clear'
          }
          icon={Clock}
          variant={followUpsToday.length > 0 ? 'warning' : 'success'}
          onClick={() => setActiveTab('followups')}
        />
      </div>

      {/* Two-Column Priority Operations Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Overdue Payment List */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-md bg-rose-50 text-rose-600">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900">
                  Overdue Payments Requiring Action
                </h2>
                <p className="text-[11px] text-slate-500">
                  {overdueList.length > 0
                    ? 'Invoices past due date awaiting payment'
                    : 'Great job! No invoices are currently overdue.'}
                </p>
              </div>
            </div>
            {overdueList.length > 0 && (
              <button
                onClick={() => setActiveTab('invoices')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="p-4 flex-1">
            {overdueList.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80" />
                <p className="font-semibold text-slate-800">Zero Overdue Receivables</p>
                <p className="text-slate-500 mt-0.5">All customer invoices are currently within credit terms.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {overdueList.map((inv) => {
                  const balance = getInvoiceBalance(inv);
                  const days = getDaysOverdue(inv.dueDate);
                  return (
                    <div
                      key={inv.id}
                      className="p-3 bg-slate-50/70 border border-slate-200/80 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 truncate">
                            {inv.customerName}
                          </span>
                          <span className="font-mono text-[11px] text-slate-500">
                            #{inv.invoiceNumber}
                          </span>
                        </div>
                        <div className="text-[11px] text-rose-600 font-semibold mt-0.5 flex items-center gap-1.5">
                          <span>{days} days overdue</span>
                          <span className="text-slate-400">·</span>
                          <span className="text-slate-500">Due {formatDate(inv.dueDate)}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                        <div className="text-right">
                          <span className="text-[11px] text-slate-500 block">Balance</span>
                          <span className="font-bold text-rose-700 tabular-nums">
                            {formatCurrency(balance, settings.currency)}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => openWhatsAppModal(inv)}
                            className="p-1.5 rounded-md bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/60 transition-colors"
                            title="Prepare WhatsApp Reminder"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => openPaymentModal(inv)}
                            className="px-2.5 py-1.5 rounded-md bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-2xs transition-colors"
                          >
                            Pay
                          </button>
                          <button
                            onClick={() => openInvoiceModal('view', inv)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md"
                            title="View Invoice"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Upcoming Follow-ups */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-md bg-amber-50 text-amber-600">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900">
                  Scheduled Follow-ups & Reminders
                </h2>
                <p className="text-[11px] text-slate-500">
                  {upcomingFollowUps.length} pending client contact tasks
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('followups')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-4 flex-1">
            {upcomingFollowUps.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">
                <Calendar className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-80" />
                <p className="font-semibold text-slate-800">No Pending Follow-ups</p>
                <p className="text-slate-500 mt-0.5">Use the quick action button to schedule your next client follow-up.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingFollowUps.map((fol) => (
                  <div
                    key={fol.id}
                    className="p-3 bg-slate-50/70 border border-slate-200/80 rounded-lg flex items-start gap-3 text-xs"
                  >
                    <input
                      type="checkbox"
                      checked={fol.completed}
                      onChange={() => toggleFollowUpComplete(fol.id)}
                      className="mt-1 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-900 truncate">
                          {fol.customerName}
                        </span>
                        <PriorityBadge priority={fol.priority} />
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                        <span className="font-semibold text-slate-700">{fol.type}</span>
                        <span>·</span>
                        <span
                          className={`font-medium ${
                            isToday(fol.date)
                              ? 'text-amber-600 font-bold'
                              : 'text-slate-600'
                          }`}
                        >
                          {formatRelativeDays(fol.date)} ({formatDate(fol.date)})
                        </span>
                        {fol.invoiceNumber && (
                          <>
                            <span>·</span>
                            <span className="font-mono text-slate-500">
                              #{fol.invoiceNumber}
                            </span>
                          </>
                        )}
                      </div>

                      <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                        {fol.notes}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Invoice Status Distribution Bar & Financial Highlights */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Invoice Portfolio Health
            </h2>
            <p className="text-xs text-slate-500">
              Distribution across {invoices.length} invoices ({formatCurrency(totalInvoiced, settings.currency)} cumulative value)
            </p>
          </div>
          <div className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-md border border-emerald-200/60 self-start sm:self-auto">
            {formatCurrency(totalCollected, settings.currency)} Collected ({totalInvoiced > 0 ? Math.round((totalCollected / totalInvoiced) * 100) : 0}%)
          </div>
        </div>

        {/* Visual Distribution Segmented Bar */}
        {invoices.length > 0 && (
          <div>
            <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
              {paidCount > 0 && (
                <div
                  style={{ width: `${(paidCount / invoices.length) * 100}%` }}
                  className="bg-emerald-500 h-full transition-all"
                  title={`Paid: ${paidCount}`}
                />
              )}
              {partialCount > 0 && (
                <div
                  style={{ width: `${(partialCount / invoices.length) * 100}%` }}
                  className="bg-amber-400 h-full transition-all"
                  title={`Partially Paid: ${partialCount}`}
                />
              )}
              {unpaidCount > 0 && (
                <div
                  style={{ width: `${(unpaidCount / invoices.length) * 100}%` }}
                  className="bg-blue-400 h-full transition-all"
                  title={`Unpaid: ${unpaidCount}`}
                />
              )}
              {overdueCount > 0 && (
                <div
                  style={{ width: `${(overdueCount / invoices.length) * 100}%` }}
                  className="bg-rose-500 h-full transition-all"
                  title={`Overdue: ${overdueCount}`}
                />
              )}
            </div>

            {/* Legend / Metrics breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3 pt-3 border-t border-slate-100 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                <span className="text-slate-600">Paid Invoices:</span>
                <span className="font-bold text-slate-900 tabular-nums">{paidCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shrink-0" />
                <span className="text-slate-600">Partially Paid:</span>
                <span className="font-bold text-slate-900 tabular-nums">{partialCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-400 shrink-0" />
                <span className="text-slate-600">Unpaid (In Terms):</span>
                <span className="font-bold text-slate-900 tabular-nums">{unpaidCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
                <span className="text-slate-600">Overdue:</span>
                <span className="font-bold text-rose-700 tabular-nums">{overdueCount}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Recent Customers Strip */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-slate-500" />
            <h2 className="text-sm font-bold text-slate-900">
              Recent Customer Accounts
            </h2>
          </div>
          <button
            onClick={() => setActiveTab('customers')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Manage All Customers ({customers.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {customers.slice(0, 6).map((c) => {
              const custInvoices = invoices.filter((inv) => inv.customerId === c.id);
              const pendingBal = custInvoices.reduce((sum, inv) => sum + getInvoiceBalance(inv), 0);

              return (
                <div
                  key={c.id}
                  onClick={() => openCustomerModal('view', c)}
                  className="p-3 rounded-lg border border-slate-200 hover:border-blue-400 hover:bg-slate-50/50 transition-all cursor-pointer text-xs"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 truncate">{c.name}</h4>
                      <p className="text-[11px] text-slate-500 truncate">{c.businessName}</p>
                    </div>
                    <span className="text-[10px] font-medium bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                      {c.category}
                    </span>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">{custInvoices.length} invoices</span>
                    <span
                      className={`font-semibold tabular-nums ${
                        pendingBal > 0 ? 'text-rose-600' : 'text-slate-700'
                      }`}
                    >
                      {pendingBal > 0
                        ? `Bal: ${formatCurrency(pendingBal, settings.currency)}`
                        : 'Settled'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
