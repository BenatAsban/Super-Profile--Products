import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Settings,
  Building2,
  DollarSign,
  Phone,
  Mail,
  MapPin,
  Shield,
  CreditCard,
  RotateCcw,
  Trash2,
  HardDrive,
  Save,
  CheckCircle2,
  Palette,
  Clock,
  MessageSquare,
  AlertTriangle,
  Info,
} from 'lucide-react';
import { AppSettings, AccentColor } from '../../types';
import { SUPPORTED_CURRENCIES, formatCurrency } from '../../utils/currency';
import { ConfirmDialog } from '../common/ConfirmDialog';

export const SettingsView: React.FC = () => {
  const { settings, updateSettings, resetDemoData, clearAllData } = useApp();

  const [form, setForm] = useState<AppSettings>({ ...settings });
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);

  const handleChange = (field: keyof AppSettings, value: unknown) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(form);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Business Settings & Customization
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Configure your company profile, currency locale, billing terms, and WhatsApp defaults.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Save className="w-3.5 h-3.5" />
          <span>Save Changes</span>
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Company Identity & Branding */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Building2 className="w-4 h-4 text-slate-600" />
            <h2 className="text-sm font-bold text-slate-900">
              Company Identity & Branding
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Business / Company Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={form.businessName}
                onChange={(e) => handleChange('businessName', e.target.value)}
                placeholder="e.g. Apex Studio Solutions"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Monogram / Logo Text (1-6 characters)
              </label>
              <input
                type="text"
                maxLength={6}
                value={form.logoText}
                onChange={(e) => handleChange('logoText', e.target.value)}
                placeholder="e.g. ApexDesk"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Brand Tagline / Sector
              </label>
              <input
                type="text"
                value={form.brandTagline}
                onChange={(e) => handleChange('brandTagline', e.target.value)}
                placeholder="e.g. Commercial Media & Software Services"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Currency & Financial Formatting */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <DollarSign className="w-4 h-4 text-slate-600" />
            <h2 className="text-sm font-bold text-slate-900">
              Currency & Region Formatting
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Default Currency <span className="text-rose-500">*</span>
              </label>
              <select
                value={form.currency}
                onChange={(e) => handleChange('currency', e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 bg-white"
              >
                {SUPPORTED_CURRENCIES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code} — {c.name}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 mt-1">
                Standard preview sample:{' '}
                <span className="font-semibold text-slate-800 tabular-nums">
                  {formatCurrency(125000.5, form.currency)}
                </span>
              </p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Default Invoice Payment Terms (Days)
              </label>
              <input
                type="number"
                min={1}
                max={180}
                value={form.defaultPaymentTermsDays}
                onChange={(e) =>
                  handleChange('defaultPaymentTermsDays', parseInt(e.target.value, 10) || 15)
                }
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Automatically sets invoice due date to (Issue Date + {form.defaultPaymentTermsDays} days).
              </p>
            </div>
          </div>
        </div>

        {/* Contact & Payment Instructions */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <CreditCard className="w-4 h-4 text-slate-600" />
            <h2 className="text-sm font-bold text-slate-900">
              Billing Contacts & Settlement Instructions
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Business Phone / WhatsApp
              </label>
              <input
                type="text"
                value={form.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Default Country Code (for WhatsApp click-to-chat)
              </label>
              <input
                type="text"
                value={form.defaultCountryCode}
                onChange={(e) => handleChange('defaultCountryCode', e.target.value)}
                placeholder="91 (India) or 1 (US/Canada)"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Billing Email
              </label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="billing@example.com"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Tax Identification / GSTIN / VAT ID
              </label>
              <input
                type="text"
                value={form.taxId}
                onChange={(e) => handleChange('taxId', e.target.value)}
                placeholder="e.g. 27AABCU9603R1ZM"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Office / Registered Address
              </label>
              <input
                type="text"
                value={form.address}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="Suite 402, Business Park, Mumbai, MH 400069"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Payment Details Included in Reminders (UPI / Bank Account / RTGS)
              </label>
              <textarea
                rows={3}
                value={form.paymentDetails}
                onChange={(e) => handleChange('paymentDetails', e.target.value)}
                placeholder="UPI ID: user@okhdfcbank&#10;Bank: HDFC Bank | A/C: 50200088991234 | IFSC: HDFC0001234"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-blue-500 resize-none font-mono text-[11px]"
              />
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-end">
          <button
            type="submit"
            className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings Changes</span>
          </button>
        </div>
      </form>

      {/* Local Storage & Data Privacy Information */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <HardDrive className="w-4 h-4 text-slate-600" />
          <h2 className="text-sm font-bold text-slate-900">
            Data Storage Architecture & Privacy Notice
          </h2>
        </div>

        <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-xs text-slate-700 leading-relaxed">
          <div className="flex items-center gap-2 font-semibold text-slate-900">
            <Info className="w-4 h-4 text-blue-600 shrink-0" />
            <span>Browser-Specific Local Storage Mode</span>
          </div>
          <p>
            All customer directories, invoices, payments, and scheduled follow-ups are stored
            directly in your browser&apos;s <code>localStorage</code> database key (<code>followupdesk_data_v1</code>).
          </p>
          <ul className="list-disc list-inside space-y-1 text-slate-600 pl-1 text-[11px]">
            <li>Data persists automatically through browser restarts and page refreshes.</li>
            <li>No customer details or financial records are uploaded to any external server.</li>
            <li>
              <strong>Notice:</strong> Local storage is single-user and device-specific. It does not provide multi-user concurrency or cloud-based server synchronization.
            </li>
          </ul>
        </div>

        {/* Danger Zone: Reset & Clear Actions */}
        <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
          <div>
            <h4 className="font-semibold text-slate-900">Demo Data Management</h4>
            <p className="text-slate-500 text-[11px]">
              Restore realistic sample records or completely wipe all local data.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setResetConfirmOpen(true)}
              className="px-3 py-1.5 font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Demo Data</span>
            </button>

            <button
              type="button"
              onClick={() => setClearConfirmOpen(true)}
              className="px-3 py-1.5 font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Records</span>
            </button>
          </div>
        </div>
      </div>

      {/* Confirm Dialogs */}
      <ConfirmDialog
        isOpen={resetConfirmOpen}
        title="Reset Demo Records?"
        message="This will replace current entries with realistic sample customers, invoices, and follow-ups. Any unsaved custom records will be overwritten."
        confirmLabel="Reset Demo Data"
        onConfirm={() => {
          resetDemoData();
          setResetConfirmOpen(false);
          setForm({ ...settings });
        }}
        onCancel={() => setResetConfirmOpen(false)}
      />

      <ConfirmDialog
        isOpen={clearConfirmOpen}
        title="Permanently Erase All Data?"
        message="This will completely wipe all customers, invoices, and follow-ups from your local browser storage. This action cannot be undone."
        confirmLabel="Erase Everything"
        isDestructive
        onConfirm={() => {
          clearAllData();
          setClearConfirmOpen(false);
        }}
        onCancel={() => setClearConfirmOpen(false)}
      />
    </div>
  );
};
