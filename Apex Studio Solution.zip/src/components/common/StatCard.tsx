import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  subtext?: string;
  icon: LucideIcon;
  variant?: 'default' | 'danger' | 'warning' | 'success';
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  subtext,
  icon: Icon,
  variant = 'default',
  onClick,
}) => {
  let iconBg = 'bg-slate-100 text-slate-700';
  let borderHighlight = 'border-slate-200';

  if (variant === 'danger') {
    iconBg = 'bg-rose-50 text-rose-600';
    borderHighlight = 'border-rose-200/80';
  } else if (variant === 'warning') {
    iconBg = 'bg-amber-50 text-amber-600';
    borderHighlight = 'border-amber-200/80';
  } else if (variant === 'success') {
    iconBg = 'bg-emerald-50 text-emerald-600';
    borderHighlight = 'border-emerald-200/80';
  }

  const Wrapper = onClick ? 'button' : 'div';

  return (
    <Wrapper
      onClick={onClick}
      className={`relative w-full text-left bg-white p-5 rounded-xl border ${borderHighlight} shadow-2xs hover:shadow-xs transition-all ${
        onClick ? 'cursor-pointer hover:border-slate-300' : ''
      }`}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">
            {label}
          </p>
          <h3 className="text-2xl font-bold text-slate-900 mt-1.5 tabular-nums">
            {value}
          </h3>
          {subtext && (
            <p className="text-xs text-slate-500 mt-1 font-normal flex items-center gap-1">
              {subtext}
            </p>
          )}
        </div>
        <div className={`p-2.5 rounded-lg shrink-0 ${iconBg}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </Wrapper>
  );
};
