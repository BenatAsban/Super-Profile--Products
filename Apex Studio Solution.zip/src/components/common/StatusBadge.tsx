import React from 'react';
import { InvoiceStatus, PriorityLevel } from '../../types';

interface StatusBadgeProps {
  status: InvoiceStatus;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';

  switch (status) {
    case 'Paid':
      return (
        <span
          className={`inline-flex items-center font-medium rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200/60 ${sizeClasses} whitespace-nowrap`}
        >
          Paid
        </span>
      );
    case 'Overdue':
      return (
        <span
          className={`inline-flex items-center font-medium rounded-md bg-rose-50 text-rose-700 border border-rose-200/60 ${sizeClasses} whitespace-nowrap`}
        >
          Overdue
        </span>
      );
    case 'Partially paid':
      return (
        <span
          className={`inline-flex items-center font-medium rounded-md bg-amber-50 text-amber-700 border border-amber-200/60 ${sizeClasses} whitespace-nowrap`}
        >
          Partially Paid
        </span>
      );
    case 'Unpaid':
    default:
      return (
        <span
          className={`inline-flex items-center font-medium rounded-md bg-slate-100 text-slate-700 border border-slate-200 ${sizeClasses} whitespace-nowrap`}
        >
          Unpaid
        </span>
      );
  }
};

export const PriorityBadge: React.FC<{ priority: PriorityLevel }> = ({ priority }) => {
  switch (priority) {
    case 'High':
      return (
        <span className="inline-flex items-center text-xs font-semibold text-rose-700 whitespace-nowrap">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-600 mr-1.5" />
          High Priority
        </span>
      );
    case 'Medium':
      return (
        <span className="inline-flex items-center text-xs font-medium text-amber-700 whitespace-nowrap">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mr-1.5" />
          Medium Priority
        </span>
      );
    case 'Low':
    default:
      return (
        <span className="inline-flex items-center text-xs font-medium text-slate-600 whitespace-nowrap">
          <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mr-1.5" />
          Low Priority
        </span>
      );
  }
};
