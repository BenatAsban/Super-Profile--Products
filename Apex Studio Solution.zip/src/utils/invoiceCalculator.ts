import { Invoice, InvoiceStatus } from '../types';
import { isPastDate } from './date';

export function getInvoicePaidAmount(invoice: Invoice): number {
  if (!invoice.payments || !Array.isArray(invoice.payments)) return 0;
  return invoice.payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
}

export function getInvoiceBalance(invoice: Invoice): number {
  const total = Number(invoice.amount) || 0;
  const paid = getInvoicePaidAmount(invoice);
  return Math.max(0, total - paid);
}

export function getInvoiceEffectiveStatus(invoice: Invoice): InvoiceStatus {
  const balance = getInvoiceBalance(invoice);
  const paid = getInvoicePaidAmount(invoice);
  const total = Number(invoice.amount) || 0;

  if (total > 0 && balance <= 0.001) {
    return 'Paid';
  }

  // If unpaid or partially paid and due date is past today
  if (isPastDate(invoice.dueDate)) {
    return 'Overdue';
  }

  if (paid > 0) {
    return 'Partially paid';
  }

  return 'Unpaid';
}
