export function todayISO(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const date = new Date(year, month, day);
      return date.toLocaleDateString('en-US', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    }
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function isToday(dateStr: string | null | undefined): boolean {
  if (!dateStr) return false;
  return dateStr === todayISO();
}

export function isPastDate(dateStr: string | null | undefined): boolean {
  if (!dateStr) return false;
  const today = todayISO();
  return dateStr < today;
}

export function getDaysOverdue(dueDateStr: string | null | undefined): number {
  if (!dueDateStr) return 0;
  const today = todayISO();
  if (dueDateStr >= today) return 0;

  const due = new Date(dueDateStr).getTime();
  const current = new Date(today).getTime();
  const diffDays = Math.ceil((current - due) / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}

export function addDays(dateStr: string, days: number): string {
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const date = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
      date.setDate(date.getDate() + days);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    }
    const d = new Date(dateStr);
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  } catch {
    return todayISO();
  }
}

export function formatRelativeDays(dateStr: string): string {
  if (!dateStr) return '';
  const today = todayISO();
  if (dateStr === today) return 'Today';
  const tomorrow = addDays(today, 1);
  if (dateStr === tomorrow) return 'Tomorrow';
  const yesterday = addDays(today, -1);
  if (dateStr === yesterday) return 'Yesterday';

  const days = Math.round((new Date(dateStr).getTime() - new Date(today).getTime()) / (1000 * 60 * 60 * 24));
  if (days < 0) {
    return `${Math.abs(days)}d overdue`;
  }
  return `in ${days}d`;
}
