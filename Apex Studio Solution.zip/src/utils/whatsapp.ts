import { formatCurrency } from './currency';
import { formatDate, getDaysOverdue, isPastDate } from './date';
import { Invoice, AppSettings } from '../types';
import { getInvoiceBalance } from './invoiceCalculator';

export interface PhoneValidationResult {
  isValid: boolean;
  rawCleaned: string; // E.g. "919876543210" without '+' or spaces
  displayFormatted: string;
  error?: string;
}

/**
 * Validates and normalizes phone numbers for WhatsApp click-to-chat (wa.me)
 * Removes spaces, dashes, parentheses. If missing leading country code, can prepend defaultCountryCode.
 */
export function validateAndCleanPhoneNumber(phone: string, defaultCountryCode = '91'): PhoneValidationResult {
  if (!phone || typeof phone !== 'string') {
    return {
      isValid: false,
      rawCleaned: '',
      displayFormatted: phone || '',
      error: 'Phone number is required.',
    };
  }

  // Remove non-digit characters except leading plus
  let cleaned = phone.replace(/[\s\-\(\)\.]/g, '');

  // Strip leading plus if present
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // Strip leading 00 (international dialing prefix)
  if (cleaned.startsWith('00')) {
    cleaned = cleaned.substring(2);
  }

  // If local 10-digit number (common in India, US, etc.) without country code
  if (/^\d{10}$/.test(cleaned)) {
    const cleanCC = defaultCountryCode.replace(/\D/g, '');
    cleaned = `${cleanCC}${cleaned}`;
  }

  // General check: valid international phone numbers have between 8 and 15 digits
  const digitRegex = /^\d{8,15}$/;
  if (!digitRegex.test(cleaned)) {
    return {
      isValid: false,
      rawCleaned: cleaned,
      displayFormatted: phone,
      error: 'Please provide a valid phone number with country code (e.g., +91 98765 43210 or 919876543210).',
    };
  }

  return {
    isValid: true,
    rawCleaned: cleaned,
    displayFormatted: `+${cleaned}`,
  };
}

export type ReminderTemplateType = 'polite' | 'due_soon' | 'overdue' | 'urgent';

export function generateReminderMessage(
  templateType: ReminderTemplateType,
  invoice: Invoice,
  settings: AppSettings
): string {
  const balance = getInvoiceBalance(invoice);
  const formattedBalance = formatCurrency(balance, settings.currency);
  const formattedDueDate = formatDate(invoice.dueDate);
  const daysOverdue = getDaysOverdue(invoice.dueDate);
  const isOverdue = isPastDate(invoice.dueDate) && balance > 0;

  const paymentInfo = settings.paymentDetails ? `\n\nPayment Details:\n${settings.paymentDetails}` : '';

  switch (templateType) {
    case 'due_soon':
      return `Hello ${invoice.customerName},\n\nThis is a friendly reminder from ${settings.businessName} regarding invoice #${invoice.invoiceNumber} for ${formattedBalance}, which is due on ${formattedDueDate}.\n\nIf you have already processed this payment, please disregard this note. Thank you for your continued business!${paymentInfo}\n\nWarm regards,\n${settings.businessName}`;

    case 'overdue':
      return `Dear ${invoice.customerName},\n\nWe hope this finds you well. Our records show that invoice #${invoice.invoiceNumber} for ${formattedBalance} was due on ${formattedDueDate} (${daysOverdue > 0 ? `${daysOverdue} days overdue` : 'now overdue'}).\n\nCould you please confirm when we can expect the settlement or let us know if there is any dispute?${paymentInfo}\n\nThank you,\n${settings.businessName}`;

    case 'urgent':
      return `URGENT NOTICE:\nDear ${invoice.customerName},\n\nThis is a follow-up from ${settings.businessName} regarding outstanding invoice #${invoice.invoiceNumber} with an unpaid balance of ${formattedBalance}. This invoice was due on ${formattedDueDate}.\n\nPlease arrange for payment settlement today to prevent any disruption in our ongoing services.${paymentInfo}\n\nThank you for your prompt attention.\n${settings.businessName}`;

    case 'polite':
    default:
      return `Hi ${invoice.customerName},\n\nGreetings from ${settings.businessName}. We are sharing a gentle follow-up regarding invoice #${invoice.invoiceNumber} with an outstanding balance of ${formattedBalance} (Due date: ${formattedDueDate}).\n\nPlease let us know if you have any questions or need a copy of the invoice.${paymentInfo}\n\nThank you,\n${settings.businessName}`;
  }
}

export function buildWhatsAppUrl(phoneClean: string, message: string): string {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${phoneClean}?text=${encoded}`;
}
