import { Customer, Invoice, FollowUp, CustomerCategory } from '../types';
import { getInvoicePaidAmount, getInvoiceBalance, getInvoiceEffectiveStatus } from './invoiceCalculator';

function escapeCSVCell(val: unknown): string {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

function triggerDownload(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function exportCustomersToCSV(customers: Customer[], invoices: Invoice[]): void {
  const headers = [
    'Customer ID',
    'Customer Name',
    'Business Name',
    'Phone',
    'Email',
    'Category',
    'Total Invoiced',
    'Total Balance Due',
    'Notes',
    'Created Date',
  ];

  const rows = customers.map((c) => {
    const custInvoices = invoices.filter((inv) => inv.customerId === c.id);
    const totalInvoiced = custInvoices.reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
    const totalBalance = custInvoices.reduce((sum, inv) => sum + getInvoiceBalance(inv), 0);

    return [
      escapeCSVCell(c.id),
      escapeCSVCell(c.name),
      escapeCSVCell(c.businessName),
      escapeCSVCell(c.phone),
      escapeCSVCell(c.email),
      escapeCSVCell(c.category),
      escapeCSVCell(totalInvoiced.toFixed(2)),
      escapeCSVCell(totalBalance.toFixed(2)),
      escapeCSVCell(c.notes || ''),
      escapeCSVCell(c.createdAt),
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\n');
  const dateStr = new Date().toISOString().split('T')[0];
  triggerDownload(csvContent, `followupdesk_customers_${dateStr}.csv`);
}

export function exportInvoicesToCSV(invoices: Invoice[]): void {
  const headers = [
    'Invoice Number',
    'Customer Name',
    'Customer ID',
    'Description',
    'Total Amount',
    'Paid Amount',
    'Remaining Balance',
    'Effective Status',
    'Issue Date',
    'Due Date',
    'Notes',
    'Created Date',
  ];

  const rows = invoices.map((inv) => {
    const paid = getInvoicePaidAmount(inv);
    const balance = getInvoiceBalance(inv);
    const status = getInvoiceEffectiveStatus(inv);

    return [
      escapeCSVCell(inv.invoiceNumber),
      escapeCSVCell(inv.customerName),
      escapeCSVCell(inv.customerId),
      escapeCSVCell(inv.description),
      escapeCSVCell(Number(inv.amount).toFixed(2)),
      escapeCSVCell(paid.toFixed(2)),
      escapeCSVCell(balance.toFixed(2)),
      escapeCSVCell(status),
      escapeCSVCell(inv.issueDate),
      escapeCSVCell(inv.dueDate),
      escapeCSVCell(inv.notes || ''),
      escapeCSVCell(inv.createdAt),
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\n');
  const dateStr = new Date().toISOString().split('T')[0];
  triggerDownload(csvContent, `followupdesk_invoices_${dateStr}.csv`);
}

export function exportFollowUpsToCSV(followUps: FollowUp[]): void {
  const headers = [
    'Follow-up ID',
    'Customer Name',
    'Invoice Number',
    'Follow-up Date',
    'Type',
    'Priority',
    'Status',
    'Notes',
    'Completed Date',
    'Created Date',
  ];

  const rows = followUps.map((f) => [
    escapeCSVCell(f.id),
    escapeCSVCell(f.customerName),
    escapeCSVCell(f.invoiceNumber || 'N/A'),
    escapeCSVCell(f.date),
    escapeCSVCell(f.type),
    escapeCSVCell(f.priority),
    escapeCSVCell(f.completed ? 'Completed' : 'Pending'),
    escapeCSVCell(f.notes),
    escapeCSVCell(f.completedAt || ''),
    escapeCSVCell(f.createdAt),
  ].join(','));

  const csvContent = [headers.join(','), ...rows].join('\n');
  const dateStr = new Date().toISOString().split('T')[0];
  triggerDownload(csvContent, `followupdesk_followups_${dateStr}.csv`);
}

export function generateSampleCustomerCSV(): string {
  const headers = ['Customer Name', 'Business Name', 'Phone', 'Email', 'Category', 'Notes'];
  const sampleRows = [
    ['Rajesh Patel', 'Patel Logistics LLP', '+91 98200 11223', 'rajesh@patellogistics.in', 'Corporate', 'Key transport client, net 30 payment cycle'],
    ['Ananya Iyer', 'Zenith Creative Studio', '+91 98450 55667', 'ananya@zenithstudio.com', 'Service', 'Designs brochures and branding campaigns'],
    ['David Miller', 'Apex Hardware Ltd', '+1 415 555 2671', 'david@apexhardware.com', 'Wholesale', 'Monthly bulk fastener orders'],
  ];

  const lines = [
    headers.join(','),
    ...sampleRows.map((r) => r.map(escapeCSVCell).join(',')),
  ];
  return lines.join('\n');
}

export interface CSVParseResult {
  valid: Omit<Customer, 'id' | 'createdAt'>[];
  errors: { row: number; reason: string }[];
  totalRows: number;
}

export function parseCustomerCSV(csvText: string): CSVParseResult {
  const lines = csvText
    .split(/\r\n|\n|\r/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length < 2) {
    return {
      valid: [],
      errors: [{ row: 1, reason: 'File is empty or does not contain data rows.' }],
      totalRows: 0,
    };
  }

  // Parse header line respecting quotes
  const parseCSVLine = (line: string): string[] => {
    const result: string[] = [];
    let cur = '';
    let inQuote = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (inQuote && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQuote = !inQuote;
        }
      } else if (char === ',' && !inQuote) {
        result.push(cur.trim());
        cur = '';
      } else {
        cur += char;
      }
    }
    result.push(cur.trim());
    return result;
  };

  const rawHeaders = parseCSVLine(lines[0]).map((h) => h.toLowerCase().replace(/[\s_\-]/g, ''));
  const headerMap: { [key: string]: number } = {};

  rawHeaders.forEach((h, idx) => {
    if (h.includes('customername') || h === 'name' || h === 'fullname') headerMap['name'] = idx;
    else if (h.includes('business') || h.includes('company') || h.includes('organization')) headerMap['businessName'] = idx;
    else if (h.includes('phone') || h.includes('mobile') || h.includes('contact')) headerMap['phone'] = idx;
    else if (h.includes('email') || h.includes('mail')) headerMap['email'] = idx;
    else if (h.includes('category') || h.includes('type')) headerMap['category'] = idx;
    else if (h.includes('note') || h.includes('remark') || h.includes('description')) headerMap['notes'] = idx;
  });

  if (headerMap['name'] === undefined) {
    return {
      valid: [],
      errors: [{ row: 1, reason: 'Missing required "Customer Name" column header.' }],
      totalRows: lines.length - 1,
    };
  }

  const valid: Omit<Customer, 'id' | 'createdAt'>[] = [];
  const errors: { row: number; reason: string }[] = [];

  const validCategories: CustomerCategory[] = ['Retail', 'Wholesale', 'Corporate', 'Service', 'Individual'];

  for (let i = 1; i < lines.length; i++) {
    const rowNum = i + 1;
    const cells = parseCSVLine(lines[i]);

    const name = cells[headerMap['name']] || '';
    const businessName = headerMap['businessName'] !== undefined ? cells[headerMap['businessName']] || '' : '';
    const phone = headerMap['phone'] !== undefined ? cells[headerMap['phone']] || '' : '';
    const email = headerMap['email'] !== undefined ? cells[headerMap['email']] || '' : '';
    const rawCategory = headerMap['category'] !== undefined ? cells[headerMap['category']] || '' : '';
    const notes = headerMap['notes'] !== undefined ? cells[headerMap['notes']] || '' : '';

    if (!name.trim()) {
      errors.push({ row: rowNum, reason: 'Customer Name cannot be empty.' });
      continue;
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errors.push({ row: rowNum, reason: `Invalid email address format: "${email}".` });
      continue;
    }

    // Match category loosely or default to 'Individual'
    let category: CustomerCategory = 'Individual';
    const foundCat = validCategories.find(
      (c) => c.toLowerCase() === rawCategory.trim().toLowerCase()
    );
    if (foundCat) {
      category = foundCat;
    } else if (businessName) {
      category = 'Corporate';
    }

    valid.push({
      name: name.trim(),
      businessName: businessName.trim() || name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      category,
      notes: notes.trim(),
    });
  }

  return {
    valid,
    errors,
    totalRows: lines.length - 1,
  };
}
