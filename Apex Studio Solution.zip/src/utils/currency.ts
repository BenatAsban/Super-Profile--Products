export interface CurrencyOption {
  code: string;
  name: string;
  symbol: string;
  locale: string;
}

export const SUPPORTED_CURRENCIES: CurrencyOption[] = [
  { code: 'INR', name: 'Indian Rupee (₹)', symbol: '₹', locale: 'en-IN' },
  { code: 'USD', name: 'US Dollar ($)', symbol: '$', locale: 'en-US' },
  { code: 'EUR', name: 'Euro (€)', symbol: '€', locale: 'de-DE' },
  { code: 'GBP', name: 'British Pound (£)', symbol: '£', locale: 'en-GB' },
  { code: 'AED', name: 'UAE Dirham (AED)', symbol: 'AED', locale: 'en-AE' },
  { code: 'CAD', name: 'Canadian Dollar (C$)', symbol: 'CA$', locale: 'en-CA' },
  { code: 'AUD', name: 'Australian Dollar (A$)', symbol: 'AU$', locale: 'en-AU' },
  { code: 'SGD', name: 'Singapore Dollar (S$)', symbol: 'SG$', locale: 'en-SG' },
  { code: 'JPY', name: 'Japanese Yen (¥)', symbol: '¥', locale: 'ja-JP' },
];

export function getCurrencyConfig(currencyCode: string): CurrencyOption {
  const found = SUPPORTED_CURRENCIES.find((c) => c.code.toUpperCase() === currencyCode.toUpperCase());
  return found || SUPPORTED_CURRENCIES[0];
}

export function formatCurrency(amount: number | null | undefined, currencyCode = 'INR'): string {
  const safeAmount = typeof amount === 'number' && !isNaN(amount) ? amount : 0;
  const config = getCurrencyConfig(currencyCode);

  try {
    return new Intl.NumberFormat(config.locale, {
      style: 'currency',
      currency: config.code,
      minimumFractionDigits: config.code === 'JPY' ? 0 : 2,
      maximumFractionDigits: config.code === 'JPY' ? 0 : 2,
    }).format(safeAmount);
  } catch {
    // Fallback if locale or currency code is unsupported in specific environment
    return `${config.symbol} ${safeAmount.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  }
}
