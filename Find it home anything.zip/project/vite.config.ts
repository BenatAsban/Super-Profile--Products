import { defineConfig } from 'vite';

// Pure vanilla HTML/CSS/JS app — no React plugin needed.
export default defineConfig({
  server: {
    open: false,
  },
});
