/* ============================================================
   FindIt Home — Application Logic
   Vanilla JS + Bootstrap 5 + localStorage
   ============================================================ */

'use strict';

/* ---------- Constants ---------- */
const STORAGE_KEY = 'findit_home_v1';

const CATEGORIES = [
  'Electronics',
  'Medicines',
  'Documents',
  'Kitchen Items',
  'Clothing',
  'Tools',
  'Accessories',
  'Household Essentials',
  'Other',
];

const DEFAULT_ROOMS = [
  { name: 'Living Room', icon: 'bi-display' },
  { name: 'Bedroom', icon: 'bi-moon-stars' },
  { name: 'Kitchen', icon: 'bi-cup-hot' },
  { name: 'Bathroom', icon: 'bi-droplet' },
  { name: 'Hallway', icon: 'bi-door-open' },
  { name: 'Study Room', icon: 'bi-book' },
  { name: 'Storage Room', icon: 'bi-box-seam' },
  { name: 'Other', icon: 'bi-building' },
];

const ROOM_ACCENTS = [
  'room-accent-blue',
  'room-accent-green',
  'room-accent-amber',
  'room-accent-pink',
  'room-accent-teal',
  'room-accent-violet',
  'room-accent-slate',
  'room-accent-rose',
];

/* ---------- State ---------- */
let state = {
  items: [],
  rooms: [],
  members: [],
  activeRoom: null, // when filtering via room card click
};

let pendingDeleteId = null;
let pendingRestoreData = null;

/* ---------- DOM refs ---------- */
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

/* ---------- Storage ---------- */
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      state.rooms = DEFAULT_ROOMS.map((r) => ({ ...r }));
      return;
    }
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') {
      state.rooms = DEFAULT_ROOMS.map((r) => ({ ...r }));
      return;
    }
    state.items = Array.isArray(parsed.items) ? parsed.items : [];
    state.rooms =
      Array.isArray(parsed.rooms) && parsed.rooms.length > 0
        ? parsed.rooms
        : DEFAULT_ROOMS.map((r) => ({ ...r }));
    state.members = Array.isArray(parsed.members) ? parsed.members : [];
  } catch (err) {
    console.warn('FindIt: could not parse saved data, starting fresh.', err);
    state.rooms = DEFAULT_ROOMS.map((r) => ({ ...r }));
  }
}

function saveState() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        items: state.items,
        rooms: state.rooms,
        members: state.members,
      })
    );
  } catch (err) {
    showToast(
      'Could not save data — browser storage may be full or unavailable.',
      'error'
    );
    console.error('FindIt save error:', err);
  }
}

/* ---------- Helpers ---------- */
function uid() {
  return 'i_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
}

function roomNames() {
  return state.rooms.map((r) => r.name);
}

function roomIcon(name) {
  const r = state.rooms.find((x) => x.name === name);
  return r ? r.icon : 'bi-door-open';
}

function roomAccent(name) {
  const idx = roomNames().indexOf(name);
  return idx >= 0 ? ROOM_ACCENTS[idx % ROOM_ACCENTS.length] : 'room-accent-slate';
}

function catClass(cat) {
  return 'cat-' + cat.replace(/\s+/g, '-');
}

function formatDate(ts) {
  if (!ts) return 'Unknown';
  const d = new Date(ts);
  return d.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }) + ', ' + d.toLocaleTimeString(undefined, {
    hour: 'numeric',
    minute: '2-digit',
  });
}

function relativeTime(ts) {
  if (!ts) return 'Unknown';
  const now = Date.now();
  const diff = now - ts;
  const sec = Math.floor(diff / 1000);
  const min = Math.floor(sec / 60);
  const hr = Math.floor(min / 60);
  const day = Math.floor(hr / 24);

  if (sec < 60) return 'Just now';
  if (min < 60) return min + ' min ago';
  if (hr < 24) return hr + ' hr ago';
  if (day === 1) return 'Yesterday';
  if (day < 7) return day + ' days ago';
  if (day < 30) return Math.floor(day / 7) + ' wk ago';
  return formatDate(ts);
}

function escapeHtml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function highlight(text, query) {
  const safe = escapeHtml(text);
  if (!query) return safe;
  const q = query.trim();
  if (!q) return safe;
  try {
    const re = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
    return safe.replace(re, '<mark>$1</mark>');
  } catch {
    return safe;
  }
}

/* ---------- Toast ---------- */
function showToast(message, type = 'success') {
  const container = $('#toastContainer');
  const id = 'toast_' + Date.now();
  const icon =
    type === 'error' ? 'bi-x-circle-fill' : 'bi-check-circle-fill';
  const cls = type === 'error' ? 'toast-error' : 'toast-success';

  const el = document.createElement('div');
  el.className = 'toast ' + cls + ' show';
  el.id = id;
  el.setAttribute('role', 'alert');
  el.innerHTML =
    '<div class="toast-body d-flex align-items-center gap-2">' +
    '<i class="bi ' + icon + '"></i><span>' + escapeHtml(message) + '</span>' +
    '</div>';
  container.appendChild(el);

  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, 3000);
}

/* ---------- Rendering: Summary cards ---------- */
function renderSummary() {
  const totalItems = state.items.length;
  const rooms = state.rooms.length;
  const recentlyMoved = state.items.filter((i) => i.lastMovedAt).length;
  const noLocation = state.items.filter(
    (i) => !i.room && !i.specificLocation
  ).length;

  const cards = [
    {
      icon: 'bi-box-seam-fill',
      accent: 'room-accent-blue',
      value: totalItems,
      label: 'Total Items',
    },
    {
      icon: 'bi-door-open-fill',
      accent: 'room-accent-green',
      value: rooms,
      label: 'Rooms',
    },
    {
      icon: 'bi-clock-history',
      accent: 'room-accent-amber',
      value: recentlyMoved,
      label: 'Recently Moved',
    },
    {
      icon: 'bi-exclamation-circle-fill',
      accent: 'room-accent-rose',
      value: noLocation,
      label: 'No Location',
    },
  ];

  $('#summaryCards').innerHTML = cards
    .map(
      (c) =>
        '<div class="col-6 col-lg-3">' +
        '<div class="card summary-card h-100">' +
        '<div class="card-body d-flex align-items-center gap-3 p-3">' +
        '<span class="summary-icon ' + c.accent + '"><i class="bi ' + c.icon + '"></i></span>' +
        '<div>' +
        '<div class="summary-value">' + c.value + '</div>' +
        '<div class="summary-label">' + c.label + '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>'
    )
    .join('');
}

/* ---------- Rendering: Room map ---------- */
function renderRooms() {
  const grid = $('#roomGrid');
  if (state.rooms.length === 0) {
    grid.innerHTML =
      '<div class="col-12"><div class="empty-state"><i class="bi bi-door-closed"></i><p>No rooms yet. Add a room to get started.</p></div></div>';
    return;
  }

  grid.innerHTML = state.rooms
    .map((room) => {
      const itemsInRoom = state.items.filter((i) => i.room === room.name);
      const count = itemsInRoom.length;
      const preview = itemsInRoom
        .slice(0, 3)
        .map((i) => '<span class="preview-chip">' + escapeHtml(i.name) + '</span>')
        .join('');
      const extra =
        count > 3
          ? '<span class="preview-chip">+' + (count - 3) + ' more</span>'
          : '';

      return (
        '<div class="col-6 col-md-4 col-lg-3">' +
        '<div class="room-card h-100" data-room="' + escapeHtml(room.name) + '" tabindex="0" role="button" aria-label="View items in ' + escapeHtml(room.name) + '">' +
        '<div class="room-card-header">' +
        '<span class="room-icon ' + roomAccent(room.name) + '"><i class="bi ' + room.icon + '"></i></span>' +
        '<div class="flex-grow-1">' +
        '<p class="room-name">' + escapeHtml(room.name) + '</p>' +
        '<span class="room-count">' + count + (count === 1 ? ' item' : ' items') + '</span>' +
        '</div>' +
        (isCustomRoom(room.name)
          ? '<button class="btn btn-sm text-danger p-0 px-1 delete-room-btn" data-room="' + escapeHtml(room.name) + '" aria-label="Delete room" title="Delete room"><i class="bi bi-trash"></i></button>'
          : '') +
        '</div>' +
        '<div class="room-preview">' +
        (count > 0 ? preview + extra : '<span class="room-empty">Nothing stored here yet.</span>') +
        '</div>' +
        '<div class="room-card-footer d-flex align-items-center justify-content-between">' +
        '<span class="small fw-bold text-primary">View Items</span>' +
        '<i class="bi bi-arrow-right text-primary"></i>' +
        '</div>' +
        '</div>' +
        '</div>'
      );
    })
    .join('');
}

function isCustomRoom(name) {
  return !DEFAULT_ROOMS.some((r) => r.name === name);
}

/* ---------- Rendering: Item list ---------- */
function getFilteredItems() {
  const q = ($('#mainSearch').value || '').trim().toLowerCase();
  const navQ = ($('#navSearch') ? $('#navSearch').value : '').trim().toLowerCase();
  const mobileQ = ($('#mobileSearch') ? $('#mobileSearch').value : '').trim().toLowerCase();
  const query = q || navQ || mobileQ;

  const fRoom = $('#filterRoom').value;
  const fCat = $('#filterCategory').value;
  const fMember = $('#filterMember').value;
  const fRecent = $('#filterRecent').value;
  const sortBy = $('#sortBy').value;

  let list = state.items.slice();

  // active room from room card click
  if (state.activeRoom) {
    list = list.filter((i) => i.room === state.activeRoom);
  }

  if (query) {
    list = list.filter((i) =>
      [i.name, i.room, i.specificLocation, i.category, i.lastMovedBy, i.notes]
        .filter(Boolean)
        .some((v) => v.toLowerCase().includes(query))
    );
  }

  if (fRoom) list = list.filter((i) => i.room === fRoom);
  if (fCat) list = list.filter((i) => i.category === fCat);
  if (fMember) list = list.filter((i) => i.lastMovedBy === fMember);

  if (fRecent) {
    const now = Date.now();
    const ranges = { today: 864e5, week: 6048e5, month: 2592e6 };
    const span = ranges[fRecent];
    list = list.filter((i) => i.lastMovedAt && now - i.lastMovedAt <= span);
  }

  switch (sortBy) {
    case 'name':
      list.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case 'room':
      list.sort((a, b) => (a.room || '').localeCompare(b.room || ''));
      break;
    case 'recent':
    default:
      list.sort((a, b) => (b.lastMovedAt || 0) - (a.lastMovedAt || 0));
  }

  return { list, query };
}

function renderItems() {
  const { list, query } = getFilteredItems();
  const container = $('#itemsList');
  $('#itemsCountBadge').textContent = list.length;

  if (list.length === 0) {
    container.innerHTML =
      '<div class="col-12"><div class="empty-state"><i class="bi bi-inbox"></i><p>' +
      (query
        ? 'No items found. Try another search or add a new item.'
        : state.activeRoom
        ? 'No items in this room.'
        : 'No items added yet. Add your first household item.') +
      '</p></div></div>';
    return;
  }

  container.innerHTML = list
    .map((i) => itemCardHtml(i, query))
    .join('');
}

function itemCardHtml(i, query = '') {
  const locationLine = [i.room, i.specificLocation]
    .filter(Boolean)
    .map((p) => highlight(p, query))
    .join(' — ');

  return (
    '<div class="col-12 col-md-6 col-lg-4">' +
    '<div class="item-card">' +
    '<div class="item-card-body">' +
    '<div class="item-name">' + highlight(i.name, query) + '</div>' +
    '<span class="cat-badge ' + catClass(i.category) + '">' + escapeHtml(i.category) + '</span>' +
    (locationLine
      ? '<div class="d-block mt-2"><span class="item-location-line"><i class="bi bi-geo-alt-fill me-1"></i>' + locationLine + '</span></div>'
      : '<div class="d-block mt-2"><span class="item-location-line text-muted"><i class="bi bi-geo-alt me-1"></i>No location set</span></div>') +
    (i.lastMovedBy
      ? '<div class="item-meta"><i class="bi bi-person"></i> <span class="member-tag"><i class="bi bi-person-circle"></i>' + highlight(i.lastMovedBy, query) + '</span></div>'
      : '') +
    (i.lastMovedAt
      ? '<div class="item-meta"><i class="bi bi-clock"></i> Last moved: <strong>' + relativeTime(i.lastMovedAt) + '</strong></div>'
      : '') +
    (i.notes
      ? '<div class="item-meta"><i class="bi bi-sticky"></i> ' + highlight(i.notes, query) + '</div>'
      : '') +
    '<div class="item-actions">' +
    '<button class="btn btn-outline-primary edit-item-btn" data-id="' + i.id + '"><i class="bi bi-pencil me-1"></i>Edit</button>' +
    '<button class="btn btn-primary move-item-btn" data-id="' + i.id + '"><i class="bi bi-box-arrow-right me-1"></i>Move</button>' +
    '<button class="btn btn-outline-danger delete-item-btn" data-id="' + i.id + '"><i class="bi bi-trash"></i></button>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</div>'
  );
}

/* ---------- Rendering: Search results (inline under quick search) ---------- */
function renderSearchResults() {
  const q = ($('#mainSearch').value || '').trim();
  const container = $('#searchResults');
  if (!q) {
    container.innerHTML = '';
    return;
  }
  const lower = q.toLowerCase();
  const matches = state.items.filter((i) =>
    [i.name, i.room, i.specificLocation, i.category, i.lastMovedBy, i.notes]
      .filter(Boolean)
      .some((v) => v.toLowerCase().includes(lower))
  );

  if (matches.length === 0) {
    container.innerHTML =
      '<div class="empty-state py-3"><i class="bi bi-search"></i><p>No items found. Try another search or add a new item.</p></div>';
    return;
  }

  container.innerHTML =
    '<p class="small text-secondary mb-2 fw-bold">' +
    matches.length + (matches.length === 1 ? ' match' : ' matches') +
    '</p>' +
    matches
      .map((i) => {
        const loc = [i.room, i.specificLocation].filter(Boolean).join(' — ');
        return (
          '<div class="search-result-item">' +
          '<div class="flex-grow-1">' +
          '<div class="fw-bold">' + highlight(i.name, q) + '</div>' +
          '<div class="small text-secondary"><i class="bi bi-geo-alt-fill text-primary"></i> ' + (loc ? highlight(loc, q) : 'No location set') + '</div>' +
          '</div>' +
          '<span class="cat-badge ' + catClass(i.category) + '">' + escapeHtml(i.category) + '</span>' +
          '</div>'
        );
      })
      .join('');
}

/* ---------- Rendering: Recently moved ---------- */
function renderRecent() {
  const container = $('#recentList');
  const moved = state.items
    .filter((i) => i.lastMovedAt)
    .sort((a, b) => b.lastMovedAt - a.lastMovedAt)
    .slice(0, 5);

  if (moved.length === 0) {
    container.innerHTML =
      '<div class="empty-state"><i class="bi bi-clock"></i><p>No recently moved items.</p></div>';
    return;
  }

  container.innerHTML = moved
    .map((i) => {
      const history = Array.isArray(i.history) ? i.history : [];
      const prev = history.length > 0 ? history[0] : null;
      const prevLoc = prev
        ? [prev.room, prev.specificLocation].filter(Boolean).join(' — ')
        : '';
      const curLoc = [i.room, i.specificLocation].filter(Boolean).join(' — ');

      return (
        '<div class="recent-row">' +
        '<i class="bi bi-arrow-left-right recent-arrow"></i>' +
        '<div class="flex-grow-1">' +
        '<div class="recent-item-name">' + escapeHtml(i.name) + '</div>' +
        '<div class="recent-meta">' +
        (prevLoc
          ? '<span class="text-secondary">From:</span> ' + escapeHtml(prevLoc) + ' &rarr; '
          : '') +
        '<strong>' + escapeHtml(curLoc || 'No location') + '</strong>' +
        (i.lastMovedBy ? ' &middot; <i class="bi bi-person-circle"></i> ' + escapeHtml(i.lastMovedBy) : '') +
        '</div>' +
        '</div>' +
        '<span class="recent-time">' + relativeTime(i.lastMovedAt) + '</span>' +
        '</div>'
      );
    })
    .join('');
}

/* ---------- Rendering: Filters ---------- */
function populateFilters() {
  populateSelect($('#filterRoom'), roomNames(), 'All rooms');
  populateSelect($('#filterCategory'), CATEGORIES, 'All categories');
  populateSelect($('#filterMember'), state.members, 'Everyone');
}

function populateSelect(select, options, placeholder) {
  if (!select) return;
  const current = select.value;
  select.innerHTML =
    '<option value="">' + placeholder + '</option>' +
    options
      .map((o) => '<option value="' + escapeHtml(o) + '">' + escapeHtml(o) + '</option>')
      .join('');
  select.value = current;
}

/* ---------- Modal population ---------- */
function populateCategorySelect() {
  $('#itemCategory').innerHTML = CATEGORIES.map(
    (c) => '<option value="' + c + '">' + c + '</option>'
  ).join('');
}

function populateRoomSelects() {
  const opts = roomNames()
    .map((n) => '<option value="' + escapeHtml(n) + '">' + escapeHtml(n) + '</option>')
    .join('');
  $('#itemRoom').innerHTML = opts;
  $('#moveRoom').innerHTML = opts;
}

function populateMemberDatalist() {
  $('#memberList').innerHTML = state.members
    .map((m) => '<option value="' + escapeHtml(m) + '"></option>')
    .join('');
}

/* ---------- Add/Edit item ---------- */
let itemModalInstance = null;

function openItemModal(editId = null) {
  const modal = $('#itemModal');
  const form = $('#itemForm');
  form.classList.remove('was-validated');

  populateCategorySelect();
  populateRoomSelects();
  populateMemberDatalist();

  if (editId) {
    const item = state.items.find((i) => i.id === editId);
    if (!item) return;
    $('#itemModalLabel').textContent = 'Edit Item';
    $('#saveItemBtn').textContent = 'Save Changes';
    $('#itemId').value = item.id;
    $('#itemName').value = item.name;
    $('#itemCategory').value = item.category;
    $('#itemRoom').value = item.room;
    $('#itemLocation').value = item.specificLocation || '';
    $('#itemMember').value = item.lastMovedBy || '';
    $('#itemNotes').value = item.notes || '';
  } else {
    $('#itemModalLabel').textContent = 'Add Item';
    $('#saveItemBtn').textContent = 'Save Item';
    $('#itemId').value = '';
    form.reset();
  }

  if (!itemModalInstance) itemModalInstance = bootstrap.Modal.getOrCreateInstance(modal);
  itemModalInstance.show();
}

function handleSaveItem() {
  const form = $('#itemForm');
  const id = $('#itemId').value;
  const name = $('#itemName').value.trim();
  const category = $('#itemCategory').value;
  const room = $('#itemRoom').value;
  const specificLocation = $('#itemLocation').value.trim();
  const lastMovedBy = $('#itemMember').value.trim();
  const notes = $('#itemNotes').value.trim();

  let valid = true;
  if (!name) {
    $('#itemName').classList.add('is-invalid');
    valid = false;
  } else {
    $('#itemName').classList.remove('is-invalid');
  }
  if (!room) {
    $('#itemRoom').classList.add('is-invalid');
    valid = false;
  } else {
    $('#itemRoom').classList.remove('is-invalid');
  }
  if (!valid) {
    form.classList.add('was-validated');
    return;
  }

  // Track member
  if (lastMovedBy && !state.members.includes(lastMovedBy)) {
    state.members.push(lastMovedBy);
  }

  if (id) {
    // Edit — preserve lastMovedAt unless location changes
    const item = state.items.find((i) => i.id === id);
    if (!item) return;
    const locationChanged =
      item.room !== room || (item.specificLocation || '') !== specificLocation;

    if (locationChanged) {
      // push previous location to history
      item.history = item.history || [];
      item.history.unshift({
        room: item.room,
        specificLocation: item.specificLocation,
        movedBy: lastMovedBy || item.lastMovedBy,
        at: Date.now(),
      });
      item.lastMovedAt = Date.now();
    }

    item.name = name;
    item.category = category;
    item.room = room;
    item.specificLocation = specificLocation;
    item.lastMovedBy = lastMovedBy || item.lastMovedBy;
    item.notes = notes;

    showToast(name + ' updated successfully!');
  } else {
    const newItem = {
      id: uid(),
      name,
      category,
      room,
      specificLocation,
      lastMovedBy: lastMovedBy || '',
      notes,
      lastMovedAt: room || specificLocation ? Date.now() : null,
      createdAt: Date.now(),
      history: [],
    };
    state.items.push(newItem);
    showToast(name + ' added successfully!');
  }

  saveState();
  renderAll();
  itemModalInstance.hide();
}

/* ---------- Move item ---------- */
let moveModalInstance = null;
let moveItemId = null;

function openMoveModal(id) {
  const item = state.items.find((i) => i.id === id);
  if (!item) return;
  moveItemId = id;

  populateRoomSelects();
  $('#moveItemName').textContent =
    'Moving: ' + item.name + ' (currently in ' + (item.room || 'no room') + (item.specificLocation ? ' — ' + item.specificLocation : '') + ')';
  $('#moveRoom').value = item.room || '';
  $('#moveLocation').value = item.specificLocation || '';
  $('#moveMember').value = item.lastMovedBy || '';
  populateMemberDatalist();

  if (!moveModalInstance) moveModalInstance = bootstrap.Modal.getOrCreateInstance($('#moveModal'));
  moveModalInstance.show();
}

function handleSaveMove() {
  if (!moveItemId) return;
  const item = state.items.find((i) => i.id === moveItemId);
  if (!item) return;

  const newRoom = $('#moveRoom').value;
  const newLoc = $('#moveLocation').value.trim();
  const movedBy = $('#moveMember').value.trim();

  if (!newRoom) {
    showToast('Please choose a room.', 'error');
    return;
  }

  // record previous location in history
  item.history = item.history || [];
  item.history.unshift({
    room: item.room,
    specificLocation: item.specificLocation,
    movedBy: item.lastMovedBy,
    at: item.lastMovedAt,
  });

  item.room = newRoom;
  item.specificLocation = newLoc;
  item.lastMovedBy = movedBy || item.lastMovedBy;
  item.lastMovedAt = Date.now();

  if (movedBy && !state.members.includes(movedBy)) {
    state.members.push(movedBy);
  }

  saveState();
  renderAll();
  moveModalInstance.hide();
  showToast(item.name + ' location updated!');
  moveItemId = null;
}

/* ---------- Delete item ---------- */
let confirmModalInstance = null;

function requestDelete(id) {
  const item = state.items.find((i) => i.id === id);
  if (!item) return;
  pendingDeleteId = id;
  $('#confirmMessage').innerHTML =
    'Are you sure you want to delete <strong>' + escapeHtml(item.name) + '</strong>? This cannot be undone.';

  if (!confirmModalInstance) confirmModalInstance = bootstrap.Modal.getOrCreateInstance($('#confirmModal'));
  confirmModalInstance.show();
}

function confirmDelete() {
  if (!pendingDeleteId) return;
  const item = state.items.find((i) => i.id === pendingDeleteId);
  const name = item ? item.name : 'Item';
  state.items = state.items.filter((i) => i.id !== pendingDeleteId);
  pendingDeleteId = null;
  saveState();
  renderAll();
  confirmModalInstance.hide();
  showToast(name + ' deleted successfully!');
}

/* ---------- Room management ---------- */
let roomModalInstance = null;

function openRoomModal() {
  $('#roomForm').classList.remove('was-validated');
  $('#roomName').value = '';
  $('#roomIcon').value = 'bi-door-open';
  if (!roomModalInstance) roomModalInstance = bootstrap.Modal.getOrCreateInstance($('#roomModal'));
  roomModalInstance.show();
}

function handleSaveRoom() {
  const name = $('#roomName').value.trim();
  const icon = $('#roomIcon').value;
  if (!name) {
    $('#roomName').classList.add('is-invalid');
    $('#roomForm').classList.add('was-validated');
    return;
  }
  if (roomNames().some((n) => n.toLowerCase() === name.toLowerCase())) {
    showToast('A room with that name already exists.', 'error');
    return;
  }
  state.rooms.push({ name, icon });
  saveState();
  populateFilters();
  populateRoomSelects();
  renderAll();
  roomModalInstance.hide();
  showToast('Room "' + name + '" added!');
}

function deleteRoom(name) {
  const count = state.items.filter((i) => i.room === name).length;
  if (count > 0) {
    showToast('Cannot delete "' + name + '" — it still has ' + count + ' item(s). Move them first.', 'error');
    return;
  }
  state.rooms = state.rooms.filter((r) => r.name !== name);
  if (state.activeRoom === name) state.activeRoom = null;
  saveState();
  populateFilters();
  populateRoomSelects();
  renderAll();
  showToast('Room "' + name + '" deleted.');
}

/* ---------- Backup / Restore ---------- */
function downloadBackup() {
  const data = {
    app: 'FindIt Home',
    version: 1,
    exportedAt: new Date().toISOString(),
    items: state.items,
    rooms: state.rooms,
    members: state.members,
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'findit-home-backup-' + new Date().toISOString().slice(0, 10) + '.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('Backup downloaded successfully!');
}

let restoreModalInstance = null;

function openRestoreModal() {
  $('#restoreFileInput').value = '';
  $('#restoreError').classList.add('d-none');
  pendingRestoreData = null;
  if (!restoreModalInstance) restoreModalInstance = bootstrap.Modal.getOrCreateInstance($('#restoreModal'));
  restoreModalInstance.show();
}

function validateRestoreFile(file, cb) {
  $('#restoreError').classList.add('d-none');
  if (!file) {
    cb(null, 'Please choose a file.');
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const parsed = JSON.parse(e.target.result);
      if (!parsed || typeof parsed !== 'object') {
        cb(null, 'Invalid backup file: not a JSON object.');
        return;
      }
      if (!Array.isArray(parsed.items) || !Array.isArray(parsed.rooms)) {
        cb(null, 'Invalid backup: missing items or rooms array.');
        return;
      }
      cb(parsed, null);
    } catch (err) {
      cb(null, 'Could not parse file: ' + err.message);
    }
  };
  reader.onerror = () => cb(null, 'Could not read file.');
  reader.readAsText(file);
}

function handleRestoreFile() {
  const file = $('#restoreFileInput').files[0];
  validateRestoreFile(file, (data, err) => {
    if (err) {
      $('#restoreError').textContent = err;
      $('#restoreError').classList.remove('d-none');
      pendingRestoreData = null;
    } else {
      pendingRestoreData = data;
      $('#restoreError').classList.add('d-none');
    }
  });
}

function confirmRestore() {
  if (!pendingRestoreData) {
    $('#restoreError').textContent = 'Please select a valid backup file first.';
    $('#restoreError').classList.remove('d-none');
    return;
  }
  state.items = pendingRestoreData.items;
  state.rooms =
    pendingRestoreData.rooms.length > 0
      ? pendingRestoreData.rooms
      : DEFAULT_ROOMS.map((r) => ({ ...r }));
  state.members = Array.isArray(pendingRestoreData.members) ? pendingRestoreData.members : [];
  saveState();
  populateFilters();
  populateRoomSelects();
  populateMemberDatalist();
  renderAll();
  restoreModalInstance.hide();
  showToast('Backup restored successfully!');
  pendingRestoreData = null;
}

/* ---------- Navigation / scroll ---------- */
function scrollToSection(name) {
  const map = {
    dashboard: '#dashboardSection',
    rooms: '#roomsSection',
    items: '#itemsSection',
    recent: '#recentSection',
  };
  const sel = map[name];
  if (!sel) return;
  const el = $(sel);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  setActiveBottomNav(name);
}

function setActiveBottomNav(name) {
  $$('.bottom-nav-btn').forEach((b) => {
    b.classList.toggle('active', b.dataset.nav === name);
  });
}

/* ---------- Active room filter ---------- */
function setActiveRoom(name) {
  if (state.activeRoom === name) {
    state.activeRoom = null;
  } else {
    state.activeRoom = name;
    // set filter too
    $('#filterRoom').value = name;
  }
  renderAll();
  scrollToSection('items');
}

/* ---------- Reset filters ---------- */
function resetFilters() {
  $('#mainSearch').value = '';
  if ($('#navSearch')) $('#navSearch').value = '';
  if ($('#mobileSearch')) $('#mobileSearch').value = '';
  $('#filterRoom').value = '';
  $('#filterCategory').value = '';
  $('#filterMember').value = '';
  $('#filterRecent').value = '';
  $('#sortBy').value = 'recent';
  state.activeRoom = null;
  renderAll();
}

/* ---------- Intro visibility ---------- */
function updateIntro() {
  const intro = $('#introSection');
  if (state.items.length === 0) {
    intro.hidden = false;
    // hide some sections to keep focus
  } else {
    intro.hidden = true;
  }
}

/* ---------- Master render ---------- */
function renderAll() {
  populateFilters();
  populateMemberDatalist();
  renderSummary();
  renderRooms();
  renderItems();
  renderSearchResults();
  renderRecent();
  updateIntro();
}

/* ---------- Event wiring ---------- */
function wireEvents() {
  // Add item buttons
  [
    '#navAddItemBtn',
    '#offcanvasAddItemBtn',
    '#addItemBtnBottom',
    '#introAddItemBtn',
  ].forEach((sel) => {
    const el = $(sel);
    if (el) el.addEventListener('click', () => openItemModal(null));
  });

  $('#saveItemBtn').addEventListener('click', handleSaveItem);
  $('#saveMoveBtn').addEventListener('click', handleSaveMove);
  $('#saveRoomBtn').addEventListener('click', handleSaveRoom);
  $('#confirmDeleteBtn').addEventListener('click', confirmDelete);

  // Room
  $('#addRoomBtn').addEventListener('click', openRoomModal);

  // Backup / Restore
  ['#backupBtnTop', '#offcanvasBackupBtn'].forEach((sel) => {
    const el = $(sel);
    if (el) el.addEventListener('click', downloadBackup);
  });
  ['#restoreBtnTop', '#offcanvasRestoreBtn'].forEach((sel) => {
    const el = $(sel);
    if (el) el.addEventListener('click', openRestoreModal);
  });
  $('#restoreFileInput').addEventListener('change', handleRestoreFile);
  $('#confirmRestoreBtn').addEventListener('click', confirmRestore);

  // Search
  $('#mainSearch').addEventListener('input', () => {
    renderSearchResults();
    renderItems();
  });
  if ($('#navSearch')) {
    $('#navSearch').addEventListener('input', () => {
      renderItems();
      renderSearchResults();
    });
  }
  if ($('#mobileSearch')) {
    $('#mobileSearch').addEventListener('input', () => {
      renderItems();
      renderSearchResults();
    });
  }
  $('#clearSearchBtn').addEventListener('click', () => {
    $('#mainSearch').value = '';
    if ($('#navSearch')) $('#navSearch').value = '';
    if ($('#mobileSearch')) $('#mobileSearch').value = '';
    renderSearchResults();
    renderItems();
  });

  // Filters
  ['#filterRoom', '#filterCategory', '#filterMember', '#filterRecent', '#sortBy'].forEach(
    (sel) => {
      const el = $(sel);
      if (el) el.addEventListener('change', renderItems);
    }
  );
  $('#resetFiltersBtn').addEventListener('click', resetFilters);

  // Bottom nav
  $$('.bottom-nav-btn[data-nav]').forEach((b) =>
    b.addEventListener('click', () => scrollToSection(b.dataset.nav))
  );
  $$('[data-nav]').forEach((b) => {
    if (b.classList.contains('bottom-nav-btn')) return;
    b.addEventListener('click', () => {
      scrollToSection(b.dataset.nav);
      const offcanvas = bootstrap.Offcanvas.getInstance($('#navOffcanvas'));
      if (offcanvas) offcanvas.hide();
    });
  });

  // Room card clicks (delegated)
  $('#roomGrid').addEventListener('click', (e) => {
    const deleteBtn = e.target.closest('.delete-room-btn');
    if (deleteBtn) {
      e.stopPropagation();
      deleteRoom(deleteBtn.dataset.room);
      return;
    }
    const card = e.target.closest('.room-card');
    if (card) {
      setActiveRoom(card.dataset.room);
    }
  });

  $('#roomGrid').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const card = e.target.closest('.room-card');
    if (card) {
      e.preventDefault();
      setActiveRoom(card.dataset.room);
    }
  });

  // Item list clicks (delegated)
  $('#itemsList').addEventListener('click', (e) => {
    const editBtn = e.target.closest('.edit-item-btn');
    if (editBtn) {
      openItemModal(editBtn.dataset.id);
      return;
    }
    const moveBtn = e.target.closest('.move-item-btn');
    if (moveBtn) {
      openMoveModal(moveBtn.dataset.id);
      return;
    }
    const delBtn = e.target.closest('.delete-item-btn');
    if (delBtn) {
      requestDelete(delBtn.dataset.id);
      return;
    }
  });
}

/* ---------- Init ---------- */
function init() {
  if (typeof localStorage === 'undefined') {
    showToast('Browser storage is unavailable. Data will not be saved.', 'error');
  }
  loadState();
  populateFilters();
  populateRoomSelects();
  populateMemberDatalist();
  renderAll();
  wireEvents();
}

document.addEventListener('DOMContentLoaded', init);
