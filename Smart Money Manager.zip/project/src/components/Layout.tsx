import { useState, type ReactNode } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  ArrowLeftRight,
  PiggyBank,
  CalendarClock,
  Receipt,
  Target,
  BarChart3,
  Settings as SettingsIcon,
  Menu,
  X,
  Moon,
  Sun,
  Wallet,
  Languages,
  ChevronLeft,
} from 'lucide-react';
import { useSettings } from '@/contexts/SettingsContext';
import { useTranslation } from '@/hooks/useTranslation';
import { classNames } from '@/lib/utils';
import { format } from 'date-fns';

interface LayoutProps {
  children: ReactNode;
}

const navItems = [
  { to: '/', icon: LayoutDashboard, key: 'dashboard' as const },
  { to: '/transactions', icon: ArrowLeftRight, key: 'transactions' as const },
  { to: '/budgets', icon: PiggyBank, key: 'budgets' as const },
  { to: '/emis', icon: CalendarClock, key: 'emis' as const },
  { to: '/bills', icon: Receipt, key: 'bills' as const },
  { to: '/savings', icon: Target, key: 'savingsGoals' as const },
  { to: '/reports', icon: BarChart3, key: 'reports' as const },
  { to: '/settings', icon: SettingsIcon, key: 'settings' as const },
];

export function Layout({ children }: LayoutProps) {
  const { theme, toggleTheme, language, setLanguage } = useSettings();
  const { t } = useTranslation();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const currentPage = navItems.find((item) =>
    item.to === '/' ? location.pathname === '/' : location.pathname.startsWith(item.to)
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={classNames(
          'fixed top-0 left-0 z-40 h-screen border-r border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800 transition-all duration-300 flex flex-col',
          sidebarCollapsed ? 'w-20' : 'w-64',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 h-16 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
          <div className="flex-shrink-0 rounded-xl bg-emerald-600 p-2">
            <Wallet className="h-6 w-6 text-white" />
          </div>
          {!sidebarCollapsed && (
            <div className="min-w-0">
              <p className="text-sm font-bold text-gray-900 dark:text-gray-100 truncate">{t('appName')}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{t('appTagline')}</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setSidebarOpen(false)}
                className={({ isActive }) =>
                  classNames(
                    'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400'
                      : 'text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700',
                    sidebarCollapsed && 'justify-center'
                  )
                }
                title={sidebarCollapsed ? t(item.key) : undefined}
              >
                <Icon className="h-5 w-5 flex-shrink-0" />
                {!sidebarCollapsed && <span className="truncate">{t(item.key)}</span>}
              </NavLink>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="border-t border-gray-200 dark:border-gray-700 p-3 flex-shrink-0">
          <div className={classNames('flex items-center gap-3 rounded-xl px-2 py-2', sidebarCollapsed && 'justify-center')}>
            <div className="flex-shrink-0 h-9 w-9 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-sm font-semibold">
              <Wallet className="h-4 w-4" />
            </div>
            {!sidebarCollapsed && (
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-gray-900 dark:text-gray-100 truncate">
                  {t('appName')}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                  {t('appTagline')}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Collapse button - desktop */}
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="hidden lg:flex absolute top-1/2 -right-3 h-6 w-6 items-center justify-center rounded-full border border-gray-200 bg-white text-gray-500 shadow-sm hover:text-gray-700 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-400 dark:hover:text-gray-200"
          aria-label="Toggle sidebar"
        >
          <ChevronLeft className={classNames('h-4 w-4 transition-transform', sidebarCollapsed && 'rotate-180')} />
        </button>
      </aside>

      {/* Main content */}
      <div className={classNames('transition-all duration-300', sidebarCollapsed ? 'lg:ml-20' : 'lg:ml-64')}>
        {/* Top bar */}
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-4 border-b border-gray-200 bg-white/80 px-4 backdrop-blur-md dark:border-gray-700 dark:bg-gray-800/80 sm:px-6">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden rounded-lg p-2 text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700"
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="min-w-0">
              <h1 className="text-base font-semibold text-gray-900 dark:text-gray-100 sm:text-lg truncate">
                {currentPage ? t(currentPage.key) : t('dashboard')}
              </h1>
              <p className="hidden sm:block text-xs text-gray-500 dark:text-gray-400">
                {format(new Date(), 'EEEE, dd MMMM yyyy')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language toggle */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
              className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-2 text-xs font-medium text-gray-600 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-400 dark:hover:bg-gray-700"
              aria-label="Switch language"
            >
              <Languages className="h-4 w-4" />
              <span className="hidden sm:inline">{language === 'en' ? 'EN' : 'தமி'}</span>
            </button>

            {/* Theme toggle */}
            <button
              onClick={toggleTheme}
              className="rounded-lg border border-gray-200 p-2 text-gray-600 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-400 dark:hover:bg-gray-700"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 sm:p-6 max-w-7xl mx-auto">{children}</main>
      </div>
    </div>
  );
}
