import { type ReactNode } from 'react';
import { classNames } from '@/lib/utils';

interface ProgressBarProps {
  value: number;
  max?: number;
  className?: string;
  color?: 'emerald' | 'amber' | 'red' | 'blue';
  showLabel?: boolean;
  label?: ReactNode;
}

const colorClasses = {
  emerald: 'bg-emerald-500',
  amber: 'bg-amber-500',
  red: 'bg-red-500',
  blue: 'bg-blue-500',
};

export function ProgressBar({ value, max = 100, className, color = 'emerald', showLabel, label }: ProgressBarProps) {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));

  const autoColor = percentage >= 100 ? 'red' : percentage >= 80 ? 'amber' : color;
  const colorClass = colorClasses[autoColor === color ? color : autoColor];

  return (
    <div className={classNames('w-full', className)}>
      {showLabel && (
        <div className="mb-1.5 flex items-center justify-between text-xs">
          <span className="text-gray-600 dark:text-gray-400">{label}</span>
          <span className="font-medium text-gray-700 dark:text-gray-300">{percentage.toFixed(0)}%</span>
        </div>
      )}
      <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200 dark:bg-gray-700">
        <div
          className={classNames('h-full rounded-full transition-all duration-300', colorClass)}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
