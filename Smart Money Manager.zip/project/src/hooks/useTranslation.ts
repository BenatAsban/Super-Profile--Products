import { useSettings } from '@/contexts/SettingsContext';
import { translate, type TranslationKey } from '@/lib/i18n';

export function useTranslation() {
  const { language } = useSettings();

  const t = (key: TranslationKey): string => translate(key, language);

  const tCategory = (category: string): string => {
    const key = `cat_${category}` as TranslationKey;
    return translate(key, language);
  };

  const tPaymentMethod = (method: string): string => {
    const key = `pm_${method}` as TranslationKey;
    return translate(key, language);
  };

  return { t, tCategory, tPaymentMethod, language };
}
