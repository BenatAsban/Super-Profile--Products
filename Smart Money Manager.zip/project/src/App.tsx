import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { SettingsProvider } from '@/contexts/SettingsContext';
import { DataProvider } from '@/contexts/DataContext';
import { ToastProvider } from '@/contexts/ToastContext';
import { Layout } from '@/components/Layout';
import { DashboardPage } from '@/pages/DashboardPage';
import { TransactionsPage } from '@/pages/TransactionsPage';
import { BudgetsPage } from '@/pages/BudgetsPage';
import { EMIPage } from '@/pages/EMIPage';
import { BillsPage } from '@/pages/BillsPage';
import { SavingsPage } from '@/pages/SavingsPage';
import { ReportsPage } from '@/pages/ReportsPage';
import { SettingsPage } from '@/pages/SettingsPage';

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Layout><DashboardPage /></Layout>} />
      <Route path="/transactions" element={<Layout><TransactionsPage /></Layout>} />
      <Route path="/budgets" element={<Layout><BudgetsPage /></Layout>} />
      <Route path="/emis" element={<Layout><EMIPage /></Layout>} />
      <Route path="/bills" element={<Layout><BillsPage /></Layout>} />
      <Route path="/savings" element={<Layout><SavingsPage /></Layout>} />
      <Route path="/reports" element={<Layout><ReportsPage /></Layout>} />
      <Route path="/settings" element={<Layout><SettingsPage /></Layout>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <SettingsProvider>
        <ToastProvider>
          <DataProvider>
            <AppRoutes />
          </DataProvider>
        </ToastProvider>
      </SettingsProvider>
    </BrowserRouter>
  );
}
