import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Theme, Language } from '@/lib/types';

interface SettingsContextValue {
  theme: Theme;
  language: Language;
  toggleTheme: () => void;
  setTheme: (t: Theme) => void;
  setLanguage: (l: Language) => void;
}

const SettingsContext = createContext<SettingsContextValue | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => {
    const stored = localStorage.getItem('smm-theme');
    return (stored === 'dark' || stored === 'light') ? stored : 'light';
  });

  const [language, setLanguageState] = useState<Language>(() => {
    const stored = localStorage.getItem('smm-language');
    return (stored === 'en' || stored === 'ta') ? stored : 'en';
  });

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('smm-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('smm-language', language);
  }, [language]);

  const toggleTheme = () => setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  const setTheme = (t: Theme) => setThemeState(t);
  const setLanguage = (l: Language) => setLanguageState(l);

  return (
    <SettingsContext.Provider value={{ theme, language, toggleTheme, setTheme, setLanguage }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
}
