import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { generateId } from '@/lib/utils';
import { DEFAULT_SETTINGS } from '@/lib/constants';
import { generateSampleData } from '@/lib/sampleData';
import type {
  Transaction,
  Budget,
  EMI,
  EMIPayment,
  Bill,
  SavingsGoal,
  SavingsContribution,
  Settings,
  AppData,
} from '@/lib/types';

const LOCAL_STORAGE_KEY = 'smm-data';

interface DataContextValue {
  data: AppData;
  loading: boolean;
  isCloudMode: boolean;
  // Transactions
  addTransaction: (t: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateTransaction: (id: string, t: Partial<Transaction>) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  // Budgets
  addBudget: (b: Omit<Budget, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateBudget: (id: string, b: Partial<Budget>) => Promise<void>;
  deleteBudget: (id: string) => Promise<void>;
  // EMIs
  addEMI: (e: Omit<EMI, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateEMI: (id: string, e: Partial<EMI>) => Promise<void>;
  deleteEMI: (id: string) => Promise<void>;
  // EMI Payments
  addEMIPayment: (p: Omit<EMIPayment, 'id' | 'created_at'>) => Promise<void>;
  deleteEMIPayment: (id: string) => Promise<void>;
  // Bills
  addBill: (b: Omit<Bill, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateBill: (id: string, b: Partial<Bill>) => Promise<void>;
  deleteBill: (id: string) => Promise<void>;
  // Savings Goals
  addSavingsGoal: (g: Omit<SavingsGoal, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateSavingsGoal: (id: string, g: Partial<SavingsGoal>) => Promise<void>;
  deleteSavingsGoal: (id: string) => Promise<void>;
  // Savings Contributions
  addContribution: (c: Omit<SavingsContribution, 'id' | 'created_at'>) => Promise<void>;
  deleteContribution: (id: string) => Promise<void>;
  // Settings
  updateSettings: (s: Partial<Settings>) => Promise<void>;
  // Data management
  loadSampleData: () => Promise<void>;
  resetAllData: () => Promise<void>;
  importData: (data: AppData) => Promise<void>;
  exportData: () => AppData;
}

const emptyData: AppData = {
  transactions: [],
  budgets: [],
  emis: [],
  emiPayments: [],
  bills: [],
  savingsGoals: [],
  savingsContributions: [],
  settings: { ...DEFAULT_SETTINGS },
};

const DataContext = createContext<DataContextValue | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(emptyData);
  const [loading, setLoading] = useState(true);

  const isCloudMode = isSupabaseConfigured;

  const loadLocalData = useCallback(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Partial<AppData>;
        setData({
          transactions: parsed.transactions || [],
          budgets: parsed.budgets || [],
          emis: parsed.emis || [],
          emiPayments: parsed.emiPayments || [],
          bills: parsed.bills || [],
          savingsGoals: parsed.savingsGoals || [],
          savingsContributions: parsed.savingsContributions || [],
          settings: { ...DEFAULT_SETTINGS, ...parsed.settings },
        });
      } else {
        setData(emptyData);
      }
    } catch {
      setData(emptyData);
    }
    setLoading(false);
  }, []);

  const saveLocalData = useCallback((newData: AppData) => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newData));
    } catch {
      // storage full or disabled
    }
  }, []);

  const loadCloudData = useCallback(async () => {
    if (!supabase) return;
    setLoading(true);
    try {
      const [txRes, budgetRes, emiRes, epRes, billRes, sgRes, scRes] = await Promise.all([
        supabase.from('transactions').select('*').order('transaction_date', { ascending: false }),
        supabase.from('budgets').select('*'),
        supabase.from('emis').select('*'),
        supabase.from('emi_payments').select('*'),
        supabase.from('bills').select('*'),
        supabase.from('savings_goals').select('*'),
        supabase.from('savings_contributions').select('*'),
      ]);

      setData({
        transactions: (txRes.data as Transaction[]) || [],
        budgets: (budgetRes.data as Budget[]) || [],
        emis: (emiRes.data as EMI[]) || [],
        emiPayments: (epRes.data as EMIPayment[]) || [],
        bills: (billRes.data as Bill[]) || [],
        savingsGoals: (sgRes.data as SavingsGoal[]) || [],
        savingsContributions: (scRes.data as SavingsContribution[]) || [],
        settings: { ...DEFAULT_SETTINGS },
      });
    } catch {
      setData(emptyData);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (isCloudMode) {
      loadCloudData();
    } else {
      loadLocalData();
    }
  }, [isCloudMode, loadCloudData, loadLocalData]);

  // Persist local data whenever it changes (local mode only)
  useEffect(() => {
    if (!isCloudMode && !loading) {
      saveLocalData(data);
    }
  }, [data, isCloudMode, loading, saveLocalData]);

  // ============ Transactions ============
  const addTransaction = async (t: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('transactions').insert(t);
      if (error) throw error;
      await loadCloudData();
    } else {
      const now = new Date().toISOString();
      const newTx: Transaction = { ...t, id: generateId(), created_at: now, updated_at: now };
      setData((prev) => ({
        ...prev,
        transactions: [newTx, ...prev.transactions],
      }));
    }
  };

  const updateTransaction = async (id: string, t: Partial<Transaction>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('transactions').update(t).eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        transactions: prev.transactions.map((tx) =>
          tx.id === id ? { ...tx, ...t, updated_at: new Date().toISOString() } : tx
        ),
      }));
    }
  };

  const deleteTransaction = async (id: string) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('transactions').delete().eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        transactions: prev.transactions.filter((tx) => tx.id !== id),
      }));
    }
  };

  // ============ Budgets ============
  const addBudget = async (b: Omit<Budget, 'id' | 'created_at' | 'updated_at'>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('budgets').insert(b);
      if (error) throw error;
      await loadCloudData();
    } else {
      const now = new Date().toISOString();
      const newBudget: Budget = { ...b, id: generateId(), created_at: now, updated_at: now };
      setData((prev) => ({ ...prev, budgets: [...prev.budgets, newBudget] }));
    }
  };

  const updateBudget = async (id: string, b: Partial<Budget>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('budgets').update(b).eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        budgets: prev.budgets.map((bu) =>
          bu.id === id ? { ...bu, ...b, updated_at: new Date().toISOString() } : bu
        ),
      }));
    }
  };

  const deleteBudget = async (id: string) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('budgets').delete().eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({ ...prev, budgets: prev.budgets.filter((b) => b.id !== id) }));
    }
  };

  // ============ EMIs ============
  const addEMI = async (e: Omit<EMI, 'id' | 'created_at' | 'updated_at'>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('emis').insert(e);
      if (error) throw error;
      await loadCloudData();
    } else {
      const now = new Date().toISOString();
      const newEMI: EMI = { ...e, id: generateId(), created_at: now, updated_at: now };
      setData((prev) => ({ ...prev, emis: [...prev.emis, newEMI] }));
    }
  };

  const updateEMI = async (id: string, e: Partial<EMI>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('emis').update(e).eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        emis: prev.emis.map((em) =>
          em.id === id ? { ...em, ...e, updated_at: new Date().toISOString() } : em
        ),
      }));
    }
  };

  const deleteEMI = async (id: string) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('emis').delete().eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        emis: prev.emis.filter((e) => e.id !== id),
        emiPayments: prev.emiPayments.filter((p) => p.emi_id !== id),
      }));
    }
  };

  // ============ EMI Payments ============
  const addEMIPayment = async (p: Omit<EMIPayment, 'id' | 'created_at'>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('emi_payments').insert(p);
      if (error) throw error;
      await loadCloudData();
    } else {
      const newPayment: EMIPayment = { ...p, id: generateId(), created_at: new Date().toISOString() };
      setData((prev) => ({ ...prev, emiPayments: [...prev.emiPayments, newPayment] }));
    }
  };

  const deleteEMIPayment = async (id: string) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('emi_payments').delete().eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        emiPayments: prev.emiPayments.filter((p) => p.id !== id),
      }));
    }
  };

  // ============ Bills ============
  const addBill = async (b: Omit<Bill, 'id' | 'created_at' | 'updated_at'>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('bills').insert(b);
      if (error) throw error;
      await loadCloudData();
    } else {
      const now = new Date().toISOString();
      const newBill: Bill = { ...b, id: generateId(), created_at: now, updated_at: now };
      setData((prev) => ({ ...prev, bills: [...prev.bills, newBill] }));
    }
  };

  const updateBill = async (id: string, b: Partial<Bill>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('bills').update(b).eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        bills: prev.bills.map((bi) =>
          bi.id === id ? { ...bi, ...b, updated_at: new Date().toISOString() } : bi
        ),
      }));
    }
  };

  const deleteBill = async (id: string) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('bills').delete().eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({ ...prev, bills: prev.bills.filter((b) => b.id !== id) }));
    }
  };

  // ============ Savings Goals ============
  const addSavingsGoal = async (g: Omit<SavingsGoal, 'id' | 'created_at' | 'updated_at'>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('savings_goals').insert(g);
      if (error) throw error;
      await loadCloudData();
    } else {
      const now = new Date().toISOString();
      const newGoal: SavingsGoal = { ...g, id: generateId(), created_at: now, updated_at: now };
      setData((prev) => ({ ...prev, savingsGoals: [...prev.savingsGoals, newGoal] }));
    }
  };

  const updateSavingsGoal = async (id: string, g: Partial<SavingsGoal>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('savings_goals').update(g).eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        savingsGoals: prev.savingsGoals.map((sg) =>
          sg.id === id ? { ...sg, ...g, updated_at: new Date().toISOString() } : sg
        ),
      }));
    }
  };

  const deleteSavingsGoal = async (id: string) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('savings_goals').delete().eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        savingsGoals: prev.savingsGoals.filter((g) => g.id !== id),
        savingsContributions: prev.savingsContributions.filter((c) => c.goal_id !== id),
      }));
    }
  };

  // ============ Savings Contributions ============
  const addContribution = async (c: Omit<SavingsContribution, 'id' | 'created_at'>) => {
    if (isCloudMode && supabase) {
      const { error } = await supabase.from('savings_contributions').insert(c);
      if (error) throw error;
      // Update goal current_amount
      const goal = data.savingsGoals.find((g) => g.id === c.goal_id);
      if (goal) {
        const delta = c.type === 'contribution' ? c.amount : -c.amount;
        const newAmount = Math.max(0, goal.current_amount + delta);
        const completed = newAmount >= goal.target_amount;
        await supabase
          .from('savings_goals')
          .update({ current_amount: newAmount, completed })
          .eq('id', c.goal_id);
      }
      await loadCloudData();
    } else {
      const newContribution: SavingsContribution = {
        ...c,
        id: generateId(),
        created_at: new Date().toISOString(),
      };
      setData((prev) => {
        const goals = prev.savingsGoals.map((g) => {
          if (g.id !== c.goal_id) return g;
          const delta = c.type === 'contribution' ? c.amount : -c.amount;
          const newAmount = Math.max(0, g.current_amount + delta);
          return {
            ...g,
            current_amount: newAmount,
            completed: newAmount >= g.target_amount,
            updated_at: new Date().toISOString(),
          };
        });
        return {
          ...prev,
          savingsGoals: goals,
          savingsContributions: [...prev.savingsContributions, newContribution],
        };
      });
    }
  };

  const deleteContribution = async (id: string) => {
    if (isCloudMode && supabase) {
      const contribution = data.savingsContributions.find((c) => c.id === id);
      if (contribution) {
        const goal = data.savingsGoals.find((g) => g.id === contribution.goal_id);
        if (goal) {
          const delta = contribution.type === 'contribution' ? -contribution.amount : contribution.amount;
          const newAmount = Math.max(0, goal.current_amount + delta);
          await supabase
            .from('savings_goals')
            .update({ current_amount: newAmount, completed: newAmount >= goal.target_amount })
            .eq('id', contribution.goal_id);
        }
      }
      const { error } = await supabase.from('savings_contributions').delete().eq('id', id);
      if (error) throw error;
      await loadCloudData();
    } else {
      setData((prev) => {
        const contribution = prev.savingsContributions.find((c) => c.id === id);
        if (!contribution) return prev;
        const goals = prev.savingsGoals.map((g) => {
          if (g.id !== contribution.goal_id) return g;
          const delta = contribution.type === 'contribution' ? -contribution.amount : contribution.amount;
          const newAmount = Math.max(0, g.current_amount + delta);
          return {
            ...g,
            current_amount: newAmount,
            completed: newAmount >= g.target_amount,
            updated_at: new Date().toISOString(),
          };
        });
        return {
          ...prev,
          savingsGoals: goals,
          savingsContributions: prev.savingsContributions.filter((c) => c.id !== id),
        };
      });
    }
  };

  // ============ Settings ============
  const updateSettings = async (s: Partial<Settings>) => {
    setData((prev) => ({ ...prev, settings: { ...prev.settings, ...s } }));
  };

  // ============ Data Management ============
  const loadSampleData = async () => {
    const sample = generateSampleData();
    if (isCloudMode && supabase) {
      await Promise.all([
        ...sample.transactions.map((t) => supabase!.from('transactions').insert(t)),
        ...sample.budgets.map((b) => supabase!.from('budgets').insert(b)),
        ...sample.emis.map((e) => supabase!.from('emis').insert(e)),
        ...sample.bills.map((b) => supabase!.from('bills').insert(b)),
        ...sample.savingsGoals.map((g) => supabase!.from('savings_goals').insert(g)),
        ...sample.savingsContributions.map((c) => supabase!.from('savings_contributions').insert(c)),
      ]);
      await loadCloudData();
    } else {
      setData((prev) => ({
        ...prev,
        transactions: [...sample.transactions, ...prev.transactions],
        budgets: [...sample.budgets, ...prev.budgets],
        emis: [...sample.emis, ...prev.emis],
        emiPayments: [...sample.emiPayments, ...prev.emiPayments],
        bills: [...sample.bills, ...prev.bills],
        savingsGoals: [...sample.savingsGoals, ...prev.savingsGoals],
        savingsContributions: [...sample.savingsContributions, ...prev.savingsContributions],
      }));
    }
  };

  const resetAllData = async () => {
    if (isCloudMode && supabase) {
      await Promise.all([
        supabase.from('transactions').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('budgets').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('emi_payments').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('emis').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('bills').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('savings_contributions').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
        supabase.from('savings_goals').delete().neq('id', '00000000-0000-0000-0000-000000000000'),
      ]);
      await loadCloudData();
    } else {
      setData({ ...emptyData, settings: { ...DEFAULT_SETTINGS } });
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  };

  const importData = async (imported: AppData) => {
    if (isCloudMode && supabase) {
      // Clear existing then insert all
      await resetAllData();
      await Promise.all([
        ...imported.transactions.map((t) => supabase!.from('transactions').insert(t)),
        ...imported.budgets.map((b) => supabase!.from('budgets').insert(b)),
        ...imported.emis.map((e) => supabase!.from('emis').insert(e)),
        ...imported.emiPayments.map((p) => supabase!.from('emi_payments').insert(p)),
        ...imported.bills.map((b) => supabase!.from('bills').insert(b)),
        ...imported.savingsGoals.map((g) => supabase!.from('savings_goals').insert(g)),
        ...imported.savingsContributions.map((c) => supabase!.from('savings_contributions').insert(c)),
      ]);
      await loadCloudData();
    } else {
      setData({
        transactions: imported.transactions || [],
        budgets: imported.budgets || [],
        emis: imported.emis || [],
        emiPayments: imported.emiPayments || [],
        bills: imported.bills || [],
        savingsGoals: imported.savingsGoals || [],
        savingsContributions: imported.savingsContributions || [],
        settings: { ...DEFAULT_SETTINGS, ...imported.settings },
      });
    }
  };

  const exportData = () => data;

  return (
    <DataContext.Provider
      value={{
        data,
        loading,
        isCloudMode,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addBudget,
        updateBudget,
        deleteBudget,
        addEMI,
        updateEMI,
        deleteEMI,
        addEMIPayment,
        deleteEMIPayment,
        addBill,
        updateBill,
        deleteBill,
        addSavingsGoal,
        updateSavingsGoal,
        deleteSavingsGoal,
        addContribution,
        deleteContribution,
        updateSettings,
        loadSampleData,
        resetAllData,
        importData,
        exportData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
