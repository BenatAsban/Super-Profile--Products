import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  PiggyBank,
  CalendarClock,
  Receipt,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Target,
  CreditCard,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { useData } from '@/contexts/DataContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { DashboardSkeleton } from '@/components/ui/Skeleton';
import { EmptyState } from '@/components/ui/EmptyState';
import {
  getDashboardStats,
  getCategorySpending,
  getMonthlyTrend,
} from '@/lib/calculations';
import { formatCurrency, formatCurrencyShort, formatDateShort, daysUntil } from '@/lib/utils';
import { CATEGORY_COLORS, CHART_COLORS } from '@/lib/constants';
import type { TranslationKey } from '@/lib/i18n';

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  trend?: string;
  trendType?: 'up' | 'down';
  accent: 'emerald' | 'blue' | 'red' | 'amber';
}

const accentClasses = {
  emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400',
  blue: 'bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',
  red: 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400',
  amber: 'bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400',
};

function StatCard({ title, value, icon, trend, trendType, accent }: StatCardProps) {
  return (
    <Card>
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
          <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-gray-100 truncate">{value}</p>
          {trend && (
            <p className={`mt-1 text-xs flex items-center gap-1 ${trendType === 'up' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500 dark:text-red-400'}`}>
              {trendType === 'up' ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {trend}
            </p>
          )}
        </div>
        <div className={`flex-shrink-0 rounded-xl p-2.5 ${accentClasses[accent]}`}>
          {icon}
        </div>
      </div>
    </Card>
  );
}

export function DashboardPage() {
  const { data, loading } = useData();
  const { t, tCategory, language } = useTranslation();

  const stats = useMemo(
    () => getDashboardStats(data.transactions, data.budgets, data.emis, data.emiPayments, data.bills),
    [data]
  );

  const categoryData = useMemo(
    () => getCategorySpending(data.transactions),
    [data.transactions]
  );

  const trendData = useMemo(
    () => getMonthlyTrend(data.transactions, 6),
    [data.transactions]
  );

  const recentTransactions = useMemo(
    () =>
      [...data.transactions]
        .sort((a, b) => new Date(b.transaction_date).getTime() - new Date(a.transaction_date).getTime())
        .slice(0, 5),
    [data.transactions]
  );

  if (loading) return <DashboardSkeleton />;

  const hasData = data.transactions.length > 0;

  return (
    <div className="space-y-6">
      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title={t('totalBalance')}
          value={formatCurrency(stats.totalBalance)}
          icon={<Wallet className="h-6 w-6" />}
          accent="blue"
        />
        <StatCard
          title={t('monthlyIncome')}
          value={formatCurrency(stats.monthlyIncome)}
          icon={<TrendingUp className="h-6 w-6" />}
          accent="emerald"
        />
        <StatCard
          title={t('monthlyExpenses')}
          value={formatCurrency(stats.monthlyExpenses)}
          icon={<TrendingDown className="h-6 w-6" />}
          accent="red"
        />
        <StatCard
          title={t('savings')}
          value={formatCurrency(stats.savings)}
          icon={<PiggyBank className="h-6 w-6" />}
          trend={`${stats.savingsRate.toFixed(1)}% ${t('savingsRate')}`}
          trendType={stats.savings >= 0 ? 'up' : 'down'}
          accent="amber"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <Card className="lg:col-span-3">
          <CardHeader title={t('incomeVsExpenses')} subtitle={t('monthlyTrend')} />
          {trendData.every((d) => d.income === 0 && d.expenses === 0) ? (
            <EmptyState title={t('noData')} description={t('noDataDesc')} />
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={trendData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" className="dark:stroke-gray-700" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#9ca3af" />
                <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" tickFormatter={(v) => formatCurrencyShort(v)} />
                <Tooltip
                  formatter={(value: number) => formatCurrency(value)}
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid #e5e7eb',
                    fontSize: '13px',
                  }}
                />
                <Area type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} fill="url(#incomeGradient)" name={t('income')} />
                <Area type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} fill="url(#expenseGradient)" name={t('expense')} />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader title={t('expenseBreakdown')} />
          {categoryData.length === 0 ? (
            <EmptyState title={t('noData')} description={t('noDataDesc')} />
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={categoryData}
                  dataKey="amount"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  innerRadius={50}
                  paddingAngle={2}
                >
                  {categoryData.map((entry, i) => (
                    <Cell key={i} fill={CATEGORY_COLORS[entry.category] || CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number, _name: string, props: { payload?: { category?: string } }) => [
                    formatCurrency(value),
                    tCategory(props?.payload?.category || ''),
                  ]}
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e5e7eb', fontSize: '13px' }}
                />
                <Legend
                  formatter={(value: string) => tCategory(value)}
                  iconType="circle"
                  iconSize={8}
                  wrapperStyle={{ fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      {/* Budget utilization */}
      {stats.budgetAmount > 0 && (
        <Card>
          <CardHeader
            title={t('budgetUtilization')}
            subtitle={`${formatCurrency(stats.monthlyExpenses)} ${t('of')} ${formatCurrency(stats.budgetAmount)}`}
          />
          <ProgressBar
            value={stats.budgetUtilization}
            showLabel
            label={`${stats.budgetUtilization.toFixed(1)}% ${t('spent')}`}
          />
        </Card>
      )}

      {/* Quick actions */}
      <Card>
        <CardHeader title={t('quickActions')} />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          <QuickActionLink to="/transactions?action=add&type=income" icon={<Plus className="h-5 w-5" />} label={t('addIncome')} color="emerald" />
          <QuickActionLink to="/transactions?action=add&type=expense" icon={<Plus className="h-5 w-5" />} label={t('addExpense')} color="red" />
          <QuickActionLink to="/emis?action=add" icon={<CreditCard className="h-5 w-5" />} label={t('addEMI')} color="blue" />
          <QuickActionLink to="/bills?action=add" icon={<Receipt className="h-5 w-5" />} label={t('addBill')} color="amber" />
          <QuickActionLink to="/savings?action=add" icon={<Target className="h-5 w-5" />} label={t('addSavingsGoal')} color="purple" />
        </div>
      </Card>

      {/* Recent transactions + upcoming payments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader
            title={t('recentTransactions')}
            action={
              <Link to="/transactions" className="text-xs text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 font-medium">
                {t('viewAll')}
              </Link>
            }
          />
          {recentTransactions.length === 0 ? (
            <EmptyState title={t('noRecentTransactions')} icon={<ArrowUpRight className="h-8 w-8 text-gray-400" />} />
          ) : (
            <div className="space-y-2">
              {recentTransactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between gap-3 rounded-xl px-3 py-2.5 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`flex-shrink-0 h-9 w-9 rounded-full flex items-center justify-center ${tx.type === 'income' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'}`}>
                      {tx.type === 'income' ? (
                        <ArrowUpRight className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                      ) : (
                        <ArrowDownRight className="h-4 w-4 text-red-500 dark:text-red-400" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{tx.description}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {tCategory(tx.category)} · {formatDateShort(tx.transaction_date)}
                      </p>
                    </div>
                  </div>
                  <p className={`text-sm font-semibold flex-shrink-0 ${tx.type === 'income' ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-900 dark:text-gray-100'}`}>
                    {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title={t('upcomingPayments')} />
          {stats.upcomingEMIs.length === 0 && stats.upcomingBills.length === 0 ? (
            <EmptyState title={t('noUpcomingBills')} icon={<CalendarClock className="h-8 w-8 text-gray-400" />} />
          ) : (
            <div className="space-y-2">
              {stats.upcomingEMIs.slice(0, 3).map((emi) => {
                const due = new Date();
                due.setDate(Math.min(emi.due_day, new Date(due.getFullYear(), due.getMonth() + 1, 0).getDate()));
                return (
                  <UpcomingPaymentItem
                    key={`emi-${emi.id}`}
                    name={emi.name}
                    amount={emi.monthly_amount}
                    dueDate={due.toISOString().split('T')[0]}
                    icon={<CreditCard className="h-4 w-4" />}
                    color="blue"
                    labelKey="emis"
                  />
                );
              })}
              {stats.upcomingBills.slice(0, 3).map((bill) => (
                <UpcomingPaymentItem
                  key={`bill-${bill.id}`}
                  name={bill.name}
                  amount={bill.amount}
                  dueDate={bill.due_date}
                  icon={<Receipt className="h-4 w-4" />}
                  color="amber"
                  labelKey="bills"
                />
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

interface QuickActionLinkProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  color: 'emerald' | 'red' | 'blue' | 'amber' | 'purple';
}

const quickActionColors = {
  emerald: 'hover:border-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 dark:hover:border-emerald-700 text-emerald-600 dark:text-emerald-400',
  red: 'hover:border-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 dark:hover:border-red-700 text-red-500 dark:text-red-400',
  blue: 'hover:border-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 dark:hover:border-blue-700 text-blue-600 dark:text-blue-400',
  amber: 'hover:border-amber-300 hover:bg-amber-50 dark:hover:bg-amber-900/20 dark:hover:border-amber-700 text-amber-600 dark:text-amber-400',
  purple: 'hover:border-purple-300 hover:bg-purple-50 dark:hover:bg-purple-900/20 dark:hover:border-purple-700 text-purple-600 dark:text-purple-400',
};

function QuickActionLink({ to, icon, label, color }: QuickActionLinkProps) {
  return (
    <Link
      to={to}
      className={`flex flex-col items-center gap-2 rounded-xl border border-gray-200 dark:border-gray-700 p-3.5 transition-colors ${quickActionColors[color]}`}
    >
      {icon}
      <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center">{label}</span>
    </Link>
  );
}

interface UpcomingPaymentItemProps {
  name: string;
  amount: number;
  dueDate: string;
  icon: React.ReactNode;
  color: 'blue' | 'amber';
  labelKey: TranslationKey;
}

function UpcomingPaymentItem({ name, amount, dueDate, icon, color, labelKey }: UpcomingPaymentItemProps) {
  const { t } = useTranslation();
  const days = daysUntil(dueDate);
  const isOverdue = days < 0;

  return (
    <div className="flex items-center justify-between gap-3 rounded-xl px-3 py-2.5 hover:bg-gray-50 dark:hover:bg-gray-700/50">
      <div className="flex items-center gap-3 min-w-0">
        <div className={`flex-shrink-0 h-9 w-9 rounded-full flex items-center justify-center ${color === 'blue' ? 'bg-blue-100 dark:bg-blue-900/30' : 'bg-amber-100 dark:bg-amber-900/30'}`}>
          {icon}
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{name}</p>
          <div className="flex items-center gap-1.5">
            <Badge variant={isOverdue ? 'danger' : days <= 3 ? 'warning' : 'default'}>
              {isOverdue ? `${Math.abs(days)} ${t('overdueBy')}` : days === 0 ? t('dueToday') : `${days} ${t('daysUntil')}`}
            </Badge>
          </div>
        </div>
      </div>
      <p className="text-sm font-semibold text-gray-900 dark:text-gray-100 flex-shrink-0">{formatCurrency(amount)}</p>
    </div>
  );
}
