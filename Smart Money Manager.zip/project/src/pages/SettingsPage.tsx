import { useRef, useState } from 'react';
import {
  Download,
  Upload,
  Trash2,
  Sun,
  Moon,
  Globe,
  Database,
  Cloud,
  HardDrive,
  Beaker,
  Wallet,
} from 'lucide-react';
import { useData } from '@/contexts/DataContext';
import { useSettings } from '@/contexts/SettingsContext';
import { useToast } from '@/contexts/ToastContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Input';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { downloadJSON } from '@/lib/csv';
import type { AppData } from '@/lib/types';
import { classNames } from '@/lib/utils';

export function SettingsPage() {
  const { data, loadSampleData, resetAllData, importData, exportData, isCloudMode } = useData();
  const { theme, setTheme, language, setLanguage } = useSettings();
  const { showToast } = useToast();
  const { t } = useTranslation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [resetConfirm, setResetConfirm] = useState(false);
  const [sampleConfirm, setSampleConfirm] = useState(false);
  const [importConfirm, setImportConfirm] = useState(false);
  const [pendingImport, setPendingImport] = useState<AppData | null>(null);

  const handleExport = () => {
    const exported = exportData();
    downloadJSON(exported, `smart-money-manager-${new Date().toISOString().split('T')[0]}.json`);
    showToast(t('saveSuccess'), 'success');
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target?.result as string) as Partial<AppData>;
        if (!parsed.transactions || !Array.isArray(parsed.transactions)) {
          showToast(t('importError'), 'error');
          return;
        }
        setPendingImport({
          transactions: parsed.transactions || [],
          budgets: parsed.budgets || [],
          emis: parsed.emis || [],
          emiPayments: parsed.emiPayments || [],
          bills: parsed.bills || [],
          savingsGoals: parsed.savingsGoals || [],
          savingsContributions: parsed.savingsContributions || [],
          settings: { currency: 'INR', theme: 'light', language: 'en', monthly_budget: 0, ...parsed.settings },
        });
        setImportConfirm(true);
      } catch {
        showToast(t('importError'), 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleImport = async () => {
    if (!pendingImport) return;
    try {
      await importData(pendingImport);
      showToast(t('importSuccess'), 'success');
    } catch {
      showToast(t('saveError'), 'error');
    }
    setPendingImport(null);
    setImportConfirm(false);
  };

  const handleReset = async () => {
    try {
      await resetAllData();
      showToast(t('resetComplete'), 'success');
    } catch {
      showToast(t('saveError'), 'error');
    }
    setResetConfirm(false);
  };

  const handleLoadSample = async () => {
    try {
      await loadSampleData();
      showToast(t('saveSuccess'), 'success');
    } catch {
      showToast(t('saveError'), 'error');
    }
    setSampleConfirm(false);
  };

  return (
    <div className="space-y-4 max-w-3xl">
      {/* Preferences */}
      <Card>
        <CardHeader title={t('preferences')} />
        <div className="space-y-4">
          {/* Theme */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-gray-100 p-2 dark:bg-gray-700">
                {theme === 'light' ? <Sun className="h-5 w-5 text-amber-500" /> : <Moon className="h-5 w-5 text-blue-400" />}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('theme')}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{theme === 'light' ? t('lightMode') : t('darkMode')}</p>
              </div>
            </div>
            <div className="flex gap-1 rounded-xl border border-gray-200 dark:border-gray-600 p-1">
              <button
                onClick={() => setTheme('light')}
                className={classNames(
                  'rounded-lg px-3 py-1.5 text-xs font-medium transition-colors',
                  theme === 'light' ? 'bg-emerald-500 text-white' : 'text-gray-500 dark:text-gray-400'
                )}
              >
                <Sun className="h-3.5 w-3.5 inline mr-1" /> {t('lightMode')}
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={classNames(
                  'rounded-lg px-3 py-1.5 text-xs font-medium transition-colors',
                  theme === 'dark' ? 'bg-emerald-500 text-white' : 'text-gray-500 dark:text-gray-400'
                )}
              >
                <Moon className="h-3.5 w-3.5 inline mr-1" /> {t('darkMode')}
              </button>
            </div>
          </div>

          {/* Language */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-gray-100 p-2 dark:bg-gray-700">
                <Globe className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('language')}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{language === 'en' ? t('english') : t('tamil')}</p>
              </div>
            </div>
            <div className="flex gap-1 rounded-xl border border-gray-200 dark:border-gray-600 p-1">
              <button
                onClick={() => setLanguage('en')}
                className={classNames(
                  'rounded-lg px-3 py-1.5 text-xs font-medium transition-colors',
                  language === 'en' ? 'bg-emerald-500 text-white' : 'text-gray-500 dark:text-gray-400'
                )}
              >
                English
              </button>
              <button
                onClick={() => setLanguage('ta')}
                className={classNames(
                  'rounded-lg px-3 py-1.5 text-xs font-medium transition-colors',
                  language === 'ta' ? 'bg-emerald-500 text-white' : 'text-gray-500 dark:text-gray-400'
                )}
              >
                தமிழ்
              </button>
            </div>
          </div>
        </div>
      </Card>

      {/* Storage mode info */}
      <Card>
        <CardHeader title={t('storageMode')} />
        <div className="flex items-start gap-3">
          <div className={classNames(
            'flex-shrink-0 rounded-xl p-2',
            isCloudMode ? 'bg-emerald-50 dark:bg-emerald-900/20' : 'bg-amber-50 dark:bg-amber-900/20'
          )}>
            {isCloudMode ? <Cloud className="h-5 w-5 text-emerald-600 dark:text-emerald-400" /> : <HardDrive className="h-5 w-5 text-amber-600 dark:text-amber-400" />}
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
              {isCloudMode ? t('cloudSync') : t('localOnly')}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              {isCloudMode ? t('cloudSyncActive') : t('localOnlyWarning')}
            </p>
          </div>
        </div>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader title={t('dataManagement')} />
        <div className="space-y-3">
          {/* Export */}
          <div className="flex items-center justify-between gap-3 rounded-xl border border-gray-200 dark:border-gray-700 p-3">
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('exportData')}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('exportDataDesc')}</p>
            </div>
            <Button variant="outline" size="sm" onClick={handleExport} className="flex-shrink-0">
              <Download className="h-4 w-4" /> {t('exportData')}
            </Button>
          </div>

          {/* Import */}
          <div className="flex items-center justify-between gap-3 rounded-xl border border-gray-200 dark:border-gray-700 p-3">
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('importData')}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('importDataDesc')}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} className="flex-shrink-0">
              <Upload className="h-4 w-4" /> {t('importData')}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={handleFileSelect}
            />
          </div>

          {/* Sample data */}
          <div className="flex items-center justify-between gap-3 rounded-xl border border-gray-200 dark:border-gray-700 p-3">
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('loadSampleData')}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('sampleDataDesc')}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setSampleConfirm(true)} className="flex-shrink-0">
              <Beaker className="h-4 w-4" /> {t('loadSampleData')}
            </Button>
          </div>

          {/* Reset */}
          <div className="flex items-center justify-between gap-3 rounded-xl border border-red-200 dark:border-red-800 p-3">
            <div className="min-w-0">
              <p className="text-sm font-medium text-red-600 dark:text-red-400">{t('resetData')}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{t('resetDataDesc')}</p>
            </div>
            <Button variant="danger" size="sm" onClick={() => setResetConfirm(true)} className="flex-shrink-0">
              <Trash2 className="h-4 w-4" /> {t('resetData')}
            </Button>
          </div>
        </div>
      </Card>

      {/* Data counts */}
      <Card>
        <CardHeader title={t('dataManagement')} />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          {[
            { label: t('transactions'), count: data.transactions.length },
            { label: t('budgets'), count: data.budgets.length },
            { label: t('emis'), count: data.emis.length },
            { label: t('bills'), count: data.bills.length },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-gray-200 dark:border-gray-700 p-3">
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{item.count}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{item.label}</p>
            </div>
          ))}
        </div>
      </Card>

      <ConfirmDialog
        open={resetConfirm}
        title={t('resetData')}
        message={t('resetConfirm')}
        confirmLabel={t('delete')}
        cancelLabel={t('cancel')}
        onConfirm={handleReset}
        onCancel={() => setResetConfirm(false)}
      />

      <ConfirmDialog
        open={sampleConfirm}
        title={t('loadSampleData')}
        message={t('sampleDataWarning')}
        confirmLabel={t('confirm')}
        cancelLabel={t('cancel')}
        variant="primary"
        onConfirm={handleLoadSample}
        onCancel={() => setSampleConfirm(false)}
      />

      <ConfirmDialog
        open={importConfirm}
        title={t('importData')}
        message={t('confirmImport')}
        confirmLabel={t('confirm')}
        cancelLabel={t('cancel')}
        variant="primary"
        onConfirm={handleImport}
        onCancel={() => { setImportConfirm(false); setPendingImport(null); }}
      />
    </div>
  );
}
