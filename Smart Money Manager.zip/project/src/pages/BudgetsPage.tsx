import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Pencil, Trash2, PiggyBank, AlertTriangle } from 'lucide-react';
import { useData } from '@/contexts/DataContext';
import { useToast } from '@/contexts/ToastContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Input, Select } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { EmptyState } from '@/components/ui/EmptyState';
import { EXPENSE_CATEGORIES } from '@/lib/constants';
import { getBudgetUtilization } from '@/lib/calculations';
import { formatCurrency, getCurrentMonth, getCurrentYear, getMonthName, classNames } from '@/lib/utils';
import type { Budget } from '@/lib/types';

export function BudgetsPage() {
  const { data, addBudget, updateBudget, deleteBudget } = useData();
  const { showToast } = useToast();
  const { t, tCategory } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();

  const [selectedMonth, setSelectedMonth] = useState(getCurrentMonth());
  const [selectedYear, setSelectedYear] = useState(getCurrentYear());
  const [modalOpen, setModalOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setEditingBudget(null);
      setModalOpen(true);
      setSearchParams({});
    }
  }, [searchParams, setSearchParams]);

  const { overall, categories } = useMemo(
    () => getBudgetUtilization(data.transactions, data.budgets, selectedMonth, selectedYear),
    [data.transactions, data.budgets, selectedMonth, selectedYear]
  );

  const monthBudgets = data.budgets.filter((b) => b.month === selectedMonth && b.year === selectedYear);

  const years = useMemo(() => {
    const set = new Set(data.budgets.map((b) => b.year));
    set.add(getCurrentYear());
    return Array.from(set).sort((a, b) => b - a);
  }, [data.budgets]);

  const handleSave = async (budgetData: { category: string; amount: number; month: number; year: number }) => {
    setSaving(true);
    try {
      if (editingBudget) {
        await updateBudget(editingBudget.id, budgetData);
        showToast(t('updateSuccess'), 'success');
      } else {
        await addBudget(budgetData);
        showToast(t('saveSuccess'), 'success');
      }
      setModalOpen(false);
      setEditingBudget(null);
    } catch {
      showToast(t('saveError'), 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteBudget(deleteId);
      showToast(t('deleteSuccess'), 'success');
    } catch {
      showToast(t('deleteError'), 'error');
    }
    setDeleteId(null);
  };

  return (
    <div className="space-y-4">
      {/* Month/Year selector */}
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
        <div className="flex gap-2">
          <Select value={selectedMonth} onChange={(e) => setSelectedMonth(Number(e.target.value))} className="w-auto">
            {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
              <option key={m} value={m}>{getMonthName(m)}</option>
            ))}
          </Select>
          <Select value={selectedYear} onChange={(e) => setSelectedYear(Number(e.target.value))} className="w-auto">
            {years.map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </Select>
        </div>
        <Button onClick={() => { setEditingBudget(null); setModalOpen(true); }}>
          <Plus className="h-4 w-4" /> {t('addBudget')}
        </Button>
      </div>

      {monthBudgets.length === 0 ? (
        <Card>
          <EmptyState
            title={t('noBudgets')}
            description={t('noBudgetsDesc')}
            icon={<PiggyBank className="h-8 w-8 text-gray-400" />}
            action={<Button onClick={() => { setEditingBudget(null); setModalOpen(true); }}>{t('addFirstBudget')}</Button>}
          />
        </Card>
      ) : (
        <>
          {/* Overall budget card */}
          {overall && (
            <Card>
              <CardHeader title={t('overallBudget')} subtitle={`${formatCurrency(overall.spent)} ${t('of')} ${formatCurrency(overall.budget)}`} />
              <ProgressBar value={overall.percentage} showLabel color="emerald" />
              {overall.percentage >= 100 && (
                <div className="mt-3 flex items-center gap-2 text-sm text-red-600 dark:text-red-400">
                  <AlertTriangle className="h-4 w-4" /> {t('budgetWarning100')}
                </div>
              )}
              {overall.percentage >= 80 && overall.percentage < 100 && (
                <div className="mt-3 flex items-center gap-2 text-sm text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="h-4 w-4" /> {t('budgetWarning80')}
                </div>
              )}
            </Card>
          )}

          {/* Category budgets */}
          {categories.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {categories.map((cat) => {
                const budget = monthBudgets.find((b) => b.category === cat.category);
                return (
                  <Card key={cat.category}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{tCategory(cat.category)}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                          {formatCurrency(cat.spent)} / {formatCurrency(cat.budget)}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <button
                          onClick={() => { setEditingBudget(budget || null); setModalOpen(true); }}
                          className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-700"
                          aria-label={t('edit')}
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => budget && setDeleteId(budget.id)}
                          className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                          aria-label={t('delete')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <ProgressBar value={cat.percentage} showLabel />
                    <div className="mt-2 flex items-center justify-between text-xs">
                      <span className={classNames(
                        'font-medium',
                        cat.percentage >= 100 ? 'text-red-600 dark:text-red-400' : 'text-gray-500 dark:text-gray-400'
                      )}>
                        {cat.percentage >= 100
                          ? `${formatCurrency(cat.spent - cat.budget)} ${t('overBudget')}`
                          : `${formatCurrency(cat.budget - cat.spent)} ${t('remaining')}`}
                      </span>
                      {cat.percentage >= 80 && (
                        <Badge variant={cat.percentage >= 100 ? 'danger' : 'warning'}>
                          {cat.percentage.toFixed(0)}%
                        </Badge>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </>
      )}

      <BudgetModal
        open={modalOpen}
        onClose={() => { setModalOpen(false); setEditingBudget(null); }}
        onSave={handleSave}
        editing={editingBudget}
        saving={saving}
        month={selectedMonth}
        year={selectedYear}
        existingCategories={monthBudgets.map((b) => b.category)}
      />

      <ConfirmDialog
        open={!!deleteId}
        title={t('deleteBudget')}
        message={t('deleteBudgetConfirm')}
        confirmLabel={t('delete')}
        cancelLabel={t('cancel')}
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

interface BudgetModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: { category: string; amount: number; month: number; year: number }) => void;
  editing: Budget | null;
  saving: boolean;
  month: number;
  year: number;
  existingCategories: string[];
}

function BudgetModal({ open, onClose, onSave, editing, saving, month, year, existingCategories }: BudgetModalProps) {
  const { t, tCategory } = useTranslation();
  const [category, setCategory] = useState('overall');
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (editing) {
      setCategory(editing.category);
      setAmount(String(editing.amount));
    } else {
      setCategory('overall');
      setAmount('');
    }
    setError('');
  }, [editing, open]);

  const availableCategories = ['overall', ...EXPENSE_CATEGORIES.filter((c) => !existingCategories.includes(c) || c === category)];

  const handleSubmit = () => {
    const amt = parseFloat(amount);
    if (!amount || isNaN(amt) || amt < 0) {
      setError(t('invalidAmount'));
      return;
    }
    onSave({ category, amount: amt, month, year });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editing ? t('editBudget') : t('addBudget')}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSubmit} loading={saving}>{t('save')}</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Select label={t('category')} value={category} onChange={(e) => setCategory(e.target.value)}>
          {availableCategories.map((c) => (
            <option key={c} value={c}>{c === 'overall' ? t('overallBudget') : tCategory(c)}</option>
          ))}
        </Select>
        <Input
          label={t('budgetAmount')}
          type="number"
          step="0.01"
          min="0"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          error={error}
        />
      </div>
    </Modal>
  );
}
