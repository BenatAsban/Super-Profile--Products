import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Pencil, Trash2, CreditCard, CalendarClock, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useData } from '@/contexts/DataContext';
import { useToast } from '@/contexts/ToastContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Input, Select, Textarea } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { EmptyState } from '@/components/ui/EmptyState';
import { getEMIDueDate, getRemainingInstallments, getOverdueEMIs } from '@/lib/calculations';
import { formatCurrency, formatDate, getDateString, daysUntil, classNames } from '@/lib/utils';
import type { EMI, EMIStatus } from '@/lib/types';

export function EMIPage() {
  const { data, addEMI, updateEMI, deleteEMI, addEMIPayment, deleteEMIPayment } = useData();
  const { showToast } = useToast();
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingEMI, setEditingEMI] = useState<EMI | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [paymentModalEMI, setPaymentModalEMI] = useState<EMI | null>(null);
  const [detailsEMI, setDetailsEMI] = useState<EMI | null>(null);

  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setEditingEMI(null);
      setModalOpen(true);
      setSearchParams({});
    }
  }, [searchParams, setSearchParams]);

  const monthlyCommitment = useMemo(
    () => data.emis.filter((e) => e.status === 'active').reduce((sum, e) => sum + e.monthly_amount, 0),
    [data.emis]
  );

  const overdueEMIs = useMemo(() => getOverdueEMIs(data.emis, data.emiPayments), [data.emis, data.emiPayments]);

  const getPaymentsForEMI = (emiId: string) => data.emiPayments.filter((p) => p.emi_id === emiId);

  const handleSave = async (emiData: Omit<EMI, 'id' | 'created_at' | 'updated_at'>) => {
    setSaving(true);
    try {
      if (editingEMI) {
        await updateEMI(editingEMI.id, emiData);
        showToast(t('updateSuccess'), 'success');
      } else {
        await addEMI(emiData);
        showToast(t('saveSuccess'), 'success');
      }
      setModalOpen(false);
      setEditingEMI(null);
    } catch {
      showToast(t('saveError'), 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteEMI(deleteId);
      showToast(t('deleteSuccess'), 'success');
    } catch {
      showToast(t('deleteError'), 'error');
    }
    setDeleteId(null);
  };

  const handlePayment = async (emiId: string, amount: number, installmentNum: number | null, paymentDate: string, notes: string) => {
    try {
      const existing = data.emiPayments.find(
        (p) => p.emi_id === emiId && p.installment_number === installmentNum
      );
      if (existing) {
        showToast(t('duplicatePayment'), 'warning');
        return;
      }
      await addEMIPayment({
        emi_id: emiId,
        amount,
        payment_date: paymentDate,
        installment_number: installmentNum,
        notes: notes || null,
      });
      showToast(t('paymentRecorded'), 'success');
      setPaymentModalEMI(null);
    } catch {
      showToast(t('saveError'), 'error');
    }
  };

  return (
    <div className="space-y-4">
      {/* Summary card */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('monthlyCommitment')}</p>
              <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-gray-100">{formatCurrency(monthlyCommitment)}</p>
            </div>
            <div className="rounded-xl bg-blue-50 p-2.5 dark:bg-blue-900/20">
              <CreditCard className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
        </Card>
        {overdueEMIs.length > 0 && (
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-600 dark:text-red-400">{t('overdue')}</p>
                <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-gray-100">{overdueEMIs.length} {t('overdue')}</p>
              </div>
              <div className="rounded-xl bg-red-50 p-2.5 dark:bg-red-900/20">
                <AlertTriangle className="h-6 w-6 text-red-500 dark:text-red-400" />
              </div>
            </div>
          </Card>
        )}
      </div>

      <div className="flex justify-end">
        <Button onClick={() => { setEditingEMI(null); setModalOpen(true); }}>
          <Plus className="h-4 w-4" /> {t('addEMI')}
        </Button>
      </div>

      {data.emis.length === 0 ? (
        <Card>
          <EmptyState
            title={t('noEMIs')}
            description={t('noEMIsDesc')}
            icon={<CreditCard className="h-8 w-8 text-gray-400" />}
            action={<Button onClick={() => { setEditingEMI(null); setModalOpen(true); }}>{t('addFirstEMI')}</Button>}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {data.emis.map((emi) => {
            const payments = getPaymentsForEMI(emi.id);
            const remaining = getRemainingInstallments(emi, payments);
            const now = new Date();
            const dueThisMonth = getEMIDueDate(emi, now.getMonth() + 1, now.getFullYear());
            const dueStr = dueThisMonth.toISOString().split('T')[0];
            const daysToDue = daysUntil(dueStr);
            const isOverdue = daysToDue < 0 && payments.filter((p) => {
              const pd = new Date(p.payment_date);
              return pd.getMonth() === now.getMonth() && pd.getFullYear() === now.getFullYear();
            }).length === 0;

            return (
              <Card key={emi.id}>
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-semibold text-gray-900 dark:text-gray-100 truncate">{emi.name}</h3>
                      <Badge variant={emi.status === 'active' ? 'success' : 'default'}>
                        {emi.status === 'active' ? t('active') : t('closed')}
                      </Badge>
                    </div>
                    {emi.lender_name && (
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{emi.lender_name}</p>
                    )}
                  </div>
                  <div className="flex gap-1 flex-shrink-0">
                    <button
                      onClick={() => { setEditingEMI(emi); setModalOpen(true); }}
                      className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-700"
                      aria-label={t('edit')}
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setDeleteId(emi.id)}
                      className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                      aria-label={t('delete')}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{t('monthlyInstallment')}</p>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{formatCurrency(emi.monthly_amount)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{t('outstandingBalance')}</p>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                      {emi.outstanding_balance != null ? formatCurrency(emi.outstanding_balance) : '-'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs mb-3">
                  <span className="text-gray-500 dark:text-gray-400">
                    {t('dueDay')}: {emi.due_day}
                  </span>
                  {remaining != null && (
                    <span className="text-gray-500 dark:text-gray-400">
                      {t('remainingInstallments')}: {remaining}
                    </span>
                  )}
                </div>

                {emi.status === 'active' && (
                  <div className="flex items-center justify-between gap-2 pt-3 border-t border-gray-100 dark:border-gray-700">
                    {isOverdue ? (
                      <Badge variant="danger"><AlertTriangle className="h-3 w-3" /> {t('overdueWarning')}</Badge>
                    ) : daysToDue === 0 ? (
                      <Badge variant="warning">{t('dueToday')}</Badge>
                    ) : daysToDue > 0 ? (
                      <Badge variant="info">{daysToDue} {t('daysUntil')}</Badge>
                    ) : (
                      <Badge variant="success"><CheckCircle2 className="h-3 w-3" /> {t('paid')}</Badge>
                    )}
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => setDetailsEMI(emi)}>
                        <CalendarClock className="h-3.5 w-3.5" /> {t('paymentHistory')}
                      </Button>
                      <Button size="sm" onClick={() => setPaymentModalEMI(emi)}>
                        {t('recordPayment')}
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <EMIModal
        open={modalOpen}
        onClose={() => { setModalOpen(false); setEditingEMI(null); }}
        onSave={handleSave}
        editing={editingEMI}
        saving={saving}
      />

      {paymentModalEMI && (
        <PaymentModal
          emi={paymentModalEMI}
          payments={getPaymentsForEMI(paymentModalEMI.id)}
          onClose={() => setPaymentModalEMI(null)}
          onSave={handlePayment}
        />
      )}

      {detailsEMI && (
        <PaymentHistoryModal
          emi={detailsEMI}
          payments={getPaymentsForEMI(detailsEMI.id)}
          onClose={() => setDetailsEMI(null)}
          onDeletePayment={async (id) => {
            try {
              await deleteEMIPayment(id);
              showToast(t('deleteSuccess'), 'success');
            } catch {
              showToast(t('deleteError'), 'error');
            }
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteId}
        title={t('deleteEMI')}
        message={t('deleteEMIConfirm')}
        confirmLabel={t('delete')}
        cancelLabel={t('cancel')}
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

interface EMIModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: Omit<EMI, 'id' | 'created_at' | 'updated_at'>) => void;
  editing: EMI | null;
  saving: boolean;
}

function EMIModal({ open, onClose, onSave, editing, saving }: EMIModalProps) {
  const { t } = useTranslation();
  const [name, setName] = useState('');
  const [totalAmount, setTotalAmount] = useState('');
  const [outstanding, setOutstanding] = useState('');
  const [monthlyAmount, setMonthlyAmount] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [startDate, setStartDate] = useState(getDateString());
  const [dueDay, setDueDay] = useState('1');
  const [numInstallments, setNumInstallments] = useState('');
  const [lenderName, setLenderName] = useState('');
  const [status, setStatus] = useState<EMIStatus>('active');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editing) {
      setName(editing.name);
      setTotalAmount(String(editing.total_amount));
      setOutstanding(editing.outstanding_balance != null ? String(editing.outstanding_balance) : '');
      setMonthlyAmount(String(editing.monthly_amount));
      setInterestRate(editing.interest_rate != null ? String(editing.interest_rate) : '');
      setStartDate(editing.start_date);
      setDueDay(String(editing.due_day));
      setNumInstallments(editing.num_installments != null ? String(editing.num_installments) : '');
      setLenderName(editing.lender_name || '');
      setStatus(editing.status);
    } else {
      setName(''); setTotalAmount(''); setOutstanding(''); setMonthlyAmount('');
      setInterestRate(''); setStartDate(getDateString()); setDueDay('1');
      setNumInstallments(''); setLenderName(''); setStatus('active');
    }
    setErrors({});
  }, [editing, open]);

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = t('requiredName');
    const ta = parseFloat(totalAmount);
    if (!totalAmount || isNaN(ta) || ta <= 0) e.totalAmount = t('invalidAmount');
    const ma = parseFloat(monthlyAmount);
    if (!monthlyAmount || isNaN(ma) || ma <= 0) e.monthlyAmount = t('invalidAmount');
    if (outstanding && (isNaN(parseFloat(outstanding)) || parseFloat(outstanding) < 0)) e.outstanding = t('invalidAmount');
    const dd = parseInt(dueDay);
    if (isNaN(dd) || dd < 1 || dd > 31) e.dueDay = t('invalidDate');
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSave({
      name: name.trim(),
      total_amount: parseFloat(totalAmount),
      outstanding_balance: outstanding ? parseFloat(outstanding) : null,
      monthly_amount: parseFloat(monthlyAmount),
      interest_rate: interestRate ? parseFloat(interestRate) : null,
      start_date: startDate,
      due_day: parseInt(dueDay),
      num_installments: numInstallments ? parseInt(numInstallments) : null,
      lender_name: lenderName.trim() || null,
      status,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editing ? t('editEMI') : t('addEMI')}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSubmit} loading={saving}>{t('save')}</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Input label={t('emiName')} value={name} onChange={(e) => setName(e.target.value)} error={errors.name} />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label={t('totalAmount')} type="number" step="0.01" min="0" value={totalAmount} onChange={(e) => setTotalAmount(e.target.value)} error={errors.totalAmount} />
          <Input label={t('outstandingBalance')} type="number" step="0.01" min="0" value={outstanding} onChange={(e) => setOutstanding(e.target.value)} error={errors.outstanding} />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label={t('monthlyInstallment')} type="number" step="0.01" min="0" value={monthlyAmount} onChange={(e) => setMonthlyAmount(e.target.value)} error={errors.monthlyAmount} />
          <Input label={t('interestRate')} type="number" step="0.01" value={interestRate} onChange={(e) => setInterestRate(e.target.value)} />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label={t('startDate')} type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          <Input label={t('dueDay')} type="number" min="1" max="31" value={dueDay} onChange={(e) => setDueDay(e.target.value)} error={errors.dueDay} />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label={t('numberOfInstallments')} type="number" min="1" value={numInstallments} onChange={(e) => setNumInstallments(e.target.value)} />
          <Input label={t('lenderName')} value={lenderName} onChange={(e) => setLenderName(e.target.value)} />
        </div>
        <Select label={t('status')} value={status} onChange={(e) => setStatus(e.target.value as EMIStatus)}>
          <option value="active">{t('active')}</option>
          <option value="closed">{t('closed')}</option>
        </Select>
      </div>
    </Modal>
  );
}

interface PaymentModalProps {
  emi: EMI;
  payments: { installment_number: number | null }[];
  onClose: () => void;
  onSave: (emiId: string, amount: number, installmentNum: number | null, paymentDate: string, notes: string) => void;
}

function PaymentModal({ emi, payments, onClose, onSave }: PaymentModalProps) {
  const { t } = useTranslation();
  const [amount, setAmount] = useState(String(emi.monthly_amount));
  const [installmentNum, setInstallmentNum] = useState('');
  const [paymentDate, setPaymentDate] = useState(getDateString());
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  const nextInstallment = (payments.length + 1).toString();
  const paidInstallments = new Set(payments.filter((p) => p.installment_number != null).map((p) => p.installment_number));

  const handleSubmit = () => {
    const amt = parseFloat(amount);
    if (!amount || isNaN(amt) || amt <= 0) {
      setError(t('invalidAmount'));
      return;
    }
    const instNum = installmentNum ? parseInt(installmentNum) : null;
    if (instNum != null && paidInstallments.has(instNum)) {
      setError(t('duplicatePayment'));
      return;
    }
    onSave(emi.id, amt, instNum, paymentDate, notes.trim());
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={`${t('recordPayment')} - ${emi.name}`}
      size="sm"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSubmit}>{t('save')}</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Input label={t('amount')} type="number" step="0.01" min="0" value={amount} onChange={(e) => setAmount(e.target.value)} error={error} />
        <Input
          label={`${t('installmentNumber')} (${t('of1')} ${emi.num_installments || '?'})`}
          type="number"
          min="1"
          placeholder={nextInstallment}
          value={installmentNum}
          onChange={(e) => setInstallmentNum(e.target.value)}
          hint={paidInstallments.size > 0 ? `Paid: ${Array.from(paidInstallments).join(', ')}` : undefined}
        />
        <Input label={t('paymentDate')} type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
        <Textarea label={t('notes')} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
    </Modal>
  );
}

interface PaymentHistoryModalProps {
  emi: EMI;
  payments: { id: string; amount: number; payment_date: string; installment_number: number | null; notes: string | null }[];
  onClose: () => void;
  onDeletePayment: (id: string) => void;
}

function PaymentHistoryModal({ emi, payments, onClose, onDeletePayment }: PaymentHistoryModalProps) {
  const { t } = useTranslation();
  const sorted = [...payments].sort((a, b) => new Date(b.payment_date).getTime() - new Date(a.payment_date).getTime());

  return (
    <Modal
      open
      onClose={onClose}
      title={`${t('paymentHistory')} - ${emi.name}`}
      size="md"
    >
      {sorted.length === 0 ? (
        <EmptyState title={t('noData')} description={t('noDataDesc')} />
      ) : (
        <div className="space-y-2">
          {sorted.map((p) => (
            <div key={p.id} className="flex items-center justify-between gap-3 rounded-xl border border-gray-200 dark:border-gray-700 px-3 py-2.5">
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                  {t('installmentNumber')} #{p.installment_number || '-'}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{formatDate(p.payment_date)}</p>
                {p.notes && <p className="text-xs text-gray-400 mt-0.5">{p.notes}</p>}
              </div>
              <div className="flex items-center gap-2">
                <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{formatCurrency(p.amount)}</p>
                <button
                  onClick={() => onDeletePayment(p.id)}
                  className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                  aria-label={t('delete')}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
