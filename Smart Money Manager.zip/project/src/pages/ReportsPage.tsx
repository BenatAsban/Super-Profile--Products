import { useState, useMemo } from 'react';
import {
  BarChart3,
  Download,
  TrendingUp,
  TrendingDown,
  PiggyBank,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from 'recharts';
import { useData } from '@/contexts/DataContext';
import { useToast } from '@/contexts/ToastContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Select, Input } from '@/components/ui/Input';
import { EmptyState } from '@/components/ui/EmptyState';
import { toCSV, downloadCSV } from '@/lib/csv';
import {
  calculateMonthlyIncome,
  calculateMonthlyExpenses,
  getCategorySpending,
  getMonthlyTrend,
  getBudgetUtilization,
} from '@/lib/calculations';
import {
  formatCurrency,
  formatCurrencyShort,
  getCurrentMonth,
  getCurrentYear,
  getMonthName,
  isWithinDateRange,
} from '@/lib/utils';
import { CATEGORY_COLORS, CHART_COLORS } from '@/lib/constants';

export function ReportsPage() {
  const { data } = useData();
  const { showToast } = useToast();
  const { t, tCategory } = useTranslation();

  const [month, setMonth] = useState(getCurrentMonth());
  const [year, setYear] = useState(getCurrentYear());
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const years = useMemo(() => {
    const set = new Set<number>([getCurrentYear()]);
    data.transactions.forEach((tx) => set.add(new Date(tx.transaction_date).getFullYear()));
    return Array.from(set).sort((a, b) => b - a);
  }, [data.transactions]);

  const income = useMemo(() => calculateMonthlyIncome(data.transactions, month, year), [data.transactions, month, year]);
  const expenses = useMemo(() => calculateMonthlyExpenses(data.transactions, month, year), [data.transactions, month, year]);
  const savings = income - expenses;
  const savingsRate = income > 0 ? (savings / income) * 100 : 0;

  const categoryData = useMemo(() => getCategorySpending(data.transactions, month, year), [data.transactions, month, year]);
  const trendData = useMemo(() => getMonthlyTrend(data.transactions, 6), [data.transactions]);
  const { categories: budgetData } = useMemo(
    () => getBudgetUtilization(data.transactions, data.budgets, month, year),
    [data.transactions, data.budgets, month, year]
  );

  const filteredTransactions = useMemo(() => {
    return data.transactions
      .filter((tx) => {
        const inMonth = new Date(tx.transaction_date).getMonth() === month - 1 && new Date(tx.transaction_date).getFullYear() === year;
        if (dateFrom || dateTo) {
          return isWithinDateRange(tx.transaction_date, dateFrom || null, dateTo || null);
        }
        return inMonth;
      })
      .sort((a, b) => new Date(b.transaction_date).getTime() - new Date(a.transaction_date).getTime());
  }, [data.transactions, month, year, dateFrom, dateTo]);

  const hasData = data.transactions.length > 0;

  const handleExportCSV = () => {
    if (filteredTransactions.length === 0) {
      showToast(t('noData'), 'warning');
      return;
    }
    const rows = filteredTransactions.map((tx) => ({
      Date: tx.transaction_date,
      Type: tx.type,
      Amount: tx.amount,
      Category: tCategory(tx.category),
      Description: tx.description,
      'Payment Method': tx.payment_method,
      Notes: tx.notes || '',
    }));
    const csv = toCSV(rows, ['Date', 'Type', 'Amount', 'Category', 'Description', 'Payment Method', 'Notes']);
    downloadCSV(csv, `transactions-${year}-${String(month).padStart(2, '0')}.csv`);
    showToast(t('saveSuccess'), 'success');
  };

  const budgetChartData = budgetData.map((b) => ({
    category: tCategory(b.category),
    Budget: b.budget,
    Spent: b.spent,
  }));

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 sm:items-end justify-between">
        <div className="flex flex-wrap gap-2">
          <Select label={t('selectMonth')} value={month} onChange={(e) => setMonth(Number(e.target.value))} className="w-auto">
            {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
              <option key={m} value={m}>{getMonthName(m)}</option>
            ))}
          </Select>
          <Select label={t('selectYear')} value={year} onChange={(e) => setYear(Number(e.target.value))} className="w-auto">
            {years.map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </Select>
        </div>
        <Button variant="outline" onClick={handleExportCSV}>
          <Download className="h-4 w-4" /> {t('exportCSV')}
        </Button>
      </div>

      {!hasData ? (
        <Card>
          <EmptyState
            title={t('noData')}
            description={t('noDataDesc')}
            icon={<BarChart3 className="h-8 w-8 text-gray-400" />}
          />
        </Card>
      ) : (
        <>
          {/* Summary cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('monthlyIncome')}</p>
                  <p className="mt-1 text-xl font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(income)}</p>
                </div>
                <TrendingUp className="h-5 w-5 text-emerald-500" />
              </div>
            </Card>
            <Card>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('monthlyExpenses')}</p>
                  <p className="mt-1 text-xl font-bold text-red-500 dark:text-red-400">{formatCurrency(expenses)}</p>
                </div>
                <TrendingDown className="h-5 w-5 text-red-500" />
              </div>
            </Card>
            <Card>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('savings')}</p>
                  <p className={`mt-1 text-xl font-bold ${savings >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500 dark:text-red-400'}`}>{formatCurrency(savings)}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{savingsRate.toFixed(1)}% {t('savingsRate')}</p>
                </div>
                <PiggyBank className="h-5 w-5 text-amber-500" />
              </div>
            </Card>
          </div>

          {/* Monthly trend */}
          <Card>
            <CardHeader title={t('monthlyTrend')} subtitle="6 months" />
            {trendData.every((d) => d.income === 0 && d.expenses === 0) ? (
              <EmptyState title={t('noData')} />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={trendData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" className="dark:stroke-gray-700" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#9ca3af" />
                  <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" tickFormatter={(v) => formatCurrencyShort(v)} />
                  <Tooltip formatter={(value: number) => formatCurrency(value)} contentStyle={{ borderRadius: '12px', border: '1px solid #e5e7eb', fontSize: '13px' }} />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
                  <Line type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} name={t('income')} />
                  <Line type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} name={t('expense')} />
                  <Line type="monotone" dataKey="savings" stroke="#f59e0b" strokeWidth={2} name={t('savings')} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Category spending */}
            <Card>
              <CardHeader title={t('categorySpending')} subtitle={`${getMonthName(month)} ${year}`} />
              {categoryData.length === 0 ? (
                <EmptyState title={t('noData')} />
              ) : (
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie data={categoryData} dataKey="amount" nameKey="category" cx="50%" cy="50%" outerRadius={90} innerRadius={50} paddingAngle={2}>
                      {categoryData.map((entry, i) => (
                        <Cell key={i} fill={CATEGORY_COLORS[entry.category] || CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number, _name: string, props: { payload?: { category?: string } }) => [formatCurrency(value), tCategory(props?.payload?.category || '')]}
                      contentStyle={{ borderRadius: '12px', border: '1px solid #e5e7eb', fontSize: '13px' }}
                    />
                    <Legend formatter={(value: string) => tCategory(value)} iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </Card>

            {/* Budget vs Actual */}
            <Card>
              <CardHeader title={t('budgetVsActual')} subtitle={`${getMonthName(month)} ${year}`} />
              {budgetChartData.length === 0 ? (
                <EmptyState title={t('noData')} />
              ) : (
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={budgetChartData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" className="dark:stroke-gray-700" />
                    <XAxis dataKey="category" tick={{ fontSize: 10 }} stroke="#9ca3af" />
                    <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" tickFormatter={(v) => formatCurrencyShort(v)} />
                    <Tooltip formatter={(value: number) => formatCurrency(value)} contentStyle={{ borderRadius: '12px', border: '1px solid #e5e7eb', fontSize: '13px' }} />
                    <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
                    <Bar dataKey="Budget" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Spent" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </Card>
          </div>

          {/* Transaction history */}
          <Card>
            <CardHeader
              title={t('transactionHistory')}
              subtitle={`${filteredTransactions.length} ${t('count')}`}
              action={
                <Button size="sm" variant="outline" onClick={handleExportCSV}>
                  <Download className="h-3.5 w-3.5" /> {t('exportCSV')}
                </Button>
              }
            />
            {/* Optional date range filter */}
            <div className="flex flex-wrap gap-2 mb-3">
              <Input type="date" placeholder={t('fromDate')} value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-auto" />
              <Input type="date" placeholder={t('toDate')} value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-auto" />
              {(dateFrom || dateTo) && (
                <Button size="sm" variant="ghost" onClick={() => { setDateFrom(''); setDateTo(''); }}>
                  {t('clearFilters')}
                </Button>
              )}
            </div>
            {filteredTransactions.length === 0 ? (
              <EmptyState title={t('noData')} />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700 text-left text-xs text-gray-500 dark:text-gray-400">
                      <th className="py-2 pr-3 font-medium">{t('date')}</th>
                      <th className="py-2 pr-3 font-medium">{t('description')}</th>
                      <th className="py-2 pr-3 font-medium hidden sm:table-cell">{t('category')}</th>
                      <th className="py-2 pr-3 font-medium text-right">{t('amount')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                    {filteredTransactions.slice(0, 50).map((tx) => (
                      <tr key={tx.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                        <td className="py-2 pr-3 text-gray-600 dark:text-gray-400 whitespace-nowrap">{tx.transaction_date}</td>
                        <td className="py-2 pr-3 text-gray-900 dark:text-gray-100 truncate max-w-[160px]">{tx.description}</td>
                        <td className="py-2 pr-3 text-gray-500 dark:text-gray-400 hidden sm:table-cell">{tCategory(tx.category)}</td>
                        <td className={`py-2 pr-3 text-right font-medium whitespace-nowrap ${tx.type === 'income' ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-900 dark:text-gray-100'}`}>
                          {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredTransactions.length > 50 && (
                  <p className="mt-2 text-xs text-gray-400 text-center">
                    Showing 50 of {filteredTransactions.length}. {t('exportCSV')} for full list.
                  </p>
                )}
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}
