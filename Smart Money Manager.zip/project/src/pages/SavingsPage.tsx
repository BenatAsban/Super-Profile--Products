import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Pencil, Trash2, Target, TrendingUp, CheckCircle2, ArrowDownCircle } from 'lucide-react';
import { useData } from '@/contexts/DataContext';
import { useToast } from '@/contexts/ToastContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Input, Textarea } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { EmptyState } from '@/components/ui/EmptyState';
import { getGoalProgress, getGoalContributions } from '@/lib/calculations';
import { formatCurrency, formatDate, getDateString, classNames } from '@/lib/utils';
import type { SavingsGoal, ContributionType } from '@/lib/types';

export function SavingsPage() {
  const { data, addSavingsGoal, updateSavingsGoal, deleteSavingsGoal, addContribution, deleteContribution } = useData();
  const { showToast } = useToast();
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<SavingsGoal | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [contributionModalGoal, setContributionModalGoal] = useState<SavingsGoal | null>(null);
  const [contributionType, setContributionType] = useState<ContributionType>('contribution');
  const [detailsGoal, setDetailsGoal] = useState<SavingsGoal | null>(null);

  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setEditingGoal(null);
      setModalOpen(true);
      setSearchParams({});
    }
  }, [searchParams, setSearchParams]);

  const totalSaved = useMemo(
    () => data.savingsGoals.reduce((sum, g) => sum + g.current_amount, 0),
    [data.savingsGoals]
  );

  const totalTarget = useMemo(
    () => data.savingsGoals.reduce((sum, g) => sum + g.target_amount, 0),
    [data.savingsGoals]
  );

  const handleSave = async (goalData: Omit<SavingsGoal, 'id' | 'created_at' | 'updated_at'>) => {
    setSaving(true);
    try {
      if (editingGoal) {
        await updateSavingsGoal(editingGoal.id, goalData);
        showToast(t('updateSuccess'), 'success');
      } else {
        await addSavingsGoal(goalData);
        showToast(t('saveSuccess'), 'success');
      }
      setModalOpen(false);
      setEditingGoal(null);
    } catch {
      showToast(t('saveError'), 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteSavingsGoal(deleteId);
      showToast(t('deleteSuccess'), 'success');
    } catch {
      showToast(t('deleteError'), 'error');
    }
    setDeleteId(null);
  };

  const handleContribution = async (goalId: string, amount: number, type: ContributionType, date: string, notes: string) => {
    const goal = data.savingsGoals.find((g) => g.id === goalId);
    if (!goal) return;
    if (type === 'withdrawal' && amount > goal.current_amount) {
      showToast(t('invalidAmount'), 'error');
      return;
    }
    try {
      await addContribution({
        goal_id: goalId,
        amount,
        type,
        contribution_date: date,
        notes: notes || null,
      });
      showToast(t('saveSuccess'), 'success');
      setContributionModalGoal(null);
    } catch {
      showToast(t('saveError'), 'error');
    }
  };

  return (
    <div className="space-y-4">
      {/* Summary */}
      {data.savingsGoals.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t('currentAmount')}</p>
                <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-gray-100">{formatCurrency(totalSaved)}</p>
              </div>
              <div className="rounded-xl bg-emerald-50 p-2.5 dark:bg-emerald-900/20">
                <TrendingUp className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t('targetAmount')}</p>
                <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-gray-100">{formatCurrency(totalTarget)}</p>
              </div>
              <div className="rounded-xl bg-blue-50 p-2.5 dark:bg-blue-900/20">
                <Target className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </Card>
        </div>
      )}

      <div className="flex justify-end">
        <Button onClick={() => { setEditingGoal(null); setModalOpen(true); }}>
          <Plus className="h-4 w-4" /> {t('addSavingsGoal')}
        </Button>
      </div>

      {data.savingsGoals.length === 0 ? (
        <Card>
          <EmptyState
            title={t('noSavingsGoals')}
            description={t('noSavingsGoalsDesc')}
            icon={<Target className="h-8 w-8 text-gray-400" />}
            action={<Button onClick={() => { setEditingGoal(null); setModalOpen(true); }}>{t('addFirstGoal')}</Button>}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.savingsGoals.map((goal) => {
            const progress = getGoalProgress(goal);
            const remaining = Math.max(0, goal.target_amount - goal.current_amount);
            return (
              <Card key={goal.id}>
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">{goal.name}</h3>
                      {goal.completed && <Badge variant="success"><CheckCircle2 className="h-3 w-3" /> {t('completed')}</Badge>}
                    </div>
                    {goal.target_date && (
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{formatDate(goal.target_date)}</p>
                    )}
                  </div>
                  <div className="flex gap-1 flex-shrink-0">
                    <button
                      onClick={() => { setEditingGoal(goal); setModalOpen(true); }}
                      className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-700"
                      aria-label={t('edit')}
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setDeleteId(goal.id)}
                      className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                      aria-label={t('delete')}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="flex items-baseline justify-between mb-1">
                    <p className="text-lg font-bold text-gray-900 dark:text-gray-100">{formatCurrency(goal.current_amount)}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">/ {formatCurrency(goal.target_amount)}</p>
                  </div>
                  <ProgressBar value={progress} showLabel color="emerald" />
                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    {formatCurrency(remaining)} {t('remainingAmount')}
                  </p>
                </div>

                <div className="flex gap-2 pt-3 border-t border-gray-100 dark:border-gray-700">
                  <Button size="sm" variant="outline" className="flex-1" onClick={() => setDetailsGoal(goal)}>
                    {t('contributionHistory')}
                  </Button>
                  {!goal.completed && (
                    <>
                      <Button
                        size="sm"
                        className="flex-1"
                        onClick={() => { setContributionModalGoal(goal); setContributionType('contribution'); }}
                      >
                        <Plus className="h-3.5 w-3.5" /> {t('addContribution')}
                      </Button>
                      {goal.current_amount > 0 && (
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => { setContributionModalGoal(goal); setContributionType('withdrawal'); }}
                        >
                          <ArrowDownCircle className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <GoalModal
        open={modalOpen}
        onClose={() => { setModalOpen(false); setEditingGoal(null); }}
        onSave={handleSave}
        editing={editingGoal}
        saving={saving}
      />

      {contributionModalGoal && (
        <ContributionModal
          goal={contributionModalGoal}
          type={contributionType}
          onClose={() => setContributionModalGoal(null)}
          onSave={handleContribution}
        />
      )}

      {detailsGoal && (
        <ContributionHistoryModal
          goal={detailsGoal}
          contributions={getGoalContributions(data.savingsContributions, detailsGoal.id)}
          onClose={() => setDetailsGoal(null)}
          onDelete={async (id) => {
            try {
              await deleteContribution(id);
              showToast(t('deleteSuccess'), 'success');
              setDetailsGoal((prev) => prev ? data.savingsGoals.find((g) => g.id === prev.id) || null : null);
            } catch {
              showToast(t('deleteError'), 'error');
            }
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteId}
        title={t('deleteGoal')}
        message={t('deleteGoalConfirm')}
        confirmLabel={t('delete')}
        cancelLabel={t('cancel')}
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

interface GoalModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: Omit<SavingsGoal, 'id' | 'created_at' | 'updated_at'>) => void;
  editing: SavingsGoal | null;
  saving: boolean;
}

function GoalModal({ open, onClose, onSave, editing, saving }: GoalModalProps) {
  const { t } = useTranslation();
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [currentAmount, setCurrentAmount] = useState('');
  const [targetDate, setTargetDate] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editing) {
      setName(editing.name);
      setTargetAmount(String(editing.target_amount));
      setCurrentAmount(String(editing.current_amount));
      setTargetDate(editing.target_date || '');
    } else {
      setName(''); setTargetAmount(''); setCurrentAmount(''); setTargetDate('');
    }
    setErrors({});
  }, [editing, open]);

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = t('requiredName');
    const ta = parseFloat(targetAmount);
    if (!targetAmount || isNaN(ta) || ta <= 0) e.targetAmount = t('invalidAmount');
    if (currentAmount && (isNaN(parseFloat(currentAmount)) || parseFloat(currentAmount) < 0)) e.currentAmount = t('invalidAmount');
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    const current = parseFloat(currentAmount) || 0;
    const target = parseFloat(targetAmount);
    onSave({
      name: name.trim(),
      target_amount: target,
      current_amount: current,
      target_date: targetDate || null,
      completed: current >= target,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editing ? t('editSavingsGoal') : t('addSavingsGoal')}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSubmit} loading={saving}>{t('save')}</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Input label={t('goalName')} value={name} onChange={(e) => setName(e.target.value)} error={errors.name} />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label={t('targetAmount')} type="number" step="0.01" min="0" value={targetAmount} onChange={(e) => setTargetAmount(e.target.value)} error={errors.targetAmount} />
          <Input label={t('currentAmount')} type="number" step="0.01" min="0" value={currentAmount} onChange={(e) => setCurrentAmount(e.target.value)} error={errors.currentAmount} hint={editing ? undefined : '0'} />
        </div>
        <Input label={t('targetDate')} type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} />
      </div>
    </Modal>
  );
}

interface ContributionModalProps {
  goal: SavingsGoal;
  type: ContributionType;
  onClose: () => void;
  onSave: (goalId: string, amount: number, type: ContributionType, date: string, notes: string) => void;
}

function ContributionModal({ goal, type, onClose, onSave }: ContributionModalProps) {
  const { t } = useTranslation();
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(getDateString());
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    const amt = parseFloat(amount);
    if (!amount || isNaN(amt) || amt <= 0) {
      setError(t('invalidAmount'));
      return;
    }
    if (type === 'withdrawal' && amt > goal.current_amount) {
      setError(t('invalidAmount'));
      return;
    }
    onSave(goal.id, amt, type, date, notes.trim());
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={type === 'contribution' ? `${t('addContribution')} - ${goal.name}` : `${t('recordWithdrawal')} - ${goal.name}`}
      size="sm"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSubmit}>{t('save')}</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Input
          label={t('contributionAmount')}
          type="number"
          step="0.01"
          min="0"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          error={error}
          hint={type === 'withdrawal' ? `${t('currentAmount')}: ${formatCurrency(goal.current_amount)}` : undefined}
        />
        <Input label={t('contributionDate')} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <Textarea label={t('notes')} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
    </Modal>
  );
}

interface ContributionHistoryModalProps {
  goal: SavingsGoal;
  contributions: { id: string; amount: number; type: ContributionType; contribution_date: string; notes: string | null }[];
  onClose: () => void;
  onDelete: (id: string) => void;
}

function ContributionHistoryModal({ goal, contributions, onClose, onDelete }: ContributionHistoryModalProps) {
  const { t } = useTranslation();
  return (
    <Modal open onClose={onClose} title={`${t('contributionHistory')} - ${goal.name}`} size="md">
      {contributions.length === 0 ? (
        <EmptyState title={t('noData')} description={t('noDataDesc')} />
      ) : (
        <div className="space-y-2">
          {contributions.map((c) => (
            <div key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-gray-200 dark:border-gray-700 px-3 py-2.5">
              <div className="flex items-center gap-3">
                <div className={classNames(
                  'flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center',
                  c.type === 'contribution' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'
                )}>
                  {c.type === 'contribution' ? (
                    <TrendingUp className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  ) : (
                    <ArrowDownCircle className="h-4 w-4 text-red-500 dark:text-red-400" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {c.type === 'contribution' ? t('contribution') : t('withdrawal')}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{formatDate(c.contribution_date)}</p>
                  {c.notes && <p className="text-xs text-gray-400 mt-0.5">{c.notes}</p>}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <p className={classNames(
                  'text-sm font-semibold',
                  c.type === 'contribution' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500 dark:text-red-400'
                )}>
                  {c.type === 'contribution' ? '+' : '-'}{formatCurrency(c.amount)}
                </p>
                <button
                  onClick={() => onDelete(c.id)}
                  className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                  aria-label={t('delete')}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
