import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  ArrowUpRight,
  ArrowDownRight,
  Filter,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { useData } from '@/contexts/DataContext';
import { useToast } from '@/contexts/ToastContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Input, Select, Textarea } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { EmptyState, SearchEmptyState } from '@/components/ui/EmptyState';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, PAYMENT_METHODS } from '@/lib/constants';
import { formatCurrency, formatDate, getDateString, isWithinDateRange, classNames } from '@/lib/utils';
import type { Transaction, TransactionType, PaymentMethod } from '@/lib/types';

const ITEMS_PER_PAGE = 10;

type SortOption = 'newest' | 'oldest' | 'highest' | 'lowest';

export function TransactionsPage() {
  const { data, addTransaction, updateTransaction, deleteTransaction } = useData();
  const { showToast } = useToast();
  const { t, tCategory, tPaymentMethod } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | TransactionType>('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [methodFilter, setMethodFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const action = searchParams.get('action');
  const presetType = searchParams.get('type') as TransactionType | null;

  useEffect(() => {
    if (action === 'add') {
      setEditingTx(null);
      setModalOpen(true);
      setSearchParams({});
    }
  }, [action, setSearchParams]);

  const filtered = useMemo(() => {
    let result = data.transactions.filter((tx) => {
      if (search && !tx.description.toLowerCase().includes(search.toLowerCase())) return false;
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
      if (categoryFilter !== 'all' && tx.category !== categoryFilter) return false;
      if (methodFilter !== 'all' && tx.payment_method !== methodFilter) return false;
      if (!isWithinDateRange(tx.transaction_date, dateFrom || null, dateTo || null)) return false;
      return true;
    });

    result.sort((a, b) => {
      switch (sortBy) {
        case 'oldest':
          return new Date(a.transaction_date).getTime() - new Date(b.transaction_date).getTime();
        case 'highest':
          return b.amount - a.amount;
        case 'lowest':
          return a.amount - b.amount;
        default:
          return new Date(b.transaction_date).getTime() - new Date(a.transaction_date).getTime();
      }
    });

    return result;
  }, [data.transactions, search, typeFilter, categoryFilter, methodFilter, dateFrom, dateTo, sortBy]);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  useEffect(() => {
    setPage(1);
  }, [search, typeFilter, categoryFilter, methodFilter, dateFrom, dateTo, sortBy]);

  const hasActiveFilters = typeFilter !== 'all' || categoryFilter !== 'all' || methodFilter !== 'all' || dateFrom || dateTo;

  const clearFilters = () => {
    setTypeFilter('all');
    setCategoryFilter('all');
    setMethodFilter('all');
    setDateFrom('');
    setDateTo('');
  };

  const handleSave = async (txData: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>) => {
    setSaving(true);
    try {
      if (editingTx) {
        await updateTransaction(editingTx.id, txData);
        showToast(t('updateSuccess'), 'success');
      } else {
        await addTransaction(txData);
        showToast(t('saveSuccess'), 'success');
      }
      setModalOpen(false);
      setEditingTx(null);
    } catch {
      showToast(t('saveError'), 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteTransaction(deleteId);
      showToast(t('deleteSuccess'), 'success');
    } catch {
      showToast(t('deleteError'), 'error');
    }
    setDeleteId(null);
  };

  const categories = typeFilter === 'income' ? INCOME_CATEGORIES : typeFilter === 'expense' ? EXPENSE_CATEGORIES : [...INCOME_CATEGORIES, ...EXPENSE_CATEGORIES];

  return (
    <div className="space-y-4">
      {/* Search + actions bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-gray-300 bg-white pl-10 pr-4 py-2.5 text-sm text-gray-900 placeholder:text-gray-400 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="flex-shrink-0"
          >
            <Filter className="h-4 w-4" />
            <span className="hidden sm:inline">{t('filterBy')}</span>
            {hasActiveFilters && <span className="ml-1 h-2 w-2 rounded-full bg-emerald-500" />}
          </Button>
          <Button
            onClick={() => { setEditingTx(null); setModalOpen(true); }}
            className="flex-shrink-0"
          >
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">{t('addTransaction')}</span>
          </Button>
        </div>
      </div>

      {/* Filters panel */}
      {showFilters && (
        <Card>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <Select
              label={t('transactionType')}
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as 'all' | TransactionType)}
            >
              <option value="all">{t('all')}</option>
              <option value="income">{t('income')}</option>
              <option value="expense">{t('expense')}</option>
            </Select>
            <Select
              label={t('category')}
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            >
              <option value="all">{t('all')}</option>
              {categories.map((c) => (
                <option key={c} value={c}>{tCategory(c)}</option>
              ))}
            </Select>
            <Select
              label={t('paymentMethod')}
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
            >
              <option value="all">{t('all')}</option>
              {PAYMENT_METHODS.map((m) => (
                <option key={m} value={m}>{tPaymentMethod(m)}</option>
              ))}
            </Select>
            <Select label={t('sortBy')} value={sortBy} onChange={(e) => setSortBy(e.target.value as SortOption)}>
              <option value="newest">{t('newest')}</option>
              <option value="oldest">{t('oldest')}</option>
              <option value="highest">{t('highest')}</option>
              <option value="lowest">{t('lowest')}</option>
            </Select>
            <Input
              type="date"
              label={t('fromDate')}
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
            />
            <Input
              type="date"
              label={t('toDate')}
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
            />
          </div>
          {hasActiveFilters && (
            <div className="mt-3 flex justify-end">
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                <X className="h-4 w-4" /> {t('clearFilters')}
              </Button>
            </div>
          )}
        </Card>
      )}

      {/* Transaction list */}
      <Card noPadding>
        {data.transactions.length === 0 ? (
          <EmptyState
            title={t('noTransactions')}
            description={t('noTransactionsDesc')}
            action={
              <Button onClick={() => { setEditingTx(null); setModalOpen(true); }}>
                <Plus className="h-4 w-4" /> {t('addFirstTransaction')}
              </Button>
            }
          />
        ) : filtered.length === 0 ? (
          <SearchEmptyState query={search || t('filterBy')} />
        ) : (
          <>
            <div className="divide-y divide-gray-100 dark:divide-gray-700">
              {paginated.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className={classNames(
                      'flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center',
                      tx.type === 'income' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'
                    )}>
                      {tx.type === 'income' ? (
                        <ArrowUpRight className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                      ) : (
                        <ArrowDownRight className="h-5 w-5 text-red-500 dark:text-red-400" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{tx.description}</p>
                      <div className="flex items-center gap-2 flex-wrap mt-0.5">
                        <Badge variant="default">{tCategory(tx.category)}</Badge>
                        <span className="text-xs text-gray-500 dark:text-gray-400">{formatDate(tx.transaction_date)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <p className={classNames(
                      'text-sm font-semibold',
                      tx.type === 'income' ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-900 dark:text-gray-100'
                    )}>
                      {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </p>
                    <div className="flex gap-1">
                      <button
                        onClick={() => { setEditingTx(tx); setModalOpen(true); }}
                        className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-700"
                        aria-label={t('edit')}
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setDeleteId(tx.id)}
                        className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                        aria-label={t('delete')}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 dark:border-gray-700">
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('page')} {page} {t('of1')} {totalPages}
                </p>
                <div className="flex gap-1">
                  <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(page - 1)}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(page + 1)}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </Card>

      {/* Add/Edit modal */}
      <TransactionModal
        open={modalOpen}
        onClose={() => { setModalOpen(false); setEditingTx(null); }}
        onSave={handleSave}
        editing={editingTx}
        saving={saving}
        presetType={presetType || undefined}
      />

      {/* Delete confirmation */}
      <ConfirmDialog
        open={!!deleteId}
        title={t('deleteTransaction')}
        message={t('deleteTransactionConfirm')}
        confirmLabel={t('delete')}
        cancelLabel={t('cancel')}
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

interface TransactionModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (tx: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>) => void;
  editing: Transaction | null;
  saving: boolean;
  presetType?: TransactionType;
}

function TransactionModal({ open, onClose, onSave, editing, saving, presetType }: TransactionModalProps) {
  const { t, tCategory, tPaymentMethod } = useTranslation();
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('food');
  const [description, setDescription] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [date, setDate] = useState(getDateString());
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editing) {
      setType(editing.type);
      setAmount(String(editing.amount));
      setCategory(editing.category);
      setDescription(editing.description);
      setPaymentMethod(editing.payment_method);
      setDate(editing.transaction_date);
      setNotes(editing.notes || '');
    } else {
      setType(presetType || 'expense');
      setAmount('');
      setCategory(presetType === 'income' ? 'salary' : 'food');
      setDescription('');
      setPaymentMethod('cash');
      setDate(getDateString());
      setNotes('');
    }
    setErrors({});
  }, [editing, open, presetType]);

  const categories = type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    const amt = parseFloat(amount);
    if (!amount || isNaN(amt) || amt <= 0) e.amount = t('invalidAmount');
    if (!description.trim()) e.description = t('requiredDescription');
    if (!date) e.date = t('requiredDate');
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSave({
      type,
      amount: parseFloat(amount),
      category,
      description: description.trim(),
      payment_method: paymentMethod,
      transaction_date: date,
      notes: notes.trim() || null,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editing ? t('editTransaction') : t('addTransaction')}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSubmit} loading={saving}>{t('save')}</Button>
        </>
      }
    >
      <div className="space-y-4">
        {/* Type toggle */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => { setType('income'); setCategory('salary'); }}
            className={classNames(
              'rounded-xl border-2 py-2.5 text-sm font-medium transition-colors',
              type === 'income'
                ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400'
                : 'border-gray-200 text-gray-500 dark:border-gray-600 dark:text-gray-400'
            )}
          >
            <ArrowUpRight className="h-4 w-4 inline mr-1" />
            {t('income')}
          </button>
          <button
            onClick={() => { setType('expense'); setCategory('food'); }}
            className={classNames(
              'rounded-xl border-2 py-2.5 text-sm font-medium transition-colors',
              type === 'expense'
                ? 'border-red-500 bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400'
                : 'border-gray-200 text-gray-500 dark:border-gray-600 dark:text-gray-400'
            )}
          >
            <ArrowDownRight className="h-4 w-4 inline mr-1" />
            {t('expense')}
          </button>
        </div>

        <Input
          label={t('amount')}
          type="number"
          step="0.01"
          min="0"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          error={errors.amount}
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Select label={t('category')} value={category} onChange={(e) => setCategory(e.target.value)}>
            {categories.map((c) => (
              <option key={c} value={c}>{tCategory(c)}</option>
            ))}
          </Select>
          <Select label={t('paymentMethod')} value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}>
            {PAYMENT_METHODS.map((m) => (
              <option key={m} value={m}>{tPaymentMethod(m)}</option>
            ))}
          </Select>
        </div>

        <Input
          label={t('description')}
          placeholder={t('description')}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          error={errors.description}
        />

        <Input
          label={t('transactionDate')}
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          error={errors.date}
        />

        <Textarea
          label={t('notes')}
          placeholder={t('notes')}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </div>
    </Modal>
  );
}
