import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Pencil, Trash2, Receipt, CheckCircle2, AlertTriangle, Clock } from 'lucide-react';
import { useData } from '@/contexts/DataContext';
import { useToast } from '@/contexts/ToastContext';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Input, Select, Textarea } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { EmptyState } from '@/components/ui/EmptyState';
import { getUpcomingBills, getOverdueBills, getPaidBills } from '@/lib/calculations';
import { formatCurrency, formatDate, getDateString, daysUntil, classNames } from '@/lib/utils';
import { BILL_CATEGORIES } from '@/lib/constants';
import type { Bill, Recurrence } from '@/lib/types';

export function BillsPage() {
  const { data, addBill, updateBill, deleteBill } = useData();
  const { showToast } = useToast();
  const { t, tCategory } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingBill, setEditingBill] = useState<Bill | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [tab, setTab] = useState<'upcoming' | 'overdue' | 'paid'>('upcoming');

  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setEditingBill(null);
      setModalOpen(true);
      setSearchParams({});
    }
  }, [searchParams, setSearchParams]);

  const upcoming = useMemo(() => getUpcomingBills(data.bills), [data.bills]);
  const overdue = useMemo(() => getOverdueBills(data.bills), [data.bills]);
  const paid = useMemo(() => getPaidBills(data.bills), [data.bills]);

  const displayBills = tab === 'upcoming' ? upcoming : tab === 'overdue' ? overdue : paid;

  const handleSave = async (billData: Omit<Bill, 'id' | 'created_at' | 'updated_at'>) => {
    setSaving(true);
    try {
      if (editingBill) {
        await updateBill(editingBill.id, billData);
        showToast(t('updateSuccess'), 'success');
      } else {
        await addBill(billData);
        showToast(t('saveSuccess'), 'success');
      }
      setModalOpen(false);
      setEditingBill(null);
    } catch {
      showToast(t('saveError'), 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteBill(deleteId);
      showToast(t('deleteSuccess'), 'success');
    } catch {
      showToast(t('deleteError'), 'error');
    }
    setDeleteId(null);
  };

  const togglePaid = async (bill: Bill) => {
    try {
      await updateBill(bill.id, {
        paid: !bill.paid,
        paid_date: !bill.paid ? getDateString() : null,
      });
      showToast(t('updateSuccess'), 'success');
    } catch {
      showToast(t('saveError'), 'error');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={() => { setEditingBill(null); setModalOpen(true); }}>
          <Plus className="h-4 w-4" /> {t('addBill')}
        </Button>
      </div>

      {data.bills.length === 0 ? (
        <Card>
          <EmptyState
            title={t('noBills')}
            description={t('noBillsDesc')}
            icon={<Receipt className="h-8 w-8 text-gray-400" />}
            action={<Button onClick={() => { setEditingBill(null); setModalOpen(true); }}>{t('addFirstBill')}</Button>}
          />
        </Card>
      ) : (
        <>
          {/* Tabs */}
          <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
            {([
              { key: 'upcoming', label: t('upcomingBillsTitle'), count: upcoming.length },
              { key: 'overdue', label: t('overdueBills'), count: overdue.length },
              { key: 'paid', label: t('paidBills'), count: paid.length },
            ] as const).map((tabItem) => (
              <button
                key={tabItem.key}
                onClick={() => setTab(tabItem.key)}
                className={classNames(
                  'flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors',
                  tab === tabItem.key
                    ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                )}
              >
                {tabItem.label}
                {tabItem.count > 0 && (
                  <span className={classNames(
                    'rounded-full px-1.5 py-0.5 text-xs',
                    tabItem.key === 'overdue' ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
                  )}>
                    {tabItem.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Bills list */}
          {displayBills.length === 0 ? (
            <Card><EmptyState title={t('noBills')} description={t('noBillsDesc')} /></Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {displayBills.map((bill) => {
                const days = daysUntil(bill.due_date);
                return (
                  <Card key={bill.id}>
                    <div className="flex items-start justify-between mb-3">
                      <div className="min-w-0">
                        <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">{bill.name}</h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{tCategory(bill.category)}</p>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <button
                          onClick={() => { setEditingBill(bill); setModalOpen(true); }}
                          className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 dark:hover:bg-gray-700"
                          aria-label={t('edit')}
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setDeleteId(bill.id)}
                          className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20"
                          aria-label={t('delete')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2">{formatCurrency(bill.amount)}</p>

                    <div className="flex items-center justify-between text-xs mb-3">
                      <span className="text-gray-500 dark:text-gray-400">{t('dueDate')}: {formatDate(bill.due_date)}</span>
                      <Badge variant={
                        bill.paid ? 'success' :
                        days < 0 ? 'danger' :
                        days === 0 ? 'warning' : 'default'
                      }>
                        {bill.paid ? (
                          <><CheckCircle2 className="h-3 w-3" /> {t('paid')}</>
                        ) : days < 0 ? (
                          <><AlertTriangle className="h-3 w-3" /> {Math.abs(days)} {t('overdueBy')}</>
                        ) : days === 0 ? (
                          <><Clock className="h-3 w-3" /> {t('dueToday')}</>
                        ) : (
                          <>{days} {t('daysUntil')}</>
                        )}
                      </Badge>
                    </div>

                    {!bill.paid && (
                      <Button size="sm" variant="outline" className="w-full" onClick={() => togglePaid(bill)}>
                        <CheckCircle2 className="h-3.5 w-3.5" /> {t('markAsPaid')}
                      </Button>
                    )}
                    {bill.paid && (
                      <Button size="sm" variant="ghost" className="w-full" onClick={() => togglePaid(bill)}>
                        {t('markAsUnpaid')}
                      </Button>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </>
      )}

      <BillModal
        open={modalOpen}
        onClose={() => { setModalOpen(false); setEditingBill(null); }}
        onSave={handleSave}
        editing={editingBill}
        saving={saving}
      />

      <ConfirmDialog
        open={!!deleteId}
        title={t('deleteBill')}
        message={t('deleteBillConfirm')}
        confirmLabel={t('delete')}
        cancelLabel={t('cancel')}
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

interface BillModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: Omit<Bill, 'id' | 'created_at' | 'updated_at'>) => void;
  editing: Bill | null;
  saving: boolean;
}

function BillModal({ open, onClose, onSave, editing, saving }: BillModalProps) {
  const { t, tCategory } = useTranslation();
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState(getDateString());
  const [category, setCategory] = useState('other');
  const [recurrence, setRecurrence] = useState<Recurrence>('monthly');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editing) {
      setName(editing.name);
      setAmount(String(editing.amount));
      setDueDate(editing.due_date);
      setCategory(editing.category);
      setRecurrence(editing.recurrence);
      setNotes(editing.notes || '');
    } else {
      setName(''); setAmount(''); setDueDate(getDateString());
      setCategory('other'); setRecurrence('monthly'); setNotes('');
    }
    setErrors({});
  }, [editing, open]);

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = t('requiredName');
    const amt = parseFloat(amount);
    if (!amount || isNaN(amt) || amt <= 0) e.amount = t('invalidAmount');
    if (!dueDate) e.dueDate = t('requiredDate');
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSave({
      name: name.trim(),
      amount: parseFloat(amount),
      due_date: dueDate,
      category,
      recurrence,
      paid: editing?.paid || false,
      paid_date: editing?.paid_date || null,
      notes: notes.trim() || null,
    });
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editing ? t('editBill') : t('addBill')}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSubmit} loading={saving}>{t('save')}</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Input label={t('billName')} value={name} onChange={(e) => setName(e.target.value)} error={errors.name} />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label={t('amount')} type="number" step="0.01" min="0" value={amount} onChange={(e) => setAmount(e.target.value)} error={errors.amount} />
          <Input label={t('dueDate')} type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} error={errors.dueDate} />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Select label={t('category')} value={category} onChange={(e) => setCategory(e.target.value)}>
            {BILL_CATEGORIES.map((c) => (
              <option key={c} value={c}>{tCategory(c)}</option>
            ))}
          </Select>
          <Select label={t('recurrence')} value={recurrence} onChange={(e) => setRecurrence(e.target.value as Recurrence)}>
            <option value="weekly">{t('weekly')}</option>
            <option value="monthly">{t('monthly')}</option>
            <option value="yearly">{t('yearly')}</option>
            <option value="one_time">{t('oneTime')}</option>
          </Select>
        </div>
        <Textarea label={t('notes')} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
    </Modal>
  );
}
