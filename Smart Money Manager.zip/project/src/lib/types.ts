export type TransactionType = 'income' | 'expense';
export type PaymentMethod = 'cash' | 'upi' | 'bank_transfer' | 'card' | 'other';
export type Recurrence = 'weekly' | 'monthly' | 'yearly' | 'one_time';
export type EMIStatus = 'active' | 'closed';
export type ContributionType = 'contribution' | 'withdrawal';
export type Theme = 'light' | 'dark';
export type Language = 'en' | 'ta';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: string;
  description: string;
  payment_method: PaymentMethod;
  transaction_date: string;
  notes?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Budget {
  id: string;
  category: string;
  amount: number;
  month: number;
  year: number;
  created_at: string;
  updated_at: string;
}

export interface EMI {
  id: string;
  name: string;
  total_amount: number;
  outstanding_balance: number | null;
  monthly_amount: number;
  interest_rate: number | null;
  start_date: string;
  due_day: number;
  num_installments: number | null;
  lender_name: string | null;
  status: EMIStatus;
  created_at: string;
  updated_at: string;
}

export interface EMIPayment {
  id: string;
  emi_id: string;
  amount: number;
  payment_date: string;
  installment_number: number | null;
  notes: string | null;
  created_at: string;
}

export interface Bill {
  id: string;
  name: string;
  amount: number;
  due_date: string;
  category: string;
  recurrence: Recurrence;
  paid: boolean;
  paid_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  target_amount: number;
  current_amount: number;
  target_date: string | null;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface SavingsContribution {
  id: string;
  goal_id: string;
  amount: number;
  type: ContributionType;
  contribution_date: string;
  notes: string | null;
  created_at: string;
}

export interface Settings {
  id?: string;
  currency: string;
  theme: Theme;
  language: Language;
  monthly_budget: number;
}

export interface AppData {
  transactions: Transaction[];
  budgets: Budget[];
  emis: EMI[];
  emiPayments: EMIPayment[];
  bills: Bill[];
  savingsGoals: SavingsGoal[];
  savingsContributions: SavingsContribution[];
  settings: Settings;
}

export interface DashboardStats {
  totalBalance: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  savings: number;
  savingsRate: number;
  upcomingEMIs: EMI[];
  upcomingBills: Bill[];
  budgetUtilization: number;
  budgetAmount: number;
}

export interface CategorySpending {
  category: string;
  amount: number;
  percentage: number;
}
