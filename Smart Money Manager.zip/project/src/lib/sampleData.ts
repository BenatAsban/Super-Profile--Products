import type {
  Transaction,
  Budget,
  EMI,
  Bill,
  SavingsGoal,
  SavingsContribution,
} from './types';
import { generateId, getDateString, getCurrentMonth, getCurrentYear } from './utils';

export function generateSampleData(): {
  transactions: Transaction[];
  budgets: Budget[];
  emis: EMI[];
  emiPayments: never[];
  bills: Bill[];
  savingsGoals: SavingsGoal[];
  savingsContributions: SavingsContribution[];
} {
  const now = new Date();
  const month = getCurrentMonth();
  const year = getCurrentYear();
  const today = getDateString(now);

  const prevDate = (days: number) => {
    const d = new Date(now);
    d.setDate(d.getDate() - days);
    return getDateString(d);
  };

  const futureDate = (days: number) => {
    const d = new Date(now);
    d.setDate(d.getDate() + days);
    return getDateString(d);
  };

  const transactions: Transaction[] = [
    {
      id: generateId(),
      type: 'income',
      amount: 75000,
      category: 'salary',
      description: 'Monthly Salary',
      payment_method: 'bank_transfer',
      transaction_date: prevDate(2),
      notes: 'October salary',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'income',
      amount: 12000,
      category: 'freelance',
      description: 'Freelance Project',
      payment_method: 'upi',
      transaction_date: prevDate(5),
      notes: 'Web design project',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 15000,
      category: 'housing',
      description: 'Monthly Rent',
      payment_method: 'bank_transfer',
      transaction_date: prevDate(3),
      notes: 'House rent',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 3200,
      category: 'food',
      description: 'Groceries',
      payment_method: 'upi',
      transaction_date: prevDate(1),
      notes: 'Weekly groceries',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 850,
      category: 'transport',
      description: 'Fuel',
      payment_method: 'card',
      transaction_date: prevDate(4),
      notes: 'Petrol',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 1500,
      category: 'entertainment',
      description: 'Movie & Dinner',
      payment_method: 'upi',
      transaction_date: prevDate(6),
      notes: 'Weekend outing',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 2200,
      category: 'utilities',
      description: 'Electricity Bill',
      payment_method: 'upi',
      transaction_date: prevDate(7),
      notes: 'Monthly electricity',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 499,
      category: 'entertainment',
      description: 'OTT Subscription',
      payment_method: 'card',
      transaction_date: prevDate(8),
      notes: 'Monthly subscription',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 1200,
      category: 'healthcare',
      description: 'Pharmacy',
      payment_method: 'cash',
      transaction_date: prevDate(10),
      notes: 'Medicines',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      type: 'expense',
      amount: 3500,
      category: 'shopping',
      description: 'New Clothes',
      payment_method: 'card',
      transaction_date: prevDate(12),
      notes: 'Festival shopping',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  const budgets: Budget[] = [
    {
      id: generateId(),
      category: 'overall',
      amount: 40000,
      month,
      year,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      category: 'food',
      amount: 8000,
      month,
      year,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      category: 'transport',
      amount: 3000,
      month,
      year,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      category: 'entertainment',
      amount: 3000,
      month,
      year,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  const emis: EMI[] = [
    {
      id: generateId(),
      name: 'Home Loan',
      total_amount: 5000000,
      outstanding_balance: 4200000,
      monthly_amount: 38500,
      interest_rate: 8.5,
      start_date: getDateString(new Date(year - 2, 0, 5)),
      due_day: 5,
      num_installments: 240,
      lender_name: 'State Bank',
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      name: 'Car Loan',
      total_amount: 800000,
      outstanding_balance: 320000,
      monthly_amount: 16500,
      interest_rate: 9.2,
      start_date: getDateString(new Date(year - 1, 5, 10)),
      due_day: 10,
      num_installments: 60,
      lender_name: 'HDFC Bank',
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  const bills: Bill[] = [
    {
      id: generateId(),
      name: 'Internet Bill',
      amount: 999,
      due_date: futureDate(3),
      category: 'internet',
      recurrence: 'monthly',
      paid: false,
      paid_date: null,
      notes: 'Broadband connection',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      name: 'Mobile Recharge',
      amount: 399,
      due_date: futureDate(5),
      category: 'mobile',
      recurrence: 'monthly',
      paid: false,
      paid_date: null,
      notes: 'Postpaid mobile',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      name: 'Netflix',
      amount: 649,
      due_date: futureDate(8),
      category: 'subscription',
      recurrence: 'monthly',
      paid: false,
      paid_date: null,
      notes: 'Monthly subscription',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      name: 'Electricity Bill',
      amount: 2200,
      due_date: prevDate(7),
      category: 'electricity',
      recurrence: 'monthly',
      paid: true,
      paid_date: prevDate(7),
      notes: 'Paid via UPI',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  const savingsGoals: SavingsGoal[] = [
    {
      id: generateId(),
      name: 'Emergency Fund',
      target_amount: 300000,
      current_amount: 125000,
      target_date: getDateString(new Date(year + 1, 5, 30)),
      completed: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      name: 'Vacation Trip',
      target_amount: 80000,
      current_amount: 25000,
      target_date: getDateString(new Date(year, 11, 15)),
      completed: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      name: 'New Laptop',
      target_amount: 120000,
      current_amount: 120000,
      target_date: null,
      completed: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  const savingsContributions: SavingsContribution[] = [
    {
      id: generateId(),
      goal_id: savingsGoals[0].id,
      amount: 25000,
      type: 'contribution',
      contribution_date: prevDate(30),
      notes: 'Initial deposit',
      created_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      goal_id: savingsGoals[0].id,
      amount: 100000,
      type: 'contribution',
      contribution_date: prevDate(10),
      notes: 'Monthly savings',
      created_at: new Date().toISOString(),
    },
    {
      id: generateId(),
      goal_id: savingsGoals[1].id,
      amount: 25000,
      type: 'contribution',
      contribution_date: prevDate(15),
      notes: 'Initial deposit',
      created_at: new Date().toISOString(),
    },
  ];

  return {
    transactions,
    budgets,
    emis,
    emiPayments: [],
    bills,
    savingsGoals,
    savingsContributions,
  };
}
