import type { PaymentMethod } from './types';

export const EXPENSE_CATEGORIES = [
  'food',
  'transport',
  'housing',
  'utilities',
  'healthcare',
  'entertainment',
  'shopping',
  'education',
  'personal',
  'other',
] as const;

export const INCOME_CATEGORIES = [
  'salary',
  'business',
  'freelance',
  'investment',
  'rental',
  'gift',
  'other',
] as const;

export const BILL_CATEGORIES = [
  'rent',
  'electricity',
  'water',
  'internet',
  'mobile',
  'subscription',
  'insurance',
  'other',
] as const;

export const PAYMENT_METHODS: PaymentMethod[] = ['cash', 'upi', 'bank_transfer', 'card', 'other'];

export const CATEGORY_COLORS: Record<string, string> = {
  food: '#ef4444',
  transport: '#f97316',
  housing: '#3b82f6',
  utilities: '#06b6d4',
  healthcare: '#10b981',
  entertainment: '#f59e0b',
  shopping: '#ec4899',
  education: '#6366f1',
  personal: '#8b5cf6',
  salary: '#10b981',
  business: '#059669',
  freelance: '#14b8a6',
  investment: '#0ea5e9',
  rental: '#6366f1',
  gift: '#f59e0b',
  rent: '#3b82f6',
  electricity: '#fbbf24',
  water: '#06b6d4',
  internet: '#8b5cf6',
  mobile: '#6366f1',
  subscription: '#ec4899',
  insurance: '#10b981',
  other: '#64748b',
};

export const DEFAULT_SETTINGS = {
  currency: 'INR',
  theme: 'light' as const,
  language: 'en' as const,
  monthly_budget: 0,
};

export const CHART_COLORS = [
  '#10b981',
  '#3b82f6',
  '#f59e0b',
  '#ef4444',
  '#8b5cf6',
  '#06b6d4',
  '#ec4899',
  '#14b8a6',
  '#f97316',
  '#6366f1',
  '#fbbf24',
  '#64748b',
];
