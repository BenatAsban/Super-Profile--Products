import { format, parseISO, isWithinInterval, startOfMonth, endOfMonth, subMonths } from 'date-fns';

export function formatCurrency(amount: number, currency = 'INR'): string {
  const formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
  return formatter.format(amount);
}

export function formatCurrencyShort(amount: number, currency = 'INR'): string {
  if (Math.abs(amount) >= 10000000) {
    return `${currency === 'INR' ? '₹' : ''}${(amount / 10000000).toFixed(2)} Cr`;
  }
  if (Math.abs(amount) >= 100000) {
    return `${currency === 'INR' ? '₹' : ''}${(amount / 100000).toFixed(2)} L`;
  }
  if (Math.abs(amount) >= 1000) {
    return `${currency === 'INR' ? '₹' : ''}${(amount / 1000).toFixed(1)}K`;
  }
  return formatCurrency(amount, currency);
}

export function formatDate(date: string | Date, formatStr = 'dd MMM yyyy'): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, formatStr);
}

export function formatDateShort(date: string | Date): string {
  return formatDate(date, 'dd MMM');
}

export function formatMonthYear(month: number, year: number): string {
  const d = new Date(year, month - 1, 1);
  return format(d, 'MMMM yyyy');
}

export function getMonthName(month: number): string {
  const d = new Date(2000, month - 1, 1);
  return format(d, 'MMMM');
}

export function getDateString(date = new Date()): string {
  return format(date, 'yyyy-MM-dd');
}

export function safeDueDate(year: number, month: number, day: number): Date {
  const lastDay = new Date(year, month, 0).getDate();
  const safeDay = Math.min(day, lastDay);
  return new Date(year, month - 1, safeDay);
}

export function isOverdue(dueDate: string): boolean {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = parseISO(dueDate);
  due.setHours(0, 0, 0, 0);
  return due < today;
}

export function isToday(date: string): boolean {
  const today = new Date();
  const d = parseISO(date);
  return (
    d.getDate() === today.getDate() &&
    d.getMonth() === today.getMonth() &&
    d.getFullYear() === today.getFullYear()
  );
}

export function daysUntil(dueDate: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = parseISO(dueDate);
  due.setHours(0, 0, 0, 0);
  const diff = due.getTime() - today.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export function generateId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
}

export function isInMonth(dateStr: string, month: number, year: number): boolean {
  const d = parseISO(dateStr);
  return d.getMonth() === month - 1 && d.getFullYear() === year;
}

export function getCurrentMonth(): number {
  return new Date().getMonth() + 1;
}

export function getCurrentYear(): number {
  return new Date().getFullYear();
}

export function getPreviousMonth(month: number, year: number): { month: number; year: number } {
  const d = subMonths(new Date(year, month - 1, 1), 1);
  return { month: d.getMonth() + 1, year: d.getFullYear() };
}

export function isWithinDateRange(
  dateStr: string,
  start: string | null,
  end: string | null
): boolean {
  if (!start && !end) return true;
  const d = parseISO(dateStr);
  if (start && end) {
    return isWithinInterval(d, { start: parseISO(start), end: parseISO(end) });
  }
  if (start) {
    return d >= parseISO(start);
  }
  if (end) {
    return d <= parseISO(end);
  }
  return true;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

export function safeDivide(numerator: number, denominator: number): number {
  if (denominator === 0 || isNaN(denominator)) return 0;
  return numerator / denominator;
}

export function monthStartEnd(month: number, year: number): { start: Date; end: Date } {
  return {
    start: startOfMonth(new Date(year, month - 1, 1)),
    end: endOfMonth(new Date(year, month - 1, 1)),
  };
}

export function classNames(...classes: (string | false | null | undefined)[]): string {
  return classes.filter(Boolean).join(' ');
}
