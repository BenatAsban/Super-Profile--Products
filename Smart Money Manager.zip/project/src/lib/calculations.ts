import type {
  Transaction,
  Budget,
  EMI,
  EMIPayment,
  Bill,
  SavingsGoal,
  SavingsContribution,
  DashboardStats,
  CategorySpending,
} from './types';
import { isInMonth, getCurrentMonth, getCurrentYear, safeDivide, daysUntil, isOverdue } from './utils';
import { format, parseISO, subMonths } from 'date-fns';

export function calculateMonthlyIncome(transactions: Transaction[], month?: number, year?: number): number {
  const m = month ?? getCurrentMonth();
  const y = year ?? getCurrentYear();
  return transactions
    .filter((t) => t.type === 'income' && isInMonth(t.transaction_date, m, y))
    .reduce((sum, t) => sum + t.amount, 0);
}

export function calculateMonthlyExpenses(transactions: Transaction[], month?: number, year?: number): number {
  const m = month ?? getCurrentMonth();
  const y = year ?? getCurrentYear();
  return transactions
    .filter((t) => t.type === 'expense' && isInMonth(t.transaction_date, m, y))
    .reduce((sum, t) => sum + t.amount, 0);
}

export function calculateTotalBalance(transactions: Transaction[]): number {
  return transactions.reduce(
    (sum, t) => sum + (t.type === 'income' ? t.amount : -t.amount),
    0
  );
}

export function calculateSavings(income: number, expenses: number): number {
  return income - expenses;
}

export function calculateSavingsRate(income: number, savings: number): number {
  return safeDivide(savings, income) * 100;
}

export function getCategorySpending(
  transactions: Transaction[],
  month?: number,
  year?: number
): CategorySpending[] {
  const m = month ?? getCurrentMonth();
  const y = year ?? getCurrentYear();
  const expenses = transactions.filter(
    (t) => t.type === 'expense' && isInMonth(t.transaction_date, m, y)
  );
  const total = expenses.reduce((sum, t) => sum + t.amount, 0);
  const byCategory = new Map<string, number>();
  expenses.forEach((t) => {
    byCategory.set(t.category, (byCategory.get(t.category) || 0) + t.amount);
  });
  return Array.from(byCategory.entries())
    .map(([category, amount]) => ({
      category,
      amount,
      percentage: safeDivide(amount, total) * 100,
    }))
    .sort((a, b) => b.amount - a.amount);
}

export function getMonthlyTrend(transactions: Transaction[], months = 6): {
  month: string;
  income: number;
  expenses: number;
  savings: number;
}[] {
  const now = new Date();
  const result: { month: string; income: number; expenses: number; savings: number }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const d = subMonths(now, i);
    const m = d.getMonth() + 1;
    const y = d.getFullYear();
    const income = calculateMonthlyIncome(transactions, m, y);
    const expenses = calculateMonthlyExpenses(transactions, m, y);
    result.push({
      month: format(d, 'MMM'),
      income,
      expenses,
      savings: income - expenses,
    });
  }
  return result;
}

export function getBudgetUtilization(
  transactions: Transaction[],
  budgets: Budget[],
  month?: number,
  year?: number
): { overall: { spent: number; budget: number; percentage: number } | null; categories: { category: string; spent: number; budget: number; percentage: number }[] } {
  const m = month ?? getCurrentMonth();
  const y = year ?? getCurrentYear();
  const monthBudgets = budgets.filter((b) => b.month === m && b.year === y);
  const overallBudget = monthBudgets.find((b) => b.category === 'overall');
  const categoryBudgets = monthBudgets.filter((b) => b.category !== 'overall');
  const expenses = transactions.filter(
    (t) => t.type === 'expense' && isInMonth(t.transaction_date, m, y)
  );

  const totalSpent = expenses.reduce((sum, t) => sum + t.amount, 0);

  const overall = overallBudget
    ? {
        spent: totalSpent,
        budget: overallBudget.amount,
        percentage: safeDivide(totalSpent, overallBudget.amount) * 100,
      }
    : null;

  const categories = categoryBudgets.map((b) => {
    const spent = expenses
      .filter((t) => t.category === b.category)
      .reduce((sum, t) => sum + t.amount, 0);
    return {
      category: b.category,
      spent,
      budget: b.amount,
      percentage: safeDivide(spent, b.amount) * 100,
    };
  });

  return { overall, categories };
}

export function getUpcomingEMIs(emis: EMI[], emiPayments: EMIPayment[], daysAhead = 30): EMI[] {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const future = new Date(now);
  future.setDate(future.getDate() + daysAhead);
  return emis.filter((emi) => {
    if (emi.status === 'closed') return false;
    const dueThisMonth = getEMIDueDate(emi, now.getMonth() + 1, now.getFullYear());
    const paymentsCount = emiPayments.filter((p) => p.emi_id === emi.id).length;
    if (emi.num_installments && paymentsCount >= emi.num_installments) return false;
    return dueThisMonth >= now && dueThisMonth <= future;
  });
}

export function getEMIDueDate(emi: EMI, month: number, year: number): Date {
  const lastDay = new Date(year, month, 0).getDate();
  const day = Math.min(emi.due_day, lastDay);
  return new Date(year, month - 1, day);
}

export function getOverdueEMIs(emis: EMI[], emiPayments: EMIPayment[]): EMI[] {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return emis.filter((emi) => {
    if (emi.status === 'closed') return false;
    const dueThisMonth = getEMIDueDate(emi, now.getMonth() + 1, now.getFullYear());
    const paymentsThisMonth = emiPayments.filter(
      (p) => p.emi_id === emi.id && isInMonth(p.payment_date, now.getMonth() + 1, now.getFullYear())
    ).length;
    return dueThisMonth < now && paymentsThisMonth === 0;
  });
}

export function getUpcomingBills(bills: Bill[], daysAhead = 30): Bill[] {
  return bills
    .filter((b) => !b.paid && daysUntil(b.due_date) >= 0 && daysUntil(b.due_date) <= daysAhead)
    .sort((a, b) => daysUntil(a.due_date) - daysUntil(b.due_date));
}

export function getOverdueBills(bills: Bill[]): Bill[] {
  return bills.filter((b) => !b.paid && isOverdue(b.due_date));
}

export function getPaidBills(bills: Bill[]): Bill[] {
  return bills.filter((b) => b.paid);
}

export function getDashboardStats(
  transactions: Transaction[],
  budgets: Budget[],
  emis: EMI[],
  emiPayments: EMIPayment[],
  bills: Bill[]
): DashboardStats {
  const monthlyIncome = calculateMonthlyIncome(transactions);
  const monthlyExpenses = calculateMonthlyExpenses(transactions);
  const totalBalance = calculateTotalBalance(transactions);
  const savings = calculateSavings(monthlyIncome, monthlyExpenses);
  const savingsRate = calculateSavingsRate(monthlyIncome, savings);
  const upcomingEMIs = getUpcomingEMIs(emis, emiPayments);
  const upcomingBills = getUpcomingBills(bills);
  const { overall } = getBudgetUtilization(transactions, budgets);

  return {
    totalBalance,
    monthlyIncome,
    monthlyExpenses,
    savings,
    savingsRate,
    upcomingEMIs,
    upcomingBills,
    budgetUtilization: overall?.percentage ?? 0,
    budgetAmount: overall?.budget ?? 0,
  };
}

export function getRemainingInstallments(emi: EMI, payments: EMIPayment[]): number | null {
  if (!emi.num_installments) return null;
  return Math.max(0, emi.num_installments - payments.length);
}

export function getGoalProgress(goal: SavingsGoal): number {
  return Math.min(100, safeDivide(goal.current_amount, goal.target_amount) * 100);
}

export function getGoalContributions(
  contributions: SavingsContribution[],
  goalId: string
): SavingsContribution[] {
  return contributions
    .filter((c) => c.goal_id === goalId)
    .sort((a, b) => parseISO(b.contribution_date).getTime() - parseISO(a.contribution_date).getTime());
}
