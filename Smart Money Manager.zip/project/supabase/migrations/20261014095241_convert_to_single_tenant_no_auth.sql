/*
# Convert finance tables from multi-tenant (authenticated) to single-tenant (no auth)

## Summary
The app no longer requires authentication. All 8 finance tables are converted
from user-scoped (authenticated-only) to single-tenant (anon+authenticated).
The app's anon-key frontend can now read and write all data without a login.

## Tables modified (all 8)
transactions, budgets, emis, emi_payments, bills, savings_goals,
savings_contributions, settings

For each table:
- user_id column: dropped NOT NULL constraint, dropped DEFAULT auth.uid(),
  dropped foreign key to auth.users. The column itself is retained to avoid
  any data loss; it simply becomes a nullable unused column.
- All 4 existing RLS policies (select/insert/update/delete, authenticated-only,
  scoped by auth.uid() = user_id) are dropped.
- 4 new policies created: TO anon, authenticated with USING(true) /
  WITH CHECK(true) — the data is intentionally shared (single-tenant, no login).

## Security
- RLS remains enabled on every table.
- USING(true) / WITH CHECK(true) is acceptable here because the app has no
  sign-in screen and all data is intentionally public/shared.

## Important notes
1. No data is lost — columns are not dropped, only constraints relaxed.
2. The migration is idempotent (uses IF EXISTS / IF NOT EXISTS patterns).
*/

-- ============ Relax user_id columns ============
ALTER TABLE transactions DROP CONSTRAINT IF EXISTS transactions_user_id_fkey;
ALTER TABLE transactions ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE transactions ALTER COLUMN user_id DROP DEFAULT;

ALTER TABLE budgets DROP CONSTRAINT IF EXISTS budgets_user_id_fkey;
ALTER TABLE budgets ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE budgets ALTER COLUMN user_id DROP DEFAULT;

ALTER TABLE emis DROP CONSTRAINT IF EXISTS emis_user_id_fkey;
ALTER TABLE emis ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE emis ALTER COLUMN user_id DROP DEFAULT;

ALTER TABLE emi_payments DROP CONSTRAINT IF EXISTS emi_payments_user_id_fkey;
ALTER TABLE emi_payments ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE emi_payments ALTER COLUMN user_id DROP DEFAULT;

ALTER TABLE bills DROP CONSTRAINT IF EXISTS bills_user_id_fkey;
ALTER TABLE bills ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE bills ALTER COLUMN user_id DROP DEFAULT;

ALTER TABLE savings_goals DROP CONSTRAINT IF EXISTS savings_goals_user_id_fkey;
ALTER TABLE savings_goals ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE savings_goals ALTER COLUMN user_id DROP DEFAULT;

ALTER TABLE savings_contributions DROP CONSTRAINT IF EXISTS savings_contributions_user_id_fkey;
ALTER TABLE savings_contributions ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE savings_contributions ALTER COLUMN user_id DROP DEFAULT;

ALTER TABLE settings DROP CONSTRAINT IF EXISTS settings_user_id_fkey;
ALTER TABLE settings ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE settings ALTER COLUMN user_id DROP DEFAULT;

-- ============ transactions policies ============
DROP POLICY IF EXISTS "select_own_transactions" ON transactions;
DROP POLICY IF EXISTS "insert_own_transactions" ON transactions;
DROP POLICY IF EXISTS "update_own_transactions" ON transactions;
DROP POLICY IF EXISTS "delete_own_transactions" ON transactions;

CREATE POLICY "anon_select_transactions" ON transactions
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_transactions" ON transactions
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_transactions" ON transactions
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_transactions" ON transactions
  FOR DELETE TO anon, authenticated USING (true);

-- ============ budgets policies ============
DROP POLICY IF EXISTS "select_own_budgets" ON budgets;
DROP POLICY IF EXISTS "insert_own_budgets" ON budgets;
DROP POLICY IF EXISTS "update_own_budgets" ON budgets;
DROP POLICY IF EXISTS "delete_own_budgets" ON budgets;

CREATE POLICY "anon_select_budgets" ON budgets
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_budgets" ON budgets
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_budgets" ON budgets
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_budgets" ON budgets
  FOR DELETE TO anon, authenticated USING (true);

-- ============ emis policies ============
DROP POLICY IF EXISTS "select_own_emis" ON emis;
DROP POLICY IF EXISTS "insert_own_emis" ON emis;
DROP POLICY IF EXISTS "update_own_emis" ON emis;
DROP POLICY IF EXISTS "delete_own_emis" ON emis;

CREATE POLICY "anon_select_emis" ON emis
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_emis" ON emis
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_emis" ON emis
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_emis" ON emis
  FOR DELETE TO anon, authenticated USING (true);

-- ============ emi_payments policies ============
DROP POLICY IF EXISTS "select_own_emi_payments" ON emi_payments;
DROP POLICY IF EXISTS "insert_own_emi_payments" ON emi_payments;
DROP POLICY IF EXISTS "update_own_emi_payments" ON emi_payments;
DROP POLICY IF EXISTS "delete_own_emi_payments" ON emi_payments;

CREATE POLICY "anon_select_emi_payments" ON emi_payments
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_emi_payments" ON emi_payments
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_emi_payments" ON emi_payments
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_emi_payments" ON emi_payments
  FOR DELETE TO anon, authenticated USING (true);

-- ============ bills policies ============
DROP POLICY IF EXISTS "select_own_bills" ON bills;
DROP POLICY IF EXISTS "insert_own_bills" ON bills;
DROP POLICY IF EXISTS "update_own_bills" ON bills;
DROP POLICY IF EXISTS "delete_own_bills" ON bills;

CREATE POLICY "anon_select_bills" ON bills
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_bills" ON bills
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_bills" ON bills
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_bills" ON bills
  FOR DELETE TO anon, authenticated USING (true);

-- ============ savings_goals policies ============
DROP POLICY IF EXISTS "select_own_savings_goals" ON savings_goals;
DROP POLICY IF EXISTS "insert_own_savings_goals" ON savings_goals;
DROP POLICY IF EXISTS "update_own_savings_goals" ON savings_goals;
DROP POLICY IF EXISTS "delete_own_savings_goals" ON savings_goals;

CREATE POLICY "anon_select_savings_goals" ON savings_goals
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_savings_goals" ON savings_goals
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_savings_goals" ON savings_goals
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_savings_goals" ON savings_goals
  FOR DELETE TO anon, authenticated USING (true);

-- ============ savings_contributions policies ============
DROP POLICY IF EXISTS "select_own_savings_contributions" ON savings_contributions;
DROP POLICY IF EXISTS "insert_own_savings_contributions" ON savings_contributions;
DROP POLICY IF EXISTS "update_own_savings_contributions" ON savings_contributions;
DROP POLICY IF EXISTS "delete_own_savings_contributions" ON savings_contributions;

CREATE POLICY "anon_select_savings_contributions" ON savings_contributions
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_savings_contributions" ON savings_contributions
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_savings_contributions" ON savings_contributions
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_savings_contributions" ON savings_contributions
  FOR DELETE TO anon, authenticated USING (true);

-- ============ settings policies ============
DROP POLICY IF EXISTS "select_own_settings" ON settings;
DROP POLICY IF EXISTS "insert_own_settings" ON settings;
DROP POLICY IF EXISTS "update_own_settings" ON settings;
DROP POLICY IF EXISTS "delete_own_settings" ON settings;

CREATE POLICY "anon_select_settings" ON settings
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_settings" ON settings
  FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_settings" ON settings
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_settings" ON settings
  FOR DELETE TO anon, authenticated USING (true);
