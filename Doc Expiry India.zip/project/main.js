import './style.css'

/* ============================================================
   DocExpiry India — Application Logic
   Vanilla JS + Bootstrap 5 + localStorage
   ============================================================ */

const STORAGE_KEY = 'docexpiry_india_documents'

/* ---------- Category metadata ---------- */
const CATEGORIES = [
  'Vehicle RC',
  'Insurance',
  'Aadhaar/PAN',
  'School Fees',
  'Gas Cylinder',
  'Passport',
  'Other',
]

const CATEGORY_ICONS = {
  'Vehicle RC': 'bi-car-front',
  Insurance: 'bi-shield-check',
  'Aadhaar/PAN': 'bi-person-vcard',
  'School Fees': 'bi-mortarboard',
  'Gas Cylinder': 'bi-fuel-pump',
  Passport: 'bi-airplane',
  Other: 'bi-file-earmark',
}

/* ---------- DOM refs ---------- */
let docModal, deleteModal, docModalInstance, deleteModalInstance

/* ---------- State ---------- */
let documents = []
let editingId = null
let deleteTargetId = null
let searchTerm = ''
let filterCategory = ''

/* ============================================================
   Storage
   ============================================================ */

function loadDocuments() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed.filter(isValidDoc)
  } catch (e) {
    console.error('Failed to load documents from localStorage:', e)
    return []
  }
}

function saveDocuments() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(documents))
    return true
  } catch (e) {
    console.error('Failed to save documents to localStorage:', e)
    showToast('Unable to save data. Browser storage may be full or disabled.', 'error')
    return false
  }
}

function isStorageAvailable() {
  try {
    const testKey = '__docexpiry_test__'
    localStorage.setItem(testKey, '1')
    localStorage.removeItem(testKey)
    return true
  } catch (e) {
    return false
  }
}

function isValidDoc(doc) {
  return (
    doc &&
    typeof doc.id === 'string' &&
    typeof doc.name === 'string' &&
    typeof doc.category === 'string' &&
    typeof doc.expiryDate === 'string' &&
    CATEGORIES.includes(doc.category)
  )
}

/* ============================================================
   Date Utilities
   ============================================================ */

function todayStr() {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

function parseDate(str) {
  const d = new Date(str + 'T00:00:00')
  d.setHours(0, 0, 0, 0)
  return d
}

function daysRemaining(expiryStr) {
  const today = todayStr()
  const expiry = parseDate(expiryStr)
  const diff = expiry - today
  return Math.round(diff / (1000 * 60 * 60 * 24))
}

function formatIndianDate(str) {
  const d = parseDate(str)
  const dd = String(d.getDate()).padStart(2, '0')
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const yyyy = d.getFullYear()
  return `${dd}/${mm}/${yyyy}`
}

function formatPrintDate() {
  const d = new Date()
  const dd = String(d.getDate()).padStart(2, '0')
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const yyyy = d.getFullYear()
  return `${dd}/${mm}/${yyyy}`
}

function statusInfo(days) {
  if (days < 0) {
    return {
      badge: 'status-expired',
      icon: 'bi-x-circle-fill',
      text: `Expired ${Math.abs(days)} day${Math.abs(days) === 1 ? '' : 's'} ago`,
      section: 'expired',
    }
  }
  if (days === 0) {
    return {
      badge: 'status-urgent',
      icon: 'bi-exclamation-circle-fill',
      text: 'Expires today',
      section: '7',
    }
  }
  if (days <= 7) {
    return {
      badge: 'status-urgent',
      icon: 'bi-exclamation-triangle-fill',
      text: `${days} day${days === 1 ? '' : 's'} left`,
      section: '7',
    }
  }
  if (days <= 15) {
    return {
      badge: 'status-soon',
      icon: 'bi-clock-fill',
      text: `${days} days left`,
      section: '15',
    }
  }
  if (days <= 30) {
    return {
      badge: 'status-approaching',
      icon: 'bi-calendar-week-fill',
      text: `${days} days left`,
      section: '30',
    }
  }
  return {
    badge: 'status-safe',
    icon: 'bi-calendar-check-fill',
    text: `Expires in ${days} days`,
    section: 'upcoming',
  }
}

/* ============================================================
   ID generation
   ============================================================ */

function generateId() {
  return 'doc_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8)
}

/* ============================================================
   Filtering & Sorting
   ============================================================ */

function getFilteredDocs() {
  let filtered = documents

  if (searchTerm.trim()) {
    const term = searchTerm.trim().toLowerCase()
    filtered = filtered.filter(
      (d) =>
        d.name.toLowerCase().includes(term) ||
        d.category.toLowerCase().includes(term),
    )
  }

  if (filterCategory) {
    filtered = filtered.filter((d) => d.category === filterCategory)
  }

  return filtered
}

function sortByExpiry(docs) {
  return [...docs].sort((a, b) => {
    const da = parseDate(a.expiryDate).getTime()
    const db = parseDate(b.expiryDate).getTime()
    return da - db
  })
}

/* ============================================================
   Rendering
   ============================================================ */

function render() {
  const filtered = getFilteredDocs()

  // Summary counts are always computed from ALL documents (not filtered)
  updateSummaryCounts()

  // Main empty state
  const mainEmpty = document.getElementById('mainEmptyState')
  const dashboardSections = document.getElementById('dashboardSections')
  const noResults = document.getElementById('noResultsState')

  if (documents.length === 0) {
    mainEmpty.classList.remove('d-none')
    dashboardSections.classList.add('d-none')
    noResults.classList.add('d-none')
    return
  }

  mainEmpty.classList.add('d-none')
  dashboardSections.classList.remove('d-none')

  // If search/filter returns nothing
  if (filtered.length === 0) {
    noResults.classList.remove('d-none')
    dashboardSections.classList.add('d-none')
    return
  }

  noResults.classList.add('d-none')
  dashboardSections.classList.remove('d-none')

  // Group documents by section
  const groups = { expired: [], '7': [], '15': [], '30': [], upcoming: [] }
  filtered.forEach((doc) => {
    const days = daysRemaining(doc.expiryDate)
    const info = statusInfo(days)
    groups[info.section].push({ doc, days, info })
  })

  // Render each section
  renderSection('expired', groups.expired, 'No expired documents.')
  renderSection('7', groups['7'], 'No documents expiring in the next 7 days.')
  renderSection('15', groups['15'], 'No documents expiring in the next 15 days.')
  renderSection('30', groups['30'], 'No documents expiring in the next 30 days.')
  renderSection('upcoming', groups.upcoming, 'No upcoming documents beyond 30 days.')
}

function renderSection(sectionKey, items, emptyMessage) {
  const suffix = capitalize(sectionKey)
  const section = document.getElementById('section' + suffix)
  const list = document.getElementById('list' + suffix)
  const badge = document.getElementById('badge' + suffix)

  // Show/hide section — hide if no items AND no active search/filter
  if (items.length === 0) {
    // When there's an active search, show the "no results" message per section
    if (searchTerm.trim() || filterCategory) {
      section.classList.remove('d-none')
      list.innerHTML = `<div class="col-12"><div class="section-empty"><i class="bi bi-inbox"></i>${emptyMessage}</div></div>`
    } else {
      section.classList.add('d-none')
    }
    badge.textContent = '0'
    return
  }

  section.classList.remove('d-none')
  badge.textContent = String(items.length)

  const sorted = sortByExpiry(items.map((i) => i.doc))
  const sortedItems = sorted.map((doc) => {
    const days = daysRemaining(doc.expiryDate)
    const info = statusInfo(days)
    return { doc, days, info }
  })

  list.innerHTML = sortedItems
    .map((item) => renderDocCard(item.doc, item.days, item.info))
    .join('')
}

function capitalize(str) {
  if (str === 'expired') return 'Expired'
  if (str === 'upcoming') return 'Upcoming'
  return str.charAt(0).toUpperCase() + str.slice(1)
}

function renderDocCard(doc, days, info) {
  const catIcon = CATEGORY_ICONS[doc.category] || 'bi-file-earmark'
  const notesHtml = doc.notes
    ? `<div class="doc-card-notes"><i class="bi bi-sticky me-1"></i>${escapeHtml(doc.notes)}</div>`
    : ''

  return `
    <div class="col-12 col-md-6 col-xl-4">
      <div class="card doc-card">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <h3 class="doc-card-title">${escapeHtml(doc.name)}</h3>
            <span class="status-badge ${info.badge}">
              <i class="bi ${info.icon}"></i>${escapeHtml(info.text)}
            </span>
          </div>
          <div class="d-flex align-items-center gap-2 mb-1">
            <span class="cat-badge"><i class="bi ${catIcon} me-1"></i>${escapeHtml(doc.category)}</span>
          </div>
          <div class="doc-card-date">
            <i class="bi bi-calendar3 me-1"></i>${formatIndianDate(doc.expiryDate)}
          </div>
          ${notesHtml}
          <div class="doc-card-actions">
            <button class="btn btn-outline-primary btn-sm" onclick="editDocument('${doc.id}')">
              <i class="bi bi-pencil me-1"></i>Edit
            </button>
            <button class="btn btn-outline-danger btn-sm" onclick="confirmDelete('${doc.id}')">
              <i class="bi bi-trash me-1"></i>Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  `
}

function escapeHtml(str) {
  if (str == null) return ''
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/* ============================================================
   Summary Counts (computed from ALL documents, not filtered)
   ============================================================ */

function updateSummaryCounts() {
  let c7 = 0, c15 = 0, c30 = 0, cExpired = 0

  documents.forEach((doc) => {
    const days = daysRemaining(doc.expiryDate)
    if (days < 0) cExpired++
    else if (days <= 7) c7++
    else if (days <= 15) c15++
    else if (days <= 30) c30++
  })

  document.getElementById('countTotal').textContent = String(documents.length)
  document.getElementById('count7').textContent = String(c7)
  document.getElementById('count15').textContent = String(c15)
  document.getElementById('count30').textContent = String(c30)
  document.getElementById('countExpired').textContent = String(cExpired)
}

/* ============================================================
   Add / Edit
   ============================================================ */

function openAddModal() {
  editingId = null
  document.getElementById('docModalLabel').textContent = 'Add New Document'
  document.getElementById('btnSaveDoc').textContent = 'Save Document'
  document.getElementById('docForm').reset()
  document.getElementById('docId').value = ''
  clearValidation()
  docModalInstance.show()
}

function openEditModal(id) {
  const doc = documents.find((d) => d.id === id)
  if (!doc) return

  editingId = id
  document.getElementById('docModalLabel').textContent = 'Edit Document'
  document.getElementById('btnSaveDoc').textContent = 'Update Document'
  document.getElementById('docId').value = doc.id
  document.getElementById('docName').value = doc.name
  document.getElementById('docCategory').value = doc.category
  document.getElementById('docExpiry').value = doc.expiryDate
  document.getElementById('docNotes').value = doc.notes || ''
  clearValidation()
  docModalInstance.show()
}

function clearValidation() {
  ;['docName', 'docCategory', 'docExpiry'].forEach((id) => {
    const el = document.getElementById(id)
    el.classList.remove('is-invalid')
  })
}

function validateForm() {
  let valid = true
  const name = document.getElementById('docName').value.trim()
  const category = document.getElementById('docCategory').value
  const expiry = document.getElementById('docExpiry').value

  if (!name) {
    document.getElementById('docName').classList.add('is-invalid')
    valid = false
  } else {
    document.getElementById('docName').classList.remove('is-invalid')
  }

  if (!category) {
    document.getElementById('docCategory').classList.add('is-invalid')
    valid = false
  } else {
    document.getElementById('docCategory').classList.remove('is-invalid')
  }

  if (!expiry || isNaN(parseDate(expiry).getTime())) {
    document.getElementById('docExpiry').classList.add('is-invalid')
    valid = false
  } else {
    document.getElementById('docExpiry').classList.remove('is-invalid')
  }

  return valid
}

function saveDocument() {
  if (!validateForm()) return

  const name = document.getElementById('docName').value.trim()
  const category = document.getElementById('docCategory').value
  const expiryDate = document.getElementById('docExpiry').value
  const notes = document.getElementById('docNotes').value.trim()

  if (editingId) {
    const doc = documents.find((d) => d.id === editingId)
    if (doc) {
      doc.name = name
      doc.category = category
      doc.expiryDate = expiryDate
      doc.notes = notes
    }
    saveDocuments()
    docModalInstance.hide()
    render()
    showToast('Document updated successfully!', 'success')
  } else {
    const newDoc = {
      id: generateId(),
      name,
      category,
      expiryDate,
      notes,
    }
    documents.push(newDoc)
    saveDocuments()
    docModalInstance.hide()
    render()
    showToast('Document added successfully!', 'success')
  }
}

/* ============================================================
   Delete
   ============================================================ */

function confirmDelete(id) {
  const doc = documents.find((d) => d.id === id)
  if (!doc) return

  deleteTargetId = id
  document.getElementById('deleteDocName').textContent = doc.name
  deleteModalInstance.show()
}

function performDelete() {
  if (!deleteTargetId) return

  documents = documents.filter((d) => d.id !== deleteTargetId)
  saveDocuments()
  deleteModalInstance.hide()
  deleteTargetId = null
  render()
  showToast('Document deleted successfully!', 'success')
}

/* ============================================================
   Toast
   ============================================================ */

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer')
  const iconMap = {
    success: 'bi-check-circle-fill',
    error: 'bi-x-circle-fill',
    warning: 'bi-exclamation-triangle-fill',
  }
  const colorMap = {
    success: 'text-success',
    error: 'text-danger',
    warning: 'text-warning',
  }

  const toastEl = document.createElement('div')
  toastEl.className = `toast toast-${type} align-items-center border-0` 
  toastEl.setAttribute('role', 'alert')
  toastEl.setAttribute('aria-live', 'assertive')
  toastEl.setAttribute('aria-atomic', 'true')
  toastEl.innerHTML = `
    <div class="toast-body">
      <i class="bi ${iconMap[type] || iconMap.success} ${colorMap[type] || ''}"></i>
      ${escapeHtml(message)}
    </div>
  `

  container.appendChild(toastEl)
  const toast = new bootstrap.Toast(toastEl, { delay: 3500 })
  toast.show()

  toastEl.addEventListener('hidden.bs.toast', () => {
    toastEl.remove()
  })
}

/* ============================================================
   Print Reminder Sheet
   ============================================================ */

function printReminderSheet() {
  if (documents.length === 0) {
    showToast('No documents to print. Add a document first.', 'warning')
    return
  }

  const sorted = sortByExpiry(documents)
  const expiredDocs = []
  const upcomingDocs = []

  sorted.forEach((doc) => {
    const days = daysRemaining(doc.expiryDate)
    if (days < 0) expiredDocs.push({ doc, days })
    else upcomingDocs.push({ doc, days })
  })

  const printArea = document.getElementById('printArea')
  printArea.innerHTML = buildPrintHTML(expiredDocs, upcomingDocs)
  printArea.classList.add('print-visible')

  // Give the DOM a tick to render, then print
  setTimeout(() => {
    window.print()
    // Clean up after print dialog
    setTimeout(() => {
      printArea.classList.remove('print-visible')
      printArea.innerHTML = ''
    }, 300)
  }, 100)
}

function buildPrintHTML(expiredDocs, upcomingDocs) {
  const buildTable = (docs) => {
    if (docs.length === 0) {
      return '<p class="print-sheet-empty">No documents in this section.</p>'
    }
    const rows = docs
      .map(({ doc, days }) => {
        const status =
          days < 0
            ? `Expired ${Math.abs(days)} day${Math.abs(days) === 1 ? '' : 's'} ago`
            : days === 0
              ? 'Expires today'
              : `${days} days left`
        return `
          <tr>
            <td>${escapeHtml(doc.name)}</td>
            <td>${escapeHtml(doc.category)}</td>
            <td>${formatIndianDate(doc.expiryDate)}</td>
            <td>${status}</td>
            <td>${escapeHtml(doc.notes || '—')}</td>
          </tr>
        `
      })
      .join('')

    return `
      <table class="print-sheet-table">
        <thead>
          <tr>
            <th>Document Name</th>
            <th>Category</th>
            <th>Expiry Date</th>
            <th>Days Remaining</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `
  }

  return `
    <div class="print-sheet">
      <div class="print-sheet-title">DocExpiry India — Document Renewal Reminder Sheet</div>
      <div class="print-sheet-subtitle">Printed on ${formatPrintDate()}</div>

      <div class="print-sheet-section-title">Expired Documents (${expiredDocs.length})</div>
      ${buildTable(expiredDocs)}

      <div class="print-sheet-section-title">Upcoming &amp; Expiring Documents (${upcomingDocs.length})</div>
      ${buildTable(upcomingDocs)}

      <div class="print-sheet-footer">
        Generated by DocExpiry India — Never miss a document renewal again
      </div>
    </div>
  `
}

/* ============================================================
   Search & Filters
   ============================================================ */

function handleSearch(e) {
  searchTerm = e.target.value
  render()
}

function handleCategoryFilter(e) {
  filterCategory = e.target.value
  render()
}

function resetFilters() {
  searchTerm = ''
  filterCategory = ''
  document.getElementById('searchInput').value = ''
  document.getElementById('categoryFilter').value = ''
  render()
}

/* ============================================================
   Expose functions to inline onclick handlers
   ============================================================ */

window.editDocument = openEditModal
window.confirmDelete = confirmDelete

/* ============================================================
   Initialization
   ============================================================ */

function init() {
  // Check localStorage availability
  if (!isStorageAvailable()) {
    document.getElementById('dashboardSections').classList.add('d-none')
    const main = document.querySelector('.app-main')
    const warning = document.createElement('div')
    warning.className = 'alert alert-warning text-center mt-4'
    warning.innerHTML =
      '<i class="bi bi-exclamation-triangle-fill me-2"></i>Browser storage (localStorage) is not available. Your documents cannot be saved.'
    main.insertBefore(warning, main.firstChild)
    return
  }

  // Load saved documents
  documents = loadDocuments()

  // Initialize Bootstrap modal instances
  docModal = document.getElementById('docModal')
  deleteModal = document.getElementById('deleteModal')
  docModalInstance = new bootstrap.Modal(docModal)
  deleteModalInstance = new bootstrap.Modal(deleteModal)

  // Bind buttons
  document.getElementById('btnAddNav').addEventListener('click', openAddModal)
  document.getElementById('btnAddEmpty').addEventListener('click', openAddModal)
  document.getElementById('btnPrintNav').addEventListener('click', printReminderSheet)
  document.getElementById('btnPrintNavMobile').addEventListener('click', printReminderSheet)
  document.getElementById('btnSaveDoc').addEventListener('click', saveDocument)
  document.getElementById('btnConfirmDelete').addEventListener('click', performDelete)

  // Search & filter
  document.getElementById('searchInput').addEventListener('input', handleSearch)
  document.getElementById('categoryFilter').addEventListener('change', handleCategoryFilter)
  document.getElementById('btnResetFilters').addEventListener('click', resetFilters)

  // Reset editingId when modal is hidden
  docModal.addEventListener('hidden.bs.modal', () => {
    editingId = null
    clearValidation()
  })

  // Reset delete target when modal is hidden
  deleteModal.addEventListener('hidden.bs.modal', () => {
    deleteTargetId = null
  })

  // Initial render
  render()
}

document.addEventListener('DOMContentLoaded', init)
