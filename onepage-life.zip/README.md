# OnePage Life — Minimal Personal Dashboard

> **A simple, calm, and distraction-free daily organizer designed for students, freelancers, employees, and minimalists.**

OnePage Life helps you organize your daily rhythm in one unified view without complicated databases, subpage mazes, or subscription fatigue.

---

## ⚡ Core Features

1. **Today's 3 Priorities**: Focus exclusively on your top 3 non-negotiable outcomes using Warren Buffett's 5/25 rule. Includes an isolated *Focus Mode* to eliminate visual clutter.
2. **Habit Tracker**: Track up to 5 atomic daily habits with streak counters and a 7-day visual dot history matrix.
3. **Quick Task List**: Fast-capture secondary errands, follow-ups, and calls with *All*, *Active*, and *Completed* filters.
4. **Daily Expense Tracker**: Record daily spending with category tagging, daily budget limit monitoring, and live today's total calculation.
5. **Quick Notes & Brain Dump**: Includes both a continuous auto-saving scratchpad for reflections and pin-able micro-note cards with 1-click clipboard copy.
6. **Daily Progress Visualizer**: Weighted visual completion score that encourages steady momentum throughout the day.
7. **Dark & Light Mode**: Warm stone stationery palette in light mode and calm obsidian charcoal in dark mode.
8. **100% Local Storage & Privacy**: Stored securely on your device. Zero account creation, zero analytics tracking, and runs completely offline.
9. **Data Export & Backup**: Download complete JSON backups, copy formatted Markdown summaries for Obsidian/Notion, or print clean daily sheets.
10. **Day Reset**: Safely start tomorrow with reset checkmarks while completely preserving your notes and expense history.

---

## 🚀 Quick Start Guide

### 1. Run Locally (Development)

Make sure you have Node.js (v18+) installed:

```bash
# 1. Install dependencies
npm install

# 2. Start local development server
npm run dev
```

Visit `http://localhost:3000` in your browser.

### 2. Build for Production

```bash
npm run build
```

The compiled static files will be generated in the `dist/` directory.

---

## 🌐 Free 1-Click Deployment Options

### Deploy to Vercel
1. Push this folder to a GitHub repository.
2. Go to [vercel.com](https://vercel.com) and click **"Add New Project"**.
3. Import your repository. Vercel will automatically detect Vite. Click **Deploy**.

### Deploy to Cloudflare Pages or Netlify
- **Build command**: `npm run build`
- **Build output directory**: `dist`

---

## 📑 Notion Embed Guide

Want to use OnePage Life directly inside your Notion workspace?

1. Deploy your app to Vercel or Netlify to get your personal URL (e.g. `https://my-onepage-life.vercel.app`).
2. Open any Notion page.
3. Type `/embed` and hit **Enter**.
4. Paste your deployed URL.
5. Resize the embed block to fit your preferred dashboard width. All changes persist in your browser's local storage!

---

## 🛍️ Selling on Payhip (Creator Guide)

If you are selling this as a digital product on Payhip:

1. **Create a Payhip Account**: Sign up for free at [payhip.com](https://payhip.com).
2. **Add a Product**: Click *Add New Product* → choose *Digital Product*.
3. **Set Details**:
   - **Title**: `OnePage Life — Minimal Personal Dashboard`
   - **Price**: Recommended `$15.00 – $25.00` (one-time purchase).
4. **Upload Package**: Compress this directory (or the pre-built `dist/` folder + this README) into a ZIP file named `OnePage-Life-Package.zip` and upload it.
5. **Configure Checkout URL**: In the app, click the **Payhip Storefront** tab → click **Configure Store Link** (or click the Seller Setup button in the footer) and paste your actual Payhip product URL (e.g., `https://payhip.com/b/your-code`).

---

## 📄 License & Terms

Designed as a clean, reliable, and premium personal productivity application.
All user data is stored strictly on the client side in standard browser `localStorage`.
