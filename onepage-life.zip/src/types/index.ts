export interface PriorityItem {
  id: string;
  title: string;
  completed: boolean;
  notes?: string;
  tag?: string;
}

export interface TaskItem {
  id: string;
  title: string;
  completed: boolean;
  createdAt: string;
  dueDate?: string;
}

export interface HabitItem {
  id: string;
  name: string;
  completedToday: boolean;
  streak: number;
  // History of the last 7 days (YYYY-MM-DD -> boolean)
  history: Record<string, boolean>;
  icon?: string;
}

export interface ExpenseItem {
  id: string;
  title: string;
  amount: number;
  category: 'Food' | 'Transport' | 'Work' | 'Personal' | 'Bills' | 'Other';
  date: string; // YYYY-MM-DD
  time: string;
}

export interface QuickNote {
  id: string;
  content: string;
  createdAt: string;
  pinned?: boolean;
}

export interface DaySnapshot {
  date: string;
  prioritiesCompleted: number;
  prioritiesTotal: number;
  habitsCompleted: number;
  habitsTotal: number;
  tasksCompleted: number;
  tasksTotal: number;
  expensesTotal: number;
  score: number;
}

export interface AppState {
  theme: 'light' | 'dark';
  currency: string;
  focusIntention: string;
  dailyBudgetLimit: number;
  priorities: PriorityItem[];
  tasks: TaskItem[];
  habits: HabitItem[];
  expenses: ExpenseItem[];
  scratchpad: string;
  notes: QuickNote[];
  lastActiveDate: string; // YYYY-MM-DD
  historySnapshots: DaySnapshot[];
  payhipCheckoutUrl: string;
}
