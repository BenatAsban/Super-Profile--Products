/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { DailyProgress } from './components/DailyProgress';
import { ThreePriorities } from './components/ThreePriorities';
import { HabitTracker } from './components/HabitTracker';
import { QuickTasks } from './components/QuickTasks';
import { ExpenseTracker } from './components/ExpenseTracker';
import { QuickNotes } from './components/QuickNotes';
import { ResetDayModal } from './components/ResetDayModal';
import { DataModal } from './components/DataModal';
import { SellerGuideModal } from './components/SellerGuideModal';
import { LandingPage } from './components/LandingPage';
import {
  ShieldCheck,
  RotateCcw,
  Download,
  BookOpen,
  ShoppingBag,
  ExternalLink
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { viewMode, setViewMode, state } = useApp();
  const [isResetOpen, setIsResetOpen] = useState(false);
  const [isDataOpen, setIsDataOpen] = useState(false);
  const [isSellerGuideOpen, setIsSellerGuideOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF9F5] text-stone-900 dark:bg-[#121211] dark:text-stone-100 transition-colors">
      {/* Top Header */}
      <Header
        onOpenReset={() => setIsResetOpen(true)}
        onOpenData={() => setIsDataOpen(true)}
        onOpenSellerGuide={() => setIsSellerGuideOpen(true)}
      />

      {/* Main Content Area */}
      {viewMode === 'landing' ? (
        <LandingPage onOpenSellerGuide={() => setIsSellerGuideOpen(true)} />
      ) : (
        <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
          {/* Section 1: Daily Progress & Completion Summary */}
          <DailyProgress />

          {/* Section 2: Core Flagship Features (3 Priorities + Habit Tracker) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Today's 3 Priorities (7 cols on desktop) */}
            <div className="lg:col-span-7">
              <ThreePriorities />
            </div>

            {/* Habit Tracker (5 cols on desktop) */}
            <div className="lg:col-span-5">
              <HabitTracker />
            </div>
          </div>

          {/* Section 3: Daily Execution (Quick Tasks, Expenses, and Quick Notes) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
            {/* Quick Tasks */}
            <div className="flex flex-col">
              <QuickTasks />
            </div>

            {/* Daily Expense Tracker */}
            <div className="flex flex-col">
              <ExpenseTracker />
            </div>

            {/* Quick Notes & Scratchpad */}
            <div className="flex flex-col md:col-span-2 lg:col-span-1">
              <QuickNotes />
            </div>
          </div>

          {/* Quiet Minimal Dashboard Footer */}
          <footer className="pt-8 pb-12 border-t border-stone-200/60 dark:border-stone-800/60 text-xs text-stone-500 dark:text-stone-400 flex flex-col sm:flex-row items-center justify-between gap-4 no-print">
            <div className="flex items-center gap-2">
              <span className="font-serif font-semibold text-stone-800 dark:text-stone-200">
                OnePage Life
              </span>
              <span>·</span>
              <span className="flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                Browser Local Storage (Private)
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => setIsResetOpen(true)}
                className="hover:text-amber-700 dark:hover:text-amber-400 flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Day</span>
              </button>
              <span>·</span>
              <button
                onClick={() => setIsDataOpen(true)}
                className="hover:text-amber-700 dark:hover:text-amber-400 flex items-center gap-1 transition-colors"
              >
                <Download className="w-3 h-3" />
                <span>Backup JSON / Print</span>
              </button>
              <span>·</span>
              <button
                onClick={() => setViewMode('landing')}
                className="hover:text-amber-700 dark:hover:text-amber-400 flex items-center gap-1 transition-colors"
              >
                <ShoppingBag className="w-3 h-3" />
                <span>Payhip Sales Page</span>
              </button>
              <span>·</span>
              <button
                onClick={() => setIsSellerGuideOpen(true)}
                className="hover:text-amber-700 dark:hover:text-amber-400 flex items-center gap-1 transition-colors"
              >
                <BookOpen className="w-3 h-3" />
                <span>Seller Setup</span>
              </button>
            </div>
          </footer>
        </main>
      )}

      {/* Modals */}
      <ResetDayModal
        isOpen={isResetOpen}
        onClose={() => setIsResetOpen(false)}
      />
      <DataModal
        isOpen={isDataOpen}
        onClose={() => setIsDataOpen(false)}
      />
      <SellerGuideModal
        isOpen={isSellerGuideOpen}
        onClose={() => setIsSellerGuideOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
