import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { getLast7DaysKeys, getDayInitial, getTodayKey } from '../utils/date';
import { Flame, Plus, Check, Trash2, Edit2, AlertCircle } from 'lucide-react';

export const HabitTracker: React.FC = () => {
  const { state, toggleHabit, addHabit, updateHabit, deleteHabit } = useApp();
  const [newHabitName, setNewHabitName] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const last7Days = getLast7DaysKeys();
  const todayKey = getTodayKey();

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;
    const added = addHabit(newHabitName);
    if (added) {
      setNewHabitName('');
      setIsAdding(false);
    }
  };

  const handleSaveEdit = (id: string) => {
    if (editName.trim()) {
      updateHabit(id, editName.trim());
    }
    setEditingId(null);
  };

  const isMaxReached = state.habits.length >= 5;

  return (
    <section className="bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold tracking-wide uppercase text-stone-900 dark:text-stone-100">
              Daily Habits
            </h2>
            <span className="text-xs text-stone-400 dark:text-stone-500">
              ({state.habits.length}/5)
            </span>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            Atomic daily repetitions that shape your identity over time.
          </p>
        </div>

        {/* Add button if under 5 */}
        <div className="no-print">
          {!isMaxReached ? (
            <button
              onClick={() => setIsAdding(!isAdding)}
              className="flex items-center gap-1 text-xs font-medium text-amber-700 dark:text-amber-400 hover:text-amber-800 dark:hover:text-amber-300 px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Habit</span>
            </button>
          ) : (
            <span className="text-[11px] text-stone-400 dark:text-stone-500 italic hidden sm:inline">
              Max 5 habits to preserve consistency
            </span>
          )}
        </div>
      </div>

      {/* Add Habit Form */}
      {isAdding && !isMaxReached && (
        <form
          onSubmit={handleAdd}
          className="mb-4 p-3 bg-stone-50 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700/80 space-y-2 no-print"
        >
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={newHabitName}
              onChange={(e) => setNewHabitName(e.target.value)}
              placeholder="e.g. Read 20 pages, Morning meditation..."
              autoFocus
              className="flex-1 bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded-lg px-3 py-1.5 text-xs text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <button
              type="submit"
              className="px-3 py-1.5 text-xs font-medium text-white bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 rounded-lg transition-colors"
            >
              Save
            </button>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-2 py-1.5 text-xs text-stone-500 hover:text-stone-700 dark:hover:text-stone-300"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Habits List */}
      <div className="space-y-2.5">
        {state.habits.length === 0 ? (
          <div className="text-center py-6 border border-dashed border-stone-200 dark:border-stone-800 rounded-xl">
            <p className="text-xs text-stone-500 dark:text-stone-400">
              No habits created yet. Keep it simple with 1–3 daily rituals.
            </p>
          </div>
        ) : (
          state.habits.map((habit) => {
            const isEditing = editingId === habit.id;

            return (
              <div
                key={habit.id}
                className="group flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-xl border border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/40 hover:bg-stone-50 dark:hover:bg-stone-900/70 transition-all gap-3"
              >
                {/* Left: Checkmark & Name */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {/* Today check toggle */}
                  <button
                    onClick={() => toggleHabit(habit.id)}
                    aria-label={`Toggle habit ${habit.name}`}
                    className={`shrink-0 w-6 h-6 rounded-md border flex items-center justify-center transition-all cursor-pointer ${
                      habit.completedToday
                        ? 'bg-amber-600 border-amber-600 text-white shadow-xs'
                        : 'border-stone-300 dark:border-stone-600 hover:border-amber-600 dark:hover:border-amber-400 bg-white dark:bg-stone-800'
                    }`}
                  >
                    {habit.completedToday && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                  </button>

                  {/* Name or Edit Input */}
                  {isEditing ? (
                    <div className="flex items-center gap-1.5 flex-1">
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        autoFocus
                        className="w-full text-xs bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-600 rounded px-2 py-1 text-stone-900 dark:text-stone-100"
                      />
                      <button
                        onClick={() => handleSaveEdit(habit.id)}
                        className="p-1 text-emerald-600 hover:text-emerald-700"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 truncate">
                      <span
                        className={`text-xs sm:text-sm font-medium transition-colors truncate ${
                          habit.completedToday
                            ? 'text-stone-800 dark:text-stone-200'
                            : 'text-stone-700 dark:text-stone-300'
                        }`}
                      >
                        {habit.name}
                      </span>

                      {/* Streak count */}
                      <span className="flex items-center gap-0.5 text-[11px] text-amber-700 dark:text-amber-400/90 font-medium shrink-0">
                        <Flame className="w-3 h-3 text-amber-500 fill-amber-500/30" />
                        {habit.streak}d
                      </span>
                    </div>
                  )}
                </div>

                {/* Right: 7-Day History Mini Matrix & Actions */}
                <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-4 shrink-0 pl-9 sm:pl-0">
                  {/* 7-day visual dots */}
                  <div className="flex items-center gap-1.5">
                    {last7Days.map((dayKey) => {
                      const isToday = dayKey === todayKey;
                      const isDone = isToday ? habit.completedToday : !!habit.history[dayKey];
                      const dayLabel = getDayInitial(dayKey);

                      return (
                        <div key={dayKey} className="flex flex-col items-center gap-1">
                          <span
                            className={`text-[9px] font-mono ${
                              isToday
                                ? 'text-amber-700 dark:text-amber-400 font-semibold'
                                : 'text-stone-400 dark:text-stone-600'
                            }`}
                          >
                            {dayLabel}
                          </span>
                          <span
                            title={`${dayKey}: ${isDone ? 'Completed' : 'Missed'}`}
                            className={`w-2.5 h-2.5 rounded-full transition-all ${
                              isDone
                                ? 'bg-amber-600 dark:bg-amber-500 scale-100'
                                : 'bg-stone-200 dark:bg-stone-800 scale-90'
                            } ${isToday ? 'ring-1 ring-amber-400/50' : ''}`}
                          />
                        </div>
                      );
                    })}
                  </div>

                  {/* Actions on hover */}
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity no-print">
                    <button
                      onClick={() => {
                        setEditingId(habit.id);
                        setEditName(habit.name);
                      }}
                      title="Edit habit name"
                      className="p-1 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 rounded"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => deleteHabit(habit.id)}
                      title="Delete habit"
                      className="p-1 text-stone-400 hover:text-red-600 rounded"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </section>
  );
};
