import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PriorityItem } from '../types';
import { Check, Edit3, Eye, Tag, ChevronDown, CheckCircle2 } from 'lucide-react';

const TAG_OPTIONS = ['Deep Work', 'Client', 'Admin', 'Health', 'Creative', 'Personal', 'Urgent'];

export const ThreePriorities: React.FC = () => {
  const { state, togglePriority, updatePriority } = useApp();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editTag, setEditTag] = useState('');
  const [focusSlot, setFocusSlot] = useState<number | null>(null);

  const startEditing = (p: PriorityItem) => {
    setEditingId(p.id);
    setEditTitle(p.title);
    setEditNotes(p.notes || '');
    setEditTag(p.tag || 'Deep Work');
  };

  const saveEditing = (id: string) => {
    updatePriority(id, {
      title: editTitle.trim(),
      notes: editNotes.trim(),
      tag: editTag,
    });
    setEditingId(null);
  };

  const cancelEditing = () => {
    setEditingId(null);
  };

  const slotLabels = [
    { num: '01', rank: 'Primary Must-Do', desc: 'Non-negotiable single highest-leverage outcome' },
    { num: '02', rank: 'High Leverage', desc: 'Important project or milestone advancement' },
    { num: '03', rank: 'Key Progress', desc: 'Meaningful task that closes out the day strong' },
  ];

  return (
    <section className="bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold tracking-wide uppercase text-stone-900 dark:text-stone-100">
              Today's 3 Priorities
            </h2>
            <span className="text-[11px] font-serif italic text-amber-700 dark:text-amber-400">
              The Essential Rule
            </span>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            When everything is a priority, nothing is. Finish these before anything else.
          </p>
        </div>

        {/* Focus Mode button */}
        <div className="no-print">
          {focusSlot !== null ? (
            <button
              onClick={() => setFocusSlot(null)}
              className="text-xs text-amber-700 dark:text-amber-400 hover:text-amber-800 font-medium px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 transition-colors"
            >
              Exit Focus View
            </button>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400">
              <Eye className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Click number to isolate focus</span>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {state.priorities.map((item, index) => {
          const slot = slotLabels[index] || {
            num: `0${index + 1}`,
            rank: `Priority #${index + 1}`,
            desc: '',
          };

          const isDimmed = focusSlot !== null && focusSlot !== index;
          const isFocused = focusSlot === index;
          const isEditing = editingId === item.id;

          return (
            <div
              key={item.id}
              className={`group relative rounded-xl border transition-all duration-200 p-4 ${
                item.completed
                  ? 'bg-stone-50/60 dark:bg-stone-900/30 border-stone-200/50 dark:border-stone-800/50'
                  : isFocused
                  ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800 ring-2 ring-amber-500/10'
                  : 'bg-white dark:bg-stone-900/40 border-stone-200/80 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700'
              } ${isDimmed ? 'opacity-30' : 'opacity-100'}`}
            >
              {isEditing ? (
                /* Inline Editor Form */
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    saveEditing(item.id);
                  }}
                  className="space-y-3"
                >
                  <div className="flex items-center justify-between text-xs text-stone-500">
                    <span className="font-semibold text-amber-700 dark:text-amber-400">
                      Editing Priority {slot.num} ({slot.rank})
                    </span>
                    <div className="flex items-center gap-1.5">
                      <label className="flex items-center gap-1 text-[11px] text-stone-600 dark:text-stone-400">
                        <Tag className="w-3 h-3 text-stone-400" />
                        Tag:
                      </label>
                      <select
                        value={editTag}
                        onChange={(e) => setEditTag(e.target.value)}
                        className="bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 text-xs px-2 py-0.5 rounded border border-stone-300 dark:border-stone-700 focus:outline-none"
                      >
                        {TAG_OPTIONS.map((t) => (
                          <option key={t} value={t}>
                            {t}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    placeholder={`What is your ${slot.rank.toLowerCase()}?`}
                    autoFocus
                    className="w-full text-sm font-medium bg-stone-50 dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-lg px-3 py-2 text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />

                  <input
                    type="text"
                    value={editNotes}
                    onChange={(e) => setEditNotes(e.target.value)}
                    placeholder="Optional details, context, or deadline..."
                    className="w-full text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700/80 rounded-lg px-3 py-1.5 text-stone-700 dark:text-stone-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={cancelEditing}
                      className="px-3 py-1 text-xs text-stone-600 dark:text-stone-400 hover:text-stone-900 rounded-md"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1 text-xs font-medium text-white bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 rounded-md shadow-xs transition-colors"
                    >
                      Save Priority
                    </button>
                  </div>
                </form>
              ) : (
                /* Normal View */
                <div className="flex items-start gap-3.5">
                  {/* Left: Number Slot (clickable for focus mode) */}
                  <button
                    onClick={() => setFocusSlot(focusSlot === index ? null : index)}
                    title={`Isolate focus on Priority #${index + 1}`}
                    className={`shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-serif text-xs font-semibold tracking-wider transition-colors cursor-pointer ${
                      item.completed
                        ? 'bg-stone-100 dark:bg-stone-800 text-stone-400 dark:text-stone-600'
                        : isFocused
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-amber-100 dark:hover:bg-amber-950/60 hover:text-amber-800 dark:hover:text-amber-300'
                    }`}
                  >
                    {slot.num}
                  </button>

                  {/* Checkbox */}
                  <button
                    onClick={() => togglePriority(item.id)}
                    aria-label={`Mark priority ${slot.num} as ${item.completed ? 'incomplete' : 'complete'}`}
                    className={`shrink-0 mt-1 w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                      item.completed
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-stone-300 dark:border-stone-600 hover:border-amber-600 dark:hover:border-amber-400 bg-white dark:bg-stone-900'
                    }`}
                  >
                    {item.completed && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                  </button>

                  {/* Title & Notes */}
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[11px] font-medium tracking-wider uppercase text-stone-400 dark:text-stone-500">
                        {slot.rank}
                      </span>
                      {item.tag && (
                        <>
                          <span className="text-stone-300 dark:text-stone-700">·</span>
                          <span className="text-[11px] text-amber-700 dark:text-amber-400 font-medium">
                            {item.tag}
                          </span>
                        </>
                      )}
                    </div>

                    <p
                      onClick={() => !item.completed && startEditing(item)}
                      className={`text-sm sm:text-base font-medium mt-0.5 cursor-pointer transition-colors ${
                        item.completed
                          ? 'line-through text-stone-400 dark:text-stone-500'
                          : 'text-stone-900 dark:text-stone-100 hover:text-amber-800 dark:hover:text-amber-300'
                      }`}
                    >
                      {item.title || (
                        <span className="text-stone-400 italic">
                          Click to define Priority {slot.num}...
                        </span>
                      )}
                    </p>

                    {item.notes && (
                      <p
                        className={`text-xs mt-1 leading-relaxed ${
                          item.completed
                            ? 'text-stone-400/80 dark:text-stone-600'
                            : 'text-stone-500 dark:text-stone-400'
                        }`}
                      >
                        {item.notes}
                      </p>
                    )}
                  </div>

                  {/* Actions on hover */}
                  <div className="shrink-0 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity no-print">
                    <button
                      onClick={() => startEditing(item)}
                      title="Edit priority"
                      className="p-1.5 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 rounded-md hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
