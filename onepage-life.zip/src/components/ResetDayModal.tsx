import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RotateCcw, AlertCircle, CheckCircle2, X } from 'lucide-react';

interface ResetDayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResetDayModal: React.FC<ResetDayModalProps> = ({ isOpen, onClose }) => {
  const { resetDay, completionScore } = useApp();
  const [clearPriorities, setClearPriorities] = useState(false);
  const [clearCompletedTasks, setClearCompletedTasks] = useState(true);

  if (!isOpen) return null;

  const handleConfirm = () => {
    resetDay({
      clearPriorities,
      clearCompletedTasks,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs">
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl max-w-md w-full p-6 shadow-xl transition-all">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center border border-amber-500/20">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-stone-900 dark:text-stone-100">
                Reset for a New Day
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Current day completion: {completionScore}%
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* What happens explanation */}
        <div className="mt-4 p-3.5 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-100 dark:border-stone-800 text-xs space-y-2">
          <div className="flex items-start gap-2 text-stone-700 dark:text-stone-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>
              <strong>Safe Reset:</strong> Your Quick Notes, Scratchpad, and Expense History are <em>never</em> deleted.
            </span>
          </div>
          <div className="flex items-start gap-2 text-stone-700 dark:text-stone-300">
            <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <span>
              Today's habit checkmarks reset to false for tomorrow, while maintaining your streaks.
            </span>
          </div>
        </div>

        {/* Preferences */}
        <div className="mt-4 space-y-3">
          <label className="flex items-center justify-between text-xs text-stone-700 dark:text-stone-300 cursor-pointer p-2 rounded-lg hover:bg-stone-50 dark:hover:bg-stone-800/40">
            <span>Clear finished quick tasks (remove completed items)</span>
            <input
              type="checkbox"
              checked={clearCompletedTasks}
              onChange={(e) => setClearCompletedTasks(e.target.checked)}
              className="rounded border-stone-300 text-amber-600 focus:ring-amber-500"
            />
          </label>

          <label className="flex items-center justify-between text-xs text-stone-700 dark:text-stone-300 cursor-pointer p-2 rounded-lg hover:bg-stone-50 dark:hover:bg-stone-800/40">
            <span>Clear 3 Priority text boxes (start completely blank)</span>
            <input
              type="checkbox"
              checked={clearPriorities}
              onChange={(e) => setClearPriorities(e.target.checked)}
              className="rounded border-stone-300 text-amber-600 focus:ring-amber-500"
            />
          </label>
        </div>

        {/* Actions */}
        <div className="mt-6 flex items-center justify-end gap-2.5 pt-3 border-t border-stone-100 dark:border-stone-800">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            className="px-4 py-2 text-xs font-semibold text-white bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 rounded-xl shadow-xs transition-colors"
          >
            Confirm Day Reset
          </button>
        </div>
      </div>
    </div>
  );
};
