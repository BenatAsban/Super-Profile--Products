import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatFriendlyDate } from '../utils/date';
import {
  Sun,
  Moon,
  RotateCcw,
  Download,
  Sparkles,
  LayoutDashboard,
  ShoppingBag,
  BookOpen,
  DollarSign,
  Printer,
  Check,
  Edit2
} from 'lucide-react';

interface HeaderProps {
  onOpenReset: () => void;
  onOpenData: () => void;
  onOpenSellerGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenReset,
  onOpenData,
  onOpenSellerGuide,
}) => {
  const {
    state,
    viewMode,
    setViewMode,
    toggleTheme,
    setFocusIntention,
    setCurrency,
  } = useApp();

  const [isEditingIntention, setIsEditingIntention] = useState(false);
  const [intentionInput, setIntentionInput] = useState(state.focusIntention);

  const handleSaveIntention = () => {
    setFocusIntention(intentionInput.trim() || 'Focus on what truly matters today.');
    setIsEditingIntention(false);
  };

  const currencies = ['$', '€', '£', '¥', 'A$', 'CA$', 'CHF'];

  return (
    <header className="border-b border-stone-200/80 dark:border-stone-800/80 bg-[#FBF9F5]/90 dark:bg-[#121211]/90 backdrop-blur-md sticky top-0 z-30 transition-colors">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3.5">
        {/* Top bar with branding, mode switch, and quick actions */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          {/* Brand & Date */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-600/10 dark:bg-amber-400/10 border border-amber-600/20 dark:border-amber-400/20 flex items-center justify-center text-amber-800 dark:text-amber-300 font-serif font-semibold text-lg shadow-xs">
              1
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-stone-900 dark:text-stone-100 tracking-tight text-base sm:text-lg">
                  OnePage Life
                </span>
                <span className="text-[11px] font-medium tracking-wide uppercase text-amber-700 dark:text-amber-400/90 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                  Daily Rhythm
                </span>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {formatFriendlyDate()}
              </p>
            </div>
          </div>

          {/* Center Navigation Switcher */}
          <nav className="flex items-center gap-1 bg-stone-100 dark:bg-stone-900/90 p-1 rounded-xl border border-stone-200/60 dark:border-stone-800 self-start sm:self-auto no-print">
            <button
              onClick={() => setViewMode('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                viewMode === 'dashboard'
                  ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs font-semibold'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Dashboard</span>
            </button>
            <button
              onClick={() => setViewMode('landing')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                viewMode === 'landing'
                  ? 'bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 shadow-xs font-semibold'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Payhip Storefront</span>
            </button>
            <button
              onClick={onOpenSellerGuide}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 transition-colors"
              title="Payhip Seller Setup & Packaging Guide"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Seller Guide</span>
            </button>
          </nav>

          {/* Quick Utility Actions */}
          <div className="flex items-center gap-1.5 self-end sm:self-auto no-print">
            {/* Currency selector */}
            <div className="relative group">
              <select
                value={state.currency}
                onChange={(e) => setCurrency(e.target.value)}
                aria-label="Select currency"
                className="appearance-none bg-stone-100 dark:bg-stone-900 text-stone-700 dark:text-stone-300 text-xs font-medium pl-2 pr-4 py-1.5 rounded-lg border border-stone-200 dark:border-stone-800 cursor-pointer hover:bg-stone-200/60 dark:hover:bg-stone-800 transition-colors"
              >
                {currencies.map((curr) => (
                  <option key={curr} value={curr}>
                    {curr}
                  </option>
                ))}
              </select>
            </div>

            {/* Export & Data */}
            <button
              onClick={onOpenData}
              title="Export, Backup & Print"
              className="p-1.5 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
              aria-label="Export and Backup data"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Reset Day */}
            <button
              onClick={onOpenReset}
              title="Reset day routine (preserves notes & expense history)"
              className="p-1.5 text-stone-600 dark:text-stone-400 hover:text-amber-600 dark:hover:text-amber-400 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
              aria-label="Reset Day"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Dark / Light toggle */}
            <button
              onClick={toggleTheme}
              title={`Switch to ${state.theme === 'light' ? 'dark' : 'light'} mode`}
              className="p-1.5 text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
              aria-label="Toggle theme"
            >
              {state.theme === 'light' ? (
                <Moon className="w-4 h-4 text-stone-600" />
              ) : (
                <Sun className="w-4 h-4 text-amber-300" />
              )}
            </button>
          </div>
        </div>

        {/* Calm Daily Focus Intention Prompt */}
        <div className="mt-2.5 pt-2 border-t border-stone-200/40 dark:border-stone-800/40 flex items-center justify-between text-xs text-stone-600 dark:text-stone-400">
          <div className="flex items-center gap-2 w-full">
            <span className="text-amber-700/80 dark:text-amber-400/80 font-serif italic flex items-center gap-1 shrink-0">
              <Sparkles className="w-3.5 h-3.5" />
              Today's Intention:
            </span>
            {isEditingIntention ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSaveIntention();
                }}
                className="flex items-center gap-1.5 w-full"
              >
                <input
                  type="text"
                  value={intentionInput}
                  onChange={(e) => setIntentionInput(e.target.value)}
                  placeholder="What is your calm guiding rule for today?"
                  autoFocus
                  onBlur={handleSaveIntention}
                  className="w-full bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded-md px-2 py-0.5 text-xs text-stone-800 dark:text-stone-200 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
                <button
                  type="submit"
                  className="p-1 text-emerald-600 hover:text-emerald-700"
                  aria-label="Save intention"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
              </form>
            ) : (
              <button
                onClick={() => {
                  setIntentionInput(state.focusIntention);
                  setIsEditingIntention(true);
                }}
                className="text-left font-serif text-stone-700 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-100 truncate flex items-center gap-1.5 group cursor-pointer transition-colors"
              >
                <span className="italic">"{state.focusIntention}"</span>
                <Edit2 className="w-3 h-3 text-stone-400 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
