import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Zap,
  Target,
  Flame,
  Wallet,
  FileText,
  Lock,
  Download,
  LayoutDashboard,
  HelpCircle,
  ChevronDown,
  Sparkles,
  ArrowRight,
  Settings
} from 'lucide-react';

interface LandingPageProps {
  onOpenSellerGuide: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onOpenSellerGuide }) => {
  const { state, setViewMode } = useApp();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Is there a recurring monthly subscription?',
      a: 'No. OnePage Life is sold as a one-time digital purchase. Once you download it, you own it forever with no monthly fees, API costs, or hidden recurring charges.',
    },
    {
      q: 'Where is my personal data stored?',
      a: '100% on your own device. The application stores all tasks, priorities, habits, expenses, and notes in your browser’s local storage. None of your private data is ever transmitted to external servers or third-party databases.',
    },
    {
      q: 'Does it work offline?',
      a: 'Yes. Once loaded, OnePage Life runs fully offline in your browser. You can save it as an offline bookmark or run the standalone file anywhere without an internet connection.',
    },
    {
      q: 'Can I embed it directly inside Notion?',
      a: 'Yes! If you host it on a free platform like Vercel or Cloudflare Pages, simply copy your link, paste it into any Notion page, and select "Create Embed". It functions seamlessly as an embedded daily widget.',
    },
    {
      q: 'How do I backup or transfer my data to another computer?',
      a: 'Use the built-in "Export JSON" button at any time to download your complete data file. On your other computer or browser, click "Import Backup" to restore everything in seconds.',
    },
    {
      q: 'What is included in the Payhip download package?',
      a: 'You receive a complete digital ZIP file containing the full clean source code (React + TypeScript + Tailwind), a pre-built static distribution ready to open directly in any browser, and a comprehensive README setup guide.',
    },
  ];

  const features = [
    {
      icon: Target,
      title: "Today's 3 Priorities",
      desc: "Inspired by Warren Buffett's 5/25 rule. Forces you to isolate your three highest-leverage outcomes before touching secondary busywork.",
    },
    {
      icon: Flame,
      title: "5-Habit Ritual Tracker",
      desc: "Intentionally limited to 5 habits to prevent overload. Includes consecutive streaks and a tactile 7-day mini dot history matrix.",
    },
    {
      icon: Wallet,
      title: "Daily Expense Log",
      desc: "Quickly record daily purchases and track against a daily budget limit. Mindful financial tracking without complex accounting menus.",
    },
    {
      icon: CheckCircle2,
      title: "Quick Tasks with Filters",
      desc: "Frictionless capture for minor phone calls, errands, and quick emails, with All, Pending, and Completed filtering tabs.",
    },
    {
      icon: FileText,
      title: "Scratchpad & Notes",
      desc: "Auto-saving continuous scratchpad for free-flowing thoughts, plus timestamped micro-note cards you can pin or copy in one click.",
    },
    {
      icon: Lock,
      title: "Zero Sign-In & Total Privacy",
      desc: "No account creation, no password to remember, and no cloud data mining. Everything stays strictly inside your browser.",
    },
  ];

  return (
    <div className="min-h-screen text-stone-900 dark:text-stone-100 transition-colors">
      {/* Top Notice Bar for Seller Setup */}
      <div className="bg-amber-700/10 dark:bg-amber-400/10 border-b border-amber-600/20 py-2 px-4 text-center text-xs text-amber-900 dark:text-amber-300 flex items-center justify-center gap-2">
        <Sparkles className="w-3.5 h-3.5" />
        <span>Payhip Digital Product Package — Ready to Sell or Self-Host.</span>
        <button
          onClick={onOpenSellerGuide}
          className="underline font-semibold hover:text-amber-800 dark:hover:text-amber-200 ml-1 inline-flex items-center gap-1"
        >
          <span>Configure Store Link</span>
          <Settings className="w-3 h-3" />
        </button>
      </div>

      {/* Hero Section */}
      <section className="py-16 sm:py-24 px-4 sm:px-6 max-w-5xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-300 text-xs font-medium mb-6">
          <Sparkles className="w-3.5 h-3.5" />
          <span>The Anti-Complexity Daily Dashboard</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-serif font-medium tracking-tight text-stone-900 dark:text-stone-50 leading-[1.15] max-w-3xl mx-auto">
          One calm page for your entire daily rhythm.
        </h1>

        <p className="mt-6 text-base sm:text-lg text-stone-600 dark:text-stone-400 max-w-2xl mx-auto leading-relaxed">
          No nested subpages, no relational databases, and no subscription fatigue. 
          Focus on your 3 priorities, daily habits, quick tasks, expenses, and thoughts in one distraction-free view.
        </p>

        {/* CTA Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
          <a
            href={state.payhipCheckoutUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 text-white font-medium text-sm shadow-md transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>Get Instant Access — $19</span>
            <ExternalLink className="w-4 h-4" />
          </a>

          <button
            onClick={() => setViewMode('dashboard')}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white dark:bg-stone-800 hover:bg-stone-50 dark:hover:bg-stone-750 text-stone-900 dark:text-stone-100 border border-stone-200 dark:border-stone-700 font-medium text-sm transition-all shadow-xs"
          >
            <LayoutDashboard className="w-4 h-4 text-amber-600" />
            <span>Launch Live Interactive Demo</span>
          </button>
        </div>

        {/* Trust Badges */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-stone-500 dark:text-stone-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            100% Private (Stored Locally)
          </span>
          <span className="text-stone-300 dark:text-stone-700">·</span>
          <span className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-600" />
            No Monthly Fees
          </span>
          <span className="text-stone-300 dark:text-stone-700">·</span>
          <span className="flex items-center gap-1.5">
            <Download className="w-4 h-4 text-stone-600 dark:text-stone-400" />
            Instant Digital Download
          </span>
        </div>
      </section>

      {/* Interactive Live Preview Spotlight */}
      <section className="py-12 px-4 sm:px-6 max-w-5xl mx-auto">
        <div className="bg-stone-100/80 dark:bg-stone-900/80 rounded-3xl p-3 sm:p-6 border border-stone-200/80 dark:border-stone-800 shadow-xl">
          <div className="flex items-center justify-between mb-4 px-2">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-400/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-400/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-400/80 inline-block" />
              <span className="ml-2 text-xs font-mono text-stone-500">
                onepage-life.app/dashboard
              </span>
            </div>

            <button
              onClick={() => setViewMode('dashboard')}
              className="text-xs font-semibold text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1"
            >
              <span>Open Full App</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mini Interactive Preview Snapshot */}
          <div className="bg-[#FBF9F5] dark:bg-[#121211] rounded-2xl p-5 border border-stone-200 dark:border-stone-800 text-left space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-200/60 dark:border-stone-800 pb-3">
              <div>
                <h3 className="font-serif font-semibold text-stone-900 dark:text-stone-100 text-lg">
                  Today's Calm Rhythm
                </h3>
                <p className="text-xs text-stone-500">
                  {state.focusIntention}
                </p>
              </div>
              <div className="text-right">
                <span className="text-xl font-serif font-bold text-stone-900 dark:text-stone-100">
                  {state.priorities.filter((p) => p.completed).length} / 3 Priorities
                </span>
                <p className="text-[11px] text-stone-400">
                  {state.habits.filter((h) => h.completedToday).length} of {state.habits.length} habits done
                </p>
              </div>
            </div>

            {/* Visual 3 Priorities Mock Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {state.priorities.map((p, i) => (
                <div
                  key={p.id}
                  className={`p-3.5 rounded-xl border ${
                    p.completed
                      ? 'bg-stone-50 dark:bg-stone-900/50 border-stone-200/60 dark:border-stone-800 text-stone-400'
                      : 'bg-white dark:bg-stone-850 border-stone-200 dark:border-stone-700 text-stone-800 dark:text-stone-200'
                  }`}
                >
                  <span className="text-[10px] font-mono font-semibold text-amber-700 dark:text-amber-400">
                    PRIORITY #0{i + 1}
                  </span>
                  <p className="text-xs font-medium mt-1 line-clamp-2">
                    {p.title || `Priority ${i + 1}`}
                  </p>
                </div>
              ))}
            </div>

            <div className="text-center pt-2">
              <button
                onClick={() => setViewMode('dashboard')}
                className="text-xs font-medium text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 underline"
              >
                Click here to test and interact with the full dashboard
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-16 px-4 sm:px-6 max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 dark:text-stone-100">
            Engineered for clarity, not cognitive overload.
          </h2>
          <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-2 max-w-xl mx-auto">
            Everything you need for an intentional day, stripped of unnecessary complexity.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center mb-4">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                    {feat.title}
                  </h3>
                  <p className="text-xs text-stone-600 dark:text-stone-400 mt-2 leading-relaxed">
                    {feat.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Who Is It For Section */}
      <section className="py-16 px-4 sm:px-6 max-w-5xl mx-auto border-t border-stone-200/60 dark:border-stone-800">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 dark:text-stone-100">
            Built for people who want simpler days.
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800">
            <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              Students & Learners
            </span>
            <p className="text-xs text-stone-600 dark:text-stone-400 mt-2 leading-relaxed">
              Track lecture assignments, reading habits, daily coffee budgets, and quick exam study notes without getting lost in multiple apps.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800">
            <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              Freelancers & Creators
            </span>
            <p className="text-xs text-stone-600 dark:text-stone-400 mt-2 leading-relaxed">
              Pin your 3 client deliverables, log business expenses on the fly, and capture creative sparks immediately in your continuous scratchpad.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800">
            <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              Knowledge Workers
            </span>
            <p className="text-xs text-stone-600 dark:text-stone-400 mt-2 leading-relaxed">
              Avoid open-tab fatigue and 30-item to-do lists. Anchor yourself to three main victories each morning and clock out with mental peace.
            </p>
          </div>
        </div>
      </section>

      {/* What is Included in the Digital Download */}
      <section className="py-16 px-4 sm:px-6 max-w-4xl mx-auto">
        <div className="p-8 rounded-3xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40">
          <div className="text-center max-w-xl mx-auto mb-6">
            <h2 className="text-2xl font-serif font-medium text-stone-900 dark:text-stone-100">
              What is included in the digital package?
            </h2>
            <p className="text-xs text-stone-600 dark:text-stone-400 mt-1">
              Everything needed to run immediately on your machine or deploy online.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-stone-700 dark:text-stone-300">
            <div className="flex items-center gap-2.5 p-2 bg-white/80 dark:bg-stone-900/60 rounded-xl border border-stone-200/60 dark:border-stone-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Full clean source code (React, Vite, TypeScript, Tailwind)</span>
            </div>
            <div className="flex items-center gap-2.5 p-2 bg-white/80 dark:bg-stone-900/60 rounded-xl border border-stone-200/60 dark:border-stone-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Pre-built static HTML/JS files ready to open offline</span>
            </div>
            <div className="flex items-center gap-2.5 p-2 bg-white/80 dark:bg-stone-900/60 rounded-xl border border-stone-200/60 dark:border-stone-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Notion Embed Guide for seamless workspace integration</span>
            </div>
            <div className="flex items-center gap-2.5 p-2 bg-white/80 dark:bg-stone-900/60 rounded-xl border border-stone-200/60 dark:border-stone-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>1-Click Deploy Guide (Vercel, Netlify, Cloudflare Pages)</span>
            </div>
          </div>

          <div className="mt-8 text-center">
            <a
              href={state.payhipCheckoutUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 text-white font-medium text-sm shadow-md transition-all hover:scale-[1.02]"
            >
              <span>Download OnePage Life — $19 (One-Time)</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4 sm:px-6 max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 dark:text-stone-100">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            Honest answers about the product, data privacy, and usage.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="border border-stone-200/80 dark:border-stone-800 rounded-xl bg-white dark:bg-stone-900/60 overflow-hidden"
            >
              <button
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full p-4 text-left flex items-center justify-between text-xs sm:text-sm font-medium text-stone-900 dark:text-stone-100 hover:text-amber-800 dark:hover:text-amber-300 transition-colors"
              >
                <span>{faq.q}</span>
                <ChevronDown
                  className={`w-4 h-4 text-stone-400 transition-transform ${
                    openFaq === idx ? 'rotate-180 text-amber-700' : ''
                  }`}
                />
              </button>

              {openFaq === idx && (
                <div className="px-4 pb-4 pt-1 text-xs text-stone-600 dark:text-stone-400 leading-relaxed border-t border-stone-100 dark:border-stone-800">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-stone-200/80 dark:border-stone-800 py-8 px-4 text-center text-xs text-stone-500">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-serif font-semibold text-stone-900 dark:text-stone-100">
              OnePage Life
            </span>
            <span>·</span>
            <span>Minimal Personal Dashboard</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setViewMode('dashboard')}
              className="hover:text-stone-900 dark:hover:text-stone-200 underline"
            >
              Dashboard View
            </button>
            <button
              onClick={onOpenSellerGuide}
              className="hover:text-stone-900 dark:hover:text-stone-200 underline"
            >
              Seller Guide
            </button>
            <a
              href={state.payhipCheckoutUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1"
            >
              <span>Payhip Store</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};
