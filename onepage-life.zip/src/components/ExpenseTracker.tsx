import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ExpenseItem } from '../types';
import { Wallet, Plus, Trash2, ArrowUpRight, TrendingUp, Sliders } from 'lucide-react';

const CATEGORIES: ExpenseItem['category'][] = [
  'Food',
  'Work',
  'Transport',
  'Personal',
  'Bills',
  'Other',
];

export const ExpenseTracker: React.FC = () => {
  const {
    state,
    todayExpenses,
    todayExpenseTotal,
    addExpense,
    deleteExpense,
    setDailyBudgetLimit,
  } = useApp();

  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseItem['category']>('Food');
  const [showBudgetSetting, setShowBudgetSetting] = useState(false);
  const [budgetInput, setBudgetInput] = useState(state.dailyBudgetLimit.toString());

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!title.trim() || isNaN(parsedAmount) || parsedAmount <= 0) return;
    addExpense(title.trim(), parsedAmount, category);
    setTitle('');
    setAmount('');
  };

  const handleSaveBudget = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(budgetInput);
    if (!isNaN(val) && val >= 0) {
      setDailyBudgetLimit(val);
      setShowBudgetSetting(false);
    }
  };

  const budgetRemaining = Math.max(0, state.dailyBudgetLimit - todayExpenseTotal);
  const budgetPercent = state.dailyBudgetLimit > 0
    ? Math.min(100, Math.round((todayExpenseTotal / state.dailyBudgetLimit) * 100))
    : 0;

  return (
    <section className="bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold tracking-wide uppercase text-stone-900 dark:text-stone-100">
              Daily Expense Tracker
            </h2>
            <span className="text-xs text-stone-400 dark:text-stone-500">
              ({todayExpenses.length})
            </span>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            Record mindfully, eliminate unconscious spending.
          </p>
        </div>

        {/* Budget Setting Toggle */}
        <button
          onClick={() => setShowBudgetSetting(!showBudgetSetting)}
          title="Set daily budget target"
          className="p-1.5 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors no-print"
        >
          <Sliders className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Today Total Big Stat Card */}
      <div className="bg-stone-50/80 dark:bg-stone-800/40 rounded-xl p-4 border border-stone-100 dark:border-stone-800 mb-4">
        <div className="flex items-baseline justify-between">
          <span className="text-xs text-stone-500 dark:text-stone-400 font-medium">
            Today's Total
          </span>
          {state.dailyBudgetLimit > 0 && (
            <span className="text-[11px] text-stone-500 dark:text-stone-400">
              Budget: {state.currency}{state.dailyBudgetLimit.toFixed(2)}
            </span>
          )}
        </div>

        <div className="flex items-baseline gap-2 mt-1">
          <span className="text-2xl sm:text-3xl font-semibold tracking-tight text-stone-900 dark:text-stone-100 font-serif">
            {state.currency}{todayExpenseTotal.toFixed(2)}
          </span>
          {state.dailyBudgetLimit > 0 && (
            <span
              className={`text-xs font-medium ${
                todayExpenseTotal > state.dailyBudgetLimit
                  ? 'text-red-600 dark:text-red-400'
                  : 'text-stone-500 dark:text-stone-400'
              }`}
            >
              {todayExpenseTotal > state.dailyBudgetLimit
                ? `(${state.currency}${(todayExpenseTotal - state.dailyBudgetLimit).toFixed(2)} over budget)`
                : `(${state.currency}${budgetRemaining.toFixed(2)} left)`}
            </span>
          )}
        </div>

        {/* Budget bar if configured */}
        {state.dailyBudgetLimit > 0 && (
          <div className="mt-2.5 h-1.5 w-full bg-stone-200 dark:bg-stone-700 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                budgetPercent >= 100
                  ? 'bg-red-500'
                  : budgetPercent >= 80
                  ? 'bg-amber-500'
                  : 'bg-emerald-600'
              }`}
              style={{ width: `${budgetPercent}%` }}
            />
          </div>
        )}
      </div>

      {/* Inline Budget Setting Form */}
      {showBudgetSetting && (
        <form
          onSubmit={handleSaveBudget}
          className="mb-4 p-3 bg-stone-100/70 dark:bg-stone-800/60 rounded-xl border border-stone-200 dark:border-stone-700/80 flex items-center gap-2 no-print"
        >
          <label className="text-xs text-stone-600 dark:text-stone-400 shrink-0">
            Daily Budget Target:
          </label>
          <input
            type="number"
            step="0.01"
            value={budgetInput}
            onChange={(e) => setBudgetInput(e.target.value)}
            className="w-24 bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded-md px-2 py-1 text-xs text-stone-900 dark:text-stone-100"
          />
          <button
            type="submit"
            className="px-2.5 py-1 text-xs font-medium bg-amber-700 text-white rounded-md hover:bg-amber-800"
          >
            Save
          </button>
          <button
            type="button"
            onClick={() => setShowBudgetSetting(false)}
            className="text-xs text-stone-500 hover:text-stone-700 ml-auto"
          >
            Close
          </button>
        </form>
      )}

      {/* Add Expense Form */}
      <form onSubmit={handleAdd} className="space-y-2 mb-4 no-print">
        <div className="flex gap-2">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Item (e.g. Matcha latte, Books)..."
            className="flex-1 bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 rounded-xl px-3 py-1.5 text-xs text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
          <div className="relative w-24">
            <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-stone-400 font-mono">
              {state.currency}
            </span>
            <input
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 rounded-xl pl-6 pr-2 py-1.5 text-xs text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as ExpenseItem['category'])}
            className="flex-1 bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 rounded-xl px-2.5 py-1.5 text-xs text-stone-700 dark:text-stone-300 focus:outline-none"
          >
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <button
            type="submit"
            disabled={!title.trim() || !amount}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 rounded-xl disabled:opacity-40 transition-colors shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </div>
      </form>

      {/* Expense Items List */}
      <div className="flex-1 space-y-2 overflow-y-auto max-h-[260px] pr-1">
        {todayExpenses.length === 0 ? (
          <div className="text-center py-7 border border-dashed border-stone-200 dark:border-stone-800 rounded-xl">
            <p className="text-xs text-stone-400 dark:text-stone-500">
              Zero expenses logged today. A calm day for your wallet.
            </p>
          </div>
        ) : (
          todayExpenses.map((item) => (
            <div
              key={item.id}
              className="group flex items-center justify-between p-2.5 rounded-xl border border-stone-100 dark:border-stone-800 bg-white dark:bg-stone-900/40 hover:bg-stone-50 dark:hover:bg-stone-900/70 transition-all"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs sm:text-sm font-medium text-stone-900 dark:text-stone-100 truncate">
                    {item.title}
                  </span>
                  <span className="text-[10px] text-stone-400 dark:text-stone-500">
                    · {item.category}
                  </span>
                </div>
                <span className="text-[10px] text-stone-400 font-mono">
                  {item.time}
                </span>
              </div>

              <div className="flex items-center gap-2.5 shrink-0 ml-2">
                <span className="text-xs sm:text-sm font-semibold font-mono text-stone-900 dark:text-stone-100">
                  {state.currency}{item.amount.toFixed(2)}
                </span>
                <button
                  onClick={() => deleteExpense(item.id)}
                  title="Delete expense entry"
                  className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-red-600 transition-opacity no-print"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
};
