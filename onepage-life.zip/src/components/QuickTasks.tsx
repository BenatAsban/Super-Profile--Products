import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Check, Trash2, Plus, ListFilter, CheckCheck } from 'lucide-react';

export const QuickTasks: React.FC = () => {
  const { state, addTask, toggleTask, deleteTask, clearCompletedTasks } = useApp();
  const [taskInput, setTaskInput] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskInput.trim()) return;
    addTask(taskInput.trim());
    setTaskInput('');
  };

  const filteredTasks = state.tasks.filter((task) => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  const completedCount = state.tasks.filter((t) => t.completed).length;

  return (
    <section className="bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors flex flex-col h-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold tracking-wide uppercase text-stone-900 dark:text-stone-100">
              Quick Tasks
            </h2>
            <span className="text-xs text-stone-400 dark:text-stone-500">
              ({state.tasks.length})
            </span>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            Secondary errands, calls, and follow-ups.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800/80 p-0.5 rounded-lg border border-stone-200/50 dark:border-stone-700/60 self-start sm:self-auto no-print">
          {(['all', 'active', 'completed'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-2.5 py-1 text-[11px] font-medium rounded-md capitalize transition-all ${
                filter === tab
                  ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 shadow-xs'
                  : 'text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Task Input Form */}
      <form onSubmit={handleAddTask} className="mb-3 relative no-print">
        <input
          type="text"
          value={taskInput}
          onChange={(e) => setTaskInput(e.target.value)}
          placeholder="Add a quick task (press Enter)..."
          className="w-full bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 rounded-xl pl-3.5 pr-10 py-2 text-xs sm:text-sm text-stone-900 dark:text-stone-100 placeholder-stone-400 dark:placeholder-stone-500 focus:outline-none focus:ring-1 focus:ring-amber-500 transition-colors"
        />
        <button
          type="submit"
          disabled={!taskInput.trim()}
          className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-amber-700 dark:hover:text-amber-400 disabled:opacity-30 transition-colors"
          aria-label="Add task"
        >
          <Plus className="w-4 h-4" />
        </button>
      </form>

      {/* Task List */}
      <div className="flex-1 space-y-2 overflow-y-auto max-h-[300px] pr-1">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-8 border border-dashed border-stone-200 dark:border-stone-800 rounded-xl">
            <p className="text-xs text-stone-400 dark:text-stone-500">
              {filter === 'completed'
                ? 'No completed tasks yet.'
                : filter === 'active'
                ? 'All clear! No pending tasks.'
                : 'No tasks added. Capture any small errands here.'}
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`group flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                task.completed
                  ? 'bg-stone-50/50 dark:bg-stone-900/30 border-stone-100 dark:border-stone-800/50'
                  : 'bg-white dark:bg-stone-900/50 border-stone-100 dark:border-stone-800 hover:border-stone-200 dark:hover:border-stone-700'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                {/* Checkbox */}
                <button
                  onClick={() => toggleTask(task.id)}
                  aria-label={`Mark task ${task.title} as ${task.completed ? 'incomplete' : 'complete'}`}
                  className={`shrink-0 w-4.5 h-4.5 rounded-md border flex items-center justify-center transition-all ${
                    task.completed
                      ? 'bg-stone-700 dark:bg-stone-600 border-stone-700 dark:border-stone-600 text-white'
                      : 'border-stone-300 dark:border-stone-600 hover:border-amber-600 bg-white dark:bg-stone-800'
                  }`}
                >
                  {task.completed && <Check className="w-3 h-3 stroke-[2.5]" />}
                </button>

                {/* Text */}
                <span
                  onClick={() => toggleTask(task.id)}
                  className={`text-xs sm:text-sm cursor-pointer truncate transition-colors ${
                    task.completed
                      ? 'line-through text-stone-400 dark:text-stone-500'
                      : 'text-stone-800 dark:text-stone-200 hover:text-amber-800 dark:hover:text-amber-300'
                  }`}
                >
                  {task.title}
                </span>
              </div>

              {/* Time & Delete */}
              <div className="flex items-center gap-2 shrink-0 ml-2">
                <span className="text-[10px] text-stone-400 dark:text-stone-500 font-mono">
                  {task.createdAt}
                </span>
                <button
                  onClick={() => deleteTask(task.id)}
                  title="Delete task"
                  className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-red-600 transition-opacity no-print"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer with Clear Completed */}
      {completedCount > 0 && (
        <div className="mt-3 pt-2.5 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-xs text-stone-500 no-print">
          <span className="text-[11px] text-stone-400">
            {completedCount} completed
          </span>
          <button
            onClick={clearCompletedTasks}
            className="flex items-center gap-1 text-[11px] text-stone-500 hover:text-stone-800 dark:hover:text-stone-300 transition-colors"
          >
            <CheckCheck className="w-3 h-3" />
            <span>Clear Completed</span>
          </button>
        </div>
      )}
    </section>
  );
};
