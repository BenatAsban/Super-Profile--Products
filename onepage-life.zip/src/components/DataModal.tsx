import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Download,
  Upload,
  FileText,
  Printer,
  RefreshCw,
  Check,
  Copy,
  AlertCircle,
  X,
  Database
} from 'lucide-react';

interface DataModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataModal: React.FC<DataModalProps> = ({ isOpen, onClose }) => {
  const {
    exportJSON,
    importJSON,
    exportMarkdown,
    resetToDefaults,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'export' | 'import' | 'markdown'>('export');
  const [importStatus, setImportStatus] = useState<{ success?: boolean; message?: string } | null>(null);
  const [markdownCopied, setMarkdownCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = importJSON(content);
      if (res.success) {
        setImportStatus({ success: true, message: 'Data imported successfully!' });
        setTimeout(() => {
          onClose();
        }, 1200);
      } else {
        setImportStatus({ success: false, message: res.error || 'Failed to import JSON' });
      }
    };
    reader.readAsText(file);
  };

  const handleCopyMarkdown = () => {
    const md = exportMarkdown();
    navigator.clipboard.writeText(md);
    setMarkdownCopied(true);
    setTimeout(() => setMarkdownCopied(false), 2000);
  };

  const handlePrint = () => {
    onClose();
    setTimeout(() => {
      window.print();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs">
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl max-w-lg w-full p-6 shadow-xl transition-all">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center border border-amber-500/20">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-stone-900 dark:text-stone-100">
                Data, Export & Backup
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Your data is stored 100% privately in your browser's local storage.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800/80 p-1 rounded-xl mt-4 border border-stone-200/50 dark:border-stone-700/60">
          <button
            onClick={() => setActiveTab('export')}
            className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-all ${
              activeTab === 'export'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            Export & Print
          </button>
          <button
            onClick={() => setActiveTab('import')}
            className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-all ${
              activeTab === 'import'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            Import Backup
          </button>
          <button
            onClick={() => setActiveTab('markdown')}
            className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-all ${
              activeTab === 'markdown'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
            }`}
          >
            Markdown Summary
          </button>
        </div>

        {/* Tab 1: Export */}
        {activeTab === 'export' && (
          <div className="mt-4 space-y-3">
            <div className="p-3.5 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-stone-900 dark:text-stone-100">
                  Full JSON Backup
                </p>
                <p className="text-[11px] text-stone-500">
                  Download all priorities, tasks, habits, expenses, and notes in standard JSON format.
                </p>
              </div>
              <button
                onClick={exportJSON}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-amber-700 hover:bg-amber-800 rounded-lg shrink-0 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>
            </div>

            <div className="p-3.5 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-stone-900 dark:text-stone-100">
                  Print or Save as PDF
                </p>
                <p className="text-[11px] text-stone-500">
                  Format for a clean physical paper printout or desk planner sheet.
                </p>
              </div>
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-700 dark:text-stone-200 bg-white dark:bg-stone-700 border border-stone-200 dark:border-stone-600 hover:bg-stone-100 rounded-lg shrink-0 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Sheet</span>
              </button>
            </div>

            <div className="p-3.5 bg-amber-50/50 dark:bg-amber-950/20 rounded-xl border border-amber-200/50 dark:border-amber-900/30 flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-stone-900 dark:text-stone-100">
                  Reset to Sample Demo Data
                </p>
                <p className="text-[11px] text-stone-500">
                  Restore default sample priorities, habits, and tasks for showcase.
                </p>
              </div>
              <button
                onClick={() => {
                  resetToDefaults();
                  onClose();
                }}
                className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-stone-600 dark:text-stone-400 hover:text-amber-700 shrink-0"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Restore</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Import */}
        {activeTab === 'import' && (
          <div className="mt-4 space-y-4">
            <p className="text-xs text-stone-600 dark:text-stone-400">
              Select a previously exported OnePage Life JSON backup file to restore your settings, habits, and records.
            </p>

            <input
              type="file"
              ref={fileInputRef}
              accept=".json,application/json"
              onChange={handleFileChange}
              className="hidden"
            />

            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-stone-300 dark:border-stone-700 hover:border-amber-500 dark:hover:border-amber-400 rounded-xl p-8 text-center cursor-pointer transition-colors bg-stone-50/50 dark:bg-stone-800/30"
            >
              <Upload className="w-8 h-8 text-stone-400 mx-auto mb-2" />
              <p className="text-xs font-medium text-stone-800 dark:text-stone-200">
                Click to browse backup file (.json)
              </p>
              <p className="text-[11px] text-stone-400 mt-1">
                Supports all OnePage Life exported data
              </p>
            </div>

            {importStatus && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                  importStatus.success
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200'
                    : 'bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-300 border border-red-200'
                }`}
              >
                {importStatus.success ? (
                  <Check className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{importStatus.message}</span>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Markdown */}
        {activeTab === 'markdown' && (
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>Ready for Obsidian, Apple Notes, or Notion</span>
              <button
                onClick={handleCopyMarkdown}
                className="flex items-center gap-1 text-xs font-medium text-amber-700 dark:text-amber-400 hover:text-amber-800"
              >
                {markdownCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600">Copied to Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Markdown</span>
                  </>
                )}
              </button>
            </div>

            <textarea
              readOnly
              value={exportMarkdown()}
              className="w-full h-44 p-3 bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 rounded-xl text-xs font-mono text-stone-800 dark:text-stone-200 focus:outline-none resize-none"
            />
          </div>
        )}

        {/* Close Button */}
        <div className="mt-6 flex justify-end pt-3 border-t border-stone-100 dark:border-stone-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-stone-700 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-100"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
