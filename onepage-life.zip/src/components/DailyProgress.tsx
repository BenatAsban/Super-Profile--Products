import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2, Target, Flame, ListChecks, Wallet } from 'lucide-react';

export const DailyProgress: React.FC = () => {
  const { completionScore, stats, todayExpenseTotal, state } = useApp();

  const getStatusMessage = (score: number) => {
    if (score === 100) return 'All essential intentions fulfilled. Rest and recharge.';
    if (score >= 75) return 'Nearly complete. Protect your remaining evening focus.';
    if (score >= 50) return 'Halfway through the day. Strong, grounded momentum.';
    if (score >= 25) return 'Good start. One deliberate priority at a time.';
    return 'A blank canvas. Begin with Priority #1.';
  };

  return (
    <section className="bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left: Score & Affirmation */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold tracking-wide uppercase text-stone-500 dark:text-stone-400">
              Daily Progress
            </h2>
            <span className="text-xs text-stone-400 dark:text-stone-600">·</span>
            <span className="text-xs font-serif italic text-amber-700 dark:text-amber-400">
              {getStatusMessage(completionScore)}
            </span>
          </div>

          <div className="flex items-baseline gap-3">
            <span className="text-3xl sm:text-4xl font-semibold tracking-tight text-stone-900 dark:text-stone-100 font-serif">
              {completionScore}%
            </span>
            <span className="text-xs text-stone-500 dark:text-stone-400">
              completed across your daily intentions
            </span>
          </div>
        </div>

        {/* Right: Clean Metric Breakdowns (No noisy capsules) */}
        <div className="flex flex-wrap items-center gap-4 sm:gap-6 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100 dark:border-stone-800/80">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0" />
            <div>
              <p className="text-[11px] text-stone-500 dark:text-stone-400 uppercase tracking-wider font-medium">
                Priorities
              </p>
              <p className="text-xs font-semibold text-stone-800 dark:text-stone-200">
                {stats.prioritiesDone} / {stats.prioritiesTotal}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-600 dark:text-amber-500 shrink-0" />
            <div>
              <p className="text-[11px] text-stone-500 dark:text-stone-400 uppercase tracking-wider font-medium">
                Habits
              </p>
              <p className="text-xs font-semibold text-stone-800 dark:text-stone-200">
                {stats.habitsDone} / {stats.habitsTotal}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <ListChecks className="w-4 h-4 text-stone-600 dark:text-stone-400 shrink-0" />
            <div>
              <p className="text-[11px] text-stone-500 dark:text-stone-400 uppercase tracking-wider font-medium">
                Tasks
              </p>
              <p className="text-xs font-semibold text-stone-800 dark:text-stone-200">
                {stats.tasksDone} / {stats.tasksTotal}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-stone-600 dark:text-stone-400 shrink-0" />
            <div>
              <p className="text-[11px] text-stone-500 dark:text-stone-400 uppercase tracking-wider font-medium">
                Today Spent
              </p>
              <p className="text-xs font-semibold text-stone-800 dark:text-stone-200">
                {state.currency}{todayExpenseTotal.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Sleek Minimalist Progress Bar */}
      <div className="mt-4 pt-4 border-t border-stone-100 dark:border-stone-800/80">
        <div className="h-2 w-full bg-stone-100 dark:bg-stone-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-amber-600 to-amber-700 dark:from-amber-500 dark:to-amber-400 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${Math.max(completionScore, 3)}%` }}
          />
        </div>
      </div>
    </section>
  );
};
