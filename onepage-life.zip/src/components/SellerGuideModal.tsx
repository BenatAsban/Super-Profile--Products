import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BookOpen, ExternalLink, Check, Copy, Package, ShieldCheck, X, DollarSign } from 'lucide-react';

interface SellerGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SellerGuideModal: React.FC<SellerGuideModalProps> = ({ isOpen, onClose }) => {
  const { state, setPayhipCheckoutUrl } = useApp();
  const [urlInput, setUrlInput] = useState(state.payhipCheckoutUrl);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSaveUrl = (e: React.FormEvent) => {
    e.preventDefault();
    setPayhipCheckoutUrl(urlInput.trim() || 'https://payhip.com/b/YOUR_PRODUCT_CODE');
    onClose();
  };

  const copyNotionEmbedCode = () => {
    navigator.clipboard.writeText('https://your-domain.vercel.app');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-xs">
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 flex items-center justify-center border border-amber-500/20">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-stone-900 dark:text-stone-100">
                Payhip Seller & Deployment Guide
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                How to package, sell, and deploy OnePage Life as a digital product.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step-by-Step Guide */}
        <div className="mt-5 space-y-4 text-xs text-stone-700 dark:text-stone-300">
          {/* Step 1 */}
          <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200/60 dark:border-stone-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-stone-900 dark:text-stone-100">
                1. Set Your Payhip Checkout Link
              </span>
              <span className="text-[10px] text-amber-700 dark:text-amber-400 font-mono">
                Storefront Setup
              </span>
            </div>
            <p className="text-stone-500 dark:text-stone-400">
              When buyers click "Buy Now" on the landing page, it directs to this link:
            </p>
            <form onSubmit={handleSaveUrl} className="flex gap-2 pt-1">
              <input
                type="text"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://payhip.com/b/XXXXX"
                className="flex-1 bg-white dark:bg-stone-900 border border-stone-300 dark:border-stone-700 rounded-lg px-2.5 py-1.5 text-xs text-stone-900 dark:text-stone-100 font-mono"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-amber-700 text-white rounded-lg hover:bg-amber-800 font-medium"
              >
                Save Link
              </button>
            </form>
          </div>

          {/* Step 2 */}
          <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200/60 dark:border-stone-800 space-y-1.5">
            <span className="font-semibold text-stone-900 dark:text-stone-100 block">
              2. Recommended Payhip Product Listing Details
            </span>
            <ul className="space-y-1 text-stone-600 dark:text-stone-400 list-disc list-inside">
              <li><strong>Product Type:</strong> Digital Product (File Download).</li>
              <li><strong>Title:</strong> OnePage Life — Minimal Personal Dashboard.</li>
              <li><strong>Price Suggestion:</strong> $15 – $25 (one-time purchase).</li>
              <li><strong>USP:</strong> A single-page, privacy-first dashboard that avoids database bloat and subscription fatigue.</li>
            </ul>
          </div>

          {/* Step 3 */}
          <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200/60 dark:border-stone-800 space-y-1.5">
            <span className="font-semibold text-stone-900 dark:text-stone-100 block">
              3. What to Upload to Payhip
            </span>
            <p className="text-stone-600 dark:text-stone-400 leading-relaxed">
              Create a ZIP file named <code className="bg-stone-200 dark:bg-stone-700 px-1 py-0.5 rounded text-[11px]">OnePage-Life-Package.zip</code> containing:
            </p>
            <ol className="list-decimal list-inside space-y-1 text-stone-600 dark:text-stone-400">
              <li>The complete application source code.</li>
              <li>The production build folder (<code className="bg-stone-200 dark:bg-stone-700 px-1 py-0.5 rounded text-[11px]">dist/</code>) ready for static hosting.</li>
              <li>The included <code className="bg-stone-200 dark:bg-stone-700 px-1 py-0.5 rounded text-[11px]">README.md</code> with zero-code setup instructions.</li>
            </ol>
          </div>

          {/* Step 4 */}
          <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-xl border border-stone-200/60 dark:border-stone-800 space-y-1.5">
            <span className="font-semibold text-stone-900 dark:text-stone-100 block">
              4. How Buyers Use & Host It
            </span>
            <ul className="space-y-1 text-stone-600 dark:text-stone-400 list-disc list-inside">
              <li><strong>Local Offline:</strong> Simply open <code className="bg-stone-200 dark:bg-stone-700 px-1 py-0.5 rounded text-[11px]">index.html</code> in Chrome, Safari, or Firefox.</li>
              <li><strong>Free Hosting:</strong> 1-click deploy to Vercel, Netlify, or Cloudflare Pages.</li>
              <li><strong>Notion Embed:</strong> Paste their deployed URL into any Notion page and select <em>Create Embed</em>.</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 flex justify-end pt-3 border-t border-stone-100 dark:border-stone-800">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 rounded-xl shadow-xs transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
