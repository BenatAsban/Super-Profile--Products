import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { StickyNote, Plus, Trash2, Copy, Check, Pin, FileText } from 'lucide-react';

export const QuickNotes: React.FC = () => {
  const {
    state,
    updateScratchpad,
    addNote,
    deleteNote,
    togglePinNote,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'scratchpad' | 'notes'>('scratchpad');
  const [newNoteInput, setNewNoteInput] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteInput.trim()) return;
    addNote(newNoteInput);
    setNewNoteInput('');
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const sortedNotes = [...state.notes].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return 0;
  });

  const wordCount = state.scratchpad.trim()
    ? state.scratchpad.trim().split(/\s+/).length
    : 0;

  return (
    <section className="bg-white dark:bg-stone-900/70 border border-stone-200/80 dark:border-stone-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors flex flex-col h-full">
      {/* Header with Tab switcher */}
      <div className="flex items-center justify-between mb-3.5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold tracking-wide uppercase text-stone-900 dark:text-stone-100">
              Quick Notes
            </h2>
            <span className="text-xs text-stone-400 dark:text-stone-500">
              {activeTab === 'scratchpad' ? `${wordCount} words` : `(${state.notes.length})`}
            </span>
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
            Capture fleeting thoughts before they evaporate.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-1 bg-stone-100 dark:bg-stone-800/80 p-0.5 rounded-lg border border-stone-200/50 dark:border-stone-700/60 no-print">
          <button
            onClick={() => setActiveTab('scratchpad')}
            className={`flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md transition-all ${
              activeTab === 'scratchpad'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-500 dark:text-stone-400 hover:text-stone-800'
            }`}
          >
            <FileText className="w-3 h-3" />
            <span>Scratchpad</span>
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded-md transition-all ${
              activeTab === 'notes'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-stone-100 shadow-xs'
                : 'text-stone-500 dark:text-stone-400 hover:text-stone-800'
            }`}
          >
            <StickyNote className="w-3 h-3" />
            <span>Cards</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Continuous Scratchpad */}
      {activeTab === 'scratchpad' && (
        <div className="flex-1 flex flex-col min-h-[220px]">
          <div className="relative flex-1">
            <textarea
              value={state.scratchpad}
              onChange={(e) => updateScratchpad(e.target.value)}
              placeholder="Type your notes, quotes, reminders, phone numbers, or reflections here... (Auto-saves continuously)"
              className="w-full h-full min-h-[200px] p-3.5 bg-stone-50/70 dark:bg-stone-800/40 border border-stone-200 dark:border-stone-700/80 rounded-xl text-xs sm:text-sm text-stone-800 dark:text-stone-200 leading-relaxed placeholder-stone-400 dark:placeholder-stone-500 focus:outline-none focus:ring-1 focus:ring-amber-500 resize-none font-sans"
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-stone-400 mt-2 px-1">
            <span className="italic">Saved automatically to browser storage</span>
            <button
              onClick={() => copyToClipboard(state.scratchpad, 'scratchpad')}
              className="flex items-center gap-1 text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 transition-colors"
            >
              {copiedId === 'scratchpad' ? (
                <>
                  <Check className="w-3 h-3 text-emerald-600" />
                  <span className="text-emerald-600">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy text</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Micro-Notes Cards */}
      {activeTab === 'notes' && (
        <div className="flex-1 flex flex-col min-h-[220px]">
          {/* Add form */}
          <form onSubmit={handleAddNote} className="mb-3 flex gap-2 no-print">
            <input
              type="text"
              value={newNoteInput}
              onChange={(e) => setNewNoteInput(e.target.value)}
              placeholder="Quick snippet or thought..."
              className="flex-1 bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700/80 rounded-xl px-3 py-1.5 text-xs text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <button
              type="submit"
              disabled={!newNoteInput.trim()}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 rounded-xl disabled:opacity-40 transition-colors shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Save</span>
            </button>
          </form>

          {/* Cards List */}
          <div className="flex-1 space-y-2 overflow-y-auto max-h-[220px] pr-1">
            {sortedNotes.length === 0 ? (
              <div className="text-center py-7 border border-dashed border-stone-200 dark:border-stone-800 rounded-xl">
                <p className="text-xs text-stone-400 dark:text-stone-500">
                  No note cards saved yet. Add key quotes, links, or insights.
                </p>
              </div>
            ) : (
              sortedNotes.map((note) => (
                <div
                  key={note.id}
                  className={`group relative p-3 rounded-xl border transition-all ${
                    note.pinned
                      ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200/80 dark:border-amber-900/50'
                      : 'bg-white dark:bg-stone-900/40 border-stone-100 dark:border-stone-800 hover:border-stone-200 dark:hover:border-stone-700'
                  }`}
                >
                  <p className="text-xs sm:text-sm text-stone-800 dark:text-stone-200 leading-relaxed pr-16 whitespace-pre-wrap">
                    {note.content}
                  </p>

                  <div className="flex items-center justify-between mt-2 pt-1 border-t border-stone-100 dark:border-stone-800/60 text-[10px] text-stone-400 font-mono">
                    <span>{note.createdAt}</span>

                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity no-print">
                      <button
                        onClick={() => togglePinNote(note.id)}
                        title={note.pinned ? 'Unpin' : 'Pin to top'}
                        className={`p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 ${
                          note.pinned ? 'text-amber-600 dark:text-amber-400' : 'text-stone-400'
                        }`}
                      >
                        <Pin className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => copyToClipboard(note.content, note.id)}
                        title="Copy note"
                        className="p-1 rounded text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800"
                      >
                        {copiedId === note.id ? (
                          <Check className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                      <button
                        onClick={() => deleteNote(note.id)}
                        title="Delete note"
                        className="p-1 rounded text-stone-400 hover:text-red-600 hover:bg-stone-100 dark:hover:bg-stone-800"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </section>
  );
};
