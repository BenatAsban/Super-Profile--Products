import { AppState } from '../types';
import { getTodayKey, getLast7DaysKeys, getCurrentTimeFormatted } from './date';

export function getDefaultState(): AppState {
  const todayKey = getTodayKey();
  const past7Days = getLast7DaysKeys();

  // Create realistic habit history for last 7 days
  const makeHistory = (activeRates: number[]) => {
    const hist: Record<string, boolean> = {};
    past7Days.forEach((day, index) => {
      // today is the last index (6)
      hist[day] = activeRates[index] === 1;
    });
    return hist;
  };

  return {
    theme: 'light',
    currency: '$',
    focusIntention: 'Focus on finishing the few things that truly matter today.',
    dailyBudgetLimit: 50,
    priorities: [
      {
        id: 'p-1',
        title: 'Finalize client proposal & deliver executive deck',
        completed: true,
        tag: 'Deep Work',
        notes: 'Needs final review on section 3 pricing before 3 PM.',
      },
      {
        id: 'p-2',
        title: 'Review weekly finances & reconcile accounts',
        completed: false,
        tag: 'Admin',
        notes: 'Double-check receipt logs and quarterly budget.',
      },
      {
        id: 'p-3',
        title: '45-minute strength training & afternoon walk',
        completed: false,
        tag: 'Health',
        notes: 'Hydrate properly, no phone during workout.',
      },
    ],
    tasks: [
      {
        id: 't-1',
        title: 'Reply to Sarah regarding brand identity design feedback',
        completed: true,
        createdAt: '09:15 AM',
      },
      {
        id: 't-2',
        title: 'Submit quarterly tax estimate receipt',
        completed: false,
        createdAt: '10:30 AM',
      },
      {
        id: 't-3',
        title: 'Book dentist routine check-up appointment',
        completed: false,
        createdAt: '11:00 AM',
      },
      {
        id: 't-4',
        title: 'Water houseplants and order replacement air filter',
        completed: true,
        createdAt: '08:45 AM',
      },
    ],
    habits: [
      {
        id: 'h-1',
        name: 'Morning sunlight & 500ml water',
        completedToday: true,
        streak: 14,
        history: makeHistory([1, 1, 1, 1, 1, 1, 1]),
      },
      {
        id: 'h-2',
        name: '90-min focused deep work block',
        completedToday: true,
        streak: 6,
        history: makeHistory([1, 0, 1, 1, 1, 1, 1]),
      },
      {
        id: 'h-3',
        name: 'Read 20 pages of non-fiction book',
        completedToday: false,
        streak: 9,
        history: makeHistory([1, 1, 1, 1, 1, 1, 0]),
      },
      {
        id: 'h-4',
        name: 'Log daily expenses mindfully',
        completedToday: true,
        streak: 21,
        history: makeHistory([1, 1, 1, 1, 1, 1, 1]),
      },
      {
        id: 'h-5',
        name: 'Digital curfew — no screens after 10 PM',
        completedToday: false,
        streak: 4,
        history: makeHistory([0, 1, 1, 0, 1, 1, 0]),
      },
    ],
    expenses: [
      {
        id: 'e-1',
        title: 'Artisan roast coffee & pastry',
        amount: 6.75,
        category: 'Food',
        date: todayKey,
        time: '08:40 AM',
      },
      {
        id: 'e-2',
        title: 'Monthly cloud development server',
        amount: 14.00,
        category: 'Work',
        date: todayKey,
        time: '10:15 AM',
      },
      {
        id: 'e-3',
        title: 'Subway transit day pass',
        amount: 5.50,
        category: 'Transport',
        date: todayKey,
        time: '01:20 PM',
      },
    ],
    scratchpad: `Today's rule: Move deliberately. When tempted to multitask, return to the current priority.

Important links & ideas:
- Send proposal to Elena: elena@studio.design
- Book quote: "Simplicity is about subtracting the obvious and adding the meaningful." — John Maeda
- Order fresh espresso beans by Friday`,
    notes: [
      {
        id: 'n-1',
        content: 'Product design idea: Add high-contrast export options so users can print their daily dashboard on standard A4 / US Letter paper directly for their physical desk mat.',
        createdAt: '10:45 AM',
        pinned: true,
      },
      {
        id: 'n-2',
        content: 'Reminder for next sprint: Keep the interface single-page. Never bury items in nested folders.',
        createdAt: '02:10 PM',
        pinned: false,
      },
    ],
    lastActiveDate: todayKey,
    historySnapshots: [],
    payhipCheckoutUrl: 'https://payhip.com/b/YOUR_PRODUCT_CODE',
  };
}
