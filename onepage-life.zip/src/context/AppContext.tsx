import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { AppState, PriorityItem, TaskItem, HabitItem, ExpenseItem, QuickNote, DaySnapshot } from '../types';
import { getDefaultState } from '../utils/defaults';
import { getTodayKey, getCurrentTimeFormatted, formatFriendlyDate } from '../utils/date';

interface AppContextType {
  state: AppState;
  viewMode: 'dashboard' | 'landing' | 'guide';
  setViewMode: (mode: 'dashboard' | 'landing' | 'guide') => void;
  // Theme
  toggleTheme: () => void;
  // Focus Intention
  setFocusIntention: (val: string) => void;
  // Currency & Budget
  setCurrency: (curr: string) => void;
  setDailyBudgetLimit: (limit: number) => void;
  // Priorities (Today's 3)
  togglePriority: (id: string) => void;
  updatePriority: (id: string, updates: Partial<PriorityItem>) => void;
  // Tasks
  addTask: (title: string) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  clearCompletedTasks: () => void;
  // Habits (Max 5)
  toggleHabit: (id: string) => void;
  addHabit: (name: string) => boolean;
  updateHabit: (id: string, name: string) => void;
  deleteHabit: (id: string) => void;
  // Expenses
  addExpense: (title: string, amount: number, category: ExpenseItem['category']) => void;
  deleteExpense: (id: string) => void;
  // Scratchpad & Notes
  updateScratchpad: (content: string) => void;
  addNote: (content: string) => void;
  deleteNote: (id: string) => void;
  togglePinNote: (id: string) => void;
  // Day Reset & Export
  resetDay: (options: { clearCompletedTasks: boolean; clearPriorities: boolean }) => void;
  exportJSON: () => void;
  importJSON: (jsonString: string) => { success: boolean; error?: string };
  exportMarkdown: () => string;
  resetToDefaults: () => void;
  setPayhipCheckoutUrl: (url: string) => void;
  // Calculations
  todayExpenses: ExpenseItem[];
  todayExpenseTotal: number;
  completionScore: number;
  stats: {
    prioritiesDone: number;
    prioritiesTotal: number;
    habitsDone: number;
    habitsTotal: number;
    tasksDone: number;
    tasksTotal: number;
  };
}

const STORAGE_KEY = 'onepage_life_v1_store';

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [viewMode, setViewMode] = useState<'dashboard' | 'landing' | 'guide'>('dashboard');

  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Ensure structure compatibility
        const defaults = getDefaultState();
        return {
          ...defaults,
          ...parsed,
          priorities: parsed.priorities?.length ? parsed.priorities : defaults.priorities,
          habits: parsed.habits?.length ? parsed.habits : defaults.habits,
          expenses: parsed.expenses || defaults.expenses,
          tasks: parsed.tasks || defaults.tasks,
          notes: parsed.notes || defaults.notes,
        };
      }
    } catch (e) {
      console.warn('Failed to parse saved state from localStorage:', e);
    }
    return getDefaultState();
  });

  // Handle dark mode class on <html>
  useEffect(() => {
    if (state.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.theme]);

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }, [state]);

  // Check if date changed to rollover habits completionToday safely
  useEffect(() => {
    const today = getTodayKey();
    if (state.lastActiveDate !== today) {
      // New day detected: update habits status for today without erasing history
      setState((prev) => {
        const updatedHabits = prev.habits.map((h) => ({
          ...h,
          completedToday: !!h.history[today],
        }));
        return {
          ...prev,
          lastActiveDate: today,
          habits: updatedHabits,
        };
      });
    }
  }, [state.lastActiveDate]);

  const toggleTheme = useCallback(() => {
    setState((prev) => ({
      ...prev,
      theme: prev.theme === 'light' ? 'dark' : 'light',
    }));
  }, []);

  const setFocusIntention = useCallback((val: string) => {
    setState((prev) => ({ ...prev, focusIntention: val }));
  }, []);

  const setCurrency = useCallback((currency: string) => {
    setState((prev) => ({ ...prev, currency }));
  }, []);

  const setDailyBudgetLimit = useCallback((dailyBudgetLimit: number) => {
    setState((prev) => ({ ...prev, dailyBudgetLimit }));
  }, []);

  const togglePriority = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      priorities: prev.priorities.map((p) =>
        p.id === id ? { ...p, completed: !p.completed } : p
      ),
    }));
  }, []);

  const updatePriority = useCallback((id: string, updates: Partial<PriorityItem>) => {
    setState((prev) => ({
      ...prev,
      priorities: prev.priorities.map((p) => (p.id === id ? { ...p, ...updates } : p)),
    }));
  }, []);

  const addTask = useCallback((title: string) => {
    if (!title.trim()) return;
    const newTask: TaskItem = {
      id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: title.trim(),
      completed: false,
      createdAt: getCurrentTimeFormatted(),
    };
    setState((prev) => ({
      ...prev,
      tasks: [newTask, ...prev.tasks],
    }));
  }, []);

  const toggleTask = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)),
    }));
  }, []);

  const deleteTask = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => t.id !== id),
    }));
  }, []);

  const clearCompletedTasks = useCallback(() => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => !t.completed),
    }));
  }, []);

  const toggleHabit = useCallback((id: string) => {
    const today = getTodayKey();
    setState((prev) => ({
      ...prev,
      habits: prev.habits.map((h) => {
        if (h.id !== id) return h;
        const willComplete = !h.completedToday;
        const newHistory = { ...h.history, [today]: willComplete };
        // calculate streak
        let streak = h.streak;
        if (willComplete) {
          streak = (streak || 0) + 1;
        } else {
          streak = Math.max(0, (streak || 1) - 1);
        }
        return {
          ...h,
          completedToday: willComplete,
          history: newHistory,
          streak,
        };
      }),
    }));
  }, []);

  const addHabit = useCallback((name: string): boolean => {
    if (!name.trim()) return false;
    let success = false;
    setState((prev) => {
      if (prev.habits.length >= 5) {
        return prev;
      }
      success = true;
      const today = getTodayKey();
      const newHabit: HabitItem = {
        id: `habit-${Date.now()}`,
        name: name.trim(),
        completedToday: false,
        streak: 0,
        history: { [today]: false },
      };
      return {
        ...prev,
        habits: [...prev.habits, newHabit],
      };
    });
    return success;
  }, []);

  const updateHabit = useCallback((id: string, name: string) => {
    if (!name.trim()) return;
    setState((prev) => ({
      ...prev,
      habits: prev.habits.map((h) => (h.id === id ? { ...h, name: name.trim() } : h)),
    }));
  }, []);

  const deleteHabit = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      habits: prev.habits.filter((h) => h.id !== id),
    }));
  }, []);

  const addExpense = useCallback(
    (title: string, amount: number, category: ExpenseItem['category']) => {
      if (!title.trim() || isNaN(amount) || amount <= 0) return;
      const today = getTodayKey();
      const newExpense: ExpenseItem = {
        id: `exp-${Date.now()}`,
        title: title.trim(),
        amount: Math.round(amount * 100) / 100,
        category,
        date: today,
        time: getCurrentTimeFormatted(),
      };
      setState((prev) => ({
        ...prev,
        expenses: [newExpense, ...prev.expenses],
      }));
    },
    []
  );

  const deleteExpense = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      expenses: prev.expenses.filter((e) => e.id !== id),
    }));
  }, []);

  const updateScratchpad = useCallback((content: string) => {
    setState((prev) => ({ ...prev, scratchpad: content }));
  }, []);

  const addNote = useCallback((content: string) => {
    if (!content.trim()) return;
    const newNote: QuickNote = {
      id: `note-${Date.now()}`,
      content: content.trim(),
      createdAt: getCurrentTimeFormatted(),
      pinned: false,
    };
    setState((prev) => ({
      ...prev,
      notes: [newNote, ...prev.notes],
    }));
  }, []);

  const deleteNote = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      notes: prev.notes.filter((n) => n.id !== id),
    }));
  }, []);

  const togglePinNote = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      notes: prev.notes.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)),
    }));
  }, []);

  // Filter today's expenses
  const todayKey = getTodayKey();
  const todayExpenses = state.expenses.filter((e) => e.date === todayKey);
  const todayExpenseTotal = todayExpenses.reduce((sum, e) => sum + e.amount, 0);

  // Completion calculation
  const prioritiesTotal = state.priorities.length;
  const prioritiesDone = state.priorities.filter((p) => p.completed).length;

  const habitsTotal = state.habits.length;
  const habitsDone = state.habits.filter((h) => h.completedToday).length;

  const tasksTotal = state.tasks.length;
  const tasksDone = state.tasks.filter((t) => t.completed).length;

  // Weighted score: Priorities = 50%, Habits = 35%, Tasks = 15%
  let completionScore = 0;
  let totalWeights = 0;

  if (prioritiesTotal > 0) {
    completionScore += (prioritiesDone / prioritiesTotal) * 50;
    totalWeights += 50;
  }
  if (habitsTotal > 0) {
    completionScore += (habitsDone / habitsTotal) * 35;
    totalWeights += 35;
  }
  if (tasksTotal > 0) {
    completionScore += (tasksDone / tasksTotal) * 15;
    totalWeights += 15;
  }

  const finalScore = totalWeights > 0 ? Math.round((completionScore / totalWeights) * 100) : 0;

  const resetDay = useCallback(
    (options: { clearCompletedTasks: boolean; clearPriorities: boolean }) => {
      setState((prev) => {
        // Record snapshot of current day first
        const snapshot: DaySnapshot = {
          date: getTodayKey(),
          prioritiesCompleted: prev.priorities.filter((p) => p.completed).length,
          prioritiesTotal: prev.priorities.length,
          habitsCompleted: prev.habits.filter((h) => h.completedToday).length,
          habitsTotal: prev.habits.length,
          tasksCompleted: prev.tasks.filter((t) => t.completed).length,
          tasksTotal: prev.tasks.length,
          expensesTotal: prev.expenses
            .filter((e) => e.date === getTodayKey())
            .reduce((s, e) => s + e.amount, 0),
          score: finalScore,
        };

        // Reset habits for today (uncheck today's checkmark)
        const updatedHabits = prev.habits.map((h) => ({
          ...h,
          completedToday: false,
        }));

        // Reset priorities based on user selection
        const updatedPriorities = options.clearPriorities
          ? prev.priorities.map((p) => ({ ...p, completed: false, title: '', notes: '' }))
          : prev.priorities.map((p) => ({ ...p, completed: false }));

        // Tasks update
        const updatedTasks = options.clearCompletedTasks
          ? prev.tasks.filter((t) => !t.completed)
          : prev.tasks.map((t) => ({ ...t, completed: false }));

        return {
          ...prev,
          priorities: updatedPriorities,
          habits: updatedHabits,
          tasks: updatedTasks,
          historySnapshots: [snapshot, ...prev.historySnapshots.slice(0, 30)],
        };
      });
    },
    [finalScore]
  );

  const exportJSON = useCallback(() => {
    const dataStr = JSON.stringify(state, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `onepage-life-${getTodayKey()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [state]);

  const importJSON = useCallback((jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      if (!data || typeof data !== 'object') {
        return { success: false, error: 'Invalid JSON file format' };
      }
      if (!Array.isArray(data.priorities) && !Array.isArray(data.habits)) {
        return { success: false, error: 'Uploaded file is not a valid OnePage Life backup' };
      }
      const defaults = getDefaultState();
      setState({
        ...defaults,
        ...data,
      });
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e?.message || 'Could not parse JSON file' };
    }
  }, []);

  const exportMarkdown = useCallback(() => {
    const todayStr = formatFriendlyDate();
    let md = `# OnePage Life Summary — ${todayStr}\n\n`;
    if (state.focusIntention) {
      md += `> **Today's Focus:** ${state.focusIntention}\n\n`;
    }
    md += `## Daily Completion: ${finalScore}%\n\n`;

    md += `### Today's 3 Priorities\n`;
    state.priorities.forEach((p, i) => {
      const check = p.completed ? '[x]' : '[ ]';
      const title = p.title || `Priority ${i + 1} (Not set)`;
      const note = p.notes ? ` — *${p.notes}*` : '';
      md += `- ${check} ${title}${note}\n`;
    });
    md += `\n`;

    md += `### Daily Habits (${habitsDone}/${habitsTotal})\n`;
    state.habits.forEach((h) => {
      const check = h.completedToday ? '[x]' : '[ ]';
      md += `- ${check} ${h.name} (Streak: ${h.streak}d)\n`;
    });
    md += `\n`;

    if (state.tasks.length > 0) {
      md += `### Quick Tasks\n`;
      state.tasks.forEach((t) => {
        const check = t.completed ? '[x]' : '[ ]';
        md += `- ${check} ${t.title}\n`;
      });
      md += `\n`;
    }

    md += `### Expenses Today (${state.currency}${todayExpenseTotal.toFixed(2)})\n`;
    if (todayExpenses.length === 0) {
      md += `- No expenses logged today\n`;
    } else {
      todayExpenses.forEach((e) => {
        md += `- ${e.title}: ${state.currency}${e.amount.toFixed(2)} [${e.category}]\n`;
      });
    }
    md += `\n`;

    if (state.scratchpad.trim()) {
      md += `### Scratchpad Notes\n${state.scratchpad}\n\n`;
    }

    return md;
  }, [state, finalScore, habitsDone, habitsTotal, todayExpenseTotal, todayExpenses]);

  const resetToDefaults = useCallback(() => {
    const defaults = getDefaultState();
    setState(defaults);
  }, []);

  const setPayhipCheckoutUrl = useCallback((url: string) => {
    setState((prev) => ({ ...prev, payhipCheckoutUrl: url }));
  }, []);

  return (
    <AppContext.Provider
      value={{
        state,
        viewMode,
        setViewMode,
        toggleTheme,
        setFocusIntention,
        setCurrency,
        setDailyBudgetLimit,
        togglePriority,
        updatePriority,
        addTask,
        toggleTask,
        deleteTask,
        clearCompletedTasks,
        toggleHabit,
        addHabit,
        updateHabit,
        deleteHabit,
        addExpense,
        deleteExpense,
        updateScratchpad,
        addNote,
        deleteNote,
        togglePinNote,
        resetDay,
        exportJSON,
        importJSON,
        exportMarkdown,
        resetToDefaults,
        setPayhipCheckoutUrl,
        todayExpenses,
        todayExpenseTotal,
        completionScore: finalScore,
        stats: {
          prioritiesDone,
          prioritiesTotal,
          habitsDone,
          habitsTotal,
          tasksDone,
          tasksTotal,
        },
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
