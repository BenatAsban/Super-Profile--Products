import React, { useState, useEffect } from 'react';
import { PageId, PetProfile } from './types';
import { storage } from './utils/storage';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { AddPetModal } from './components/AddPetModal';
import { HomePage } from './pages/HomePage';
import { SoundTranslatorPage } from './pages/SoundTranslatorPage';
import { BodyLanguagePage } from './pages/BodyLanguagePage';
import { PetDashboardPage } from './pages/PetDashboardPage';
import { AIAssistantPage } from './pages/AIAssistantPage';
import { AboutPage } from './pages/AboutPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { ContactPage } from './pages/ContactPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [pets, setPets] = useState<PetProfile[]>([]);
  const [activePetId, setActivePetId] = useState<string>('');
  const [isAddPetModalOpen, setIsAddPetModalOpen] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Initialize data on mount
  useEffect(() => {
    const loadedPets = storage.getPets();
    setPets(loadedPets);
    const activeId = storage.getActivePetId();
    setActivePetId(activeId);
    const savedTheme = storage.getTheme();
    setTheme(savedTheme);
  }, []);

  // Update HTML body theme class
  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light-mode');
    } else {
      document.documentElement.classList.remove('light-mode');
      document.documentElement.classList.add('dark');
    }
    storage.setTheme(theme);
  }, [theme]);

  // Handle pet selection
  const handleSelectPet = (id: string) => {
    setActivePetId(id);
    storage.setActivePetId(id);
  };

  // Handle adding new pet
  const handleAddPet = (petData: Omit<PetProfile, 'id' | 'createdAt'>) => {
    const newPet = storage.addPet(petData);
    const updatedPets = storage.getPets();
    setPets(updatedPets);
    setActivePetId(newPet.id);
  };

  // Handle theme toggle
  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const activePet = pets.find((p) => p.id === activePetId) || pets[0] || null;

  // Scroll to top on page switch
  const handleNavigate = (page: PageId) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors ${
      theme === 'light' ? 'bg-slate-100 text-slate-900' : 'bg-slate-950 text-slate-100'
    }`}>
      {/* Disclaimer Banner */}
      <DisclaimerBanner />

      {/* Main Navbar */}
      <Navbar
        currentPage={currentPage}
        setCurrentPage={handleNavigate}
        pets={pets}
        activePet={activePet}
        onSelectPet={handleSelectPet}
        onOpenAddPet={() => setIsAddPetModalOpen(true)}
        theme={theme}
        onToggleTheme={handleToggleTheme}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {currentPage === 'home' && <HomePage setCurrentPage={handleNavigate} />}
        {currentPage === 'sound-translator' && (
          <SoundTranslatorPage
            activePet={activePet}
            pets={pets}
            onSelectPet={handleSelectPet}
            setCurrentPage={handleNavigate}
          />
        )}
        {currentPage === 'body-language' && (
          <BodyLanguagePage
            activePet={activePet}
            pets={pets}
            onSelectPet={handleSelectPet}
            setCurrentPage={handleNavigate}
          />
        )}
        {currentPage === 'dashboard' && (
          <PetDashboardPage
            activePet={activePet}
            pets={pets}
            onSelectPet={handleSelectPet}
            onOpenAddPet={() => setIsAddPetModalOpen(true)}
            setCurrentPage={handleNavigate}
          />
        )}
        {currentPage === 'assistant' && <AIAssistantPage activePet={activePet} />}
        {currentPage === 'about' && <AboutPage setCurrentPage={handleNavigate} />}
        {currentPage === 'privacy' && <PrivacyPolicyPage />}
        {currentPage === 'contact' && <ContactPage />}
      </main>

      {/* Footer */}
      <Footer setCurrentPage={handleNavigate} />

      {/* Add Pet Profile Modal */}
      <AddPetModal
        isOpen={isAddPetModalOpen}
        onClose={() => setIsAddPetModalOpen(false)}
        onAddPet={handleAddPet}
      />
    </div>
  );
}
