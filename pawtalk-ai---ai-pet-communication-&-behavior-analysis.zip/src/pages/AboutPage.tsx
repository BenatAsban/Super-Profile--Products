import React from 'react';
import { PageId } from '../types';
import {
  Sparkles,
  ShieldCheck,
  Heart,
  Activity,
  Layers,
  ArrowRight,
  BookOpen,
} from 'lucide-react';

interface AboutPageProps {
  setCurrentPage: (page: PageId) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ setCurrentPage }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-16">
      {/* Hero */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 text-xs font-semibold uppercase tracking-wider border border-purple-500/20">
          <BookOpen className="w-3.5 h-3.5" />
          Our Ethological Mission
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Bioacoustics Meets Compassionate Pet Ethology
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          PawTalk AI was created to bridge the communicative divide between humans and their domestic animal companions—without resorting to gimmicky pseudo-translations.
        </p>
      </div>

      {/* The Core Problem & Our Ethical Stand */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-8 sm:p-10 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white">
            The Ethics of Animal Sound Analysis
          </h2>
        </div>
        <div className="text-xs sm:text-sm text-slate-300 space-y-4 leading-relaxed">
          <p>
            For years, viral mobile apps have claimed they can "translate" a cat meow or dog bark into literal English sentences like <em>"I want a treat"</em> or <em>"I dislike your friend"</em>. As any certified veterinary behaviorist will attest, non-human animal communication does not function as human semantic language.
          </p>
          <p>
            Domestic cats and dogs do not possess syntactic grammar. Instead, they produce vocalizations modulated by emotional valence, autonomic arousal, territorial stimuli, and learned reinforcement.
          </p>
          <p className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/40 text-purple-200 font-medium">
            PawTalk AI takes a strictly scientific, respectful stance: We use neural bioacoustic modeling to examine acoustic frequency contours, cadence, duration, and harmonic overtones alongside posture vision, providing pet guardians with behavioral hypotheses, alternative interpretations, and positive welfare guidance.
          </p>
        </div>
      </div>

      {/* 3 Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
            <Activity className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Bioacoustic Signal Processing</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Extracting pitch variance, harmonic richness, intensity pulses, and duration from raw audio captured via browser media interfaces.
          </p>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Multimodal Gemini AI</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Correlating acoustic features with known feline/canine ethology literature to identify emotional arousal states and communicative context.
          </p>
        </div>

        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-pink-600/20 text-pink-400 flex items-center justify-center">
            <Heart className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Guardian Welfare Support</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Empowering owners with positive reinforcement recommendations, environmental enrichment, and clear veterinary referral reminders.
          </p>
        </div>
      </div>

      {/* Call to action */}
      <div className="text-center pt-4">
        <button
          onClick={() => setCurrentPage('sound-translator')}
          className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-purple-600/30 inline-flex items-center gap-2"
        >
          Try the Sound Translator
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
