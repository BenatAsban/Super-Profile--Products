import React, { useState, useEffect } from 'react';
import {
  PetProfile,
  SoundAnalysisResult,
  BodyLanguageResult,
  PetActivityNote,
  PageId,
} from '../types';
import { storage } from '../utils/storage';
import { downloadSoundReport, downloadBodyReport } from '../utils/reportGenerator';
import {
  LayoutDashboard,
  Plus,
  Trash2,
  Bookmark,
  Volume2,
  Eye,
  Calendar,
  Sparkles,
  Download,
  Filter,
  FileText,
  Activity,
  Heart,
  ChevronRight,
  X,
  Clock,
  Tag,
} from 'lucide-react';

interface PetDashboardPageProps {
  activePet: PetProfile | null;
  pets: PetProfile[];
  onSelectPet: (id: string) => void;
  onOpenAddPet: () => void;
  setCurrentPage: (page: PageId) => void;
}

export const PetDashboardPage: React.FC<PetDashboardPageProps> = ({
  activePet,
  pets,
  onSelectPet,
  onOpenAddPet,
  setCurrentPage,
}) => {
  // History data
  const [soundHistory, setSoundHistory] = useState<SoundAnalysisResult[]>([]);
  const [bodyHistory, setBodyHistory] = useState<BodyLanguageResult[]>([]);
  const [activityNotes, setActivityNotes] = useState<PetActivityNote[]>([]);

  // Filter tabs
  const [activeTab, setActiveTab] = useState<'all' | 'sound' | 'body' | 'favorites'>('all');
  const [selectedPetFilter, setSelectedPetFilter] = useState<string>('all'); // 'all' or petId

  // New activity note form state
  const [newNoteText, setNewNoteText] = useState('');
  const [newNoteCategory, setNewNoteCategory] = useState<PetActivityNote['category']>('vocal');
  const [newNoteMood, setNewNoteMood] = useState('Attentive');

  // Modal inspection of past result
  const [inspectSound, setInspectSound] = useState<SoundAnalysisResult | null>(null);
  const [inspectBody, setInspectBody] = useState<BodyLanguageResult | null>(null);

  // Load storage data
  const loadData = () => {
    setSoundHistory(storage.getSoundHistory());
    setBodyHistory(storage.getBodyHistory());
    setActivityNotes(storage.getActivityNotes());
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filter items
  const filteredSound = soundHistory.filter((item) => {
    if (selectedPetFilter !== 'all' && item.petId !== selectedPetFilter) return false;
    if (activeTab === 'favorites' && !item.isFavorite) return false;
    return activeTab === 'all' || activeTab === 'sound' || activeTab === 'favorites';
  });

  const filteredBody = bodyHistory.filter((item) => {
    if (selectedPetFilter !== 'all' && item.petId !== selectedPetFilter) return false;
    if (activeTab === 'favorites' && !item.isFavorite) return false;
    return activeTab === 'all' || activeTab === 'body' || activeTab === 'favorites';
  });

  // Calculate mood distribution for active or filtered pet
  const allEmotions = [
    ...soundHistory
      .filter((s) => selectedPetFilter === 'all' || s.petId === selectedPetFilter)
      .map((s) => s.emotion),
    ...bodyHistory
      .filter((b) => selectedPetFilter === 'all' || b.petId === selectedPetFilter)
      .map((b) => b.primaryEmotion),
  ];

  const emotionCounts: Record<string, number> = {};
  allEmotions.forEach((em) => {
    emotionCounts[em] = (emotionCounts[em] || 0) + 1;
  });

  // Handle adding note
  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim() || !activePet) return;

    storage.addActivityNote({
      petId: activePet.id,
      category: newNoteCategory,
      note: newNoteText.trim(),
      moodTag: newNoteMood,
    });

    setNewNoteText('');
    setActivityNotes(storage.getActivityNotes());
  };

  // Handle note delete
  const handleDeleteNote = (id: string) => {
    storage.deleteActivityNote(id);
    setActivityNotes(storage.getActivityNotes());
  };

  // Toggle favorite on sound
  const handleToggleSoundFav = (id: string) => {
    storage.toggleSoundFavorite(id);
    loadData();
  };

  // Toggle favorite on body
  const handleToggleBodyFav = (id: string) => {
    storage.toggleBodyFavorite(id);
    loadData();
  };

  // Delete history item
  const handleDeleteSound = (id: string) => {
    storage.deleteSoundResult(id);
    loadData();
  };

  const handleDeleteBody = (id: string) => {
    storage.deleteBodyResult(id);
    loadData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2 border border-cyan-500/20">
            <LayoutDashboard className="w-3.5 h-3.5" />
            Communication Hub
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Pet Mood &amp; Activity Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track communication trends, review vocal bioacoustics, and record daily behavioral notes.
          </p>
        </div>

        <button
          onClick={onOpenAddPet}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          Add Pet Profile
        </button>
      </div>

      {/* Pet Profiles Cards Row */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          Registered Pet Companions ({pets.length})
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {pets.map((pet) => {
            const isActive = activePet?.id === pet.id;
            const petSoundCount = soundHistory.filter((s) => s.petId === pet.id).length;
            const petBodyCount = bodyHistory.filter((b) => b.petId === pet.id).length;

            return (
              <div
                key={pet.id}
                onClick={() => onSelectPet(pet.id)}
                className={`rounded-2xl p-5 border cursor-pointer transition-all relative overflow-hidden ${
                  isActive
                    ? 'bg-slate-900 border-purple-500/80 shadow-xl shadow-purple-500/15 ring-1 ring-purple-400/40'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${
                        pet.avatarColor || 'from-purple-500 to-indigo-600'
                      } flex items-center justify-center text-2xl shadow-md`}
                    >
                      {pet.type === 'dog' ? '🐕' : '🐈'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-white">{pet.name}</h4>
                        {isActive && (
                          <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-2 py-0.5 rounded-full border border-purple-500/30">
                            Active
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400">
                        {pet.breed || pet.type} • {pet.age || 'Age unlisted'}
                      </p>
                    </div>
                  </div>

                  {/* Delete pet button if more than 1 pet */}
                  {pets.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Remove profile for ${pet.name}?`)) {
                          storage.deletePet(pet.id);
                          loadData();
                        }
                      }}
                      className="text-slate-600 hover:text-rose-400 p-1 rounded-lg transition-colors"
                      title="Delete pet profile"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {pet.notes && (
                  <p className="text-xs text-slate-400 mt-3 line-clamp-2 italic">
                    "{pet.notes}"
                  </p>
                )}

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Volume2 className="w-3 h-3 text-purple-400" />
                    {petSoundCount} Sounds
                  </span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3 h-3 text-indigo-400" />
                    {petBodyCount} Postures
                  </span>
                  <span className="text-purple-400 font-semibold flex items-center gap-0.5">
                    Select <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mood Distribution Overview & Quick Action */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Mood Distribution Summary */}
        <div className="lg:col-span-2 rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-7 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Observed Mood Frequency Breakdown
              </h3>
            </div>
            <span className="text-xs text-slate-400">
              Total Recorded Events: {allEmotions.length}
            </span>
          </div>

          {allEmotions.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No analyses recorded yet. Start by analyzing a sound or photo!
            </div>
          ) : (
            <div className="space-y-3 pt-2">
              {Object.entries(emotionCounts).map(([emotion, count]) => {
                const percentage = Math.round((count / allEmotions.length) * 100);
                return (
                  <div key={emotion} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-300">{emotion}</span>
                      <span className="text-slate-400 font-mono">
                        {count} ({percentage}%)
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                      <div
                        style={{ width: `${percentage}%` }}
                        className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 rounded-full transition-all duration-500"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Quick Launch Card */}
        <div className="rounded-3xl bg-gradient-to-br from-purple-900/30 to-indigo-950/40 border border-purple-500/30 p-6 flex flex-col justify-between space-y-4">
          <div>
            <span className="text-[10px] font-bold text-purple-300 uppercase tracking-wider bg-purple-500/20 px-2.5 py-0.5 rounded-full border border-purple-500/30">
              Quick Actions
            </span>
            <h4 className="text-xl font-bold text-white mt-2">New Bioacoustic Scan</h4>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Capture current vocalization or posture for {activePet?.name || 'your pet'}.
            </p>
          </div>

          <div className="space-y-2 pt-4">
            <button
              onClick={() => setCurrentPage('sound-translator')}
              className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
            >
              <Volume2 className="w-4 h-4" />
              Analyze Pet Sound
            </button>
            <button
              onClick={() => setCurrentPage('body-language')}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center justify-center gap-2 transition-all"
            >
              <Eye className="w-4 h-4" />
              Analyze Body Posture
            </button>
          </div>
        </div>
      </div>

      {/* Pet Activity & Behavioral Notes */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-purple-400" />
              Pet Activity &amp; Behavioral Notes
            </h3>
            <p className="text-xs text-slate-400">
              Log daily observations, unusual vocal triggers, and routine milestones for {activePet?.name || 'your pet'}.
            </p>
          </div>
        </div>

        {/* Note Input Form */}
        <form onSubmit={handleAddNote} className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              required
              placeholder={`Add observation for ${activePet?.name || 'pet'} (e.g., chirped at mail carrier, relaxed in sunbeam)...`}
              value={newNoteText}
              onChange={(e) => setNewNoteText(e.target.value)}
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-purple-500 text-xs text-white placeholder-slate-500 outline-none"
            />
            <div className="flex items-center gap-2">
              <select
                value={newNoteCategory}
                onChange={(e) => setNewNoteCategory(e.target.value as any)}
                className="px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 outline-none"
              >
                <option value="vocal">Vocalization</option>
                <option value="behavior">Behavior</option>
                <option value="mood">Mood</option>
                <option value="play">Play / Exercise</option>
                <option value="feeding">Feeding</option>
                <option value="health">Health Check</option>
              </select>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md flex-shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Note
              </button>
            </div>
          </div>
        </form>

        {/* Notes List */}
        <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
          {activityNotes.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-3 text-center">No activity notes recorded yet.</p>
          ) : (
            activityNotes.map((note) => (
              <div
                key={note.id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-purple-300 uppercase text-[10px] px-2 py-0.5 rounded-full bg-purple-950/60 border border-purple-800/40">
                      {note.category}
                    </span>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {new Date(note.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-slate-200">{note.note}</p>
                </div>
                <button
                  onClick={() => handleDeleteNote(note.id)}
                  className="text-slate-500 hover:text-rose-400 p-1"
                  title="Delete note"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Analysis History Section */}
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-white">Analysis History Log</h3>
            <p className="text-xs text-slate-400">
              Browse past bioacoustic sound translations and body posture breakdowns.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'all'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              All Events ({filteredSound.length + filteredBody.length})
            </button>
            <button
              onClick={() => setActiveTab('sound')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'sound'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Volume2 className="w-3 h-3" />
              Sounds ({filteredSound.length})
            </button>
            <button
              onClick={() => setActiveTab('body')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'body'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Eye className="w-3 h-3" />
              Postures ({filteredBody.length})
            </button>
            <button
              onClick={() => setActiveTab('favorites')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'favorites'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Bookmark className="w-3 h-3 text-amber-400" />
              Favorites
            </button>
          </div>
        </div>

        {/* History Items Grid */}
        <div className="space-y-4">
          {filteredSound.length === 0 && filteredBody.length === 0 && (
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-12 text-center text-slate-400 space-y-3">
              <Sparkles className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-sm font-semibold text-slate-300">No records found matching current filters</p>
              <p className="text-xs text-slate-500">Record a sound or analyze a photo to populate your history.</p>
            </div>
          )}

          {/* Sound History Items */}
          {filteredSound.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500/40 p-5 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Volume2 className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-white">{item.vocalizationType}</span>
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30">
                      {item.emotion}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {new Date(item.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 line-clamp-2 max-w-2xl">
                    {item.humanExplanation}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                <button
                  onClick={() => downloadSoundReport(item)}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                  title="Download Report (.html)"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleToggleSoundFav(item.id)}
                  className={`p-2 rounded-lg transition-colors ${
                    item.isFavorite
                      ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                  title={item.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                >
                  <Bookmark className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setInspectSound(item)}
                  className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
                >
                  Inspect
                </button>
                <button
                  onClick={() => handleDeleteSound(item.id)}
                  className="p-2 rounded-lg text-slate-500 hover:text-rose-400"
                  title="Delete record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}

          {/* Body Language Items */}
          {filteredBody.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/40 p-5 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Eye className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="text-xs font-bold text-white">{item.detectedSubject}</span>
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30">
                      {item.primaryEmotion}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {new Date(item.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 line-clamp-2 max-w-2xl">
                    {item.detailedSummary}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                <button
                  onClick={() => downloadBodyReport(item)}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                  title="Download Report (.html)"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleToggleBodyFav(item.id)}
                  className={`p-2 rounded-lg transition-colors ${
                    item.isFavorite
                      ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                  title={item.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                >
                  <Bookmark className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setInspectBody(item)}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                >
                  Inspect
                </button>
                <button
                  onClick={() => handleDeleteBody(item.id)}
                  className="p-2 rounded-lg text-slate-500 hover:text-rose-400"
                  title="Delete record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Inspect Sound Modal */}
      {inspectSound && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700 p-6 sm:p-8 space-y-6 text-white relative">
            <button
              onClick={() => setInspectSound(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center text-xl">
                {inspectSound.petType === 'cat' ? '🐈' : '🐕'}
              </div>
              <div>
                <h3 className="text-xl font-bold">{inspectSound.vocalizationType}</h3>
                <p className="text-xs text-slate-400">
                  Recorded on {new Date(inspectSound.timestamp).toLocaleString()}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/40 text-purple-200 text-sm font-semibold">
              State: {inspectSound.emotion} (Confidence: {inspectSound.confidenceLevel.toUpperCase()})
            </div>

            <p className="text-sm text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
              {inspectSound.humanExplanation}
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <span className="text-slate-500 uppercase">Pitch:</span>
                <p className="font-semibold text-white mt-0.5">
                  {inspectSound.soundCharacteristics.pitch}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <span className="text-slate-500 uppercase">Intensity:</span>
                <p className="font-semibold text-white mt-0.5">
                  {inspectSound.soundCharacteristics.intensity}
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => downloadSoundReport(inspectSound)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                Download Report (.html)
              </button>
              <button
                onClick={() => setInspectSound(null)}
                className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Inspect Body Modal */}
      {inspectBody && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700 p-6 sm:p-8 space-y-6 text-white relative">
            <button
              onClick={() => setInspectBody(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-300 flex items-center justify-center text-xl">
                {inspectBody.petType === 'cat' ? '🐈' : '🐕'}
              </div>
              <div>
                <h3 className="text-xl font-bold">{inspectBody.detectedSubject}</h3>
                <p className="text-xs text-slate-400">
                  Observed on {new Date(inspectBody.timestamp).toLocaleString()}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-indigo-950/40 border border-indigo-800/40 text-indigo-200 text-sm font-semibold">
              Primary State: {inspectBody.primaryEmotion} ({inspectBody.confidenceLevel.toUpperCase()})
            </div>

            <p className="text-sm text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
              {inspectBody.detailedSummary}
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <span className="text-purple-300 font-semibold uppercase">Ears:</span>
                <p className="text-slate-300 mt-1">
                  {inspectBody.bodyLanguageBreakdown.ears.observation}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <span className="text-indigo-300 font-semibold uppercase">Tail:</span>
                <p className="text-slate-300 mt-1">
                  {inspectBody.bodyLanguageBreakdown.tail.observation}
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => downloadBodyReport(inspectBody)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                Download Report (.html)
              </button>
              <button
                onClick={() => setInspectBody(null)}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
