import React, { useState, useRef } from 'react';
import { PetProfile, PetType, BodyLanguageResult, PageId } from '../types';
import { storage } from '../utils/storage';
import { downloadBodyReport } from '../utils/reportGenerator';
import { blobToBase64 } from '../utils/audioRecorder';
import {
  Eye,
  Upload,
  Camera,
  Sparkles,
  Download,
  Bookmark,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  ArrowRight,
  ShieldAlert,
  Info,
} from 'lucide-react';

interface BodyLanguagePageProps {
  activePet: PetProfile | null;
  pets: PetProfile[];
  onSelectPet: (id: string) => void;
  setCurrentPage: (page: PageId) => void;
}

// Curated high quality SVG / canvas sample photos so users can test immediately on any device without uploading
const PRESET_IMAGE_SAMPLES = [
  {
    id: 'sample-cat-loaf',
    name: 'Relaxed Cat Loaf',
    petType: 'cat' as PetType,
    description: 'Cat resting with paws tucked beneath chest',
    generateDataUrl: () => generateSampleCanvas('cat', 'loaf'),
  },
  {
    id: 'sample-dog-playbow',
    name: 'Dog Play Bow',
    petType: 'dog' as PetType,
    description: 'Front chest lowered with hindquarters upright',
    generateDataUrl: () => generateSampleCanvas('dog', 'playbow'),
  },
  {
    id: 'sample-cat-alert',
    name: 'Alert Cat with Swishing Tail',
    petType: 'cat' as PetType,
    description: 'Ears pricked forward, intense focal gaze',
    generateDataUrl: () => generateSampleCanvas('cat', 'alert'),
  },
  {
    id: 'sample-dog-relaxed',
    name: 'Relaxed Panting Dog',
    petType: 'dog' as PetType,
    description: 'Soft open mouth, loose curved posture',
    generateDataUrl: () => generateSampleCanvas('dog', 'relaxed'),
  },
];

// Helper to draw clean graphic canvas image for instant test drive
function generateSampleCanvas(type: 'cat' | 'dog', posture: string): string {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 450;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Background gradient
  const grad = ctx.createLinearGradient(0, 0, 600, 450);
  grad.addColorStop(0, '#1E1B4B');
  grad.addColorStop(1, '#0F172A');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 600, 450);

  // Soft floor
  ctx.fillStyle = '#1E293B';
  ctx.fillRect(0, 320, 600, 130);

  // Draw stylish silhouette graphic
  ctx.fillStyle = type === 'cat' ? '#C084FC' : '#F59E0B';
  ctx.beginPath();
  if (posture === 'loaf') {
    // Cat loaf oval
    ctx.ellipse(300, 290, 140, 80, 0, 0, Math.PI * 2);
    ctx.fill();
    // Head
    ctx.beginPath();
    ctx.ellipse(200, 240, 55, 50, 0, 0, Math.PI * 2);
    ctx.fill();
    // Ears
    ctx.beginPath();
    ctx.moveTo(170, 210);
    ctx.lineTo(190, 160);
    ctx.lineTo(210, 205);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(215, 205);
    ctx.lineTo(235, 160);
    ctx.lineTo(250, 210);
    ctx.fill();
  } else if (posture === 'playbow') {
    // Dog play bow
    ctx.beginPath();
    ctx.moveTo(180, 310);
    ctx.lineTo(240, 290);
    ctx.lineTo(340, 230);
    ctx.lineTo(400, 220);
    ctx.lineTo(440, 310);
    ctx.lineTo(340, 310);
    ctx.closePath();
    ctx.fill();
    // Tail up
    ctx.beginPath();
    ctx.moveTo(410, 220);
    ctx.quadraticCurveTo(460, 160, 440, 130);
    ctx.lineWidth = 14;
    ctx.strokeStyle = '#F59E0B';
    ctx.stroke();
  } else {
    // Default animal form
    ctx.ellipse(300, 260, 120, 90, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Label text on canvas
  ctx.font = 'bold 20px -apple-system, sans-serif';
  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'center';
  ctx.fillText(
    `PawTalk AI Ethology Sample: ${type.toUpperCase()} (${posture.toUpperCase()})`,
    300,
    60
  );

  return canvas.toDataURL('image/jpeg', 0.9);
}

export const BodyLanguagePage: React.FC<BodyLanguagePageProps> = ({
  activePet,
  pets,
  onSelectPet,
  setCurrentPage,
}) => {
  const [selectedPetType, setSelectedPetType] = useState<PetType>(activePet?.type || 'cat');
  const [contextInput, setContextInput] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [fileName, setFileName] = useState<string>('');

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [result, setResult] = useState<BodyLanguageResult | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);

  // Process selected image file
  const handleFileSelect = async (file: File) => {
    try {
      setAnalysisError(null);
      setResult(null);

      if (!file.type.startsWith('image/')) {
        setAnalysisError('Please upload an image file (JPEG, PNG, WEBP).');
        return;
      }

      if (file.size > 15 * 1024 * 1024) {
        setAnalysisError('Image size exceeds 15MB. Please upload a smaller photo.');
        return;
      }

      const base64 = await blobToBase64(file);
      setImagePreview(base64);
      setImageBase64(base64);
      setMimeType(file.type);
      setFileName(file.name);
    } catch (err) {
      console.error('Error loading image:', err);
      setAnalysisError('Failed to process image file.');
    }
  };

  // Load preset sample
  const handleLoadPreset = (preset: typeof PRESET_IMAGE_SAMPLES[0]) => {
    setSelectedPetType(preset.petType);
    setAnalysisError(null);
    setResult(null);
    const dataUrl = preset.generateDataUrl();
    setImagePreview(dataUrl);
    setImageBase64(dataUrl);
    setMimeType('image/jpeg');
    setFileName(`${preset.name}.jpg`);
  };

  // Submit to Gemini vision endpoint
  const handleAnalyze = async () => {
    if (!imageBase64) return;

    setIsAnalyzing(true);
    setAnalysisError(null);
    setResult(null);

    try {
      const response = await fetch('/api/analyze-body-language', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          petType: selectedPetType,
          imageBase64,
          mimeType,
          petName: activePet?.name,
          breed: activePet?.breed,
          context: contextInput.trim(),
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with code ${response.status}`);
      }

      const data = await response.json();

      const newResult: BodyLanguageResult = {
        id: `body-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        timestamp: Date.now(),
        petId: activePet?.id,
        petName: activePet?.name || (selectedPetType === 'cat' ? 'Cat' : 'Dog'),
        petType: selectedPetType,
        petIdentified: data.petIdentified !== false,
        detectedSubject: data.detectedSubject || `${selectedPetType === 'cat' ? 'Cat' : 'Dog'} Subject`,
        primaryEmotion: data.primaryEmotion || 'Relaxed & Content',
        confidenceLevel: data.confidenceLevel || 'medium',
        confidenceScore: data.confidenceScore || 82,
        bodyLanguageBreakdown: data.bodyLanguageBreakdown || {
          ears: { observation: 'Neutral forward posture', meaning: 'Receptive and comfortable' },
          tail: { observation: 'Resting curved', meaning: 'Calm baseline' },
          eyes: { observation: 'Soft open gaze', meaning: 'Absence of perceived threat' },
          posture: { observation: 'Balanced natural stance', meaning: 'Secure in territory' },
        },
        detailedSummary: data.detailedSummary || 'Visual ethology evaluation completed.',
        alternativeInterpretations: data.alternativeInterpretations || [
          'Ambient temperature or room warmth',
          'Fatigue prior to normal sleep cycle',
        ],
        confidenceLimitations: data.confidenceLimitations || [
          'Single frame photographic capture cannot observe dynamic motion velocity',
        ],
        suggestedActions: data.suggestedActions || [
          'Respect natural boundary',
          'Continue gentle positive engagement',
        ],
        imageUrl: imagePreview || undefined,
      };

      setResult(newResult);
      storage.addBodyResult(newResult);
    } catch (err: any) {
      console.error('Vision analysis error:', err);
      setAnalysisError(err.message || 'Failed to complete body language analysis.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-300 text-xs font-semibold uppercase tracking-wider border border-indigo-500/20">
          <Eye className="w-3.5 h-3.5" />
          Ethological Computer Vision
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Pet Body Language Analyzer
        </h1>
        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto">
          Upload a cat or dog photo to inspect anatomical markers—ears, tail, eyes, and muscular stance—grounded in companion animal ethology.
        </p>
      </div>

      {/* Species Selector & Active Profile */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Target Species:</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedPetType('cat')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all border ${
                selectedPetType === 'cat'
                  ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
              }`}
            >
              <span>🐈</span> Cat
            </button>
            <button
              onClick={() => setSelectedPetType('dog')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all border ${
                selectedPetType === 'dog'
                  ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
              }`}
            >
              <span>🐕</span> Dog
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400 w-full sm:w-auto justify-end">
          <span>Profile context:</span>
          {pets.length > 0 ? (
            <select
              value={activePet?.id || ''}
              onChange={(e) => onSelectPet(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 text-xs font-medium outline-none focus:border-purple-500"
            >
              {pets.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.type})
                </option>
              ))}
            </select>
          ) : (
            <span className="text-slate-500 italic">No pet profiles</span>
          )}
        </div>
      </div>

      {/* Upload & Photo Selection Box */}
      <div className="rounded-3xl bg-slate-900 border border-slate-700/80 p-6 sm:p-10 shadow-2xl space-y-8">
        {!imagePreview ? (
          <div className="space-y-6">
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-700 hover:border-purple-500/60 rounded-3xl p-10 text-center cursor-pointer bg-slate-950/40 hover:bg-slate-950/80 transition-all flex flex-col items-center justify-center space-y-3"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelect(e.target.files[0]);
                  }
                }}
              />
              {/* Hidden camera input for mobile photo snap */}
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelect(e.target.files[0]);
                  }
                }}
              />

              <div className="w-16 h-16 rounded-2xl bg-purple-600/20 text-purple-300 flex items-center justify-center">
                <Upload className="w-8 h-8" />
              </div>
              <div>
                <p className="text-base font-bold text-white">
                  Drop your pet’s photo here or <span className="text-purple-400 underline">browse</span>
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Supports full body or face photos (JPEG, PNG, WEBP up to 15MB)
                </p>
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    cameraInputRef.current?.click();
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-semibold flex items-center gap-2 border border-slate-700 transition-all"
                >
                  <Camera className="w-4 h-4 text-purple-400" />
                  Take Photo with Camera
                </button>
              </div>
            </div>

            {/* Instant test drive samples */}
            <div className="space-y-3 pt-2">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                Or test with an instant ethology sample:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                {PRESET_IMAGE_SAMPLES.map((sample) => (
                  <button
                    key={sample.id}
                    onClick={() => handleLoadPreset(sample)}
                    className="p-3.5 rounded-xl bg-slate-950/70 hover:bg-purple-950/40 border border-slate-800 hover:border-purple-500/40 text-left transition-all"
                  >
                    <p className="text-xs font-bold text-slate-200">
                      {sample.petType === 'cat' ? '🐈' : '🐕'} {sample.name}
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                      {sample.description}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Image Preview & Analyze Action */
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row gap-6 items-center">
              <div className="w-full sm:w-72 h-56 rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden relative flex-shrink-0 flex items-center justify-center">
                <img
                  src={imagePreview}
                  alt="Pet preview"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1 space-y-4 w-full">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <span>{fileName || 'Pet Photo Selected'}</span>
                    <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-500/30">
                      {selectedPetType.toUpperCase()}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Ready for Gemini vision analysis. You may provide optional situational context below.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Situational Context (Optional):
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Just woke up, heard someone at the door, after dinner"
                    value={contextInput}
                    onChange={(e) => setContextInput(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-purple-500 text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={handleAnalyze}
                    disabled={isAnalyzing}
                    className={`flex-1 py-3 px-6 rounded-xl font-bold text-sm text-white flex items-center justify-center gap-2 shadow-lg transition-all ${
                      isAnalyzing
                        ? 'bg-slate-800 cursor-not-allowed text-slate-400'
                        : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-purple-600/30'
                    }`}
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Analyzing Body Language with Gemini...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-purple-200" />
                        <span>Analyze Pet Body Language</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => {
                      setImagePreview(null);
                      setImageBase64(null);
                      setResult(null);
                      setAnalysisError(null);
                    }}
                    className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-semibold"
                  >
                    Change Photo
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Error notice */}
        {analysisError && (
          <div className="rounded-2xl bg-rose-950/40 border border-rose-800/60 p-4 text-xs sm:text-sm text-rose-200 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-rose-100">Analysis Error</p>
              <p className="text-rose-300 mt-0.5">{analysisError}</p>
            </div>
          </div>
        )}
      </div>

      {/* RESULTS DISPLAY */}
      {result && (
        <div className="rounded-3xl bg-slate-900/90 border border-indigo-500/40 p-6 sm:p-10 shadow-2xl backdrop-blur-xl space-y-8 animate-fade-in">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-2xl">{result.petType === 'cat' ? '🐈' : '🐕'}</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                  {result.detectedSubject}
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                Ethological posture analysis for {result.petName || result.petType}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-purple-600/20 text-purple-200 border border-purple-500/40">
                {result.primaryEmotion}
              </span>
              <span className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300">
                Confidence: <strong className="text-purple-300">{result.confidenceLevel.toUpperCase()}</strong>
              </span>
            </div>
          </div>

          {/* Detailed Summary */}
          <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800 text-sm sm:text-base text-slate-200 leading-relaxed">
            {result.detailedSummary}
          </div>

          {/* 4 Anatomical Focus Cards */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Anatomical Breakdown
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Ears */}
              <div className="rounded-2xl bg-slate-950 border border-slate-800 p-5 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-purple-300">
                  <span>👂</span>
                  <span>Ear Stance &amp; Rotation</span>
                </div>
                <p className="text-xs font-semibold text-white">
                  {result.bodyLanguageBreakdown.ears.observation}
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {result.bodyLanguageBreakdown.ears.meaning}
                </p>
              </div>

              {/* Tail */}
              <div className="rounded-2xl bg-slate-950 border border-slate-800 p-5 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-indigo-300">
                  <span>🐾</span>
                  <span>Tail Position &amp; Carriage</span>
                </div>
                <p className="text-xs font-semibold text-white">
                  {result.bodyLanguageBreakdown.tail.observation}
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {result.bodyLanguageBreakdown.tail.meaning}
                </p>
              </div>

              {/* Eyes */}
              <div className="rounded-2xl bg-slate-950 border border-slate-800 p-5 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-cyan-300">
                  <span>👁️</span>
                  <span>Eye Expression &amp; Aperture</span>
                </div>
                <p className="text-xs font-semibold text-white">
                  {result.bodyLanguageBreakdown.eyes.observation}
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {result.bodyLanguageBreakdown.eyes.meaning}
                </p>
              </div>

              {/* Posture */}
              <div className="rounded-2xl bg-slate-950 border border-slate-800 p-5 space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-pink-300">
                  <span>🧘</span>
                  <span>Body Posture &amp; Weight Balance</span>
                </div>
                <p className="text-xs font-semibold text-white">
                  {result.bodyLanguageBreakdown.posture.observation}
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {result.bodyLanguageBreakdown.posture.meaning}
                </p>
              </div>
            </div>
          </div>

          {/* Alternative Explanations */}
          {result.alternativeInterpretations && result.alternativeInterpretations.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Alternative Situational Explanations
              </h3>
              <div className="rounded-2xl bg-slate-950/60 p-4 border border-slate-800 space-y-1.5">
                {result.alternativeInterpretations.map((alt, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                    <span className="text-purple-400 font-bold">•</span>
                    <span>{alt}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Suggested Actions */}
          {result.suggestedActions && result.suggestedActions.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Recommended Guardian Actions
              </h3>
              <div className="rounded-2xl bg-emerald-950/20 border border-emerald-800/40 p-4 space-y-2">
                {result.suggestedActions.map((act, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-emerald-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                    <span>{act}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Limitations & Ethical Notice */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
            <ShieldAlert className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-slate-300">Ethological Limitations of Photographic Capture</p>
              <ul className="list-disc pl-4 space-y-0.5">
                {result.confidenceLimitations.map((lim, i) => (
                  <li key={i}>{lim}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Actions Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
            <div className="flex items-center gap-2">
              <button
                onClick={() => downloadBodyReport(result)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                <Download className="w-4 h-4" />
                Download Report (.html)
              </button>
              <button
                onClick={() => {
                  storage.toggleBodyFavorite(result.id);
                  setResult({
                    ...result,
                    isFavorite: !result.isFavorite,
                  });
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                  result.isFavorite
                    ? 'bg-purple-600/30 text-purple-200 border-purple-500'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                <Bookmark className="w-4 h-4" />
                {result.isFavorite ? 'Bookmarked' : 'Bookmark'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage('assistant')}
                className="px-4 py-2 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                Ask Assistant About Posture
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => {
                  setImagePreview(null);
                  setImageBase64(null);
                  setResult(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Analyze Another
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
