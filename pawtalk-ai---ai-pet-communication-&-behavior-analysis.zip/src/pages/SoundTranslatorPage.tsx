import React, { useState, useRef, useEffect } from 'react';
import { PetProfile, PetType, SoundAnalysisResult, PageId } from '../types';
import { AudioRecorder, blobToBase64 } from '../utils/audioRecorder';
import { storage } from '../utils/storage';
import { downloadSoundReport } from '../utils/reportGenerator';
import {
  Mic,
  Square,
  Play,
  Pause,
  Trash2,
  Upload,
  Sparkles,
  Volume2,
  Download,
  Bookmark,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  ArrowRight,
  ShieldCheck,
  Radio,
  FileAudio,
} from 'lucide-react';

interface SoundTranslatorPageProps {
  activePet: PetProfile | null;
  pets: PetProfile[];
  onSelectPet: (id: string) => void;
  setCurrentPage: (page: PageId) => void;
}

// Preset samples synthesized dynamically for quick testing on any device
const SAMPLE_PRESETS: {
  id: string;
  name: string;
  petType: PetType;
  description: string;
  toneType: 'sine' | 'triangle' | 'sawtooth';
  startFreq: number;
  endFreq: number;
}[] = [
  {
    id: 'sample-cat-trill',
    name: 'Cat Affiliative Trill',
    petType: 'cat',
    description: 'Harmonic rising greeting chirp (800Hz - 1200Hz)',
    toneType: 'sine',
    startFreq: 820,
    endFreq: 1180,
  },
  {
    id: 'sample-dog-alert',
    name: 'Dog Single Alert Bark',
    petType: 'dog',
    description: 'Resonant acoustic alert burst (360Hz - 480Hz)',
    toneType: 'triangle',
    startFreq: 460,
    endFreq: 320,
  },
  {
    id: 'sample-cat-demand',
    name: 'Cat Solicitation Meow',
    petType: 'cat',
    description: 'Extended mealtime call with high overtone',
    toneType: 'sine',
    startFreq: 600,
    endFreq: 950,
  },
  {
    id: 'sample-dog-whimper',
    name: 'Dog Attention Whimper',
    petType: 'dog',
    description: 'Soft high-pitched solicitous whimper',
    toneType: 'sine',
    startFreq: 1050,
    endFreq: 750,
  },
];

export const SoundTranslatorPage: React.FC<SoundTranslatorPageProps> = ({
  activePet,
  pets,
  onSelectPet,
  setCurrentPage,
}) => {
  // Selected pet type
  const [selectedPetType, setSelectedPetType] = useState<PetType>(activePet?.type || 'cat');
  const [contextNote, setContextNote] = useState('');

  // Audio recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);
  const recorderRef = useRef<AudioRecorder | null>(null);
  const timerRef = useRef<number | null>(null);

  // Audio playback state
  const [recordedAudio, setRecordedAudio] = useState<{
    blob: Blob;
    base64: string;
    mimeType: string;
    url: string;
    durationSeconds: number;
    fileName?: string;
  } | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);

  // Drag and drop state
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<SoundAnalysisResult | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Sync selected pet type if activePet changes
  useEffect(() => {
    if (activePet) {
      setSelectedPetType(activePet.type);
    }
  }, [activePet]);

  // Handle timer during recording
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      timerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRecording]);

  // Clean up audio playback on unmount
  useEffect(() => {
    return () => {
      if (recorderRef.current) {
        recorderRef.current.cancel();
      }
      if (recordedAudio?.url) {
        URL.revokeObjectURL(recordedAudio.url);
      }
    };
  }, [recordedAudio]);

  // Start recording
  const handleStartRecording = async () => {
    try {
      setAnalysisError(null);
      setAnalysisResult(null);
      const recorder = new AudioRecorder();
      recorderRef.current = recorder;
      await recorder.start((lvl) => setAudioLevel(lvl));
      setIsRecording(true);
    } catch (err: any) {
      console.error('Recording error:', err);
      setAnalysisError(
        'Could not access microphone. Please grant browser microphone permission or use the file upload / sample options below.'
      );
      setIsRecording(false);
    }
  };

  // Stop recording
  const handleStopRecording = async () => {
    if (!recorderRef.current) return;
    try {
      const res = await recorderRef.current.stop();
      setIsRecording(false);
      setRecordedAudio({
        blob: res.blob,
        base64: res.base64,
        mimeType: res.mimeType,
        url: res.audioUrl,
        durationSeconds: res.durationSeconds,
        fileName: `Recorded_${selectedPetType}_${Date.now()}.webm`,
      });
      recorderRef.current = null;
    } catch (err) {
      console.error('Error stopping recorder:', err);
      setIsRecording(false);
    }
  };

  // Play / Pause audio preview
  const handleTogglePlay = () => {
    if (!recordedAudio) return;
    if (!audioElementRef.current) {
      const audio = new Audio(recordedAudio.url);
      audioElementRef.current = audio;
      audio.onended = () => setIsPlayingAudio(false);
      audio.onerror = () => setIsPlayingAudio(false);
    }

    if (isPlayingAudio) {
      audioElementRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      audioElementRef.current.play().then(() => setIsPlayingAudio(true)).catch(() => setIsPlayingAudio(false));
    }
  };

  // Discard recording
  const handleDiscardAudio = () => {
    if (audioElementRef.current) {
      audioElementRef.current.pause();
      audioElementRef.current = null;
    }
    if (recordedAudio?.url) {
      URL.revokeObjectURL(recordedAudio.url);
    }
    setRecordedAudio(null);
    setIsPlayingAudio(false);
    setAnalysisResult(null);
    setAnalysisError(null);
  };

  // Process an uploaded file
  const handleProcessFile = async (file: File) => {
    try {
      setAnalysisError(null);
      setAnalysisResult(null);

      // Validate audio file
      if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|m4a|aac|ogg|webm)$/i)) {
        setAnalysisError('Please upload a valid audio file (MP3, WAV, M4A, OGG, or WEBM).');
        return;
      }

      if (file.size > 20 * 1024 * 1024) {
        setAnalysisError('File size exceeds 20MB. Please upload a shorter audio clip.');
        return;
      }

      const base64 = await blobToBase64(file);
      const url = URL.createObjectURL(file);

      setRecordedAudio({
        blob: file,
        base64,
        mimeType: file.type || 'audio/webm',
        url,
        durationSeconds: 5,
        fileName: file.name,
      });
    } catch (err) {
      console.error('File load error:', err);
      setAnalysisError('Failed to read audio file. Please try another audio format.');
    }
  };

  // Generate synthetic audio for sample presets
  const handleLoadSample = async (preset: typeof SAMPLE_PRESETS[0]) => {
    try {
      setSelectedPetType(preset.petType);
      setAnalysisError(null);
      setAnalysisResult(null);

      // Create a 2-second synthesized AudioBuffer and render to WAV/WebM blob
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const sampleRate = ctx.sampleRate;
      const duration = 1.8;
      const frameCount = sampleRate * duration;
      const buffer = ctx.createBuffer(1, frameCount, sampleRate);
      const data = buffer.getChannelData(0);

      for (let i = 0; i < frameCount; i++) {
        const t = i / sampleRate;
        const freq = preset.startFreq + (preset.endFreq - preset.startFreq) * (t / duration);
        const envelope = Math.sin((Math.PI * t) / duration); // bell curve envelope
        data[i] = Math.sin(2 * Math.PI * freq * t) * envelope * 0.4;
      }

      // Convert buffer to WAV blob
      const wavBlob = audioBufferToWav(buffer);
      const base64 = await blobToBase64(wavBlob);
      const url = URL.createObjectURL(wavBlob);

      setRecordedAudio({
        blob: wavBlob,
        base64,
        mimeType: 'audio/wav',
        url,
        durationSeconds: 2,
        fileName: `${preset.name}.wav`,
      });
    } catch (err) {
      console.error('Error generating sample:', err);
      setAnalysisError('Could not synthesize sample audio.');
    }
  };

  // WAV converter helper
  function audioBufferToWav(buffer: AudioBuffer): Blob {
    const numChannels = 1;
    const sampleRate = buffer.sampleRate;
    const format = 1; // PCM
    const bitDepth = 16;
    const bytesPerSample = bitDepth / 8;
    const blockAlign = numChannels * bytesPerSample;
    const data = buffer.getChannelData(0);
    const dataSize = data.length * bytesPerSample;
    const bufferSize = 44 + dataSize;
    const arrayBuffer = new ArrayBuffer(bufferSize);
    const view = new DataView(arrayBuffer);

    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, format, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);
    writeString(36, 'data');
    view.setUint32(40, dataSize, true);

    let offset = 44;
    for (let i = 0; i < data.length; i++) {
      const s = Math.max(-1, Math.min(1, data[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      offset += 2;
    }

    return new Blob([view], { type: 'audio/wav' });
  }

  // Submit audio to Gemini backend
  const handleAnalyzeAudio = async () => {
    if (!recordedAudio) return;

    setIsAnalyzing(true);
    setAnalysisError(null);
    setAnalysisResult(null);
    setSavedSuccess(false);

    try {
      const response = await fetch('/api/analyze-sound', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          petType: selectedPetType,
          audioBase64: recordedAudio.base64,
          mimeType: recordedAudio.mimeType,
          petName: activePet?.name,
          breed: activePet?.breed,
          context: contextNote.trim(),
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with status ${response.status}`);
      }

      const data = await response.json();

      const newResult: SoundAnalysisResult = {
        id: `sound-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        timestamp: Date.now(),
        petId: activePet?.id,
        petName: activePet?.name || (selectedPetType === 'cat' ? 'Cat' : 'Dog'),
        petType: selectedPetType,
        vocalizationDetected: data.vocalizationDetected !== false,
        detectedPetType: data.detectedPetType || (selectedPetType === 'cat' ? 'Cat' : 'Dog'),
        vocalizationType: data.vocalizationType || 'Acoustic Vocalization',
        emotion: data.emotion || 'Possibly seeking attention',
        confidenceLevel: data.confidenceLevel || 'medium',
        confidenceScore: data.confidenceScore || 75,
        soundCharacteristics: data.soundCharacteristics || {
          pitch: 'Mid-to-high frequency',
          intensity: 'Moderate',
          cadence: 'Rhythmic repetition',
          repetition: 'Multiple bursts',
        },
        humanExplanation: data.humanExplanation || 'Vocal pattern analyzed.',
        petQuote: data.petQuote || '',
        alternativeInterpretations: data.alternativeInterpretations || ['Situational stimulus reaction'],
        suggestedNextSteps: data.suggestedNextSteps || ['Acknowledge with gentle positive reinforcement.'],
        scientificNotes: data.scientificNotes,
        veterinaryDisclaimer: data.veterinaryDisclaimer,
        audioDurationSeconds: recordedAudio.durationSeconds,
      };

      setAnalysisResult(newResult);
      // Auto-save to history
      storage.addSoundResult(newResult);
      setSavedSuccess(true);
    } catch (err: any) {
      console.error('Analysis error:', err);
      setAnalysisError(err.message || 'Failed to analyze pet audio. Please verify your connection.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Get color badge based on emotion
  const getEmotionBadge = (emotion: string) => {
    switch (emotion) {
      case 'Possibly excited':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'Possibly anxious':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      case 'Possibly seeking attention':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      case 'Possibly hungry':
        return 'bg-orange-500/20 text-orange-300 border-orange-500/40';
      case 'Possibly playful':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      case 'Possibly uncomfortable':
        return 'bg-red-500/20 text-red-300 border-red-500/40';
      default:
        return 'bg-slate-700/40 text-slate-300 border-slate-600/40';
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      {/* Page Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 text-xs font-semibold uppercase tracking-wider border border-purple-500/20">
          <Volume2 className="w-3.5 h-3.5" />
          Flagship Bioacoustic Engine
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          AI Pet Sound Translator
        </h1>
        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto">
          Record or upload your dog or cat’s authentic vocalization. Multimodal bioacoustic modeling analyzes pitch, cadence, and harmonic structure to estimate emotional context.
        </p>
      </div>

      {/* Pet Selection & Active Profile Bar */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-md">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Target Species:</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedPetType('cat')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all border ${
                selectedPetType === 'cat'
                  ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
              }`}
            >
              <span>🐈</span> Cat
            </button>
            <button
              onClick={() => setSelectedPetType('dog')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all border ${
                selectedPetType === 'dog'
                  ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/30'
                  : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
              }`}
            >
              <span>🐕</span> Dog
            </button>
          </div>
        </div>

        {/* Linked Pet Profile */}
        <div className="flex items-center gap-2 text-xs text-slate-400 w-full sm:w-auto justify-end">
          <span>Profile context:</span>
          {pets.length > 0 ? (
            <select
              value={activePet?.id || ''}
              onChange={(e) => onSelectPet(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 text-xs font-medium outline-none focus:border-purple-500"
            >
              {pets.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.type})
                </option>
              ))}
            </select>
          ) : (
            <span className="text-slate-500 italic">No pet profiles</span>
          )}
        </div>
      </div>

      {/* Main Recording / Upload Container */}
      <div className="rounded-3xl bg-slate-900 border border-slate-700/80 p-6 sm:p-10 shadow-2xl space-y-8">
        {/* Step A: Live Recording Station */}
        <div className="text-center space-y-6">
          <div className="relative inline-flex items-center justify-center">
            {/* Visual pulse rings when recording */}
            {isRecording && (
              <>
                <div
                  style={{ transform: `scale(${1 + audioLevel / 80})` }}
                  className="absolute w-36 h-36 rounded-full bg-purple-500/20 animate-ping pointer-events-none transition-transform duration-100"
                />
                <div
                  style={{ transform: `scale(${1 + audioLevel / 100})` }}
                  className="absolute w-28 h-28 rounded-full bg-purple-600/30 pointer-events-none transition-transform duration-100"
                />
              </>
            )}

            {!isRecording ? (
              <button
                onClick={handleStartRecording}
                className="relative z-10 w-24 h-24 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white flex flex-col items-center justify-center shadow-xl shadow-purple-600/40 hover:scale-105 active:scale-95 transition-all group"
                title="Start Recording"
              >
                <Mic className="w-8 h-8 group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-bold mt-1 uppercase tracking-wider">Record</span>
              </button>
            ) : (
              <button
                onClick={handleStopRecording}
                className="relative z-10 w-24 h-24 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex flex-col items-center justify-center shadow-xl shadow-rose-600/40 animate-pulse transition-all"
                title="Stop Recording"
              >
                <Square className="w-8 h-8" />
                <span className="text-[10px] font-bold mt-1 uppercase tracking-wider">Stop</span>
              </button>
            )}
          </div>

          {/* Recording Timer & Audio Meter */}
          {isRecording ? (
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-mono font-bold border border-rose-500/30">
                <Radio className="w-3.5 h-3.5 animate-pulse" />
                Recording Live: 00:{recordingSeconds < 10 ? `0${recordingSeconds}` : recordingSeconds}
              </div>

              {/* Dynamic Sound Amplitude Level Bars */}
              <div className="flex items-center justify-center gap-1.5 h-10 max-w-xs mx-auto">
                {[15, 30, 60, 90, 100, 80, 45, 25, 60, 95, 70, 40].map((bar, i) => {
                  const activeHeight = Math.max(15, (audioLevel * bar) / 100);
                  return (
                    <div
                      key={i}
                      style={{ height: `${activeHeight}%` }}
                      className="w-2 rounded-full bg-gradient-to-t from-purple-500 to-cyan-400 transition-all duration-75"
                    />
                  );
                })}
              </div>
              <p className="text-xs text-slate-400">Speak or capture your pet’s natural sounds now</p>
            </div>
          ) : (
            <p className="text-xs text-slate-400">
              Click the microphone button to start recording (MediaRecorder API)
            </p>
          )}
        </div>

        {/* Divider with "OR" */}
        <div className="relative flex items-center justify-center">
          <div className="border-t border-slate-800 w-full" />
          <span className="bg-slate-900 px-4 text-xs font-semibold text-slate-500 uppercase tracking-widest absolute">
            or upload audio file
          </span>
        </div>

        {/* Step B: Drag and Drop Upload Box */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
              handleProcessFile(e.dataTransfer.files[0]);
            }
          }}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-purple-400 bg-purple-500/10'
              : 'border-slate-700/80 hover:border-purple-500/50 bg-slate-950/40 hover:bg-slate-950/80'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.webm"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleProcessFile(e.target.files[0]);
              }
            }}
          />
          <div className="flex flex-col items-center justify-center space-y-2">
            <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center">
              <Upload className="w-5 h-5" />
            </div>
            <p className="text-sm font-semibold text-white">
              Drag &amp; drop an audio file here, or{' '}
              <span className="text-purple-400 underline">browse device</span>
            </p>
            <p className="text-xs text-slate-400">
              Supports MP3, WAV, M4A, AAC, WEBM, OGG (Up to 20MB)
            </p>
          </div>
        </div>

        {/* Step C: Quick Test Audio Presets */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Need an instant sample to test?
            </span>
            <span className="text-slate-500">Synthesized Bioacoustic Samples</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {SAMPLE_PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleLoadSample(preset)}
                className="p-3 rounded-xl bg-slate-950/70 hover:bg-purple-950/40 border border-slate-800 hover:border-purple-500/40 text-left transition-all group"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-bold text-slate-200 group-hover:text-purple-300">
                    {preset.petType === 'cat' ? '🐈' : '🐕'} {preset.name}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-1">{preset.description}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Audio Preview & Context Input (When Audio is Ready) */}
        {recordedAudio && (
          <div className="rounded-2xl bg-slate-950 border border-purple-500/40 p-5 space-y-4 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleTogglePlay}
                  className="w-10 h-10 rounded-xl bg-purple-600 hover:bg-purple-500 text-white flex items-center justify-center flex-shrink-0 transition-transform active:scale-95 shadow-md"
                  title={isPlayingAudio ? 'Pause' : 'Play Audio'}
                >
                  {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>
                <div className="truncate">
                  <p className="text-sm font-semibold text-white truncate flex items-center gap-1.5">
                    <FileAudio className="w-4 h-4 text-purple-400 flex-shrink-0" />
                    {recordedAudio.fileName || 'Pet Audio Recording'}
                  </p>
                  <p className="text-xs text-slate-400">
                    Duration: ~{recordedAudio.durationSeconds}s | Format: {recordedAudio.mimeType}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleDiscardAudio}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-950/50 text-slate-400 hover:text-rose-300 text-xs font-medium flex items-center gap-1.5 border border-slate-800 hover:border-rose-700/50 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Discard
                </button>
              </div>
            </div>

            {/* Optional situational note */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Situational Context (Optional):
              </label>
              <input
                type="text"
                placeholder="e.g. Near the food bowl, seeing a dog through the window, after a nap"
                value={contextNote}
                onChange={(e) => setContextNote(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 focus:border-purple-500 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>

            {/* Trigger AI Analysis button */}
            <div className="pt-2">
              <button
                onClick={handleAnalyzeAudio}
                disabled={isAnalyzing}
                className={`w-full py-3.5 rounded-xl font-bold text-sm text-white flex items-center justify-center gap-2 shadow-lg transition-all ${
                  isAnalyzing
                    ? 'bg-slate-800 cursor-not-allowed text-slate-400'
                    : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-500 hover:to-indigo-500 shadow-purple-600/30 active:scale-[0.99]'
                }`}
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Analyzing Bioacoustics with Gemini...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-purple-200" />
                    <span>Analyze Vocalization with AI</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Error message */}
        {analysisError && (
          <div className="rounded-2xl bg-rose-950/40 border border-rose-800/60 p-4 text-rose-200 text-xs sm:text-sm flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-rose-100">Unable to complete analysis</p>
              <p className="text-rose-300 leading-relaxed">{analysisError}</p>
            </div>
          </div>
        )}
      </div>

      {/* RESULTS DISPLAY DASHBOARD */}
      {analysisResult && (
        <div className="rounded-3xl bg-slate-900/90 border border-purple-500/40 p-6 sm:p-10 shadow-2xl backdrop-blur-xl space-y-8 animate-fade-in">
          {/* Result Header & Emotion Badge */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-2xl">{analysisResult.petType === 'cat' ? '🐈' : '🐕'}</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                  {analysisResult.vocalizationType}
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                Analyzed for {analysisResult.petName || analysisResult.petType} at{' '}
                {new Date(analysisResult.timestamp).toLocaleTimeString()}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold border ${getEmotionBadge(
                  analysisResult.emotion
                )}`}
              >
                {analysisResult.emotion}
              </span>

              <div className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300">
                <span className="text-slate-400">Confidence: </span>
                <strong className="text-purple-300 capitalize">
                  {analysisResult.confidenceLevel}{' '}
                  {analysisResult.confidenceScore ? `(${analysisResult.confidenceScore}%)` : ''}
                </strong>
              </div>
            </div>
          </div>

          {/* Non-vocalization warning if audio had no pet sound */}
          {!analysisResult.vocalizationDetected && (
            <div className="rounded-2xl bg-amber-950/40 border border-amber-800/60 p-4 text-xs text-amber-200 flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <strong>Acoustic Note:</strong> No clear domestic cat or dog vocalization was identifiable in this audio segment. The audio may contain ambient room noise, silence, or human speech.
              </div>
            </div>
          )}

          {/* Playful Pet Quote */}
          {analysisResult.petQuote && (
            <div className="rounded-2xl bg-gradient-to-r from-purple-900/30 via-indigo-900/20 to-slate-950 border border-purple-500/30 p-5 relative overflow-hidden">
              <div className="flex items-center gap-2 text-xs font-bold text-purple-300 uppercase tracking-wider mb-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Playful Pet Interpretation (Non-Literal)
              </div>
              <p className="text-base sm:text-lg font-medium text-slate-100 italic">
                {analysisResult.petQuote}
              </p>
            </div>
          )}

          {/* Explanation */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Human Language Explanation
            </h3>
            <p className="text-sm sm:text-base text-slate-200 leading-relaxed bg-slate-950/60 p-5 rounded-2xl border border-slate-800">
              {analysisResult.humanExplanation}
            </p>
          </div>

          {/* Sound Characteristics Breakdown Grid */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Sound Characteristics
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Pitch</span>
                <p className="text-xs sm:text-sm font-bold text-purple-300 mt-1">
                  {analysisResult.soundCharacteristics.pitch}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Intensity</span>
                <p className="text-xs sm:text-sm font-bold text-indigo-300 mt-1">
                  {analysisResult.soundCharacteristics.intensity}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Cadence</span>
                <p className="text-xs sm:text-sm font-bold text-cyan-300 mt-1">
                  {analysisResult.soundCharacteristics.cadence}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Repetition</span>
                <p className="text-xs sm:text-sm font-bold text-slate-200 mt-1">
                  {analysisResult.soundCharacteristics.repetition}
                </p>
              </div>
            </div>
          </div>

          {/* Alternative Interpretations */}
          {analysisResult.alternativeInterpretations &&
            analysisResult.alternativeInterpretations.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Alternative Interpretations
                </h3>
                <div className="rounded-2xl bg-slate-950/60 p-4 border border-slate-800 space-y-2">
                  {analysisResult.alternativeInterpretations.map((alt, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                      <span className="text-purple-400 font-bold">•</span>
                      <span>{alt}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

          {/* Suggested Next Steps */}
          {analysisResult.suggestedNextSteps && analysisResult.suggestedNextSteps.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Suggested Guardian Next Steps
              </h3>
              <div className="rounded-2xl bg-emerald-950/20 border border-emerald-800/40 p-4 space-y-2">
                {analysisResult.suggestedNextSteps.map((step, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-emerald-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Scientific Notes */}
          {analysisResult.scientificNotes && (
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 leading-relaxed">
              <strong className="text-purple-300">Bioacoustic Scientific Context: </strong>
              {analysisResult.scientificNotes}
            </div>
          )}

          {/* Clear Notice Banner */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-start gap-3 text-xs text-slate-400">
            <ShieldCheck className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
            <p>
              <strong>Notice:</strong> These are AI behavioral hypotheses based on bioacoustic modeling and companion animal ethology. They are not literal word-for-word human translations or veterinary medical diagnoses.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800">
            <div className="flex items-center gap-2">
              <button
                onClick={() => downloadSoundReport(analysisResult)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                <Download className="w-4 h-4" />
                Download Report (.html)
              </button>
              <button
                onClick={() => {
                  storage.toggleSoundFavorite(analysisResult.id);
                  setAnalysisResult({
                    ...analysisResult,
                    isFavorite: !analysisResult.isFavorite,
                  });
                }}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                  analysisResult.isFavorite
                    ? 'bg-purple-600/30 text-purple-200 border-purple-500'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                <Bookmark className="w-4 h-4" />
                {analysisResult.isFavorite ? 'Bookmarked' : 'Bookmark'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage('assistant')}
                className="px-4 py-2 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all"
              >
                Ask Assistant About This
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => {
                  handleDiscardAudio();
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Analyze Another
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
