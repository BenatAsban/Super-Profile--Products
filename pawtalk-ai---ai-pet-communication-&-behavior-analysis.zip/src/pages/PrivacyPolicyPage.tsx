import React from 'react';
import { Shield, Lock, HardDrive, Cpu, CheckCircle } from 'lucide-react';

export const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 text-xs font-semibold uppercase tracking-wider border border-purple-500/20">
          <Shield className="w-3.5 h-3.5" />
          Transparency &amp; Trust
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white">Privacy Policy &amp; Ethics</h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Last revised: November 2026 • Commitment to secure animal data handling
        </p>
      </div>

      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-8 sm:p-10 space-y-8 text-xs sm:text-sm text-slate-300 leading-relaxed">
        {/* Section 1 */}
        <section className="space-y-3">
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-purple-400" />
            1. Audio and Photographic Processing
          </h2>
          <p>
            When you record animal vocalizations or upload pet photographs to PawTalk AI, that data is transmitted securely to our backend server and passed to the Google Gemini multimodal API solely for the purpose of generating your behavioral interpretation.
          </p>
          <p>
            Audio streams and images are processed in-memory. PawTalk AI does not sell, broker, or trade your pet recordings or household photographs to third-party data brokers or advertisement networks.
          </p>
        </section>

        {/* Section 2 */}
        <section className="space-y-3">
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-indigo-400" />
            2. LocalStorage &amp; On-Device History
          </h2>
          <p>
            Your pet profiles, analysis history, bookmarked favorites, and activity notes are stored locally within your browser using the HTML5 LocalStorage API. You maintain total sovereignty over this data: you can delete individual history records, clear your history logs, or reset all pet profiles directly through the interface at any time.
          </p>
        </section>

        {/* Section 3 */}
        <section className="space-y-3">
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            3. Artificial Intelligence &amp; Model Guardrails
          </h2>
          <p>
            Our prompts explicitly enforce companion animal welfare standards. The AI is strictly instructed to refrain from generating medical prescriptions, pharmacological dosages, or surgical diagnoses, and to always prioritize animal safety and prompt veterinary intervention for red flag symptoms.
          </p>
        </section>

        {/* Section 4 */}
        <section className="space-y-3">
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            4. User Rights &amp; Support
          </h2>
          <p>
            If you have questions regarding data privacy, bioacoustics processing, or behavioral research standards, please reach out to our team at{' '}
            <span className="text-purple-400 font-semibold">privacy@pawtalk.ai</span> or submit an inquiry through our Contact page.
          </p>
        </section>
      </div>
    </div>
  );
};
