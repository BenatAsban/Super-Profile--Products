import React, { useState } from 'react';
import { PageId } from '../types';
import {
  Volume2,
  Eye,
  LayoutDashboard,
  MessageSquare,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Play,
  Pause,
  HelpCircle,
  Activity,
  HeartHandshake,
} from 'lucide-react';

interface HomePageProps {
  setCurrentPage: (page: PageId) => void;
}

interface DemoSample {
  id: string;
  type: 'cat' | 'dog';
  title: string;
  subtitle: string;
  soundType: string;
  emotion: string;
  confidence: string;
  pitch: string;
  explanation: string;
  quote: string;
  action: string;
  soundFrequency: number[];
}

const DEMO_SAMPLES: DemoSample[] = [
  {
    id: 'demo-1',
    type: 'cat',
    title: 'Luna’s Affiliative Trill',
    subtitle: 'Recorded during morning greeting',
    soundType: 'Chirp & Harmonic Trill',
    emotion: 'Possibly excited',
    confidence: '88% High',
    pitch: 'High rising (850Hz - 1.4kHz)',
    explanation:
      'In feline ethology, trilling with a closed mouth is an evolutionary maternal contact greeting preserved in domestic cat-human relationships.',
    quote: '"I\'m delighted to see you awake! Let\'s start our day together."',
    action: 'Offer a slow-blink greeting, check breakfast bowl, or engage in 5 mins of play.',
    soundFrequency: [30, 45, 60, 85, 95, 75, 50, 40, 65, 80, 55, 30],
  },
  {
    id: 'demo-2',
    type: 'dog',
    title: 'Milo’s Isolated Alert Bark',
    subtitle: 'Recorded when mail carrier approached',
    soundType: 'Resonant Single Alert Bark',
    emotion: 'Possibly seeking attention',
    confidence: '82% High',
    pitch: 'Mid-to-low resonant (380Hz - 520Hz)',
    explanation:
      'A single or spaced bark with low pitch and pause serves as a canine situational beacon to inform the family pack of perimeter movement.',
    quote: '"Hey family! There is movement outside our perimeter, just making sure you know!"',
    action: 'Acknowledge calmly with "Thank you, all good" to de-escalate without rewarding frantic arousal.',
    soundFrequency: [20, 30, 85, 100, 90, 40, 20, 15, 20, 25, 20, 15],
  },
  {
    id: 'demo-3',
    type: 'cat',
    title: 'Cleo’s Dinner Demand Meow',
    subtitle: 'Recorded near pantry at 6:00 PM',
    soundType: 'Long Drawn-Out Solicitation Meow',
    emotion: 'Possibly hungry',
    confidence: '90% High',
    pitch: 'Modulated mid-to-high pitch',
    explanation:
      'Solicitation meows contain high-frequency acoustic elements that domestic cats evolved specifically to trigger human parental caregiving instincts.',
    quote: '"Dinner schedule alert! It is exactly 18:00 and my bowl is looking unusually empty."',
    action: 'Verify regular feeding schedule and ensure fresh water is accessible.',
    soundFrequency: [35, 50, 70, 90, 85, 95, 80, 70, 60, 45, 30, 20],
  },
  {
    id: 'demo-4',
    type: 'dog',
    title: 'Cooper’s Play Bow & Chuff',
    subtitle: 'Recorded during yard game',
    soundType: 'Soft Expiratory Chuff & Play Whimper',
    emotion: 'Possibly playful',
    confidence: '85% High',
    pitch: 'Variable light breathy pitch',
    explanation:
      'Play chuffing accompanied by lowered front elbows signifies ritualized meta-communication that subsequent rough behavior is entirely friendly.',
    quote: '"Look at this toy! I am going to chase you and you cannot catch me!"',
    action: 'Engage in structured tug-of-war or retrieve games with clear release commands.',
    soundFrequency: [25, 40, 65, 75, 60, 80, 70, 50, 40, 30, 20, 15],
  },
];

const FAQS = [
  {
    q: 'Does PawTalk AI claim to literally translate pet sounds into exact human sentences?',
    a: 'No. Authentic animal welfare science does not support word-for-word human translations of animal vocalizations. PawTalk AI analyzes bioacoustic frequency, pitch contour, cadence, repetition, and ethological body language markers to estimate behavioral intentions, emotional arousal, and communicative states.',
  },
  {
    q: 'How does the Gemini multimodal analysis work for pet audio?',
    a: 'When you record or upload your pet’s vocalization, the audio stream is passed directly to Google Gemini’s multimodal engine. The AI evaluates acoustic characteristics such as pitch range, intensity, and rhythm against documented feline and canine bioacoustic research, returning structured interpretations, confidence scores, and care recommendations.',
  },
  {
    q: 'Can PawTalk AI replace a veterinary examination?',
    a: 'Absolutely not. PawTalk AI is an educational and communication companion tool. Any sudden change in vocalization, lethargy, loss of appetite, whimpering from physical touch, or persistent distress should always be immediately examined by a licensed veterinarian.',
  },
  {
    q: 'How does the Body Language Analyzer work?',
    a: 'You can upload or photograph your pet. Our vision model inspects anatomical markers—for cats: ear angle, pupil dilation, tail curvature, and body tension; for dogs: tail carriage, ear stance, commissure relaxation, and weight distribution—to provide contextual behavioral insights.',
  },
  {
    q: 'Can I track multiple pets over time?',
    a: 'Yes! The Pet Mood Dashboard allows you to create individual profiles for multiple cats and dogs, log their vocal and body language analyses, note daily behavioral patterns, and track emotional states over time.',
  },
];

export const HomePage: React.FC<HomePageProps> = ({ setCurrentPage }) => {
  const [selectedDemo, setSelectedDemo] = useState<DemoSample>(DEMO_SAMPLES[0]);
  const [isPlayingDemo, setIsPlayingDemo] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Synthesize simulated acoustic audio tone on demo play for interactive fidelity
  const handleToggleDemoPlay = () => {
    if (isPlayingDemo) {
      setIsPlayingDemo(false);
      return;
    }

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      const isCat = selectedDemo.type === 'cat';
      osc.type = isCat ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(isCat ? 650 : 280, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(isCat ? 1100 : 380, ctx.currentTime + 0.4);

      gain.gain.setValueAtTime(0.01, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.9);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.95);
      setIsPlayingDemo(true);
      setTimeout(() => setIsPlayingDemo(false), 1200);
    } catch {
      setIsPlayingDemo(true);
      setTimeout(() => setIsPlayingDemo(false), 1200);
    }
  };

  return (
    <div className="space-y-24 sm:space-y-32 pb-24">
      {/* HERO SECTION */}
      <section className="relative pt-12 sm:pt-20 lg:pt-24 overflow-hidden">
        {/* Glow ambient background orbs */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-gradient-to-tr from-purple-600/20 via-indigo-600/15 to-cyan-500/10 blur-[130px] rounded-full pointer-events-none -z-10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Eyebrow badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-purple-500/30 text-purple-300 text-xs sm:text-sm font-medium mb-8 backdrop-blur-xl shadow-lg shadow-purple-500/10">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>Next-Generation Bioacoustic Pet Communication</span>
          </div>

          {/* Hero headline */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-4xl mx-auto leading-[1.12]">
            Your Pet Has Something to{' '}
            <span className="bg-gradient-to-r from-purple-400 via-violet-300 to-indigo-300 bg-clip-text text-transparent">
              Tell You.
            </span>
          </h1>

          {/* Subtitle */}
          <p className="mt-6 text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Discover what your furry friend might be feeling with AI-powered sound and behaviour analysis.
          </p>

          {/* Hero Buttons */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => setCurrentPage('sound-translator')}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-base shadow-xl shadow-purple-600/30 hover:shadow-purple-600/50 flex items-center justify-center gap-2.5 transform hover:-translate-y-0.5 transition-all"
            >
              <Volume2 className="w-5 h-5 text-purple-200" />
              <span>Analyse My Pet</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            <button
              onClick={() => {
                const el = document.getElementById('features-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white font-semibold text-base border border-slate-700/80 hover:border-slate-600 shadow-md flex items-center justify-center gap-2 transition-all"
            >
              Explore Features
            </button>
          </div>

          {/* Floating Pet Badges */}
          <div className="mt-14 max-w-3xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 text-left">
            <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800/80 backdrop-blur-md">
              <div className="text-2xl mb-1">🐈</div>
              <p className="text-xs font-semibold text-white">Cat Bioacoustics</p>
              <p className="text-[11px] text-slate-400">Trills, purrs, demand meows, &amp; hisses</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800/80 backdrop-blur-md">
              <div className="text-2xl mb-1">🐕</div>
              <p className="text-xs font-semibold text-white">Dog Vocalizations</p>
              <p className="text-[11px] text-slate-400">Alerts, play growls, whines, &amp; bays</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800/80 backdrop-blur-md">
              <div className="text-2xl mb-1">🔍</div>
              <p className="text-xs font-semibold text-white">Ethology Vision</p>
              <p className="text-[11px] text-slate-400">Ears, tail posture, &amp; micro-expressions</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800/80 backdrop-blur-md">
              <div className="text-2xl mb-1">🛡️</div>
              <p className="text-xs font-semibold text-white">Vet-Aligned Ethics</p>
              <p className="text-[11px] text-slate-400">Zero gimmick fake human speech claims</p>
            </div>
          </div>
        </div>
      </section>

      {/* INTERACTIVE DEMO TEST DRIVE SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Interactive Test Drive
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Hear &amp; Interpret Real Animal Cues
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-2">
            Select an acoustic scenario below to test our multimodal behavioral pipeline in action.
          </p>
        </div>

        {/* Demo Selector Tabs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 mb-6">
          {DEMO_SAMPLES.map((sample) => (
            <button
              key={sample.id}
              onClick={() => setSelectedDemo(sample)}
              className={`p-3.5 rounded-2xl text-left border transition-all ${
                selectedDemo.id === sample.id
                  ? 'bg-gradient-to-br from-purple-900/50 to-indigo-950/60 border-purple-500/80 shadow-lg shadow-purple-500/20 ring-1 ring-purple-400/40'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xl">{sample.type === 'cat' ? '🐈' : '🐕'}</span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    selectedDemo.id === sample.id
                      ? 'bg-purple-500 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {sample.type.toUpperCase()}
                </span>
              </div>
              <p className="text-xs font-bold text-white truncate">{sample.title}</p>
              <p className="text-[11px] text-slate-400 truncate">{sample.soundType}</p>
            </button>
          ))}
        </div>

        {/* Active Demo Card */}
        <div className="rounded-3xl bg-slate-900/90 border border-slate-700/80 p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative overflow-hidden">
          <div className="flex flex-col lg:flex-row gap-8 items-start lg:items-center justify-between">
            {/* Left: Audio waveform preview & Play control */}
            <div className="space-y-4 flex-1">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{selectedDemo.type === 'cat' ? '🐈' : '🐕'}</span>
                <div>
                  <h3 className="text-xl font-bold text-white">{selectedDemo.title}</h3>
                  <p className="text-xs text-slate-400">{selectedDemo.subtitle}</p>
                </div>
              </div>

              {/* Waveform graphic */}
              <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 flex items-center gap-3">
                <button
                  onClick={handleToggleDemoPlay}
                  className="w-12 h-12 rounded-xl bg-purple-600 hover:bg-purple-500 text-white flex items-center justify-center flex-shrink-0 transition-transform active:scale-95 shadow-md shadow-purple-600/30"
                  title="Play demo acoustic tone"
                >
                  {isPlayingDemo ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                </button>
                <div className="flex-1 flex items-end gap-1.5 h-12 px-2">
                  {selectedDemo.soundFrequency.map((height, i) => (
                    <div
                      key={i}
                      style={{ height: `${height}%` }}
                      className={`flex-1 rounded-full transition-all duration-300 ${
                        isPlayingDemo
                          ? 'bg-gradient-to-t from-purple-500 to-cyan-400 animate-pulse'
                          : 'bg-slate-700'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-xs font-mono text-purple-300 px-2 py-1 bg-purple-950/50 rounded-lg border border-purple-800/40">
                  {selectedDemo.pitch}
                </span>
              </div>
            </div>

            {/* Right: AI Ethology Interpretation */}
            <div className="flex-1 bg-slate-950/70 rounded-2xl p-6 border border-slate-800/90 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 uppercase font-semibold">AI Emotional State:</span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-purple-600/30 text-purple-200 border border-purple-500/40">
                    {selectedDemo.emotion}
                  </span>
                </div>
                <span className="text-xs text-emerald-400 font-semibold bg-emerald-950/50 px-2 py-0.5 rounded-full border border-emerald-800/40">
                  {selectedDemo.confidence}
                </span>
              </div>

              {/* Playful quote */}
              <div className="bg-gradient-to-r from-purple-900/20 to-indigo-900/20 border-l-4 border-purple-500 p-3 rounded-r-xl">
                <p className="text-xs text-purple-300 font-semibold uppercase tracking-wider mb-0.5">
                  Playful Pet Perspective
                </p>
                <p className="text-sm font-medium text-slate-100 italic">{selectedDemo.quote}</p>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {selectedDemo.explanation}
              </p>

              <div className="text-xs text-slate-400 bg-slate-900/90 p-3 rounded-xl border border-slate-800">
                <strong className="text-purple-300">Guardian Next Step: </strong>
                {selectedDemo.action}
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
            <span>Ready to test with your pet’s genuine voice?</span>
            <button
              onClick={() => setCurrentPage('sound-translator')}
              className="text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1 group"
            >
              Open Live Sound Translator
              <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* HOW PAWTALK AI WORKS (3-STEP FLOW) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-bold text-purple-400 uppercase tracking-widest">
            Evidence-Based Methodology
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
            How PawTalk AI Works
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-2">
            A three-tier synthesis of acoustic signal processing, feline/canine ethology, and Google Gemini AI.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Step 1 */}
          <div className="rounded-3xl bg-slate-900/70 border border-slate-800 p-8 relative hover:border-purple-500/40 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/20 text-purple-400 flex items-center justify-center font-black text-xl mb-6 border border-purple-500/30 group-hover:scale-110 transition-transform">
              1
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Record or Upload</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Capture your pet’s vocalization directly through your browser’s high-fidelity microphone or upload any MP3, WAV, or M4A audio clip.
            </p>
          </div>

          {/* Step 2 */}
          <div className="rounded-3xl bg-slate-900/70 border border-slate-800 p-8 relative hover:border-purple-500/40 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-black text-xl mb-6 border border-indigo-500/30 group-hover:scale-110 transition-transform">
              2
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Multimodal Analysis</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Google Gemini evaluates pitch frequency, vocal burst rhythm, repetition cadence, and species-specific ethological rules securely on the server.
            </p>
          </div>

          {/* Step 3 */}
          <div className="rounded-3xl bg-slate-900/70 border border-slate-800 p-8 relative hover:border-purple-500/40 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center font-black text-xl mb-6 border border-cyan-500/30 group-hover:scale-110 transition-transform">
              3
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Actionable Insight</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Receive nuanced emotional interpretations, alternative hypotheses, confidence metrics, and caring guardian actions to nurture your companion.
            </p>
          </div>
        </div>
      </section>

      {/* CORE FEATURES SHOWCASE */}
      <section id="features-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold text-purple-400 uppercase tracking-widest">
            Comprehensive Suite
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
            Engineered for Modern Pet Guardians
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-2">
            Everything you need to decode communication, track emotional wellness, and nurture mutual trust.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Feature 1: Sound Translator */}
          <div className="rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-8 hover:border-purple-500/50 transition-all flex flex-col justify-between">
            <div>
              <div className="w-14 h-14 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-6">
                <Volume2 className="w-7 h-7" />
              </div>
              <div className="inline-block text-[11px] font-semibold text-purple-300 bg-purple-950/60 px-2.5 py-0.5 rounded-full border border-purple-800/40 mb-3">
                Flagship Bioacoustic Engine
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">AI Pet Sound Translator</h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Real-time browser audio recording and file uploads. Maps acoustic contours to plausible feline and canine states: from excited greetings and demand cries to discomfort alerts.
              </p>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-400 flex-shrink-0" />
                  <span>Real audio capture via MediaRecorder with dynamic level meter</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-400 flex-shrink-0" />
                  <span>Bioacoustic pitch, intensity, repetition &amp; cadence profiling</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-400 flex-shrink-0" />
                  <span>Exportable PDF/HTML ethology reports</span>
                </li>
              </ul>
            </div>
            <div className="pt-8">
              <button
                onClick={() => setCurrentPage('sound-translator')}
                className="w-full py-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-200 border border-purple-500/40 font-semibold text-sm flex items-center justify-center gap-2 transition-all"
              >
                Launch Sound Translator <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Feature 2: Body Language Analyzer */}
          <div className="rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-8 hover:border-indigo-500/50 transition-all flex flex-col justify-between">
            <div>
              <div className="w-14 h-14 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-6">
                <Eye className="w-7 h-7" />
              </div>
              <div className="inline-block text-[11px] font-semibold text-indigo-300 bg-indigo-950/60 px-2.5 py-0.5 rounded-full border border-indigo-800/40 mb-3">
                Vision &amp; Posture Modeling
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">Body Language Vision Analyzer</h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Upload a pet photo. Our vision system evaluates anatomical markers including ear angle, tail position, pupil state, and muscular tension.
              </p>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                  <span>4-point anatomical inspection (Ears, Tail, Eyes, Posture)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                  <span>Explains alternative situational factors (temperature, resting fatigue)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                  <span>Transparent visual limitations &amp; confidence scores</span>
                </li>
              </ul>
            </div>
            <div className="pt-8">
              <button
                onClick={() => setCurrentPage('body-language')}
                className="w-full py-3 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-200 border border-indigo-500/40 font-semibold text-sm flex items-center justify-center gap-2 transition-all"
              >
                Analyze Body Language <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Feature 3: Pet Mood Dashboard */}
          <div className="rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-8 hover:border-cyan-500/50 transition-all flex flex-col justify-between">
            <div>
              <div className="w-14 h-14 rounded-2xl bg-cyan-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-6">
                <LayoutDashboard className="w-7 h-7" />
              </div>
              <div className="inline-block text-[11px] font-semibold text-cyan-300 bg-cyan-950/60 px-2.5 py-0.5 rounded-full border border-cyan-800/40 mb-3">
                Multi-Pet Management
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">Pet Mood &amp; Activity Dashboard</h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Manage multiple cat and dog profiles. Review longitudinal emotional trends, bookmark key vocal moments, and log behavioral notes in one unified hub.
              </p>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  <span>Multi-pet profiles with custom avatars &amp; traits</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  <span>Filterable timeline of sound &amp; body language analyses</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  <span>Favorite bookmarks &amp; timestamped activity logs</span>
                </li>
              </ul>
            </div>
            <div className="pt-8">
              <button
                onClick={() => setCurrentPage('dashboard')}
                className="w-full py-3 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-200 border border-cyan-500/40 font-semibold text-sm flex items-center justify-center gap-2 transition-all"
              >
                Open Mood Dashboard <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Feature 4: 24/7 AI Behavior Assistant */}
          <div className="rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-8 hover:border-pink-500/50 transition-all flex flex-col justify-between">
            <div>
              <div className="w-14 h-14 rounded-2xl bg-pink-600/20 border border-pink-500/30 flex items-center justify-center text-pink-400 mb-6">
                <MessageSquare className="w-7 h-7" />
              </div>
              <div className="inline-block text-[11px] font-semibold text-pink-300 bg-pink-950/60 px-2.5 py-0.5 rounded-full border border-pink-800/40 mb-3">
                Context-Aware Companion
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">AI Pet Behavior Assistant</h3>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Have ongoing conversations with an empathetic companion ethologist. Ask about barking triggers, nighttime zoomies, litter box hesitance, or greeting habits.
              </p>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-pink-400 flex-shrink-0" />
                  <span>Personalized advice matched to your active pet profile</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-pink-400 flex-shrink-0" />
                  <span>Positive reinforcement strategies and enrichment ideas</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-pink-400 flex-shrink-0" />
                  <span>Safe boundaries: urges veterinary visit for medical red flags</span>
                </li>
              </ul>
            </div>
            <div className="pt-8">
              <button
                onClick={() => setCurrentPage('assistant')}
                className="w-full py-3 rounded-xl bg-pink-600/20 hover:bg-pink-600/30 text-pink-200 border border-pink-500/40 font-semibold text-sm flex items-center justify-center gap-2 transition-all"
              >
                Chat with Assistant <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SCIENTIFIC ETHICS & BENEFITS BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-purple-900/40 via-indigo-900/30 to-slate-900 border border-purple-500/30 p-8 sm:p-12 relative overflow-hidden">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-semibold">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              Ethological Science Promise
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
              Why We Never Invent Fake Translations
            </h2>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Animals do not speak human syntax. Claiming that an app can translate a meow into "I want salmon now" is gimmicky fiction. Instead, PawTalk AI respects animal cognition by analyzing pitch trajectories, acoustic arousal, and contextual posturing—providing owners with genuine ethological empathy.
            </p>
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="flex items-center gap-2 text-slate-200 font-medium">
                <HeartHandshake className="w-4 h-4 text-purple-400" />
                <span>Strengthens the Human-Animal Bond</span>
              </div>
              <div className="flex items-center gap-2 text-slate-200 font-medium">
                <Activity className="w-4 h-4 text-purple-400" />
                <span>Bioacoustic Pattern Detection</span>
              </div>
              <div className="flex items-center gap-2 text-slate-200 font-medium">
                <ShieldCheck className="w-4 h-4 text-purple-400" />
                <span>Veterinary Boundary Safety</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FREQUENTLY ASKED QUESTIONS */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-purple-300 text-xs font-semibold uppercase tracking-wider mb-2 border border-slate-800">
            <HelpCircle className="w-3.5 h-3.5 text-purple-400" />
            Questions &amp; Clarity
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Frequently Asked Questions
          </h2>
          <p className="text-slate-400 text-sm mt-2">
            Clear, transparent answers about our animal bioacoustics technology.
          </p>
        </div>

        <div className="space-y-4">
          {FAQS.map((faq, index) => {
            const isOpen = openFaqIndex === index;
            return (
              <div
                key={index}
                className="rounded-2xl bg-slate-900/80 border border-slate-800 transition-all overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                  className="w-full px-6 py-5 text-left flex items-center justify-between text-base font-semibold text-white hover:text-purple-300 transition-colors"
                >
                  <span className="pr-4">{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-5 h-5 text-purple-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400 flex-shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="px-6 pb-6 text-sm text-slate-400 leading-relaxed border-t border-slate-800/60 pt-4">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* BOTTOM CTA BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-cyan-500 p-8 sm:p-14 text-center text-white relative shadow-2xl overflow-hidden">
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
              Ready to Understand Your Furry Companion?
            </h2>
            <p className="text-purple-100 text-sm sm:text-base leading-relaxed">
              Start with a single sound recording or photograph. No credit card required. Free bioacoustic analysis powered by Google Gemini.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
              <button
                onClick={() => setCurrentPage('sound-translator')}
                className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-white text-slate-950 hover:bg-slate-100 font-extrabold text-base shadow-xl transition-all"
              >
                Translate Pet Sound Now
              </button>
              <button
                onClick={() => setCurrentPage('body-language')}
                className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-purple-950/40 hover:bg-purple-950/60 text-white font-semibold text-base border border-white/30 backdrop-blur-md transition-all"
              >
                Analyze Body Language
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
