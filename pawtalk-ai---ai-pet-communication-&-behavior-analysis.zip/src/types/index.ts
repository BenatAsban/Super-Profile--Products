export type PetType = 'cat' | 'dog';

export interface PetProfile {
  id: string;
  name: string;
  type: PetType;
  breed?: string;
  age?: string;
  gender?: 'male' | 'female' | 'unknown';
  photoUrl?: string;
  avatarColor?: string;
  notes?: string;
  createdAt: number;
}

export interface SoundCharacteristics {
  pitch: string;
  intensity: string;
  cadence: string;
  duration?: string;
  repetition: string;
}

export interface SoundAnalysisResult {
  id: string;
  timestamp: number;
  petId?: string;
  petName?: string;
  petType: PetType;
  vocalizationDetected: boolean;
  detectedPetType?: string;
  vocalizationType: string;
  emotion:
    | 'Possibly excited'
    | 'Possibly anxious'
    | 'Possibly seeking attention'
    | 'Possibly hungry'
    | 'Possibly playful'
    | 'Possibly uncomfortable'
    | 'Unclear / insufficient evidence'
    | string;
  confidenceLevel: 'low' | 'medium' | 'high';
  confidenceScore?: number;
  soundCharacteristics: SoundCharacteristics;
  humanExplanation: string;
  petQuote?: string;
  alternativeInterpretations: string[];
  suggestedNextSteps: string[];
  scientificNotes?: string;
  veterinaryDisclaimer?: string;
  audioDurationSeconds?: number;
  isFavorite?: boolean;
}

export interface AnatomicalFeature {
  observation: string;
  meaning: string;
}

export interface BodyLanguageBreakdown {
  ears: AnatomicalFeature;
  tail: AnatomicalFeature;
  eyes: AnatomicalFeature;
  posture: AnatomicalFeature;
}

export interface BodyLanguageResult {
  id: string;
  timestamp: number;
  petId?: string;
  petName?: string;
  petType: PetType;
  petIdentified: boolean;
  detectedSubject: string;
  primaryEmotion: string;
  confidenceLevel: 'low' | 'medium' | 'high';
  confidenceScore?: number;
  bodyLanguageBreakdown: BodyLanguageBreakdown;
  detailedSummary: string;
  alternativeInterpretations: string[];
  confidenceLimitations: string[];
  suggestedActions: string[];
  imageUrl?: string;
  isFavorite?: boolean;
}

export interface PetActivityNote {
  id: string;
  petId: string;
  timestamp: number;
  category: 'mood' | 'vocal' | 'behavior' | 'feeding' | 'health' | 'play';
  note: string;
  moodTag?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export type PageId =
  | 'home'
  | 'sound-translator'
  | 'body-language'
  | 'dashboard'
  | 'assistant'
  | 'about'
  | 'privacy'
  | 'contact';
