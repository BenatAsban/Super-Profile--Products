import { SoundAnalysisResult, BodyLanguageResult } from '../types';

export function downloadSoundReport(result: SoundAnalysisResult) {
  const formattedDate = new Date(result.timestamp).toLocaleString();
  const title = `PawTalk_AI_Sound_Analysis_${result.petName || result.petType}_${new Date(result.timestamp).toISOString().slice(0, 10)}.html`;

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PawTalk AI - Sound Analysis Report</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0B0F19; color: #E2E8F0; padding: 40px; margin: 0; line-height: 1.6; }
    .container { max-width: 800px; margin: 0 auto; background: #131B2E; border: 1px solid #2A3655; border-radius: 16px; padding: 36px; box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
    .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #2A3655; padding-bottom: 24px; margin-bottom: 28px; }
    .brand { font-size: 24px; font-weight: 800; color: #A78BFA; display: flex; align-items: center; gap: 8px; }
    .badge { background: #312E81; color: #C4B5FD; padding: 4px 12px; border-radius: 999px; font-size: 13px; font-weight: 600; text-transform: uppercase; }
    h1 { margin: 0 0 8px 0; font-size: 24px; color: #F8FAFC; }
    .meta { font-size: 14px; color: #94A3B8; }
    .card { background: #1E293B; border-radius: 12px; padding: 20px; margin-bottom: 20px; border-left: 4px solid #8B5CF6; }
    .card h3 { margin-top: 0; color: #C4B5FD; font-size: 16px; text-transform: uppercase; letter-spacing: 0.05em; }
    .highlight-box { background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(59, 130, 246, 0.15)); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 12px; padding: 20px; margin: 24px 0; }
    .quote { font-style: italic; color: #E0E7FF; font-size: 18px; margin: 12px 0; font-weight: 500; }
    .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin: 20px 0; }
    .grid-item { background: #0F172A; padding: 14px 18px; border-radius: 8px; border: 1px solid #1E293B; }
    .grid-label { font-size: 12px; color: #94A3B8; text-transform: uppercase; }
    .grid-val { font-size: 15px; font-weight: 600; color: #F1F5F9; margin-top: 4px; }
    ul { margin: 8px 0; padding-left: 20px; }
    li { margin-bottom: 6px; color: #CBD5E1; }
    .disclaimer { font-size: 12px; color: #94A3B8; border-top: 1px solid #2A3655; padding-top: 20px; margin-top: 30px; text-align: center; }
    @media print { body { background: #fff; color: #111; } .container { background: #fff; border: 1px solid #ddd; } }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="brand">🐾 PawTalk AI</div>
      <div class="badge">Acoustic Ethology Report</div>
    </div>
    
    <h1>${result.petName || (result.petType === 'cat' ? 'Feline' : 'Canine')} Vocal Analysis</h1>
    <div class="meta">Recorded on ${formattedDate} | Pet Type: ${result.petType.toUpperCase()} | Vocalization: ${result.vocalizationType}</div>

    <div class="highlight-box">
      <div class="grid-label">Primary Interpretation</div>
      <div style="font-size: 22px; font-weight: 700; color: #A78BFA; margin-top: 4px;">${result.emotion}</div>
      ${result.petQuote ? `<div class="quote">${result.petQuote}</div>` : ''}
      <div style="margin-top: 10px; color: #E2E8F0;">${result.humanExplanation}</div>
    </div>

    <div class="grid">
      <div class="grid-item">
        <div class="grid-label">Pitch Profile</div>
        <div class="grid-val">${result.soundCharacteristics.pitch}</div>
      </div>
      <div class="grid-item">
        <div class="grid-label">Intensity / Volume</div>
        <div class="grid-val">${result.soundCharacteristics.intensity}</div>
      </div>
      <div class="grid-item">
        <div class="grid-label">Cadence & Timing</div>
        <div class="grid-val">${result.soundCharacteristics.cadence}</div>
      </div>
      <div class="grid-item">
        <div class="grid-label">AI Confidence Level</div>
        <div class="grid-val">${result.confidenceLevel.toUpperCase()} ${result.confidenceScore ? `(${result.confidenceScore}%)` : ''}</div>
      </div>
    </div>

    <div class="card">
      <h3>Alternative Interpretations</h3>
      <ul>
        ${result.alternativeInterpretations.map((alt) => `<li>${alt}</li>`).join('')}
      </ul>
    </div>

    <div class="card" style="border-left-color: #10B981;">
      <h3 style="color: #6EE7B7;">Suggested Next Steps for Guardian</h3>
      <ul>
        ${result.suggestedNextSteps.map((step) => `<li>${step}</li>`).join('')}
      </ul>
    </div>

    ${
      result.scientificNotes
        ? `
    <div class="card" style="border-left-color: #3B82F6;">
      <h3 style="color: #93C5FD;">Bioacoustic Scientific Context</h3>
      <p style="margin: 0; color: #CBD5E1;">${result.scientificNotes}</p>
    </div>`
        : ''
    }

    <div class="disclaimer">
      <strong>Veterinary Notice:</strong> ${result.veterinaryDisclaimer || 'This report is generated using artificial intelligence acoustic modeling and veterinary behavioral ethology frameworks. It does not constitute a veterinary medical diagnosis. If your pet exhibits chronic behavioral change, signs of pain, or lethargy, please consult a licensed veterinarian.'}
    </div>
  </div>
</body>
</html>`;

  triggerDownload(title, htmlContent, 'text/html');
}

export function downloadBodyReport(result: BodyLanguageResult) {
  const formattedDate = new Date(result.timestamp).toLocaleString();
  const title = `PawTalk_AI_BodyLanguage_${result.petName || result.petType}_${new Date(result.timestamp).toISOString().slice(0, 10)}.html`;

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PawTalk AI - Body Language Analysis Report</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0B0F19; color: #E2E8F0; padding: 40px; margin: 0; line-height: 1.6; }
    .container { max-width: 800px; margin: 0 auto; background: #131B2E; border: 1px solid #2A3655; border-radius: 16px; padding: 36px; }
    .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #2A3655; padding-bottom: 24px; margin-bottom: 28px; }
    .brand { font-size: 24px; font-weight: 800; color: #A78BFA; }
    .badge { background: #312E81; color: #C4B5FD; padding: 4px 12px; border-radius: 999px; font-size: 13px; font-weight: 600; text-transform: uppercase; }
    h1 { margin: 0 0 8px 0; font-size: 24px; color: #F8FAFC; }
    .highlight-box { background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(59, 130, 246, 0.15)); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 12px; padding: 20px; margin: 24px 0; }
    .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin: 20px 0; }
    .anatomy-card { background: #1E293B; border-radius: 10px; padding: 16px; border: 1px solid #334155; }
    .anatomy-title { color: #A78BFA; font-weight: 700; font-size: 14px; text-transform: uppercase; margin-bottom: 6px; }
    .disclaimer { font-size: 12px; color: #94A3B8; border-top: 1px solid #2A3655; padding-top: 20px; margin-top: 30px; text-align: center; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="brand">🐾 PawTalk AI</div>
      <div class="badge">Visual Ethology Report</div>
    </div>
    
    <h1>${result.petName || (result.petType === 'cat' ? 'Feline' : 'Canine')} Body Language Report</h1>
    <div style="font-size: 14px; color: #94A3B8; margin-bottom: 20px;">Analyzed on ${formattedDate} | Detected: ${result.detectedSubject}</div>

    <div class="highlight-box">
      <div style="font-size: 12px; color: #94A3B8; text-transform: uppercase;">Observed State</div>
      <div style="font-size: 22px; font-weight: 700; color: #A78BFA; margin-top: 4px;">${result.primaryEmotion}</div>
      <div style="margin-top: 10px; color: #E2E8F0;">${result.detailedSummary}</div>
    </div>

    <h2 style="font-size: 18px; color: #F1F5F9; margin-top: 30px;">Anatomical Breakdown</h2>
    <div class="grid">
      <div class="anatomy-card">
        <div class="anatomy-title">👂 Ears</div>
        <div><strong>Observed:</strong> ${result.bodyLanguageBreakdown.ears.observation}</div>
        <div style="color: #94A3B8; font-size: 13px; margin-top: 4px;">${result.bodyLanguageBreakdown.ears.meaning}</div>
      </div>
      <div class="anatomy-card">
        <div class="anatomy-title">🐾 Tail</div>
        <div><strong>Observed:</strong> ${result.bodyLanguageBreakdown.tail.observation}</div>
        <div style="color: #94A3B8; font-size: 13px; margin-top: 4px;">${result.bodyLanguageBreakdown.tail.meaning}</div>
      </div>
      <div class="anatomy-card">
        <div class="anatomy-title">👁️ Eyes</div>
        <div><strong>Observed:</strong> ${result.bodyLanguageBreakdown.eyes.observation}</div>
        <div style="color: #94A3B8; font-size: 13px; margin-top: 4px;">${result.bodyLanguageBreakdown.eyes.meaning}</div>
      </div>
      <div class="anatomy-card">
        <div class="anatomy-title">🧘 Posture & Body</div>
        <div><strong>Observed:</strong> ${result.bodyLanguageBreakdown.posture.observation}</div>
        <div style="color: #94A3B8; font-size: 13px; margin-top: 4px;">${result.bodyLanguageBreakdown.posture.meaning}</div>
      </div>
    </div>

    <div style="background: #1E293B; border-radius: 12px; padding: 20px; margin-top: 20px;">
      <h3 style="margin-top:0; color:#A78BFA; font-size:15px;">Alternative Explanations</h3>
      <ul>
        ${result.alternativeInterpretations.map((alt) => `<li>${alt}</li>`).join('')}
      </ul>
    </div>

    <div style="background: #1E293B; border-radius: 12px; padding: 20px; margin-top: 20px;">
      <h3 style="margin-top:0; color:#6EE7B7; font-size:15px;">Suggested Guardian Response</h3>
      <ul>
        ${result.suggestedActions.map((action) => `<li>${action}</li>`).join('')}
      </ul>
    </div>

    <div class="disclaimer">
      <strong>Scientific Ethics Notice:</strong> Body language analysis from static imagery provides circumstantial behavioral indicators. Animals change posture dynamically based on environmental temperature, fatigue, and momentary stimuli.
    </div>
  </div>
</body>
</html>`;

  triggerDownload(title, htmlContent, 'text/html');
}

function triggerDownload(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
