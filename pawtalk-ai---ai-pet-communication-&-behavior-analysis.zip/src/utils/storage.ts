import { PetProfile, SoundAnalysisResult, BodyLanguageResult, PetActivityNote } from '../types';

const STORAGE_KEYS = {
  PETS: 'pawtalk_pets_v1',
  ACTIVE_PET_ID: 'pawtalk_active_pet_id_v1',
  SOUND_HISTORY: 'pawtalk_sound_history_v1',
  BODY_HISTORY: 'pawtalk_body_history_v1',
  ACTIVITY_NOTES: 'pawtalk_activity_notes_v1',
  THEME: 'pawtalk_theme_v1',
};

const DEFAULT_PETS: PetProfile[] = [
  {
    id: 'pet-luna-cat',
    name: 'Luna',
    type: 'cat',
    breed: 'Domestic Shorthair',
    age: '2.5 years',
    gender: 'female',
    avatarColor: 'from-purple-500 to-indigo-600',
    notes: 'Curious explorer, loves high perches and window birdwatching. Expressive chirper.',
    createdAt: Date.now() - 86400000 * 30,
  },
  {
    id: 'pet-milo-dog',
    name: 'Milo',
    type: 'dog',
    breed: 'Golden Retriever',
    age: '3 years',
    gender: 'male',
    avatarColor: 'from-amber-400 to-orange-500',
    notes: 'Gentle, friendly, energetic tennis-ball enthusiast. Moderate alert barker when doorbell rings.',
    createdAt: Date.now() - 86400000 * 20,
  },
];

const INITIAL_SOUND_HISTORY: SoundAnalysisResult[] = [
  {
    id: 'sound-sample-1',
    timestamp: Date.now() - 1000 * 60 * 60 * 3, // 3 hours ago
    petId: 'pet-luna-cat',
    petName: 'Luna',
    petType: 'cat',
    vocalizationDetected: true,
    detectedPetType: 'Cat',
    vocalizationType: 'Ascending Chirp & Soft Trill',
    emotion: 'Possibly excited',
    confidenceLevel: 'high',
    confidenceScore: 88,
    soundCharacteristics: {
      pitch: 'High-frequency harmonic rise',
      intensity: 'Moderate & cheerful',
      cadence: 'Short rising melodic burst (0.8s)',
      repetition: 'Dual burst response',
      duration: '1.2s',
    },
    humanExplanation:
      'Luna vocalized a classic feline trill. In domestic ethology, trills and chirps are friendly affiliative greetings typically used by mother cats to kittens and retained in relationships with trusted human guardians.',
    petQuote: '"Oh you\'re back! Look at you, let\'s see what we are doing next!"',
    alternativeInterpretations: [
      'Positive anticipation before regular feeding time',
      'Affiliative greeting upon owner entering the room',
      'Interest stimulated by sudden outdoor motion (bird or insect)',
    ],
    suggestedNextSteps: [
      'Offer a gentle soft blink or verbal greeting in a warm tone',
      'Engage in a 5-minute interactive feather wand or laser session',
      'Check if fresh water or mealtime is scheduled',
    ],
    scientificNotes:
      'Feline vocal acoustic tract produces trills with closed mouth and rapid respiratory expiration, distinct from the open-mouth meow.',
    veterinaryDisclaimer:
      'Interpretation is an AI behavioral hypothesis based on acoustic features and should not replace veterinary care for chronic changes.',
    isFavorite: true,
  },
  {
    id: 'sound-sample-2',
    timestamp: Date.now() - 1000 * 60 * 60 * 24, // 1 day ago
    petId: 'pet-milo-dog',
    petName: 'Milo',
    petType: 'dog',
    vocalizationDetected: true,
    detectedPetType: 'Dog',
    vocalizationType: 'Short Rhythmic Alert Bark',
    emotion: 'Possibly seeking attention',
    confidenceLevel: 'medium',
    confidenceScore: 78,
    soundCharacteristics: {
      pitch: 'Mid-to-low resonant acoustic pitch',
      intensity: 'Crisp, moderate amplitude',
      cadence: 'Single bark followed by 2-second pause',
      repetition: 'Isolated pattern',
      duration: '0.6s',
    },
    humanExplanation:
      'Milo emitted a localized demand or alert bark. The spaced cadence and moderate pitch indicate an intentional communicative beacon rather than fear-driven alarm.',
    petQuote: '"Excuse me! Someone is walking by our sidewalk, just letting you know!"',
    alternativeInterpretations: [
      'Alert to delivery courier or outdoor auditory stimulus',
      'Mild demand for evening walk or fetch toss',
      'Social contact check to confirm where guardian is in the house',
    ],
    suggestedNextSteps: [
      'Acknowledge calmly with "Thank you, good boy" to disarm alertness without rewarding frantic barking',
      'Redirect energy to a chew toy or snuffle mat',
      'Check backyard perimeter for unusual distractions',
    ],
    scientificNotes:
      'Canine acoustic studies classify spaced, single barks as territorial announcements or social solicitation.',
    veterinaryDisclaimer:
      'Interpretive guidance only. Frequent high-arousal barking may indicate separation distress requiring professional certified trainer support.',
    isFavorite: false,
  },
];

const INITIAL_BODY_HISTORY: BodyLanguageResult[] = [
  {
    id: 'body-sample-1',
    timestamp: Date.now() - 1000 * 60 * 60 * 18,
    petId: 'pet-luna-cat',
    petName: 'Luna',
    petType: 'cat',
    petIdentified: true,
    detectedSubject: 'Domestic Cat in Relaxed Loaf Posture',
    primaryEmotion: 'Relaxed & Content',
    confidenceLevel: 'high',
    confidenceScore: 92,
    bodyLanguageBreakdown: {
      ears: {
        observation: 'Ears facing upright and angled gently forward in natural baseline rest.',
        meaning: 'Receptive and comfortable with the current acoustic room atmosphere.',
      },
      tail: {
        observation: 'Tail neatly wrapped tight along body contours without twitching or bristling.',
        meaning: 'State of physical calm and security in their resting territory.',
      },
      eyes: {
        observation: 'Soft almond apertures with gentle half-closed lids indicating slow-blink comfort.',
        meaning: 'Absence of threat perception and high trust in surrounding companions.',
      },
      posture: {
        observation: 'Classic "cat loaf" with paws curled beneath breastbone, spine leveled.',
        meaning: 'Deep contentment; posture signifies pet does not feel need for rapid escape.',
      },
    },
    detailedSummary:
      'Luna exhibits harmonious signs of parasympathetic relaxation. The tucked paws, soft eyelid posture, and forward ear orientation reflect secure comfort in her immediate environment.',
    alternativeInterpretations: [
      'Preserving body heat in a cool ambient temperature room',
      'Drowsiness preceding a natural feline nap cycle',
    ],
    confidenceLimitations: [
      'Static single-frame capture cannot show respiration rate or heart rate variability',
      'Subtle micro-movements of tail tip cannot be observed from a still picture',
    ],
    suggestedActions: [
      'Allow continued uninterrupted rest; resting periods are crucial for feline wellness',
      'Return a gentle slow-blink from across the room to reinforce mutual bond',
    ],
    isFavorite: true,
  },
];

const INITIAL_NOTES: PetActivityNote[] = [
  {
    id: 'note-1',
    petId: 'pet-luna-cat',
    timestamp: Date.now() - 1000 * 60 * 120,
    category: 'vocal',
    note: 'Chirped twice when hearing bird outside balcony window.',
    moodTag: 'Excited',
  },
  {
    id: 'note-2',
    petId: 'pet-milo-dog',
    timestamp: Date.now() - 1000 * 60 * 60 * 5,
    category: 'play',
    note: 'Brought squeaky hedgehog toy directly to desk, tail in wide sweeping wag.',
    moodTag: 'Playful',
  },
];

export const storage = {
  // Pets
  getPets(): PetProfile[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PETS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.PETS, JSON.stringify(DEFAULT_PETS));
        return DEFAULT_PETS;
      }
      return JSON.parse(data);
    } catch {
      return DEFAULT_PETS;
    }
  },

  savePets(pets: PetProfile[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.PETS, JSON.stringify(pets));
    } catch (e) {
      console.warn('Failed to save pets to localStorage', e);
    }
  },

  getActivePetId(): string {
    const pets = this.getPets();
    const stored = localStorage.getItem(STORAGE_KEYS.ACTIVE_PET_ID);
    if (stored && pets.some((p) => p.id === stored)) {
      return stored;
    }
    return pets[0]?.id || '';
  },

  setActivePetId(id: string) {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_PET_ID, id);
  },

  addPet(pet: Omit<PetProfile, 'id' | 'createdAt'>): PetProfile {
    const pets = this.getPets();
    const newPet: PetProfile = {
      ...pet,
      id: `pet-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
    };
    const updated = [newPet, ...pets];
    this.savePets(updated);
    this.setActivePetId(newPet.id);
    return newPet;
  },

  updatePet(updatedPet: PetProfile) {
    const pets = this.getPets();
    const index = pets.findIndex((p) => p.id === updatedPet.id);
    if (index !== -1) {
      pets[index] = updatedPet;
      this.savePets([...pets]);
    }
  },

  deletePet(id: string) {
    const pets = this.getPets().filter((p) => p.id !== id);
    this.savePets(pets);
    if (this.getActivePetId() === id && pets.length > 0) {
      this.setActivePetId(pets[0].id);
    }
  },

  // Sound History
  getSoundHistory(): SoundAnalysisResult[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SOUND_HISTORY);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.SOUND_HISTORY, JSON.stringify(INITIAL_SOUND_HISTORY));
        return INITIAL_SOUND_HISTORY;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_SOUND_HISTORY;
    }
  },

  addSoundResult(result: SoundAnalysisResult) {
    const history = this.getSoundHistory();
    const updated = [result, ...history].slice(0, 50); // limit to last 50
    try {
      localStorage.setItem(STORAGE_KEYS.SOUND_HISTORY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save sound result', e);
    }
  },

  toggleSoundFavorite(id: string) {
    const history = this.getSoundHistory();
    const item = history.find((h) => h.id === id);
    if (item) {
      item.isFavorite = !item.isFavorite;
      localStorage.setItem(STORAGE_KEYS.SOUND_HISTORY, JSON.stringify([...history]));
    }
  },

  deleteSoundResult(id: string) {
    const history = this.getSoundHistory().filter((h) => h.id !== id);
    localStorage.setItem(STORAGE_KEYS.SOUND_HISTORY, JSON.stringify(history));
  },

  clearSoundHistory() {
    localStorage.setItem(STORAGE_KEYS.SOUND_HISTORY, JSON.stringify([]));
  },

  // Body Language History
  getBodyHistory(): BodyLanguageResult[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BODY_HISTORY);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.BODY_HISTORY, JSON.stringify(INITIAL_BODY_HISTORY));
        return INITIAL_BODY_HISTORY;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_BODY_HISTORY;
    }
  },

  addBodyResult(result: BodyLanguageResult) {
    const history = this.getBodyHistory();
    // avoid storing huge base64 in history to protect localStorage limit (store thumbnail or truncated)
    const sanitized = {
      ...result,
      imageUrl: result.imageUrl && result.imageUrl.length > 200000 ? result.imageUrl.slice(0, 1000) + '...' : result.imageUrl,
    };
    const updated = [sanitized, ...history].slice(0, 50);
    try {
      localStorage.setItem(STORAGE_KEYS.BODY_HISTORY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save body result', e);
    }
  },

  toggleBodyFavorite(id: string) {
    const history = this.getBodyHistory();
    const item = history.find((h) => h.id === id);
    if (item) {
      item.isFavorite = !item.isFavorite;
      localStorage.setItem(STORAGE_KEYS.BODY_HISTORY, JSON.stringify([...history]));
    }
  },

  deleteBodyResult(id: string) {
    const history = this.getBodyHistory().filter((h) => h.id !== id);
    localStorage.setItem(STORAGE_KEYS.BODY_HISTORY, JSON.stringify(history));
  },

  clearBodyHistory() {
    localStorage.setItem(STORAGE_KEYS.BODY_HISTORY, JSON.stringify([]));
  },

  // Activity Notes
  getActivityNotes(): PetActivityNote[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACTIVITY_NOTES);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.ACTIVITY_NOTES, JSON.stringify(INITIAL_NOTES));
        return INITIAL_NOTES;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_NOTES;
    }
  },

  addActivityNote(note: Omit<PetActivityNote, 'id' | 'timestamp'>) {
    const notes = this.getActivityNotes();
    const newNote: PetActivityNote = {
      ...note,
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
    };
    const updated = [newNote, ...notes].slice(0, 100);
    localStorage.setItem(STORAGE_KEYS.ACTIVITY_NOTES, JSON.stringify(updated));
    return newNote;
  },

  deleteActivityNote(id: string) {
    const notes = this.getActivityNotes().filter((n) => n.id !== id);
    localStorage.setItem(STORAGE_KEYS.ACTIVITY_NOTES, JSON.stringify(notes));
  },

  // Theme
  getTheme(): 'dark' | 'light' {
    return (localStorage.getItem(STORAGE_KEYS.THEME) as 'dark' | 'light') || 'dark';
  },

  setTheme(theme: 'dark' | 'light') {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  },
};
