import React, { useState } from 'react';
import { PageId, PetProfile } from '../types';
import {
  Sparkles,
  Menu,
  X,
  Volume2,
  Eye,
  LayoutDashboard,
  MessageSquare,
  Info,
  Sun,
  Moon,
  ChevronDown,
  Plus,
} from 'lucide-react';

interface NavbarProps {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  pets: PetProfile[];
  activePet: PetProfile | null;
  onSelectPet: (petId: string) => void;
  onOpenAddPet: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  setCurrentPage,
  pets,
  activePet,
  onSelectPet,
  onOpenAddPet,
  theme,
  onToggleTheme,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [petDropdownOpen, setPetDropdownOpen] = useState(false);

  const navItems: { id: PageId; label: string; icon: React.ReactNode; primary?: boolean }[] = [
    { id: 'home', label: 'Home', icon: null },
    {
      id: 'sound-translator',
      label: 'Sound Translator',
      icon: <Volume2 className="w-4 h-4 mr-1.5" />,
      primary: true,
    },
    { id: 'body-language', label: 'Body Language', icon: <Eye className="w-4 h-4 mr-1.5" /> },
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4 mr-1.5" /> },
    { id: 'assistant', label: 'AI Assistant', icon: <MessageSquare className="w-4 h-4 mr-1.5" /> },
    { id: 'about', label: 'About', icon: <Info className="w-4 h-4 mr-1.5" /> },
  ];

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-950/85 border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <div
            onClick={() => setCurrentPage('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-[1.5px] shadow-lg shadow-purple-500/20 group-hover:shadow-purple-500/40 transition-all duration-300">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <span className="text-xl select-none transform group-hover:scale-110 transition-transform">🐾</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl sm:text-2xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-purple-300 bg-clip-text text-transparent">
                  PawTalk<span className="text-purple-400 font-black">.ai</span>
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                  <Sparkles className="w-2.5 h-2.5 mr-1 text-purple-400" />
                  Bioacoustic AI
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block tracking-wide uppercase font-medium">
                Ethological Pet Intelligence
              </p>
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1.5">
            {navItems.map((item) => {
              const isActive = currentPage === item.id;
              if (item.primary) {
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentPage(item.id)}
                    className={`flex items-center px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 shadow-md ${
                      isActive
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-purple-500/30 ring-2 ring-purple-400/30'
                        : 'bg-purple-950/40 text-purple-200 hover:bg-purple-900/50 border border-purple-800/40 hover:text-white'
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </button>
                );
              }
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`flex items-center px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-slate-800/90 text-white shadow-inner font-semibold border border-slate-700'
                      : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Controls: Active Pet & Theme */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Active Pet Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setPetDropdownOpen(!petDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/40 text-xs sm:text-sm font-medium text-slate-200 hover:text-white transition-all shadow-sm"
                title="Select active pet profile"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-base">{activePet?.type === 'dog' ? '🐕' : '🐈'}</span>
                <span className="max-w-[70px] sm:max-w-[100px] truncate font-semibold">
                  {activePet?.name || 'My Pet'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {petDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-56 rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl p-2 z-50 backdrop-blur-2xl"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800 mb-1">
                    Select Active Pet
                  </div>
                  <div className="space-y-1 max-h-56 overflow-y-auto">
                    {pets.map((pet) => (
                      <button
                        key={pet.id}
                        onClick={() => {
                          onSelectPet(pet.id);
                          setPetDropdownOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-all text-left ${
                          activePet?.id === pet.id
                            ? 'bg-purple-600/20 text-purple-200 border border-purple-500/40 font-semibold'
                            : 'text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="text-base">{pet.type === 'dog' ? '🐕' : '🐈'}</span>
                          <div className="truncate">
                            <p className="font-medium text-white truncate">{pet.name}</p>
                            <p className="text-[10px] text-slate-400 truncate">{pet.breed || pet.type}</p>
                          </div>
                        </div>
                        {activePet?.id === pet.id && (
                          <span className="text-[10px] bg-purple-500/30 text-purple-300 px-1.5 py-0.5 rounded-full">
                            Active
                          </span>
                        )}
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 mt-1 border-t border-slate-800">
                    <button
                      onClick={() => {
                        setPetDropdownOpen(false);
                        onOpenAddPet();
                      }}
                      className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 text-xs font-medium border border-purple-500/30 transition-all"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add New Pet
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Theme Toggle */}
            <button
              onClick={onToggleTheme}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition-all"
              title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} mode`}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-purple-400" />}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-950/95 border-b border-slate-800 px-4 pt-3 pb-6 space-y-2 backdrop-blur-2xl">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setCurrentPage(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                currentPage === item.id
                  ? 'bg-purple-600 text-white font-semibold shadow-lg shadow-purple-600/30'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Pet Profile: {activePet?.name || 'Default'}</span>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAddPet();
              }}
              className="text-purple-400 font-semibold"
            >
              + Add Pet
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
