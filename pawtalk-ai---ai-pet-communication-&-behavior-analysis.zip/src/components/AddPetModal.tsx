import React, { useState } from 'react';
import { PetProfile, PetType } from '../types';
import { X, Sparkles } from 'lucide-react';

interface AddPetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPet: (pet: Omit<PetProfile, 'id' | 'createdAt'>) => void;
}

const COLOR_GRADIENTS = [
  'from-purple-500 to-indigo-600',
  'from-amber-400 to-orange-500',
  'from-emerald-400 to-teal-600',
  'from-pink-500 to-rose-600',
  'from-blue-500 to-cyan-500',
  'from-violet-500 to-fuchsia-600',
];

export const AddPetModal: React.FC<AddPetModalProps> = ({ isOpen, onClose, onAddPet }) => {
  const [name, setName] = useState('');
  const [type, setType] = useState<PetType>('cat');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'male' | 'female' | 'unknown'>('male');
  const [avatarColor, setAvatarColor] = useState(COLOR_GRADIENTS[0]);
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onAddPet({
      name: name.trim(),
      type,
      breed: breed.trim() || (type === 'cat' ? 'Domestic Shorthair' : 'Mixed Breed'),
      age: age.trim() || 'Adult',
      gender,
      avatarColor,
      notes: notes.trim(),
    });

    // Reset and close
    setName('');
    setBreed('');
    setAge('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div
        className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700/80 p-6 sm:p-8 shadow-2xl relative text-white"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${avatarColor} flex items-center justify-center text-2xl shadow-lg`}>
            {type === 'dog' ? '🐕' : '🐈'}
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Add New Pet Profile</h3>
            <p className="text-xs text-slate-400">Personalize AI behavioral models for your furry companion</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Species */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Pet Species
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setType('cat')}
                className={`py-3 px-4 rounded-xl flex items-center justify-center gap-2 font-semibold text-sm transition-all border ${
                  type === 'cat'
                    ? 'bg-purple-600/30 border-purple-500 text-purple-200 ring-2 ring-purple-500/20'
                    : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span className="text-xl">🐈</span> Cat
              </button>
              <button
                type="button"
                onClick={() => setType('dog')}
                className={`py-3 px-4 rounded-xl flex items-center justify-center gap-2 font-semibold text-sm transition-all border ${
                  type === 'dog'
                    ? 'bg-purple-600/30 border-purple-500 text-purple-200 ring-2 ring-purple-500/20'
                    : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span className="text-xl">🐕</span> Dog
              </button>
            </div>
          </div>

          {/* Name & Age */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Pet Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Oliver, Bella, Archie"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-sm text-white placeholder-slate-500 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Age
              </label>
              <input
                type="text"
                placeholder="e.g. 2 years, 6 months"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-sm text-white placeholder-slate-500 outline-none transition-all"
              />
            </div>
          </div>

          {/* Breed & Gender */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Breed (optional)
              </label>
              <input
                type="text"
                placeholder={type === 'cat' ? 'e.g. British Shorthair, Tabby' : 'e.g. French Bulldog, Poodle'}
                value={breed}
                onChange={(e) => setBreed(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-sm text-white placeholder-slate-500 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Gender
              </label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-sm text-white outline-none"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="unknown">Prefer not to say</option>
              </select>
            </div>
          </div>

          {/* Color theme avatar */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Avatar Color
            </label>
            <div className="flex items-center gap-2">
              {COLOR_GRADIENTS.map((grad, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setAvatarColor(grad)}
                  className={`w-8 h-8 rounded-full bg-gradient-to-tr ${grad} transition-all transform ${
                    avatarColor === grad ? 'scale-110 ring-2 ring-white shadow-lg' : 'opacity-70 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Behavioral Traits / Personality Notes
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Vocal around dinner time, shy with new visitors, loves fetch"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-sm text-white placeholder-slate-500 outline-none transition-all resize-none"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-slate-300 hover:bg-slate-800 text-sm font-medium transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-purple-600/30 flex items-center gap-2 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              Save Pet Profile
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
