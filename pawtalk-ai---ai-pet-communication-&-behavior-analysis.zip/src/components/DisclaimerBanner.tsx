import React, { useState } from 'react';
import { ShieldCheck, X } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-purple-950 via-indigo-950 to-slate-900 border-b border-purple-800/40 text-purple-200 px-4 py-2 text-[11px] sm:text-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 truncate">
          <ShieldCheck className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
          <span className="truncate">
            <strong className="text-white">Scientific Ethology Standard:</strong> PawTalk AI provides evidence-informed behavioral estimates from bioacoustics and posture—never literal translations or medical diagnosis.
          </span>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-purple-400 hover:text-white p-0.5 rounded transition-colors flex-shrink-0"
          title="Dismiss notification"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
