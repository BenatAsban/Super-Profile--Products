import React from 'react';
import { PageId } from '../types';
import { ShieldAlert, Heart, Sparkles, AudioWaveform } from 'lucide-react';

interface FooterProps {
  setCurrentPage: (page: PageId) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800/80 pt-16 pb-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Disclaimer Card */}
        <div className="mb-12 rounded-2xl bg-gradient-to-r from-purple-950/40 via-indigo-950/30 to-slate-900 border border-purple-900/40 p-6 flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="p-3 rounded-xl bg-purple-900/40 text-purple-300 border border-purple-700/50 flex-shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div className="text-xs sm:text-sm text-slate-300 space-y-1">
            <p className="font-semibold text-white flex items-center gap-2">
              <span>Scientific Ethics &amp; Veterinary Notice</span>
              <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-500/30">
                Ethological Guidance
              </span>
            </p>
            <p className="text-slate-400 leading-relaxed">
              PawTalk AI utilizes multimodal neural networks trained on domestic animal bioacoustics and feline/canine ethology. We do not claim to literally translate animal sounds into human language or provide veterinary medical diagnosis. Always consult a licensed veterinarian for medical emergencies or abrupt behavioral shifts.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-slate-800/80">
          {/* Col 1: Brand */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white text-base shadow-md">
                🐾
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">
                PawTalk<span className="text-purple-400">.ai</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Pioneering bioacoustic sound interpretation and visual body language analysis for cat and dog guardians worldwide.
            </p>
            <div className="flex items-center gap-2 text-xs text-purple-400 font-medium">
              <AudioWaveform className="w-4 h-4 text-purple-400 animate-pulse" />
              Powered by Google Gemini Multimodal
            </div>
          </div>

          {/* Col 2: Features */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Features</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => setCurrentPage('sound-translator')}
                  className="hover:text-purple-300 transition-colors text-left"
                >
                  AI Sound Translator (Audio Bioacoustics)
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('body-language')}
                  className="hover:text-purple-300 transition-colors text-left"
                >
                  Body Language Vision Analyzer
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('dashboard')}
                  className="hover:text-purple-300 transition-colors text-left"
                >
                  Pet Mood Dashboard &amp; Profiles
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('assistant')}
                  className="hover:text-purple-300 transition-colors text-left"
                >
                  24/7 AI Pet Behavior Assistant
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Company & Ethics */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Science &amp; Company</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => setCurrentPage('about')}
                  className="hover:text-purple-300 transition-colors text-left"
                >
                  About Our Ethology Research
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('privacy')}
                  className="hover:text-purple-300 transition-colors text-left"
                >
                  Privacy Policy &amp; Data Ethics
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentPage('contact')}
                  className="hover:text-purple-300 transition-colors text-left"
                >
                  Contact &amp; Support
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Ethology Highlights */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Ethology Standards</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Our acoustic algorithms evaluate frequency modulation, harmonic ratios, and pulse repetition—treating domestic pets as sentient communicative companions.
            </p>
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Zero Gimmick Translation Promise
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} PawTalk AI Inc. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <button onClick={() => setCurrentPage('privacy')} className="hover:text-slate-300">
              Privacy
            </button>
            <button onClick={() => setCurrentPage('about')} className="hover:text-slate-300">
              Ethical Standards
            </button>
            <button onClick={() => setCurrentPage('contact')} className="hover:text-slate-300">
              Help Desk
            </button>
          </div>
          <p className="flex items-center gap-1 text-slate-400">
            Engineered for animals with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" />
          </p>
        </div>
      </div>
    </footer>
  );
};
