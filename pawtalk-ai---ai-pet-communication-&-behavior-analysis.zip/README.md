# PawTalk AI 🐾
### AI-Powered Pet Communication & Behavior Analysis Platform

PawTalk AI is a full-stack web application designed to help pet guardians better understand their cats and dogs. By synthesizing **bioacoustic signal processing**, **feline and canine ethology research**, and **Google Gemini multimodal AI**, PawTalk AI provides evidence-informed interpretations of animal vocalizations and physical postures in clear human language.

---

## 🌟 Core Features

1. **AI Pet Sound Translator (Primary Bioacoustic Engine)**:
   - Live browser audio recording with real-time volume and amplitude visualizer via HTML5 MediaRecorder and Web Audio API.
   - File upload support for MP3, WAV, M4A, OGG, and WEBM formats.
   - Synthesized authentic sample audio presets (e.g. Cat Affiliative Trill, Dog Alert Bark, Cat Demand Meow) for instant 1-click test drives.
   - Multimodal Gemini audio analysis evaluating pitch, frequency modulation, intensity, and repetition cadence.
   - Categorized emotional states: *"Possibly excited"*, *"Possibly seeking attention"*, *"Possibly anxious"*, *"Possibly hungry"*, *"Possibly playful"*, *"Possibly uncomfortable"*, or *"Unclear / insufficient evidence"*.
   - Bioacoustic context, playful first-person pet thought, alternative interpretations, and actionable guardian next steps.
   - Exportable HTML/printable ethological reports.

2. **Pet Body Language Vision Analyzer**:
   - Photo upload and live camera capture for cats and dogs.
   - Curated anatomical posture test samples (e.g. Cat Loaf, Dog Play Bow).
   - 4-point anatomical inspection: Ears, Tail, Eyes, and Body Posture.
   - Primary emotional state, confidence score, situational alternatives (ambient temperature, fatigue), and observable single-frame limitations.

3. **Pet Mood & Activity Dashboard**:
   - Multi-pet profile management (species, custom name, breed, age, gender, notes, custom gradient avatar).
   - Longitudinal mood breakdown chart displaying frequency distribution of observed emotions.
   - Unified chronological history of sound and body language scans with filtering and favorite bookmarking.
   - Daily behavioral activity log with timestamped category tags (vocalization, play, feeding, health).

4. **24/7 AI Pet Behavior Assistant**:
   - Conversational chat interface grounded in companion animal ethology and positive reinforcement techniques.
   - Active pet profile contextual awareness.
   - Suggested prompts for common behavioral inquiries (nighttime vocalization, separation anxiety, doorbell alerts).
   - Strict veterinary safety boundary: immediately urges veterinary care for physical distress, lethargy, or acute illness.

5. **Scientific Ethics & Non-Veterinary Notice**:
   - Zero-gimmick policy: PawTalk AI does not claim to literally translate animal vocalizations into exact human words or replace veterinary diagnosis.

---

## 🛠️ Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide React icons.
- **Backend**: Node.js, Express, tsx.
- **AI Engine**: Google Gemini API (`gemini-3.8-flash`) via the official `@google/genai` TypeScript SDK.
- **Audio & Media**: Web Audio API (`AudioContext`, `AnalyserNode`), `MediaRecorder` API.
- **Persistence**: HTML5 LocalStorage for pet profiles, history logs, and user preferences.

---

## 🚀 Installation & Local Development

### Prerequisites
- Node.js (version 20 or higher recommended)
- npm (version 9 or higher)
- Google Gemini API Key

### 1. Clone the repository
```bash
git clone <repository-url>
cd pawtalk-ai
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Ensure `GEMINI_API_KEY` is provided:
```env
GEMINI_API_KEY="your-gemini-api-key-here"
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Run Development Server
```bash
npm run dev
```
The server will start on `http://localhost:3000` with Express backend endpoints and Vite middleware running concurrently.

---

## 📦 Production Build & Deployment

### Build the frontend assets:
```bash
npm run build
```

### Start the production server:
```bash
npm start
```
The Express server serves the compiled static files from `/dist` and powers the `/api/*` endpoints.

---

## 📄 License
Apache-2.0
