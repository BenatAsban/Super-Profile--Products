import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Allow large payloads for base64 audio and high-res pet photos
app.use(express.json({ limit: '35mb' }));
app.use(express.urlencoded({ extended: true, limit: '35mb' }));

// Server-side Gemini initialization with required user-agent
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment variables.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Health and capability check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: !!process.env.GEMINI_API_KEY,
    timestamp: new Date().toISOString(),
  });
});

// Sound Analysis Endpoint
app.post('/api/analyze-sound', async (req, res) => {
  try {
    const { petType = 'cat', audioBase64, mimeType = 'audio/webm', petName, breed, context } = req.body;

    if (!audioBase64) {
      return res.status(400).json({ error: 'Audio data is required for sound analysis.' });
    }

    // Clean base64 if prefixed
    const cleanBase64 = audioBase64.replace(/^data:[^;]+;base64,/, '');

    const ai = getGeminiClient();

    const systemInstruction = `You are a certified veterinary behaviorist and animal bioacoustics researcher for PawTalk AI.
Analyze audio recordings of domestic cats and dogs.
IMPORTANT ETHICS & SCIENTIFIC INTEGRITY:
- NEVER claim to scientifically "translate" animal vocalizations into exact human words or verbatim speech.
- Clearly differentiate scientific bioacoustic observations (pitch, cadence, repetition, duration) from behavioral hypotheses.
- If the audio has no identifiable cat or dog vocalization (e.g. human voices, white noise, room silence, background TV), state clearly: vocalizationDetected: false, and set emotion: "Unclear / insufficient evidence".
- Emotion must be one of:
  "Possibly excited", "Possibly anxious", "Possibly seeking attention", "Possibly hungry", "Possibly playful", "Possibly uncomfortable", "Unclear / insufficient evidence".
- Offer grounded alternative interpretations (e.g. boredom, barrier frustration, territorial response, greeting).
- Suggest safe, evidence-informed positive reinforcement and environmental checks.
- Include a disclaimer that acoustic analysis is an interpretive estimate, not a veterinary or behavioral diagnosis.`;

    const userPrompt = `Analyze this ${petType} vocalization recording.
${petName ? `Pet Name: ${petName}` : ''}
${breed ? `Breed: ${breed}` : ''}
${context ? `Owner situational context: ${context}` : ''}
Evaluate:
1. Vocalization presence: Is a real ${petType} sound present?
2. Sound characteristics: Pitch (low, mid, high, variable), repetition rate, duration, tonal qualities (e.g., trill, purr, hiss, growl, whimper, alert bark, baying).
3. Primary emotional hypothesis: One of ["Possibly excited", "Possibly anxious", "Possibly seeking attention", "Possibly hungry", "Possibly playful", "Possibly uncomfortable", "Unclear / insufficient evidence"].
4. Human explanation: Clear, friendly, informative translation of what this vocalization pattern often communicates in domestic pets.
5. Confidence level: "low", "medium", or "high" based on audio clarity and vocal specificity.
6. Alternative interpretations: 2 to 3 alternative situational reasons.
7. Suggested next steps: 3 to 4 actionable, loving recommendations for the pet guardian.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          inlineData: {
            mimeType: mimeType || 'audio/webm',
            data: cleanBase64,
          },
        },
        {
          text: userPrompt,
        },
      ],
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            vocalizationDetected: {
              type: Type.BOOLEAN,
              description: 'Whether a domestic cat or dog vocalization was identifiable in the audio.',
            },
            detectedPetType: {
              type: Type.STRING,
              description: 'Observed animal type (e.g. cat, dog, unidentified).',
            },
            vocalizationType: {
              type: Type.STRING,
              description: 'Specific vocal type, e.g. "Chirp / Trill", "Short Alert Bark", "Demand Meow", "Whimper", "Play Growl", "Hiss".',
            },
            emotion: {
              type: Type.STRING,
              description: 'One of: Possibly excited, Possibly anxious, Possibly seeking attention, Possibly hungry, Possibly playful, Possibly uncomfortable, Unclear / insufficient evidence.',
            },
            confidenceLevel: {
              type: Type.STRING,
              description: 'low, medium, or high.',
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: 'Confidence percentage between 0 and 100.',
            },
            soundCharacteristics: {
              type: Type.OBJECT,
              properties: {
                pitch: { type: Type.STRING, description: 'e.g. High-pitched, Low resonant, Ascending, Flat' },
                intensity: { type: Type.STRING, description: 'e.g. Soft, Moderate, Urgent/Loud' },
                cadence: { type: Type.STRING, description: 'e.g. Rapid bursts, Single isolated sound, Continuous rhythmic' },
                duration: { type: Type.STRING, description: 'Estimated vocal duration pattern' },
                repetition: { type: Type.STRING, description: 'e.g. High repetition, Single instance' },
              },
              required: ['pitch', 'intensity', 'cadence', 'repetition'],
            },
            humanExplanation: {
              type: Type.STRING,
              description: 'Warm, clear explanation of what this sound typically signifies.',
            },
            petQuote: {
              type: Type.STRING,
              description: 'Playful first-person pet thought (e.g. "Hey! Look over here, I am excited!"), clearly labeled as a playful interpretation.',
            },
            alternativeInterpretations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '2-3 alternative explanations depending on environment.',
            },
            suggestedNextSteps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3-4 actionable positive guidance items for the owner.',
            },
            scientificNotes: {
              type: Type.STRING,
              description: 'Brief bioacoustic context regarding evolutionary purpose of this vocalization.',
            },
            veterinaryDisclaimer: {
              type: Type.STRING,
              description: 'Standard reminder that persistent changes or distress require veterinary review.',
            },
          },
          required: [
            'vocalizationDetected',
            'vocalizationType',
            'emotion',
            'confidenceLevel',
            'soundCharacteristics',
            'humanExplanation',
            'alternativeInterpretations',
            'suggestedNextSteps',
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error analyzing sound:', error);
    return res.status(500).json({
      error: error.message || 'Failed to analyze pet audio.',
      details: error.status || 'AI_SERVICE_ERROR',
    });
  }
});

// Body Language Analysis Endpoint
app.post('/api/analyze-body-language', async (req, res) => {
  try {
    const { petType = 'cat', imageBase64, mimeType = 'image/jpeg', petName, breed, context } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Image data is required for body language analysis.' });
    }

    const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
    const ai = getGeminiClient();

    const systemInstruction = `You are a certified veterinary ethologist and animal behavior analyst for PawTalk AI.
Analyze domestic feline and canine body language from photographs.
CORE SCIENTIFIC RULES:
- Never claim to know an animal's exact internal emotional state from a single photograph.
- Thoroughly inspect observable anatomical markers:
  * For cats: ear position (forward, rotated, pinned flat), tail position & shape (neutral, hook, tucked, bristled), eye expression (slow blink, dilated pupils, almond relaxed), body posture (tucked loaf, crouched, side stretch, defensive arch).
  * For dogs: tail carriage & tension (relaxed wag angle, tucked, vertical rigid), ear posture (neutral floppy, prick forward, slicked back), facial features (commissures, whale eye, soft brow, open mouth smile), body weight distribution (play bow, center balanced, tucked tail cowering, rigid forward lean).
- Identify situational context and potential environmental triggers.
- Present primary interpretation along with alternative explanations and observable limitations.`;

    const userPrompt = `Analyze the body language of this ${petType}.
${petName ? `Pet Name: ${petName}` : ''}
${breed ? `Breed: ${breed}` : ''}
${context ? `Context provided: ${context}` : ''}
Provide an anatomical breakdown, emotional state hypothesis, alternative explanations, and guardian recommendations.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          inlineData: {
            mimeType: mimeType || 'image/jpeg',
            data: cleanBase64,
          },
        },
        {
          text: userPrompt,
        },
      ],
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            petIdentified: {
              type: Type.BOOLEAN,
              description: 'Whether a cat or dog is clearly visible in the image.',
            },
            detectedSubject: {
              type: Type.STRING,
              description: 'Subject description (e.g., Ginger Tabby Cat, Golden Retriever).',
            },
            primaryEmotion: {
              type: Type.STRING,
              description: 'e.g. Relaxed & Content, Inquisitive / Alert, Playful & Engaged, Mildly Anxious, Guarded / Defensive, Overstimulated, Affectionate.',
            },
            confidenceLevel: {
              type: Type.STRING,
              description: 'low, medium, or high.',
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: 'Confidence score percentage (0-100).',
            },
            bodyLanguageBreakdown: {
              type: Type.OBJECT,
              properties: {
                ears: {
                  type: Type.OBJECT,
                  properties: {
                    observation: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                  },
                  required: ['observation', 'meaning'],
                },
                tail: {
                  type: Type.OBJECT,
                  properties: {
                    observation: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                  },
                  required: ['observation', 'meaning'],
                },
                eyes: {
                  type: Type.OBJECT,
                  properties: {
                    observation: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                  },
                  required: ['observation', 'meaning'],
                },
                posture: {
                  type: Type.OBJECT,
                  properties: {
                    observation: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                  },
                  required: ['observation', 'meaning'],
                },
              },
              required: ['ears', 'tail', 'eyes', 'posture'],
            },
            detailedSummary: {
              type: Type.STRING,
              description: 'Clear, comprehensive explanation of the overall physical posture and what it signifies.',
            },
            alternativeInterpretations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Alternative environmental or physical explanations (e.g., room warmth, fatigue).',
            },
            confidenceLimitations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Limitations of single-frame photographic analysis (e.g. angle obscured, static vs dynamic motion).',
            },
            suggestedActions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Recommended caring responses from the pet guardian.',
            },
          },
          required: [
            'petIdentified',
            'detectedSubject',
            'primaryEmotion',
            'confidenceLevel',
            'bodyLanguageBreakdown',
            'detailedSummary',
            'alternativeInterpretations',
            'confidenceLimitations',
            'suggestedActions',
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error analyzing body language:', error);
    return res.status(500).json({
      error: error.message || 'Failed to analyze pet body language.',
      details: error.status || 'AI_SERVICE_ERROR',
    });
  }
});

// AI Pet Assistant Chat Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { messages = [], petProfile } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required.' });
    }

    const ai = getGeminiClient();

    let profileContext = '';
    if (petProfile && petProfile.name) {
      profileContext = `The user is discussing their pet named "${petProfile.name}", which is a ${petProfile.type || 'pet'}${petProfile.breed ? ` (${petProfile.breed})` : ''}${petProfile.age ? `, age: ${petProfile.age}` : ''}. Tailor examples and advice to this specific pet where appropriate.`;
    }

    const systemInstruction = `You are "PawTalk AI Assistant", an empathetic, highly knowledgeable companion animal behaviorist and pet care expert.
Your mission is to help pet parents understand cat and dog behavior, vocalizations, social needs, enrichment, and non-verbal cues.

GUIDELINES:
1. Always be warm, clear, compassionate, and scientifically grounded in modern positive reinforcement and feline/canine ethology.
2. Structure your answers with clear headings, bullet points, and practical tips where helpful.
3. VETERINARY SAFETY FIRST: Never provide veterinary prescriptions, drug dosages, or medical diagnosis. For symptoms of physical illness, acute lethargy, vomiting, refusal to eat, sudden intense aggression, or severe pain, explicitly urge the user to consult a licensed veterinarian.
4. Distinguish between behavioral instincts (territory, prey drive, communication, resource guarding) and emotional reactions (fear, joy, stress, contentment).
${profileContext}`;

    // Convert message history to format suitable for Gemini
    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
      },
    });

    return res.json({
      reply: response.text || 'I apologize, I could not generate a response. Please try again.',
    });
  } catch (error: any) {
    console.error('Error in chat assistant:', error);
    return res.status(500).json({
      error: error.message || 'Failed to communicate with pet assistant.',
      details: error.status || 'AI_SERVICE_ERROR',
    });
  }
});

// Configure Vite middleware in dev or static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`PawTalk AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
});
