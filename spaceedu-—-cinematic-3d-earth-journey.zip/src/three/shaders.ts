import * as THREE from 'three';

// Atmospheric Rayleigh Scattering Outer Glow Shader
export const AtmosphereGlowShader = {
  uniforms: {
    sunDirection: { value: new THREE.Vector3(5, 2, 4).normalize() },
    atmosphereColor: { value: new THREE.Color(0x38bdf8) }, // Electric cyan-blue
    twilightColor: { value: new THREE.Color(0xf97316) },   // Warm sunset orange at terminator
    intensity: { value: 1.15 },
    power: { value: 3.5 },
  },
  vertexShader: `
    varying vec3 vNormal;
    varying vec3 vWorldPosition;

    void main() {
      vNormal = normalize(normalMatrix * normal);
      vec4 worldPos = modelMatrix * vec4(position, 1.0);
      vWorldPosition = worldPos.xyz;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec3 sunDirection;
    uniform vec3 atmosphereColor;
    uniform vec3 twilightColor;
    uniform float intensity;
    uniform float power;

    varying vec3 vNormal;
    varying vec3 vWorldPosition;

    void main() {
      // Camera view direction
      vec3 viewDir = normalize(cameraPosition - vWorldPosition);
      vec3 normal = normalize(vNormal);

      // Fresnel rim factor (strongest at edges)
      float rim = 1.0 - max(0.0, dot(viewDir, normal));
      rim = pow(rim, power);

      // Sunlight alignment
      float sunDot = dot(normalize(vWorldPosition), sunDirection);
      float daylight = smoothstep(-0.35, 0.45, sunDot);
      float terminator = smoothstep(0.25, -0.05, abs(sunDot));

      // Blend daytime sky blue with terminator sunset orange
      vec3 glowColor = mix(atmosphereColor, twilightColor, terminator * 0.7);

      float alpha = rim * daylight * intensity;
      // Soft falloff
      gl_FragColor = vec4(glowColor, clamp(alpha, 0.0, 0.95));
    }
  `,
};

// Custom setup for Earth material to blend Day texture and Night lights across the sunlit terminator
export function injectNightLightsShader(
  material: THREE.MeshStandardMaterial,
  nightTexture: THREE.CanvasTexture,
  sunDirRef: { current: THREE.Vector3 }
) {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.tNight = { value: nightTexture };
    shader.uniforms.uSunDirection = { value: sunDirRef.current };

    // Inject varying worldNormal & worldPosition in vertex
    shader.vertexShader = shader.vertexShader.replace(
      '#include <common>',
      `
      #include <common>
      varying vec3 vWorldNormalCustom;
      `
    );

    shader.vertexShader = shader.vertexShader.replace(
      '#include <defaultnormal_vertex>',
      `
      #include <defaultnormal_vertex>
      vWorldNormalCustom = normalize((modelMatrix * vec4(transformedNormal, 0.0)).xyz);
      `
    );

    // Inject in fragment
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <common>',
      `
      #include <common>
      uniform sampler2D tNight;
      uniform vec3 uSunDirection;
      varying vec3 vWorldNormalCustom;
      `
    );

    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <dithering_fragment>',
      `
      #include <dithering_fragment>
      
      // Calculate day-night terminator factor
      float sunFacing = dot(normalize(vWorldNormalCustom), normalize(uSunDirection));
      // Night lights appear when sun is below horizon (-0.05 to -0.3)
      float nightFactor = smoothstep(0.05, -0.22, sunFacing);

      if (nightFactor > 0.001) {
        vec4 nightColor = texture2D(tNight, vMapUv);
        // Additive warm city lights glow
        gl_FragColor.rgb += nightColor.rgb * nightFactor * 1.85;
      }
      `
    );
  };
}
