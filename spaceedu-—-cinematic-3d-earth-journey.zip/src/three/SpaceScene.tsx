import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  createEarthDayTexture,
  createEarthNightTexture,
  createEarthSpecularTexture,
  createEarthCloudsTexture,
  createStarfieldData,
} from './earthTextures';
import { AtmosphereGlowShader, injectNightLightsShader } from './shaders';
import { setupCameraScrollAnimation, CameraAnimationController } from './cameraController';
import { EarthLayersState, TelemetryData } from '../types';

interface SpaceSceneProps {
  layers: EarthLayersState;
  onTelemetryUpdate: (data: TelemetryData) => void;
  onControllerReady?: (controller: CameraAnimationController) => void;
  scrollContainerRef: React.RefObject<HTMLDivElement | null>;
  sectionsContainerRef: React.RefObject<HTMLDivElement | null>;
}

export const SpaceScene: React.FC<SpaceSceneProps> = ({
  layers,
  onTelemetryUpdate,
  onControllerReady,
  scrollContainerRef,
  sectionsContainerRef,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const controllerRef = useRef<CameraAnimationController | null>(null);

  // References for dynamic layer toggling
  const cloudsMeshRef = useRef<THREE.Mesh | null>(null);
  const atmosphereMeshRef = useRef<THREE.Mesh | null>(null);
  const orbitRingRef = useRef<THREE.Line | null>(null);
  const satelliteGroupRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Software-WebGL Guard per Three.js skill
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: true,
    });
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 3. Scene & Camera
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(3.2, 1.0, 7.2);

    // 4. Lighting Rig
    const sunDirection = new THREE.Vector3(8, 3, 6).normalize();
    const sunLight = new THREE.DirectionalLight(0xfff7ed, 3.2);
    sunLight.position.set(sunDirection.x * 20, sunDirection.y * 20, sunDirection.z * 20);
    sunLight.castShadow = !isSoftwareGl;
    if (!isSoftwareGl) {
      sunLight.shadow.mapSize.width = 1024;
      sunLight.shadow.mapSize.height = 1024;
      sunLight.shadow.bias = -0.0005;
      sunLight.shadow.normalBias = 0.02;
    }
    scene.add(sunLight);

    // Cool deep space fill light
    const hemiLight = new THREE.HemisphereLight(0x0a192f, 0x020408, 0.35);
    scene.add(hemiLight);

    // 5. Earth Assembly (Hierarchical THREE.Group)
    const earthGroup = new THREE.Group();
    earthGroup.position.set(1.1, -0.1, 0.0);
    scene.add(earthGroup);

    // Procedural textures
    const dayTexture = createEarthDayTexture();
    const nightTexture = createEarthNightTexture();
    const specularTexture = createEarthSpecularTexture();
    const cloudsTexture = createEarthCloudsTexture();

    // 5A. Earth Surface Sphere
    const earthRadius = 2.0;
    const earthSegments = isSoftwareGl ? 32 : 64;
    const earthGeo = new THREE.SphereGeometry(earthRadius, earthSegments, earthSegments);
    const earthMat = new THREE.MeshStandardMaterial({
      map: dayTexture,
      roughnessMap: specularTexture,
      roughness: 0.85,
      metalness: 0.1,
    });

    const sunDirRef = { current: sunDirection };
    injectNightLightsShader(earthMat, nightTexture, sunDirRef);

    const earthMesh = new THREE.Mesh(earthGeo, earthMat);
    earthMesh.receiveShadow = !isSoftwareGl;
    earthMesh.castShadow = !isSoftwareGl;
    earthGroup.add(earthMesh);

    // 5B. Atmospheric Clouds Sphere (Rotates independently)
    const cloudsGeo = new THREE.SphereGeometry(earthRadius * 1.014, earthSegments, earthSegments);
    const cloudsMat = new THREE.MeshStandardMaterial({
      map: cloudsTexture,
      transparent: true,
      opacity: 0.85,
      blending: THREE.NormalBlending,
      depthWrite: false,
    });
    const cloudsMesh = new THREE.Mesh(cloudsGeo, cloudsMat);
    cloudsMeshRef.current = cloudsMesh;
    earthGroup.add(cloudsMesh);

    // 5C. Outer Atmosphere Glow Shell (Rayleigh scattering Fresnel)
    const atmosphereGeo = new THREE.SphereGeometry(earthRadius * 1.045, earthSegments, earthSegments);
    const atmosphereMat = new THREE.ShaderMaterial({
      uniforms: {
        sunDirection: { value: sunDirection },
        atmosphereColor: { value: new THREE.Color(0x38bdf8) },
        twilightColor: { value: new THREE.Color(0xf97316) },
        intensity: { value: 1.25 },
        power: { value: 3.2 },
      },
      vertexShader: AtmosphereGlowShader.vertexShader,
      fragmentShader: AtmosphereGlowShader.fragmentShader,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true,
      depthWrite: false,
    });
    const atmosphereMesh = new THREE.Mesh(atmosphereGeo, atmosphereMat);
    atmosphereMeshRef.current = atmosphereMesh;
    earthGroup.add(atmosphereMesh);

    // 5D. Orbital Spline Ring (LEO / ISS trajectory)
    const orbitRadius = 2.55;
    const orbitCurve = new THREE.EllipseCurve(0, 0, orbitRadius, orbitRadius * 0.95, 0, 2 * Math.PI, false, 0);
    const orbitPoints = orbitCurve.getPoints(120);
    const orbitGeo = new THREE.BufferGeometry().setFromPoints(
      orbitPoints.map((p) => new THREE.Vector3(p.x, p.y * 0.35, p.y * 0.85)) // tilted inclined plane
    );
    const orbitMat = new THREE.LineDashedMaterial({
      color: 0x38bdf8,
      dashSize: 0.12,
      gapSize: 0.08,
      transparent: true,
      opacity: 0.55,
    });
    const orbitLine = new THREE.Line(orbitGeo, orbitMat);
    orbitLine.computeLineDistances();
    orbitRingRef.current = orbitLine;
    earthGroup.add(orbitLine);

    // 5E. Procedural Satellite Model (Spacecraft exploring Earth)
    const satelliteGroup = new THREE.Group();
    // Central chassis
    const busGeo = new THREE.BoxGeometry(0.08, 0.08, 0.12);
    const busMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.85, roughness: 0.25 });
    const busMesh = new THREE.Mesh(busGeo, busMat);
    satelliteGroup.add(busMesh);
    // Solar panels
    const panelGeo = new THREE.BoxGeometry(0.32, 0.005, 0.09);
    const panelMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, metalness: 0.9, roughness: 0.15 });
    const panelLeft = new THREE.Mesh(panelGeo, panelMat);
    panelLeft.position.set(-0.21, 0, 0);
    const panelRight = new THREE.Mesh(panelGeo, panelMat);
    panelRight.position.set(0.21, 0, 0);
    satelliteGroup.add(panelLeft);
    satelliteGroup.add(panelRight);
    // Communication dish
    const dishGeo = new THREE.ConeGeometry(0.04, 0.03, 12, 1, true);
    const dishMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, metalness: 0.6, roughness: 0.3 });
    const dish = new THREE.Mesh(dishGeo, dishMat);
    dish.position.set(0, 0.06, 0.03);
    dish.rotation.x = Math.PI;
    satelliteGroup.add(dish);

    satelliteGroup.position.set(1.9, 0.65, 1.4);
    satelliteGroup.scale.set(0.9, 0.9, 0.9);
    satelliteGroupRef.current = satelliteGroup;
    earthGroup.add(satelliteGroup);

    // 6. Deep Space Starfield & Cosmic Dust
    const starData = createStarfieldData(isSoftwareGl ? 1200 : 2800);
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starData.positions, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(starData.colors, 3));

    const starMat = new THREE.PointsMaterial({
      size: 1.6,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      sizeAttenuation: false,
    });
    const starField = new THREE.Points(starGeo, starMat);
    scene.add(starField);

    // 7. Initialize Scroll Animation Controller
    let controller: CameraAnimationController | null = null;
    const scrollContainer = scrollContainerRef.current;
    const sectionsContainer = sectionsContainerRef.current;

    if (scrollContainer && sectionsContainer) {
      controller = setupCameraScrollAnimation({
        camera,
        earthGroup,
        cloudsMesh,
        containerElement: scrollContainer,
        sectionsElement: sectionsContainer,
        onTelemetryUpdate,
      });
      controllerRef.current = controller;
      if (onControllerReady) {
        onControllerReady(controller);
      }
    }

    // 8. Animation & Render Loop
    let clock = new THREE.Clock();
    let frameId = 0;
    let satAngle = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function renderLoop() {
      const delta = Math.min(clock.getDelta(), 0.1);

      // Advance scroll camera interpolation
      if (controller) {
        controller.update(delta);
      }

      // Orbit satellite along orbital path
      satAngle += delta * 0.45;
      if (satelliteGroupRef.current) {
        const sx = Math.cos(satAngle) * orbitRadius;
        const sz = Math.sin(satAngle) * (orbitRadius * 0.85);
        const sy = Math.sin(satAngle) * (orbitRadius * 0.35);
        satelliteGroupRef.current.position.set(sx, sy, sz);
        satelliteGroupRef.current.rotation.y = satAngle + Math.PI / 2;
      }

      // Parallax subtle rotation on starfield
      starField.rotation.y += delta * 0.002;
      starField.rotation.x += delta * 0.0008;

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(renderLoop);
      } else {
        frameId = requestAnimationFrame(renderLoop);
      }
    }

    renderLoop();

    // 9. Resize handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    // 10. Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (isSoftwareGl) {
        clearTimeout(frameId);
      } else {
        cancelAnimationFrame(frameId);
      }

      if (controller) {
        controller.destroy();
      }

      // Dispose Three.js resources
      earthGeo.dispose();
      earthMat.dispose();
      cloudsGeo.dispose();
      cloudsMat.dispose();
      atmosphereGeo.dispose();
      atmosphereMat.dispose();
      orbitGeo.dispose();
      orbitMat.dispose();
      busGeo.dispose();
      busMat.dispose();
      panelGeo.dispose();
      panelMat.dispose();
      dishGeo.dispose();
      dishMat.dispose();
      starGeo.dispose();
      starMat.dispose();

      dayTexture.dispose();
      nightTexture.dispose();
      specularTexture.dispose();
      cloudsTexture.dispose();

      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Sync dynamic layer visibility
  useEffect(() => {
    if (cloudsMeshRef.current) {
      cloudsMeshRef.current.visible = layers.clouds;
    }
    if (atmosphereMeshRef.current) {
      atmosphereMeshRef.current.visible = layers.atmosphere;
    }
    if (orbitRingRef.current) {
      orbitRingRef.current.visible = layers.orbitPath;
    }
    if (satelliteGroupRef.current) {
      satelliteGroupRef.current.visible = layers.satellites;
    }
  }, [layers]);

  return (
    <div
      ref={mountRef}
      className="fixed inset-0 w-full h-full pointer-events-none z-0 overflow-hidden"
      style={{ touchAction: 'none' }}
    />
  );
};
