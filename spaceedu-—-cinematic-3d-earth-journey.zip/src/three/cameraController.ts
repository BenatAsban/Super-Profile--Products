import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import * as THREE from 'three';
import { TelemetryData } from '../types';

gsap.registerPlugin(ScrollTrigger);

export interface CameraAnimationController {
  update: (delta: number) => void;
  destroy: () => void;
  jumpToSection: (sectionIndex: number) => void;
}

export interface SetupProps {
  camera: THREE.PerspectiveCamera;
  earthGroup: THREE.Group;
  cloudsMesh: THREE.Mesh;
  containerElement: HTMLElement;
  sectionsElement: HTMLElement;
  onTelemetryUpdate: (data: TelemetryData) => void;
}

// Cinematic Waypoints for the 6 sections
export const SECTION_CONFIGS = [
  {
    id: 'hero',
    name: 'Sector 01 // Planetary Ingress',
    camPos: { x: 3.2, y: 1.0, z: 7.2 },
    lookAt: { x: 0.9, y: 0.0, z: 0.0 },
    earthPos: { x: 1.1, y: -0.1, z: 0.0 },
    earthRotY: 0.25,
    altitudeKm: 24500,
    speedKms: 3.07,
    phase: 'High Earth Orbit Insertion',
    solarAngleDeg: 42,
    coordinates: '00°00\'N, 24°15\'E',
  },
  {
    id: 'closeup',
    name: 'Sector 02 // Stratospheric Descent',
    camPos: { x: 0.8, y: 0.45, z: 2.75 },
    lookAt: { x: 0.25, y: -0.05, z: 0.0 },
    earthPos: { x: 0.35, y: -0.2, z: 0.0 },
    earthRotY: 1.15,
    altitudeKm: 420,
    speedKms: 7.66,
    phase: 'Low Earth Orbit (LEO) Perigee',
    solarAngleDeg: 68,
    coordinates: '28°36\'N, 80°36\'W',
  },
  {
    id: 'orbital',
    name: 'Sector 03 // Inclined Orbital Vector',
    camPos: { x: -3.4, y: 2.1, z: 4.2 },
    lookAt: { x: -0.4, y: 0.1, z: 0.0 },
    earthPos: { x: -0.4, y: 0.0, z: 0.0 },
    earthRotY: 2.35,
    altitudeKm: 850,
    speedKms: 7.42,
    phase: 'Polar Inclination Survey (51.6°)',
    solarAngleDeg: 110,
    coordinates: '51°10\'N, 01°49\'W',
  },
  {
    id: 'terminator',
    name: 'Sector 04 // Twilight Meridian',
    camPos: { x: -0.3, y: 0.2, z: 3.1 },
    lookAt: { x: 0.0, y: 0.0, z: 0.0 },
    earthPos: { x: 0.0, y: 0.0, z: 0.0 },
    earthRotY: 3.65,
    altitudeKm: 580,
    speedKms: 7.55,
    phase: 'Terminator Crossing & Aurora Watch',
    solarAngleDeg: 90,
    coordinates: '64°08\'N, 21°56\'W',
  },
  {
    id: 'bluemarble',
    name: 'Sector 05 // Global Vantage',
    camPos: { x: 0.0, y: 0.6, z: 7.8 },
    lookAt: { x: 0.0, y: 0.0, z: 0.0 },
    earthPos: { x: 0.0, y: 0.0, z: 0.0 },
    earthRotY: 5.1,
    altitudeKm: 35786,
    speedKms: 3.07,
    phase: 'Geostationary Equilibrium',
    solarAngleDeg: 35,
    coordinates: '00°00\'N, 00°00\'E',
  },
  {
    id: 'deepspace',
    name: 'Sector 06 // Pale Blue Dot',
    camPos: { x: 0.0, y: 1.4, z: 11.2 },
    lookAt: { x: 0.0, y: 0.0, z: 0.0 },
    earthPos: { x: 0.0, y: 0.0, z: 0.0 },
    earthRotY: 6.4,
    altitudeKm: 120000,
    speedKms: 1.45,
    phase: 'Deep Space Cosmic Baseline',
    solarAngleDeg: 15,
    coordinates: '12°00\'S, 45°00\'E',
  },
];

export function setupCameraScrollAnimation({
  camera,
  earthGroup,
  cloudsMesh,
  containerElement,
  sectionsElement,
  onTelemetryUpdate,
}: SetupProps): CameraAnimationController {
  // Animated proxy state interpolated by GSAP ScrollTrigger
  const animState = {
    // Camera position
    camX: SECTION_CONFIGS[0].camPos.x,
    camY: SECTION_CONFIGS[0].camPos.y,
    camZ: SECTION_CONFIGS[0].camPos.z,
    // LookAt position
    lookX: SECTION_CONFIGS[0].lookAt.x,
    lookY: SECTION_CONFIGS[0].lookAt.y,
    lookZ: SECTION_CONFIGS[0].lookAt.z,
    // Earth position
    earthX: SECTION_CONFIGS[0].earthPos.x,
    earthY: SECTION_CONFIGS[0].earthPos.y,
    earthZ: SECTION_CONFIGS[0].earthPos.z,
    // Earth base rotation from scroll
    earthRotY: SECTION_CONFIGS[0].earthRotY,
    // Telemetry values
    altitudeKm: SECTION_CONFIGS[0].altitudeKm,
    speedKms: SECTION_CONFIGS[0].speedKms,
    solarAngleDeg: SECTION_CONFIGS[0].solarAngleDeg,
    sectionIndex: 0,
  };

  // Internal lerp targets for silky smooth damping (avoiding camera jitter)
  const currentLookAt = new THREE.Vector3(animState.lookX, animState.lookY, animState.lookZ);
  const targetLookAt = new THREE.Vector3(animState.lookX, animState.lookY, animState.lookZ);

  // Background idle rotation tracker
  let idleTime = 0;

  // Master GSAP timeline bound to page scroll
  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: containerElement,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1.2, // buttery smooth scrub
      onUpdate: (self) => {
        // Calculate active section from progress (0 to 1 across 5 segments)
        const progress = self.progress;
        const segmentProgress = progress * (SECTION_CONFIGS.length - 1);
        const idx = Math.min(Math.floor(segmentProgress), SECTION_CONFIGS.length - 1);
        const nextIdx = Math.min(idx + 1, SECTION_CONFIGS.length - 1);
        const frac = segmentProgress - idx;

        const currentCfg = SECTION_CONFIGS[idx];
        const nextCfg = SECTION_CONFIGS[nextIdx];

        // Format telemetry
        const alt = Math.round(currentCfg.altitudeKm + (nextCfg.altitudeKm - currentCfg.altitudeKm) * frac);
        const spd = Number((currentCfg.speedKms + (nextCfg.speedKms - currentCfg.speedKms) * frac).toFixed(2));
        const sol = Math.round(currentCfg.solarAngleDeg + (nextCfg.solarAngleDeg - currentCfg.solarAngleDeg) * frac);

        const hours = Math.floor(progress * 18).toString().padStart(2, '0');
        const mins = Math.floor((progress * 1080) % 60).toString().padStart(2, '0');
        const secs = Math.floor((progress * 64800) % 60).toString().padStart(2, '0');

        onTelemetryUpdate({
          altitudeKm: alt,
          speedKms: spd,
          inclination: '51.6° Prograde',
          phase: frac > 0.5 ? nextCfg.phase : currentCfg.phase,
          solarAngleDeg: sol,
          coordinates: frac > 0.5 ? nextCfg.coordinates : currentCfg.coordinates,
          missionTime: `T+00:${hours}:${mins}:${secs}`,
        });
      },
    },
  });

  // Build sequential timeline keyframes across each section
  for (let i = 0; i < SECTION_CONFIGS.length - 1; i++) {
    const from = SECTION_CONFIGS[i];
    const to = SECTION_CONFIGS[i + 1];

    // Duration is proportional (each section gets 1 time unit)
    tl.to(
      animState,
      {
        camX: to.camPos.x,
        camY: to.camPos.y,
        camZ: to.camPos.z,
        lookX: to.lookAt.x,
        lookY: to.lookAt.y,
        lookZ: to.lookAt.z,
        earthX: to.earthPos.x,
        earthY: to.earthPos.y,
        earthZ: to.earthPos.z,
        earthRotY: to.earthRotY,
        altitudeKm: to.altitudeKm,
        speedKms: to.speedKms,
        solarAngleDeg: to.solarAngleDeg,
        ease: 'power2.inOut',
        duration: 1,
      },
      i // start time at index i
    );
  }

  // Setup cinematic entrance animations for text elements in the DOM
  const sectionCards = sectionsElement.querySelectorAll('.cinematic-section');
  sectionCards.forEach((sec, idx) => {
    const content = sec.querySelector('.section-content');
    const badge = sec.querySelector('.section-badge');
    const heading = sec.querySelector('.section-heading');
    const desc = sec.querySelector('.section-desc');
    const elements = sec.querySelectorAll('.section-interactive');

    if (content) {
      // Create scroll-driven reveal and exit for each section
      gsap.fromTo(
        [badge, heading, desc, elements],
        { opacity: 0, y: 35, filter: 'blur(8px)' },
        {
          opacity: 1,
          y: 0,
          filter: 'blur(0px)',
          stagger: 0.12,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sec,
            start: 'top 75%',
            end: 'top 25%',
            toggleActions: 'play reverse play reverse',
          },
        }
      );
    }
  });

  return {
    update: (delta: number) => {
      idleTime += delta;

      // Apply animated camera position smoothly
      camera.position.x = THREE.MathUtils.damp(camera.position.x, animState.camX, 4.5, delta);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, animState.camY, 4.5, delta);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, animState.camZ, 4.5, delta);

      // Smoothly damp lookAt target
      targetLookAt.set(animState.lookX, animState.lookY, animState.lookZ);
      currentLookAt.x = THREE.MathUtils.damp(currentLookAt.x, targetLookAt.x, 5.0, delta);
      currentLookAt.y = THREE.MathUtils.damp(currentLookAt.y, targetLookAt.y, 5.0, delta);
      currentLookAt.z = THREE.MathUtils.damp(currentLookAt.z, targetLookAt.z, 5.0, delta);
      camera.lookAt(currentLookAt);

      // Update Earth group position
      earthGroup.position.x = THREE.MathUtils.damp(earthGroup.position.x, animState.earthX, 4.0, delta);
      earthGroup.position.y = THREE.MathUtils.damp(earthGroup.position.y, animState.earthY, 4.0, delta);
      earthGroup.position.z = THREE.MathUtils.damp(earthGroup.position.z, animState.earthZ, 4.0, delta);

      // Earth rotation: combined scroll rotation + subtle natural planetary axial spin
      const naturalSpin = idleTime * 0.035;
      earthGroup.rotation.y = THREE.MathUtils.damp(earthGroup.rotation.y, animState.earthRotY + naturalSpin, 3.5, delta);
      // Realistic Earth 23.4° axial tilt
      earthGroup.rotation.z = 23.44 * (Math.PI / 180);

      // Clouds rotate slightly faster than Earth surface for atmospheric drift
      if (cloudsMesh) {
        cloudsMesh.rotation.y += delta * 0.015;
      }
    },
    destroy: () => {
      tl.kill();
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    },
    jumpToSection: (sectionIndex: number) => {
      const targetSec = sectionCards[sectionIndex];
      if (targetSec) {
        targetSec.scrollIntoView({ behavior: 'smooth' });
      }
    },
  };
}
