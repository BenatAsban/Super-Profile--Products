import * as THREE from 'three';

// Procedural high-resolution textures for Earth
// Zero 404 dependencies per Three.js directives

// Simple deterministic 2D Simplex/Perlin-style hash & noise for realistic coastlines and clouds
function hash(x: number, y: number): number {
  const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
  return n - Math.floor(n);
}

function noise2D(x: number, y: number): number {
  const i = Math.floor(x);
  const j = Math.floor(y);
  const fx = x - i;
  const fy = y - j;

  // Smoothstep
  const sx = fx * fx * (3 - 2 * fx);
  const sy = fy * fy * (3 - 2 * fy);

  const a = hash(i, j);
  const b = hash(i + 1, j);
  const c = hash(i, j + 1);
  const d = hash(i + 1, j + 1);

  return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
}

function fbm(x: number, y: number, octaves = 5): number {
  let value = 0;
  let amplitude = 0.5;
  let frequency = 1;
  let totalAmp = 0;
  for (let i = 0; i < octaves; i++) {
    value += noise2D(x * frequency, y * frequency) * amplitude;
    totalAmp += amplitude;
    frequency *= 2;
    amplitude *= 0.5;
  }
  return value / totalAmp;
}

// Major continent mask generator for realistic Earth representation
function isLandmass(lonNorm: number, latNorm: number): { isLand: boolean; elevation: number; biome: 'forest' | 'desert' | 'snow' | 'mountain' | 'coast' } {
  // lonNorm: 0 to 1 (corresponds to -180 to +180 deg)
  // latNorm: 0 to 1 (corresponds to +90 to -90 deg: 0 = North Pole, 1 = South Pole)
  const lon = (lonNorm - 0.5) * 360; // -180 to 180
  const lat = (0.5 - latNorm) * 180; // 90 to -90

  // Polar ice caps
  if (lat < -70) {
    return { isLand: true, elevation: 0.9, biome: 'snow' }; // Antarctica
  }
  if (lat > 78) {
    return { isLand: true, elevation: 0.8, biome: 'snow' }; // Greenland / Arctic
  }

  // Define broad continental centers (lon, lat, radiusLon, radiusLat)
  const continents = [
    // North America
    { lon: -100, lat: 45, rx: 42, ry: 25, weight: 1.1 },
    // South America
    { lon: -60, lat: -15, rx: 25, ry: 35, weight: 1.0 },
    // Europe
    { lon: 18, lat: 52, rx: 30, ry: 18, weight: 1.0 },
    // Africa
    { lon: 20, lat: 5, rx: 32, ry: 35, weight: 1.1 },
    // Asia / Siberia
    { lon: 88, lat: 48, rx: 55, ry: 28, weight: 1.2 },
    // East / South Asia
    { lon: 105, lat: 25, rx: 35, ry: 22, weight: 1.0 },
    // Australia
    { lon: 135, lat: -25, rx: 24, ry: 18, weight: 0.95 },
  ];

  let continentField = 0;
  for (const c of continents) {
    const dx = (lon - c.lon) / c.rx;
    const dy = (lat - c.lat) / c.ry;
    const distSq = dx * dx + dy * dy;
    if (distSq < 1.6) {
      continentField += Math.exp(-distSq * 1.8) * c.weight;
    }
  }

  // Add multi-octave FBM noise for realistic fractal coastlines
  const noiseVal = fbm(lonNorm * 18, latNorm * 18, 5);
  const threshold = 0.44 - (noiseVal - 0.5) * 0.42;

  const isLand = continentField > threshold;

  if (!isLand) {
    return { isLand: false, elevation: 0, biome: 'coast' };
  }

  const elevation = Math.min(1, Math.max(0, (continentField - threshold) * 1.5 + noiseVal * 0.4));

  // Determine biome based on latitude, elevation, and noise
  let biome: 'forest' | 'desert' | 'snow' | 'mountain' | 'coast' = 'forest';
  if (elevation > 0.75) {
    biome = 'mountain';
  } else if (Math.abs(lat) > 55 || elevation > 0.9) {
    biome = 'snow';
  } else if ((lat > 14 && lat < 34 && lon > -15 && lon < 55) || (lat < -18 && lat > -32 && lon > 115 && lon < 140)) {
    // Sahara / Arabian / Australian Outback
    biome = 'desert';
  } else if (elevation < 0.15) {
    biome = 'coast';
  } else {
    biome = 'forest';
  }

  return { isLand, elevation, biome };
}

export function createEarthDayTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const latNorm = y / height;
    const latDeg = (0.5 - latNorm) * 180;

    for (let x = 0; x < width; x++) {
      const lonNorm = x / width;
      const idx = (y * width + x) * 4;

      const { isLand, elevation, biome } = isLandmass(lonNorm, latNorm);

      let r = 12;
      let g = 38;
      let b = 88; // Deep oceanic navy blue

      if (!isLand) {
        // Ocean depth shading & shallow coastal turquoise shelf
        const depthNoise = fbm(lonNorm * 30, latNorm * 30, 3);
        const coastalGrad = Math.max(0, 1 - Math.abs(latDeg) / 90);
        r = Math.floor(10 + depthNoise * 15);
        g = Math.floor(35 + depthNoise * 30 + coastalGrad * 15);
        b = Math.floor(85 + depthNoise * 45 + coastalGrad * 30);
      } else {
        // Land biomes
        const detail = fbm(lonNorm * 50, latNorm * 50, 4);
        if (biome === 'snow') {
          // Polar ice / high glaciers
          const val = 210 + Math.floor(detail * 45);
          r = val;
          g = val;
          b = Math.min(255, val + 15);
        } else if (biome === 'desert') {
          // Warm sand / arid terrain
          r = Math.floor(185 + detail * 40);
          g = Math.floor(145 + detail * 30);
          b = Math.floor(95 + detail * 20);
        } else if (biome === 'mountain') {
          // Rocky peaks with alpine snow dust
          if (elevation > 0.88) {
            r = 230;
            g = 235;
            b = 245;
          } else {
            r = Math.floor(110 + detail * 35);
            g = Math.floor(95 + detail * 25);
            b = Math.floor(75 + detail * 20);
          }
        } else if (biome === 'coast') {
          // Lush coastal plains
          r = Math.floor(45 + detail * 30);
          g = Math.floor(105 + detail * 40);
          b = Math.floor(55 + detail * 25);
        } else {
          // Dense temperate / tropical forests & grasslands
          r = Math.floor(35 + detail * 35);
          g = Math.floor(95 + detail * 45);
          b = Math.floor(42 + detail * 25);
        }
      }

      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

export function createEarthNightTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Fill pure space black
  ctx.fillStyle = '#010204';
  ctx.fillRect(0, 0, width, height);

  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const latNorm = y / height;
    const latDeg = (0.5 - latNorm) * 180;

    for (let x = 0; x < width; x++) {
      const lonNorm = x / width;
      const lonDeg = (lonNorm - 0.5) * 360;

      const { isLand, biome } = isLandmass(lonNorm, latNorm);

      if (isLand && biome !== 'snow') {
        const idx = (y * width + x) * 4;
        const cityNoise = fbm(lonNorm * 120, latNorm * 120, 4);

        // Clustered high population zones (North America East, Western Europe, India, East Asia, coastal belts)
        let popDensity = 0;
        if (latDeg > 20 && latDeg < 55 && lonDeg > -125 && lonDeg < -65) popDensity += 0.85; // US
        if (latDeg > 35 && latDeg < 60 && lonDeg > -10 && lonDeg < 40) popDensity += 1.0; // Europe
        if (latDeg > 8 && latDeg < 35 && lonDeg > 68 && lonDeg < 92) popDensity += 0.95; // India
        if (latDeg > 20 && latDeg < 45 && lonDeg > 105 && lonDeg < 145) popDensity += 1.1; // China, Japan, Korea
        if (latDeg > -38 && latDeg < -20 && lonDeg > -55 && lonDeg < -40) popDensity += 0.7; // Brazil coast
        if (latDeg > -38 && latDeg < -25 && lonDeg > 140 && lonDeg < 155) popDensity += 0.7; // SE Australia
        if (latDeg > 22 && latDeg < 32 && lonDeg > 28 && lonDeg < 34) popDensity += 1.2; // Nile river cluster

        const lightFactor = Math.pow(cityNoise, 3.2) * (popDensity + 0.35);

        if (lightFactor > 0.32) {
          const intensity = Math.min(255, Math.floor((lightFactor - 0.32) * 500));
          // Warm golden/amber sodium city light color with high intensity white cores
          data[idx] = Math.min(255, intensity + 30); // R
          data[idx + 1] = Math.min(255, Math.floor(intensity * 0.82)); // G
          data[idx + 2] = Math.min(255, Math.floor(intensity * 0.45)); // B
          data[idx + 3] = 255;
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

export function createEarthSpecularTexture(): THREE.CanvasTexture {
  const width = 1024;
  const height = 512;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const latNorm = y / height;
    for (let x = 0; x < width; x++) {
      const lonNorm = x / width;
      const idx = (y * width + x) * 4;

      const { isLand } = isLandmass(lonNorm, latNorm);
      // Ocean reflects sunlight intensely (specular highlights); land has low gloss
      const val = isLand ? 15 : 220;

      data[idx] = val;
      data[idx + 1] = val;
      data[idx + 2] = val;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

export function createEarthCloudsTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    const latNorm = y / height;
    const lat = (0.5 - latNorm) * Math.PI; // -pi/2 to pi/2

    for (let x = 0; x < width; x++) {
      const lonNorm = x / width;
      const idx = (y * width + x) * 4;

      // Realistic cloud bands: ITCZ at equator, mid-latitude storm tracks
      const equatorialBand = Math.exp(-Math.pow(latNorm - 0.5, 2) * 55);
      const northTrack = Math.exp(-Math.pow(latNorm - 0.28, 2) * 60);
      const southTrack = Math.exp(-Math.pow(latNorm - 0.72, 2) * 60);

      // Multi-octave cloud turbulence
      const cloudNoise1 = fbm(lonNorm * 12, latNorm * 8, 4);
      const cloudNoise2 = fbm(lonNorm * 28 + cloudNoise1 * 0.4, latNorm * 20, 3);
      const density = (cloudNoise2 * 0.7 + equatorialBand * 0.4 + northTrack * 0.35 + southTrack * 0.35);

      if (density > 0.48) {
        const alpha = Math.min(235, Math.floor((density - 0.48) * 450));
        data[idx] = 255;
        data[idx + 1] = 255;
        data[idx + 2] = 255;
        data[idx + 3] = alpha;
      } else {
        data[idx] = 255;
        data[idx + 1] = 255;
        data[idx + 2] = 255;
        data[idx + 3] = 0;
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

export function createStarfieldData(count = 2400): { positions: Float32Array; colors: Float32Array; sizes: Float32Array } {
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  const sizes = new Float32Array(count);

  const starColors = [
    new THREE.Color('#ffffff'), // Pure white
    new THREE.Color('#b0d5ff'), // Blue-white giant
    new THREE.Color('#ffe2a8'), // Warm yellow/orange dwarf
    new THREE.Color('#cceeff'), // Sky blue
  ];

  for (let i = 0; i < count; i++) {
    // Distribute on a wide outer sphere (radius 300 to 500)
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 2 - 1);
    const radius = 320 + Math.random() * 220;

    positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = radius * Math.cos(phi);

    const color = starColors[Math.floor(Math.random() * starColors.length)];
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;

    sizes[i] = 1.0 + Math.random() * 2.2;
  }

  return { positions, colors, sizes };
}
