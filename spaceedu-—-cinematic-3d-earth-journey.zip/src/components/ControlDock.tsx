import React, { useState } from 'react';
import { Eye, EyeOff, Layers, Sparkles, Cloud, Sun, Radio, Compass, ChevronDown, ChevronUp } from 'lucide-react';
import { EarthLayersState } from '../types';
import { SECTION_CONFIGS } from '../three/cameraController';

interface ControlDockProps {
  layers: EarthLayersState;
  onUpdateLayers: (newLayers: Partial<EarthLayersState>) => void;
  activeSectionIndex: number;
  onSelectSection: (index: number) => void;
  isZenMode: boolean;
  onToggleZenMode: () => void;
}

export const ControlDock: React.FC<ControlDockProps> = ({
  layers,
  onUpdateLayers,
  activeSectionIndex,
  onSelectSection,
  isZenMode,
  onToggleZenMode,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 max-w-[min(960px,94vw)] w-full flex flex-col items-center pointer-events-none">
      {/* Collapse / Zen Toggle Tab */}
      <div className="pointer-events-auto mb-1.5 flex items-center space-x-2">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="px-3 py-1 rounded-full bg-[#030712]/90 border border-white/10 text-slate-300 hover:text-white text-xs font-mono flex items-center space-x-1.5 shadow-lg backdrop-blur-md transition-all hover:border-cyan-500/40"
          title="Toggle Control Dock"
        >
          {isCollapsed ? (
            <>
              <ChevronUp className="w-3.5 h-3.5 text-cyan-400" />
              <span>SHOW DOCK</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              <span>HIDE DOCK</span>
            </>
          )}
        </button>

        <button
          onClick={onToggleZenMode}
          className={`px-3 py-1 rounded-full border text-xs font-mono flex items-center space-x-1.5 shadow-lg backdrop-blur-md transition-all ${
            isZenMode
              ? 'bg-cyan-500 text-black border-cyan-400 font-semibold'
              : 'bg-[#030712]/90 border-white/10 text-slate-300 hover:text-white hover:border-cyan-500/40'
          }`}
          title="Cinema Zen Mode (Full 3D view with no HUD)"
        >
          {isZenMode ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-cyan-400" />}
          <span>{isZenMode ? 'EXIT ZEN MODE' : 'ZEN MODE'}</span>
        </button>
      </div>

      {/* Main Dock Drawer */}
      <div
        className={`pointer-events-auto w-full bg-[#030712]/85 border border-white/10 rounded-2xl p-2.5 sm:p-3 shadow-2xl backdrop-blur-xl transition-all duration-300 flex flex-wrap items-center justify-between gap-2.5 ${
          isCollapsed || isZenMode ? 'opacity-0 translate-y-10 pointer-events-none' : 'opacity-100 translate-y-0'
        }`}
      >
        {/* Section Jump Waypoints */}
        <div className="flex items-center space-x-1 overflow-x-auto py-1 scrollbar-none">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider px-1.5 hidden md:inline">
            CAMERA:
          </span>
          {SECTION_CONFIGS.map((cfg, idx) => {
            const isActive = idx === activeSectionIndex;
            const shortName = ['Ingress', 'Close-Up', 'Orbit', 'Terminator', 'Marble', 'Deep Space'][idx];
            return (
              <button
                key={cfg.id}
                onClick={() => onSelectSection(idx)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono whitespace-nowrap transition-all duration-200 flex items-center space-x-1 ${
                  isActive
                    ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 font-medium shadow-sm shadow-cyan-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5 border border-transparent'
                }`}
              >
                <span className="text-[10px] text-cyan-400/80">{idx + 1}</span>
                <span>{shortName}</span>
              </button>
            );
          })}
        </div>

        {/* Earth Layer Toggles */}
        <div className="flex items-center space-x-1.5 pl-2 border-l border-white/10 text-xs font-mono">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider hidden lg:inline">
            LAYERS:
          </span>

          {/* Clouds */}
          <button
            onClick={() => onUpdateLayers({ clouds: !layers.clouds })}
            className={`px-2 py-1 rounded-md border flex items-center space-x-1 transition-all ${
              layers.clouds
                ? 'bg-cyan-950/60 border-cyan-500/30 text-cyan-300'
                : 'bg-white/5 border-white/5 text-slate-500 line-through'
            }`}
            title="Toggle Cloud Weather Mantle"
          >
            <Cloud className="w-3 h-3" />
            <span className="hidden sm:inline">CLOUDS</span>
          </button>

          {/* Atmosphere Glow */}
          <button
            onClick={() => onUpdateLayers({ atmosphere: !layers.atmosphere })}
            className={`px-2 py-1 rounded-md border flex items-center space-x-1 transition-all ${
              layers.atmosphere
                ? 'bg-cyan-950/60 border-cyan-500/30 text-cyan-300'
                : 'bg-white/5 border-white/5 text-slate-500 line-through'
            }`}
            title="Toggle Atmospheric Rayleigh Glow"
          >
            <Sparkles className="w-3 h-3" />
            <span className="hidden sm:inline">GLOW</span>
          </button>

          {/* Orbit Spline */}
          <button
            onClick={() => onUpdateLayers({ orbitPath: !layers.orbitPath })}
            className={`px-2 py-1 rounded-md border flex items-center space-x-1 transition-all ${
              layers.orbitPath
                ? 'bg-cyan-950/60 border-cyan-500/30 text-cyan-300'
                : 'bg-white/5 border-white/5 text-slate-500 line-through'
            }`}
            title="Toggle Orbital Trajectory Ring"
          >
            <Compass className="w-3 h-3" />
            <span className="hidden sm:inline">ORBIT</span>
          </button>

          {/* Satellites */}
          <button
            onClick={() => onUpdateLayers({ satellites: !layers.satellites })}
            className={`px-2 py-1 rounded-md border flex items-center space-x-1 transition-all ${
              layers.satellites
                ? 'bg-cyan-950/60 border-cyan-500/30 text-cyan-300'
                : 'bg-white/5 border-white/5 text-slate-500 line-through'
            }`}
            title="Toggle Satellite Crafts"
          >
            <Radio className="w-3 h-3" />
            <span className="hidden sm:inline">CRAFT</span>
          </button>
        </div>
      </div>
    </div>
  );
};
