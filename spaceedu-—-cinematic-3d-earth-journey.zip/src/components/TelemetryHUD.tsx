import React from 'react';
import { Gauge, Navigation, Compass, Sun, Clock, Orbit } from 'lucide-react';
import { TelemetryData } from '../types';

interface TelemetryHUDProps {
  telemetry: TelemetryData;
  isZenMode: boolean;
}

export const TelemetryHUD: React.FC<TelemetryHUDProps> = ({ telemetry, isZenMode }) => {
  if (isZenMode) return null;

  return (
    <aside className="fixed top-18 right-4 md:right-8 z-30 pointer-events-none select-none max-w-[280px] hidden sm:block">
      <div className="bg-[#030712]/80 border border-white/10 rounded-xl p-3.5 shadow-2xl backdrop-blur-md pointer-events-auto transition-all">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-white/10">
          <div className="flex items-center space-x-1.5 text-cyan-400">
            <Orbit className="w-3.5 h-3.5" />
            <span className="font-mono text-[11px] font-semibold tracking-wider uppercase">
              ORBITAL TELEMETRY
            </span>
          </div>
          <span className="font-mono text-[10px] text-slate-400">
            {telemetry.missionTime}
          </span>
        </div>

        {/* Primary Metrics Grid */}
        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
          {/* Altitude */}
          <div className="bg-white/5 rounded-lg p-2 border border-white/5">
            <div className="flex items-center space-x-1 text-slate-400 text-[10px] mb-0.5">
              <Gauge className="w-3 h-3 text-cyan-400" />
              <span>ALTITUDE</span>
            </div>
            <div className="text-sm font-bold text-white flex items-baseline space-x-1">
              <span>{telemetry.altitudeKm.toLocaleString()}</span>
              <span className="text-[10px] text-cyan-400 font-normal">KM</span>
            </div>
          </div>

          {/* Orbital Velocity */}
          <div className="bg-white/5 rounded-lg p-2 border border-white/5">
            <div className="flex items-center space-x-1 text-slate-400 text-[10px] mb-0.5">
              <Navigation className="w-3 h-3 text-cyan-400" />
              <span>VELOCITY</span>
            </div>
            <div className="text-sm font-bold text-white flex items-baseline space-x-1">
              <span>{telemetry.speedKms}</span>
              <span className="text-[10px] text-cyan-400 font-normal">KM/S</span>
            </div>
          </div>

          {/* Sub-solar Angle */}
          <div className="bg-white/5 rounded-lg p-2 border border-white/5">
            <div className="flex items-center space-x-1 text-slate-400 text-[10px] mb-0.5">
              <Sun className="w-3 h-3 text-amber-400" />
              <span>SOLAR ANGLE</span>
            </div>
            <div className="text-xs font-semibold text-slate-200">
              {telemetry.solarAngleDeg}°
            </div>
          </div>

          {/* Inclination */}
          <div className="bg-white/5 rounded-lg p-2 border border-white/5">
            <div className="flex items-center space-x-1 text-slate-400 text-[10px] mb-0.5">
              <Compass className="w-3 h-3 text-cyan-400" />
              <span>INCLINATION</span>
            </div>
            <div className="text-xs font-semibold text-slate-200 truncate">
              {telemetry.inclination}
            </div>
          </div>
        </div>

        {/* Current Ground Track Coordinates */}
        <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] font-mono text-slate-400">
          <span>GROUND TRACK:</span>
          <span className="text-cyan-300 font-medium">{telemetry.coordinates}</span>
        </div>

        {/* Mission Flight Phase */}
        <div className="mt-1.5 px-2 py-1 rounded bg-cyan-950/40 border border-cyan-800/30 text-[10px] font-mono text-cyan-300 truncate">
          {telemetry.phase}
        </div>
      </div>
    </aside>
  );
};
