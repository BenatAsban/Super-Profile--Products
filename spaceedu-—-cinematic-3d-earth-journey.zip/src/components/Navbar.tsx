import React from 'react';
import { Compass, Volume2, VolumeX, Radio, Globe, ChevronRight } from 'lucide-react';
import { SECTION_CONFIGS } from '../three/cameraController';

interface NavbarProps {
  activeSectionIndex: number;
  onSelectSection: (index: number) => void;
  isAudioActive: boolean;
  onToggleAudio: () => void;
  isZenMode: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeSectionIndex,
  onSelectSection,
  isAudioActive,
  onToggleAudio,
  isZenMode,
}) => {
  if (isZenMode) return null;

  return (
    <header className="fixed top-0 left-0 right-0 z-40 px-4 md:px-8 py-3.5 flex items-center justify-between border-b border-white/5 bg-[#030712]/70 backdrop-blur-md transition-all duration-300">
      {/* Brand & Mission */}
      <div className="flex items-center space-x-3.5">
        <div className="w-9 h-9 rounded-lg bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-lg shadow-cyan-950/40">
          <Globe className="w-5 h-5 animate-spin" style={{ animationDuration: '24s' }} />
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <span className="font-['Space_Grotesk'] font-bold text-base tracking-wider text-white">
              SPACE<span className="text-cyan-400">EDU</span>
            </span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              SOL-3 EXPEDITION
            </span>
          </div>
          <p className="text-[11px] font-mono text-slate-400 hidden sm:block">
            Cinematic Orbital Camera Telemetry
          </p>
        </div>
      </div>

      {/* Nav waypoints */}
      <nav className="hidden lg:flex items-center space-x-1 font-mono text-xs">
        {SECTION_CONFIGS.map((cfg, idx) => {
          const isActive = idx === activeSectionIndex;
          const label = cfg.name.split('//')[1]?.trim() || cfg.name;
          return (
            <button
              key={cfg.id}
              onClick={() => onSelectSection(idx)}
              className={`px-3 py-1.5 rounded-md transition-all duration-200 flex items-center space-x-1.5 ${
                isActive
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-medium'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
              }`}
            >
              <span className="text-[10px] opacity-60">0{idx + 1}</span>
              <span>{label}</span>
            </button>
          );
        })}
      </nav>

      {/* Actions */}
      <div className="flex items-center space-x-2.5">
        {/* Sound toggle */}
        <button
          onClick={onToggleAudio}
          className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-mono transition-all ${
            isAudioActive
              ? 'bg-cyan-500/20 border-cyan-400/40 text-cyan-300'
              : 'bg-white/5 border-white/10 text-slate-400 hover:text-slate-200'
          }`}
          title={isAudioActive ? 'Mute ambient space drone' : 'Play ambient space drone'}
        >
          {isAudioActive ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          <span className="hidden sm:inline">{isAudioActive ? 'AUDIO ON' : 'AUDIO OFF'}</span>
        </button>

        {/* Live Expedition status */}
        <div className="hidden sm:flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 text-xs font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span>LEO INGRESS</span>
        </div>

        {/* Jump to Next */}
        <button
          onClick={() => {
            const next = (activeSectionIndex + 1) % SECTION_CONFIGS.length;
            onSelectSection(next);
          }}
          className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-black font-semibold text-xs tracking-wide transition-all shadow-md shadow-cyan-600/30"
        >
          <span>NEXT SECTOR</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
