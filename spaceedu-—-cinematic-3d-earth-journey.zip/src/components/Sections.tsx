import React, { useState } from 'react';
import {
  ChevronDown,
  Layers,
  Compass,
  Sun,
  Moon,
  Globe,
  Radio,
  BookOpen,
  ArrowRight,
  Shield,
  Wind,
  Droplets,
  Zap,
  Activity,
  Award,
} from 'lucide-react';

interface SectionsProps {
  onScrollToNext: () => void;
  onJumpToSection: (index: number) => void;
}

export const Sections: React.FC<SectionsProps> = ({ onScrollToNext, onJumpToSection }) => {
  // State for interactive educational tabs in Section 5
  const [selectedModule, setSelectedModule] = useState(0);

  // State for interactive close-up biome selector in Section 2
  const [selectedBiome, setSelectedBiome] = useState<'atmosphere' | 'hydrosphere' | 'cryosphere'>('atmosphere');

  return (
    <div className="relative z-10 w-full flex flex-col pointer-events-none">
      {/* ======================================================== */}
      {/* SECTION 1: HERO — THE CRADLE OF HUMANITY */}
      {/* ======================================================== */}
      <section className="cinematic-section min-h-screen w-full flex flex-col justify-center px-6 md:px-16 lg:px-24 py-24">
        <div className="section-content max-w-2xl pointer-events-auto">
          {/* Badge */}
          <div className="section-badge inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>SECTOR 01 // ORBITAL INSERTION</span>
          </div>

          {/* Heading */}
          <h1 className="section-heading font-['Space_Grotesk'] text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.08] mb-6">
            THE CRADLE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400">
              OF HUMANITY
            </span>
          </h1>

          {/* Description */}
          <p className="section-desc text-base sm:text-lg text-slate-300 font-light leading-relaxed mb-8 max-w-xl">
            Embark on a continuous, scroll-driven orbital journey around Earth.
            From high celestial apogee to stratospheric close-up, experience our living biosphere,
            atmospheric scattering, and day-night terminator through real-time 3D flight mechanics.
          </p>

          {/* Interactive chips & CTA */}
          <div className="section-interactive flex flex-wrap items-center gap-3">
            <button
              onClick={() => onJumpToSection(1)}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 hover:from-cyan-400 hover:to-sky-500 text-black font-semibold text-sm tracking-wide shadow-lg shadow-cyan-500/25 transition-all flex items-center space-x-2 group"
            >
              <span>BEGIN DESCENT</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => onJumpToSection(4)}
              className="px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-sm font-mono transition-all"
            >
              EXPLORE BLUE MARBLE
            </button>
          </div>

          {/* Quick telemetry preview chips */}
          <div className="section-interactive mt-12 grid grid-cols-3 gap-3 max-w-lg">
            <div className="bg-[#030712]/75 border border-white/10 rounded-xl p-3 backdrop-blur-md">
              <div className="text-[10px] font-mono text-slate-400">PLANETARY MASS</div>
              <div className="text-sm font-bold text-white font-mono mt-0.5">5.972 × 10²⁴ kg</div>
            </div>
            <div className="bg-[#030712]/75 border border-white/10 rounded-xl p-3 backdrop-blur-md">
              <div className="text-[10px] font-mono text-slate-400">EQUATORIAL RADIUS</div>
              <div className="text-sm font-bold text-white font-mono mt-0.5">6,378.1 km</div>
            </div>
            <div className="bg-[#030712]/75 border border-white/10 rounded-xl p-3 backdrop-blur-md">
              <div className="text-[10px] font-mono text-slate-400">ORBIT VELOCITY</div>
              <div className="text-sm font-bold text-cyan-400 font-mono mt-0.5">7.66 km/s</div>
            </div>
          </div>
        </div>

        {/* Scroll down indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-auto cursor-pointer" onClick={onScrollToNext}>
          <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 mb-2">
            SCROLL TO COMMENCE FLIGHT
          </span>
          <div className="w-6 h-10 rounded-full border border-white/20 flex items-start justify-center p-1.5 bg-[#030712]/50 backdrop-blur-sm">
            <div className="w-1.5 h-2.5 rounded-full bg-cyan-400 animate-bounce" />
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 2: EXTREME CLOSE-UP — STRATOSPHERIC DESCENT */}
      {/* ======================================================== */}
      <section className="cinematic-section min-h-screen w-full flex flex-col justify-center px-6 md:px-16 lg:px-24 py-24">
        <div className="section-content max-w-2xl pointer-events-auto">
          {/* Badge */}
          <div className="section-badge inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-sky-400" />
            <span>SECTOR 02 // EXTREME CLOSE-UP</span>
          </div>

          {/* Heading */}
          <h2 className="section-heading font-['Space_Grotesk'] text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight mb-4">
            ATMOSPHERIC OCEAN <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-teal-300">
              & LIVING BIOMES
            </span>
          </h2>

          {/* Description */}
          <p className="section-desc text-slate-300 text-base leading-relaxed mb-6 font-light">
            As your spacecraft descends toward 420 km perigee, Earth fills the forward canopy.
            Observe the razor-thin blue veil that shields all known biology against hard solar radiation
            and the vacuum of space.
          </p>

          {/* Interactive Biome Tabs */}
          <div className="section-interactive flex items-center space-x-2 mb-4 font-mono text-xs">
            <button
              onClick={() => setSelectedBiome('atmosphere')}
              className={`px-3 py-1.5 rounded-lg border transition-all ${
                selectedBiome === 'atmosphere'
                  ? 'bg-sky-500/20 border-sky-400 text-sky-200 font-semibold'
                  : 'bg-[#030712]/60 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              ATMOSPHERE
            </button>
            <button
              onClick={() => setSelectedBiome('hydrosphere')}
              className={`px-3 py-1.5 rounded-lg border transition-all ${
                selectedBiome === 'hydrosphere'
                  ? 'bg-teal-500/20 border-teal-400 text-teal-200 font-semibold'
                  : 'bg-[#030712]/60 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              HYDROSPHERE
            </button>
            <button
              onClick={() => setSelectedBiome('cryosphere')}
              className={`px-3 py-1.5 rounded-lg border transition-all ${
                selectedBiome === 'cryosphere'
                  ? 'bg-indigo-500/20 border-indigo-400 text-indigo-200 font-semibold'
                  : 'bg-[#030712]/60 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              CRYOSPHERE
            </button>
          </div>

          {/* Tab content card */}
          <div className="section-interactive bg-[#030712]/80 border border-white/10 rounded-2xl p-5 backdrop-blur-md shadow-xl">
            {selectedBiome === 'atmosphere' && (
              <div>
                <div className="flex items-center space-x-2 text-sky-400 mb-2">
                  <Wind className="w-4 h-4" />
                  <span className="font-mono text-xs font-semibold uppercase">The Gaseous Mantle</span>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Composed of 78.08% Nitrogen, 20.95% Oxygen, and trace gases. 99% of atmospheric mass
                  resides below 32 km. The Kármán line at 100 km marks the boundary where orbital speed
                  replaces aerodynamic lift.
                </p>
                <div className="mt-3 flex items-center space-x-4 text-xs font-mono text-slate-400">
                  <span>Surface Pressure: 101.325 kPa</span>
                  <span className="text-sky-300">Scale Height: 8.5 km</span>
                </div>
              </div>
            )}

            {selectedBiome === 'hydrosphere' && (
              <div>
                <div className="flex items-center space-x-2 text-teal-400 mb-2">
                  <Droplets className="w-4 h-4" />
                  <span className="font-mono text-xs font-semibold uppercase">The Planetary Thermal Sink</span>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Oceans cover 70.8% of the surface with an average depth of 3,688 meters. Acting as a massive
                  thermal flywheel, the oceans absorb over 90% of excess solar heat and drive the global thermohaline conveyor belt.
                </p>
                <div className="mt-3 flex items-center space-x-4 text-xs font-mono text-slate-400">
                  <span>Total Volume: 1.335 × 10⁹ km³</span>
                  <span className="text-teal-300">Salinity: 3.5%</span>
                </div>
              </div>
            )}

            {selectedBiome === 'cryosphere' && (
              <div>
                <div className="flex items-center space-x-2 text-indigo-400 mb-2">
                  <Shield className="w-4 h-4" />
                  <span className="font-mono text-xs font-semibold uppercase">Albedo Shield & Polar Glaciers</span>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Antarctica and Greenland store over 68% of the world’s freshwater. High surface albedo reflects up to
                  85% of incoming solar irradiance back into space, maintaining global temperature equilibrium.
                </p>
                <div className="mt-3 flex items-center space-x-4 text-xs font-mono text-slate-400">
                  <span>Antarctic Ice Sheet: 27M km³</span>
                  <span className="text-indigo-300">Albedo: 0.85</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 3: ORBITAL CAMERA MOVEMENT — ORBITAL MECHANICS */}
      {/* ======================================================== */}
      <section className="cinematic-section min-h-screen w-full flex flex-col justify-center px-6 md:px-16 lg:px-24 py-24">
        <div className="section-content max-w-2xl ml-auto pointer-events-auto">
          {/* Badge */}
          <div className="section-badge inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-indigo-400" />
            <span>SECTOR 03 // ORBITAL SWEEP</span>
          </div>

          {/* Heading */}
          <h2 className="section-heading font-['Space_Grotesk'] text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight mb-4">
            ORBITAL MECHANICS <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400">
              & SATELLITE DYNAMICS
            </span>
          </h2>

          {/* Description */}
          <p className="section-desc text-slate-300 text-base leading-relaxed mb-6 font-light">
            Travelling at 27,600 km/h, spacecraft in Low Earth Orbit complete a revolution every 92 minutes.
            The camera swings along an inclined orbital vector, showcasing parallax depth against the distant starfield.
          </p>

          {/* Technical Specs Cards */}
          <div className="section-interactive grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            <div className="bg-[#030712]/80 border border-white/10 rounded-xl p-4 backdrop-blur-md">
              <div className="flex items-center space-x-2 text-indigo-400 text-xs font-mono mb-1">
                <Compass className="w-4 h-4" />
                <span>KEPLER’S 1ST LAW</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Orbits are ellipses with the primary body at one focus. In LEO, eccentricity is near 0.0002, creating an almost perfect circular free-fall.
              </p>
            </div>

            <div className="bg-[#030712]/80 border border-white/10 rounded-xl p-4 backdrop-blur-md">
              <div className="flex items-center space-x-2 text-pink-400 text-xs font-mono mb-1">
                <Zap className="w-4 h-4" />
                <span>ESCAPE VELOCITY</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                At Earth’s surface, parabolic escape velocity is 11.186 km/s (Mach 33). Spacecraft require precise delta-V burns for orbital maneuvers.
              </p>
            </div>
          </div>

          {/* Interactive ground track indicator */}
          <div className="section-interactive bg-white/5 border border-white/10 rounded-xl p-3.5 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center space-x-2 text-slate-300">
              <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>ISS INCLINATION: 51.64° PROGRADE</span>
            </div>
            <span className="text-cyan-400">GROUND TRACK ACTIVE</span>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 4: TERMINATOR LINE — TWILIGHT MERIDIAN */}
      {/* ======================================================== */}
      <section className="cinematic-section min-h-screen w-full flex flex-col justify-center px-6 md:px-16 lg:px-24 py-24">
        <div className="section-content max-w-2xl pointer-events-auto">
          {/* Badge */}
          <div className="section-badge inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>SECTOR 04 // THE TERMINATOR</span>
          </div>

          {/* Heading */}
          <h2 className="section-heading font-['Space_Grotesk'] text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight mb-4">
            THE TERMINATOR: <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-300 to-rose-400">
              DAWN & CIVILIZATION
            </span>
          </h2>

          {/* Description */}
          <p className="section-desc text-slate-300 text-base leading-relaxed mb-6 font-light">
            Observe the dramatic day-night boundary slicing across the globe. As direct sunlight gives way to the shadow
            of space, the glowing golden arterial networks of human civilization ignite across the dark continents.
          </p>

          {/* Day vs Night physics */}
          <div className="section-interactive grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="bg-[#030712]/80 border border-amber-500/20 rounded-xl p-4 backdrop-blur-md">
              <div className="flex items-center space-x-2 text-amber-400 text-xs font-mono mb-1.5">
                <Sun className="w-4 h-4" />
                <span>SOLAR ILLUMINATION</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Solar irradiance reaches 1,361 W/m² at the top of the atmosphere. Rayleigh scattering scatters short blue wavelengths,
                painting the limb cyan, while twilight filters into warm crimson and amber.
              </p>
            </div>

            <div className="bg-[#030712]/80 border border-indigo-500/20 rounded-xl p-4 backdrop-blur-md">
              <div className="flex items-center space-x-2 text-indigo-400 text-xs font-mono mb-1.5">
                <Moon className="w-4 h-4" />
                <span>NOCTURNAL RADIANCE</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Urban agglomerations, highway corridors, and maritime ports emit distinct golden sodium signatures,
                visible from hundreds of kilometers above the surface.
              </p>
            </div>
          </div>

          {/* Quote / Reflection */}
          <blockquote className="section-interactive border-l-2 border-amber-400/40 pl-4 py-1 text-xs text-slate-400 italic font-light">
            "Looking down at the terminator line from orbit is like seeing the boundary between time itself — yesterday and tomorrow coexisting in a single glance."
          </blockquote>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 5: BLUE MARBLE — EARTH SYSTEM SCIENCE */}
      {/* ======================================================== */}
      <section className="cinematic-section min-h-screen w-full flex flex-col justify-center items-center text-center px-6 md:px-16 py-24">
        <div className="section-content max-w-3xl pointer-events-auto">
          {/* Badge */}
          <div className="section-badge inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>SECTOR 05 // GLOBAL VANTAGE</span>
          </div>

          {/* Heading */}
          <h2 className="section-heading font-['Space_Grotesk'] text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight mb-4">
            THE BLUE MARBLE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-300">
              EARTH SYSTEM SCIENCE
            </span>
          </h2>

          {/* Description */}
          <p className="section-desc text-slate-300 text-base leading-relaxed mb-8 font-light max-w-2xl mx-auto">
            Pulling back into geostationary perspective reveals Earth as a unified, interconnected biogeochemical engine.
            Explore the core interactive curriculum modules below.
          </p>

          {/* Module Selector Buttons */}
          <div className="section-interactive flex flex-wrap justify-center gap-2.5 mb-6 font-mono text-xs">
            {[
              { id: 0, label: '01 LITHOSPHERE & TECTONICS', icon: Globe },
              { id: 1, label: '02 HYDROLOGICAL CYCLE', icon: Droplets },
              { id: 2, label: '03 GEOMAGNETIC SHIELD', icon: Shield },
            ].map((m) => {
              const Icon = m.icon;
              const isSelected = selectedModule === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setSelectedModule(m.id)}
                  className={`px-4 py-2 rounded-xl border flex items-center space-x-2 transition-all ${
                    isSelected
                      ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-md shadow-cyan-500/20 font-semibold'
                      : 'bg-[#030712]/70 border-white/10 text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>

          {/* Selected Module Detail Card */}
          <div className="section-interactive bg-[#030712]/85 border border-white/10 rounded-2xl p-6 backdrop-blur-md shadow-2xl max-w-2xl mx-auto text-left">
            {selectedModule === 0 && (
              <div>
                <h3 className="text-base font-semibold text-white mb-2 font-['Space_Grotesk']">
                  Module 01: Lithosphere Dynamics & Crustal Drift
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  Seven major lithospheric plates float atop the plastic asthenosphere at rates of 2 to 10 cm per year.
                  Subduction zones recycle carbon into the mantle, volcanic outgassing replenished prehistoric oceans,
                  and mountain building continues shaping continental geography.
                </p>
                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">CRUST THICKNESS</div>
                    <div className="text-white font-bold mt-0.5">5 – 70 km</div>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">MANTLE DEPTH</div>
                    <div className="text-white font-bold mt-0.5">2,900 km</div>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">CORE TEMPERATURE</div>
                    <div className="text-cyan-400 font-bold mt-0.5">~5,400 K</div>
                  </div>
                </div>
              </div>
            )}

            {selectedModule === 1 && (
              <div>
                <h3 className="text-base font-semibold text-white mb-2 font-['Space_Grotesk']">
                  Module 02: Global Hydrological Engine & Evaporative Lift
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  Driven by solar insolation, over 505,000 km³ of water evaporates into the atmosphere annually.
                  Atmospheric rivers transport moisture across oceans, sustaining continental agriculture and replenishing
                  subsurface aquifers that support billions of people.
                </p>
                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">PRECIPITATION</div>
                    <div className="text-white font-bold mt-0.5">113,000 km³/yr</div>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">RESIDENCE TIME</div>
                    <div className="text-white font-bold mt-0.5">9 Days</div>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">LATENT HEAT FLUX</div>
                    <div className="text-cyan-400 font-bold mt-0.5">~80 W/m²</div>
                  </div>
                </div>
              </div>
            )}

            {selectedModule === 2 && (
              <div>
                <h3 className="text-base font-semibold text-white mb-2 font-['Space_Grotesk']">
                  Module 03: The Magnetosphere & Solar Wind Shield
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  Convection in Earth’s molten liquid iron outer core generates a dipolar magnetic field extending over
                  60,000 km towards the Sun and millions of kilometers into the magnetotail. It deflects charged solar plasma
                  that would otherwise strip away the planetary atmosphere.
                </p>
                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">SURFACE FIELD</div>
                    <div className="text-white font-bold mt-0.5">25 – 65 µT</div>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">BOW SHOCK</div>
                    <div className="text-white font-bold mt-0.5">10–12 Earth Radii</div>
                  </div>
                  <div className="bg-white/5 rounded-lg p-2 border border-white/5">
                    <div className="text-[10px] text-slate-400">VAN ALLEN BELTS</div>
                    <div className="text-cyan-400 font-bold mt-0.5">2 Concentric</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* SECTION 6: FINAL EARTH REVEAL — DEEP SPACE PERSPECTIVE */}
      {/* ======================================================== */}
      <section className="cinematic-section min-h-screen w-full flex flex-col justify-center items-center text-center px-6 md:px-16 py-28">
        <div className="section-content max-w-3xl pointer-events-auto">
          {/* Badge */}
          <div className="section-badge inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-6">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>SECTOR 06 // DEEP SPACE REVEAL</span>
          </div>

          {/* Heading */}
          <h2 className="section-heading font-['Space_Grotesk'] text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-tight mb-6">
            PLANET <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-white">EARTH</span>
          </h2>

          {/* Description */}
          <p className="section-desc text-slate-300 text-base sm:text-lg leading-relaxed mb-10 font-light max-w-2xl mx-auto">
            Suspended in the quiet expanse of the cosmos, our oasis of life continues its timeless orbital dance.
            Join thousands of researchers, students, and space explorers participating in the SpaceEdu global planetary fellowship.
          </p>

          {/* Action Cards */}
          <div className="section-interactive grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl mx-auto mb-10">
            <div className="bg-[#030712]/80 border border-white/10 hover:border-cyan-500/40 rounded-2xl p-5 text-left backdrop-blur-md transition-all shadow-xl group cursor-pointer" onClick={() => onJumpToSection(0)}>
              <div className="w-9 h-9 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-3 group-hover:bg-cyan-500/20 transition-colors">
                <Compass className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-semibold text-white mb-1">Replay Orbital Flight</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Reset camera trajectory to Sector 01 ingress and control the spacecraft journey again.
              </p>
            </div>

            <div className="bg-[#030712]/80 border border-white/10 hover:border-sky-500/40 rounded-2xl p-5 text-left backdrop-blur-md transition-all shadow-xl group cursor-pointer">
              <div className="w-9 h-9 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center mb-3 group-hover:bg-sky-500/20 transition-colors">
                <Award className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-semibold text-white mb-1">SpaceEdu Certification</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Complete all six planetary science assessments to earn your accredited orbital diploma.
              </p>
            </div>
          </div>

          {/* Final Call to Action */}
          <div className="section-interactive flex flex-wrap justify-center gap-3">
            <button
              onClick={() => onJumpToSection(0)}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 hover:from-cyan-400 hover:to-sky-500 text-black font-semibold text-sm tracking-wide shadow-lg shadow-cyan-500/25 transition-all"
            >
              RETURN TO INGRESS (TOP)
            </button>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* FOOTER */}
      {/* ======================================================== */}
      <footer className="w-full border-t border-white/10 bg-[#030712]/90 backdrop-blur-xl px-6 md:px-16 py-12 pointer-events-auto text-xs font-mono text-slate-400">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-white font-['Space_Grotesk'] font-bold text-sm mb-1">
              <Globe className="w-4 h-4 text-cyan-400" />
              <span>SPACEEDU GLOBAL EXPEDITION</span>
            </div>
            <p className="text-slate-500 text-[11px]">
              Three.js + WebGL + GSAP ScrollTrigger Cinematic 3D Earth Experience
            </p>
          </div>

          <div className="flex flex-wrap gap-6 text-[11px]">
            <div>
              <span className="text-slate-300 font-semibold block mb-0.5">COORDINATES</span>
              <span className="text-slate-500">Sol-3 // Orbit Radius 1.000 AU</span>
            </div>
            <div>
              <span className="text-slate-300 font-semibold block mb-0.5">ESCAPE SPEED</span>
              <span className="text-slate-500">11.186 km/s (Mach 33)</span>
            </div>
            <div>
              <span className="text-slate-300 font-semibold block mb-0.5">AXIAL TILT</span>
              <span className="text-slate-500">23.44° Obliquity</span>
            </div>
          </div>

          <div className="text-[11px] text-slate-500">
            © {new Date().getFullYear()} SpaceEdu Science Foundation. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};
