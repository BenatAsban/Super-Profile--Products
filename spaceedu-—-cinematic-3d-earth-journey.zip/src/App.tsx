/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { SpaceScene } from './three/SpaceScene';
import { Navbar } from './components/Navbar';
import { TelemetryHUD } from './components/TelemetryHUD';
import { ControlDock } from './components/ControlDock';
import { Sections } from './components/Sections';
import { CameraAnimationController, SECTION_CONFIGS } from './three/cameraController';
import { EarthLayersState, TelemetryData } from './types';
import { spaceAudio } from './utils/audio';

export default function App() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const sectionsContainerRef = useRef<HTMLDivElement>(null);
  const controllerRef = useRef<CameraAnimationController | null>(null);

  // Earth display layers
  const [layers, setLayers] = useState<EarthLayersState>({
    clouds: true,
    atmosphere: true,
    nightLights: true,
    orbitPath: true,
    satellites: true,
    rotationSpeed: 1.0,
  });

  // Flight telemetry
  const [telemetry, setTelemetry] = useState<TelemetryData>({
    altitudeKm: SECTION_CONFIGS[0].altitudeKm,
    speedKms: SECTION_CONFIGS[0].speedKms,
    inclination: '51.6° Prograde',
    phase: SECTION_CONFIGS[0].phase,
    solarAngleDeg: SECTION_CONFIGS[0].solarAngleDeg,
    coordinates: SECTION_CONFIGS[0].coordinates,
    missionTime: 'T+00:00:00:00',
  });

  const [activeSectionIndex, setActiveSectionIndex] = useState(0);
  const [isAudioActive, setIsAudioActive] = useState(false);
  const [isZenMode, setIsZenMode] = useState(false);

  // Handle telemetry update from Three.js scroll controller
  const handleTelemetryUpdate = useCallback((data: TelemetryData) => {
    setTelemetry(data);
  }, []);

  // Set active section based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      if (!scrollContainerRef.current) return;
      const scrollY = window.scrollY;
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight <= 0) return;

      const progress = scrollY / totalHeight;
      const segment = progress * (SECTION_CONFIGS.length - 1);
      const activeIdx = Math.min(Math.round(segment), SECTION_CONFIGS.length - 1);
      setActiveSectionIndex(activeIdx);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Jump to specific section
  const handleSelectSection = (index: number) => {
    if (controllerRef.current) {
      controllerRef.current.jumpToSection(index);
    } else {
      const sections = document.querySelectorAll('.cinematic-section');
      if (sections[index]) {
        sections[index].scrollIntoView({ behavior: 'smooth' });
      }
    }
    setActiveSectionIndex(index);
  };

  const handleScrollToNext = () => {
    handleSelectSection(1);
  };

  const handleToggleAudio = () => {
    const active = spaceAudio.toggle();
    setIsAudioActive(active);
  };

  const handleToggleZenMode = () => {
    setIsZenMode((prev) => !prev);
  };

  const handleUpdateLayers = (newLayers: Partial<EarthLayersState>) => {
    setLayers((prev) => ({ ...prev, ...newLayers }));
  };

  // Keyboard navigation shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.key === 'z' || e.key === 'Z' || e.key === 'h' || e.key === 'H') {
        setIsZenMode((prev) => !prev);
      } else if (e.key === 'm' || e.key === 'M') {
        handleToggleAudio();
      } else if (e.key >= '1' && e.key <= '6') {
        const idx = parseInt(e.key, 10) - 1;
        handleSelectSection(idx);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div
      ref={scrollContainerRef}
      className="relative min-h-screen w-full bg-[#030712] text-slate-100 overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200"
    >
      {/* 1. Full-screen 3D Three.js WebGL Scene (Fixed background) */}
      <SpaceScene
        layers={layers}
        onTelemetryUpdate={handleTelemetryUpdate}
        onControllerReady={(controller) => {
          controllerRef.current = controller;
        }}
        scrollContainerRef={scrollContainerRef}
        sectionsContainerRef={sectionsContainerRef}
      />

      {/* 2. Top Navigation Bar */}
      <Navbar
        activeSectionIndex={activeSectionIndex}
        onSelectSection={handleSelectSection}
        isAudioActive={isAudioActive}
        onToggleAudio={handleToggleAudio}
        isZenMode={isZenMode}
      />

      {/* 3. Flight Telemetry HUD (Fixed upper right) */}
      <TelemetryHUD telemetry={telemetry} isZenMode={isZenMode} />

      {/* 4. Scrollable Narrative & Educational Sections (Drives GSAP camera trajectory) */}
      <div ref={sectionsContainerRef} className="relative z-10 w-full">
        <Sections
          onScrollToNext={handleScrollToNext}
          onJumpToSection={handleSelectSection}
        />
      </div>

      {/* 5. Ergonomic Collapsible Bottom Dock (Zero center occlusion per Three.js skill) */}
      <ControlDock
        layers={layers}
        onUpdateLayers={handleUpdateLayers}
        activeSectionIndex={activeSectionIndex}
        onSelectSection={handleSelectSection}
        isZenMode={isZenMode}
        onToggleZenMode={handleToggleZenMode}
      />
    </div>
  );
}
