export interface SectionWaypoint {
  id: string;
  name: string;
  cameraPos: [number, number, number];
  lookAt: [number, number, number];
  earthRotation: [number, number, number];
  altitudeKm: number;
  speedKms: number;
  fov: number;
}

export interface TelemetryData {
  altitudeKm: number;
  speedKms: number;
  inclination: string;
  phase: string;
  solarAngleDeg: number;
  coordinates: string;
  missionTime: string;
}

export interface EarthLayersState {
  clouds: boolean;
  atmosphere: boolean;
  nightLights: boolean;
  orbitPath: boolean;
  satellites: boolean;
  rotationSpeed: number;
}
