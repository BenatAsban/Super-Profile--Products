# Life Admin Buddy 📋✨

**Life Admin Buddy** is a simple, friendly, privacy-focused daily-life management web application that helps ordinary people remember small but crucial tasks they often forget: bills, document renewals, vehicle care, home maintenance, subscriptions, warranties, and major life transitions.

---

## 🌟 Key Features

1. **Today Dashboard:**
   - Real-time scannable metrics: Due Today, Overdue, Next 7 Days, Expiries < 30 Days, Completed Today.
   - Categorized task view: Overdue warnings, Today's focus, Upcoming week, and collapsible recent completions.
   - Fast client-side search, category filtering, priority filtering, and custom sorting.

2. **Smart Life Checklists (Curated Packs):**
   - Ready-made templates for routine life tasks:
     - Monthly Bills & Fixed Expenses (Electricity, Water, Broadband, Credit card balances)
     - Home Maintenance & Safety (AC filters, Smoke detectors, Drain seals, Dryer lint ducts)
     - Vehicle Upkeep & Safety (Tire pressure, Screenwash, Oil levels, Alignment)
     - Document Renewals & Bureaucracy (Passports, Tax filings, Road tax, Insurance inventory)
     - Health & Preventive Care (Dental cleanings, Annual checkups, First-aid audits)
     - Digital Hygiene (Cloud backup test, Subscription audit, Router updates)
   - 1-click batch selection and import directly into active dashboard schedule.

3. **Expiry Tracker:**
   - Dedicated tracker for driving licences, passports, vehicle road tax, warranties, and insurance policies.
   - Real-time countdowns (`tabular-nums`) with visual status indicators: Expired (overdue), Expiring Soon (≤30 days), Attention (≤90 days), Valid & Safe.
   - 1-click "Renew" action with fast validity extension (+6m, +1y, +2y, +5y).
   - Storage locations and policy/reference numbers tracking.

4. **Recurring Reminders:**
   - Native support for Daily, Weekly, Monthly, Quarterly (every 3 months), and Yearly cadences.
   - When a recurring task is completed, it automatically records completion history and schedules the next occurrence with the correct future date.

5. **Life Events Planner:**
   - Phased roadmaps for major life milestones:
     - Moving House (4 Weeks Out, 2 Weeks Out, Moving Week, Settling In)
     - Starting a New Job (Pre-boarding, First 2 Weeks & Benefits)
     - International Travel Preparation (4 Weeks Out, 72 Hours Before Departure)
     - Household Emergency & Disaster Readiness (Grab-and-go kit & family plan)
   - Ability to track phase completion % and import phase tasks into daily dashboard.
   - Support for creating custom life milestones.

6. **Quick Add (Shortcut: `N`):**
   - Fast modal dialog with date presets (Today, Tomorrow, In 3 Days, Next Week), categories, priorities, and recurrence.

7. **Visual Insights & Progress:**
   - Overall task completion rate meter.
   - 7-day forward workload timeline strip.
   - Category and priority distribution charts.

8. **100% Local-First Privacy & Backup:**
   - Works fully offline using browser `localStorage`.
   - Zero servers, zero trackers, no account required.
   - One-click "Export Backup (JSON)" and "Restore Backup" for complete data ownership.

9. **Bilingual Support (English & Tamil):**
   - Instant toggle between English and Tamil (தமிழ்) across all navigation, categories, priorities, and views.

10. **Light & Dark Theme:**
    - High-contrast, accessibility-friendly light and dark modes with persistent user choice.

---

## 🚀 Local Development Setup

### Prerequisites
- Node.js (version 18 or higher recommended)
- npm, yarn, or bun

### Installation Steps

1. Clone or extract the project directory:
   ```bash
   cd life-admin-buddy
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the local development server:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🛠️ Production Build

To test or build the application for production:

```bash
npm run build
```

This generates an optimized static bundle in the `dist` directory:
- HTML, JavaScript, CSS, and asset files.
- `_redirects` file automatically copied to `dist/` for SPA client-side routing.

You can preview the production build locally with:
```bash
npm run preview
```

---

## 🌐 How to Deploy to Netlify

You can deploy Life Admin Buddy to Netlify in any of three simple ways:

### Method 1: Git-Connected Deployment (Recommended)
1. Push your repository to GitHub, GitLab, or Bitbucket.
2. Log in to [Netlify](https://www.netlify.com).
3. Click **"Add new site"** → **"Import an existing project"**.
4. Select your repository.
5. Netlify will automatically detect the included `netlify.toml`:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Click **"Deploy site"**. Every push to your git repository will now automatically build and deploy!

### Method 2: Netlify Drop (Manual Drag-and-Drop)
1. Build the production package locally:
   ```bash
   npm run build
   ```
2. Navigate to [https://app.netlify.com/drop](https://app.netlify.com/drop).
3. Drag and drop the `dist` folder directly onto the browser window.
4. Your site will be live instantly with a free `.netlify.app` subdomain!

### Method 3: Netlify CLI
1. Install Netlify CLI:
   ```bash
   npm install -g netlify-cli
   ```
2. Run build and deploy:
   ```bash
   npm run build
   netlify deploy --prod --dir=dist
   ```

---

## 📦 Project Structure

```
├── public/
│   └── _redirects             # Netlify SPA routing redirect rule
├── src/
│   ├── components/
│   │   ├── Header.tsx                 # Top navigation with Top Bar Contract
│   │   ├── TaskCard.tsx               # Anti-slop task item with zero-pill metadata
│   │   ├── DashboardView.tsx          # Today's focus, overdue callout, KPI cards
│   │   ├── ChecklistTemplatesView.tsx # Ready-made life packs & batch import
│   │   ├── ExpiryTrackerView.tsx      # Document, licence, warranty & policy tracker
│   │   ├── LifeEventsView.tsx         # Phased life milestones (Moving, Job, Travel)
│   │   ├── ProgressView.tsx           # Workload charts & 7-day forecast
│   │   ├── QuickAddModal.tsx          # Fast task creation dialog
│   │   ├── AddExpiryModal.tsx         # Document and expiry tracking modal
│   │   ├── RenewExpiryModal.tsx       # Fast validity extension modal
│   │   └── SettingsModal.tsx          # Theme, language, backup & privacy controls
│   ├── locales/
│   │   ├── translations.ts            # English & Tamil dictionaries
│   │   └── TranslationContext.tsx     # Context & hook for language switching
│   ├── types/
│   │   └── index.ts                   # TypeScript interfaces
│   ├── utils/
│   │   ├── dateUtils.ts               # Date math, recurrence, relative labels
│   │   ├── sampleData.ts              # Dynamic relative starter tasks & expiries
│   │   ├── storage.ts                 # LocalStorage persistence & JSON export/import
│   │   └── templates.ts               # Curated checklist packs & life events
│   ├── App.tsx                        # Root application container & logic
│   ├── index.css                      # Tailwind v4 configuration & theme tokens
│   └── main.tsx                       # React 19 entry point
├── index.html                         # HTML entry point with metadata & fonts
├── metadata.json                      # AI Studio app metadata
├── netlify.toml                       # Netlify build configuration
├── package.json                       # Dependencies and build scripts
└── tsconfig.json                      # TypeScript configuration
```

---

## 🔒 Privacy Notice
Life Admin Buddy runs entirely in your browser. All tasks, expiry dates, and notes are stored strictly inside your browser's `localStorage`. No telemetry, external analytics, or remote database services are used.
