import React, { useRef, useState } from 'react';
import { useTranslation } from '../locales/TranslationContext';
import { AppData } from '../types';
import { exportBackup, validateImportData, getStorageUsageKB } from '../utils/storage';
import { 
  X, 
  Sun, 
  Moon, 
  Globe, 
  Download, 
  Upload, 
  RotateCcw, 
  Trash2, 
  ShieldCheck, 
  HardDrive,
  Check
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  appData: AppData;
  onRestoreData: (data: AppData) => void;
  onResetDemo: () => void;
  onClearAll: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  isDark,
  onToggleTheme,
  appData,
  onRestoreData,
  onResetDemo,
  onClearAll,
}) => {
  const { t, locale, setLocale } = useTranslation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleExport = () => {
    exportBackup(appData);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        const validated = validateImportData(parsed);

        if (validated) {
          onRestoreData(validated);
          setImportStatus('Backup restored successfully!');
          setTimeout(() => setImportStatus(null), 3000);
        } else {
          setImportStatus('Invalid backup file structure.');
          setTimeout(() => setImportStatus(null), 4000);
        }
      } catch (err) {
        setImportStatus('Failed to read JSON backup file.');
        setTimeout(() => setImportStatus(null), 4000);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const storageKB = getStorageUsageKB();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs transition-opacity"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="w-full max-w-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-xl overflow-hidden transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 dark:border-neutral-800">
          <h3 className="text-base sm:text-lg font-semibold text-neutral-900 dark:text-neutral-100">
            {t.settings.title}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {importStatus && (
            <div className="p-3 text-xs rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>{importStatus}</span>
            </div>
          )}

          {/* Theme & Language Section */}
          <div className="space-y-4">
            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
              Interface Preferences
            </h4>

            {/* Theme Toggle */}
            <div className="flex items-center justify-between p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-800/20">
              <div className="flex items-center gap-2.5">
                {isDark ? <Moon className="w-4 h-4 text-neutral-300" /> : <Sun className="w-4 h-4 text-amber-500" />}
                <div>
                  <div className="text-xs sm:text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                    {t.settings.themeTitle}
                  </div>
                  <div className="text-[11px] text-neutral-500">
                    {isDark ? t.settings.themeDark : t.settings.themeLight}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={onToggleTheme}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors"
              >
                Toggle {isDark ? 'Light' : 'Dark'}
              </button>
            </div>

            {/* Language Selector */}
            <div className="flex items-center justify-between p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-800/20">
              <div className="flex items-center gap-2.5">
                <Globe className="w-4 h-4 text-emerald-600" />
                <div>
                  <div className="text-xs sm:text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                    {t.settings.languageTitle}
                  </div>
                  <div className="text-[11px] text-neutral-500">
                    {locale === 'en' ? 'English (Current)' : 'தமிழ் (தற்போதைய மொழி)'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setLocale('en')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    locale === 'en'
                      ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-semibold'
                      : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => setLocale('ta')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    locale === 'ta'
                      ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-semibold'
                      : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  தமிழ்
                </button>
              </div>
            </div>
          </div>

          {/* Backup & Data Management */}
          <div className="space-y-4">
            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
              {t.settings.dataTitle}
            </h4>

            <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
              {t.settings.dataDescription}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Export Backup */}
              <button
                type="button"
                onClick={handleExport}
                className="flex items-center justify-center gap-2 p-3 text-xs font-semibold rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-700 transition-colors shadow-xs"
              >
                <Download className="w-4 h-4 text-emerald-600" />
                <span>{t.actions.exportBackup}</span>
              </button>

              {/* Import Backup */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 p-3 text-xs font-semibold rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-700 transition-colors shadow-xs"
              >
                <Upload className="w-4 h-4 text-blue-600" />
                <span>{t.actions.importBackup}</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {/* Storage Footprint & Reset Controls */}
            <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-800/20 space-y-3">
              <div className="flex items-center justify-between text-xs text-neutral-500">
                <span className="flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5" />
                  <span>{t.settings.storageUsage}</span>
                </span>
                <span className="font-mono tabular-nums font-semibold text-neutral-800 dark:text-neutral-200">
                  {storageKB} KB stored locally
                </span>
              </div>

              <div className="pt-2 border-t border-neutral-200/60 dark:border-neutral-700/60 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm('Reset all tasks and expiries to default sample data?')) {
                      onResetDemo();
                      onClose();
                    }
                  }}
                  className="flex items-center gap-1 text-xs text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>{t.actions.resetDemo}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm('Clear all tasks and document expiries? This cannot be undone unless you have a backup.')) {
                      onClearAll();
                      onClose();
                    }
                  }}
                  className="flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 font-medium"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{t.actions.clearAll}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Privacy Guarantee */}
          <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/50 dark:bg-emerald-950/20 space-y-1">
            <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-semibold text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{t.settings.privacyTitle}</span>
            </div>
            <p className="text-[11px] text-emerald-900/80 dark:text-emerald-300/80 leading-relaxed">
              {t.settings.privacyBody}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
