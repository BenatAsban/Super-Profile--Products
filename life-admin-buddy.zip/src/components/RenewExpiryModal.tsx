import React, { useState } from 'react';
import { ExpiryItem } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { formatDateISO, parseLocalDate, getTodayString } from '../utils/dateUtils';
import { X, RefreshCw, Calendar, Check } from 'lucide-react';

interface RenewExpiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: ExpiryItem | null;
  onConfirmRenew: (id: string, newExpiryDate: string) => void;
}

export const RenewExpiryModal: React.FC<RenewExpiryModalProps> = ({
  isOpen,
  onClose,
  item,
  onConfirmRenew,
}) => {
  const { t } = useTranslation();
  if (!isOpen || !item) return null;

  // Calculate default +1 year from either current expiry or today
  const calculateAdvancedDate = (months: number): string => {
    const base = parseLocalDate(item.expiryDate);
    const now = new Date();
    // if already expired in the distant past, advance from today
    const startingPoint = base.getTime() < now.getTime() ? now : base;
    const next = new Date(startingPoint);
    next.setMonth(next.getMonth() + months);
    return formatDateISO(next);
  };

  const [newDate, setNewDate] = useState<string>(() => calculateAdvancedDate(12));

  const quickOptions = [
    { label: '+6 Months', months: 6 },
    { label: '+1 Year', months: 12 },
    { label: '+2 Years', months: 24 },
    { label: '+5 Years', months: 60 },
  ];

  const handleRenew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDate) return;
    onConfirmRenew(item.id, newDate);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs transition-opacity"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="w-full max-w-md bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-xl overflow-hidden transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <RefreshCw className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-neutral-900 dark:text-neutral-100">
                {t.expiries.renewDialogTitle}
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleRenew} className="p-6 space-y-4">
          <div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              {t.expiries.renewDialogSub}
            </p>
            <p className="mt-1 text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              {item.title}
            </p>
            <p className="text-xs text-neutral-400 mt-0.5 font-mono tabular-nums">
              Current expiry: {item.expiryDate}
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-2">
              Extend Validity By
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {quickOptions.map((opt) => {
                const target = calculateAdvancedDate(opt.months);
                const isSelected = newDate === target;
                return (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => setNewDate(target)}
                    className={`px-3 py-2 text-xs font-medium rounded-lg border transition-all text-center ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-neutral-50 dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:border-neutral-400'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              <Calendar className="w-3.5 h-3.5 text-neutral-500" />
              <span>New Expiry Date</span>
            </label>
            <input
              type="date"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono tabular-nums"
              required
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors"
            >
              {t.actions.cancel}
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-lg transition-colors shadow-xs"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Confirm Renewal</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
