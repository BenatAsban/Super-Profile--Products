import React, { useMemo } from 'react';
import { Task, ExpiryItem, Category, Priority } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { addDaysToToday, getDaysDifference, getExpiryStatus, parseLocalDate } from '../utils/dateUtils';
import { 
  BarChart3, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  ShieldCheck, 
  TrendingUp, 
  CalendarDays,
  Tag
} from 'lucide-react';

interface ProgressViewProps {
  tasks: Task[];
  expiries: ExpiryItem[];
}

export const ProgressView: React.FC<ProgressViewProps> = ({ tasks, expiries }) => {
  const { t, locale } = useTranslation();

  // Task Completion Stats
  const taskStats = useMemo(() => {
    const total = tasks.length;
    const completed = tasks.filter((t) => t.completed).length;
    const active = total - completed;
    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
    return { total, completed, active, rate };
  }, [tasks]);

  // Expiry Health Stats
  const expiryStats = useMemo(() => {
    let valid = 0;
    let soon = 0;
    let expired = 0;

    expiries.forEach((e) => {
      const { status } = getExpiryStatus(e.expiryDate);
      if (status === 'expired') expired++;
      else if (status === 'urgent' || status === 'warning') soon++;
      else valid++;
    });

    return { total: expiries.length, valid, soon, expired };
  }, [expiries]);

  // Category Breakdown for Active Tasks
  const categoryBreakdown = useMemo(() => {
    const activeTasks = tasks.filter((t) => !t.completed);
    const counts: Record<Category, number> = {
      bills: 0,
      documents: 0,
      home: 0,
      health: 0,
      vehicle: 0,
      subscriptions: 0,
      personal: 0,
      family: 0,
    };

    activeTasks.forEach((t) => {
      if (counts[t.category] !== undefined) {
        counts[t.category]++;
      }
    });

    return Object.entries(counts)
      .map(([cat, count]) => ({
        category: cat as Category,
        label: t.categories[cat as Category] || cat,
        count,
        percent: activeTasks.length > 0 ? Math.round((count / activeTasks.length) * 100) : 0,
      }))
      .sort((a, b) => b.count - a.count);
  }, [tasks, t]);

  // Priority Breakdown for Active Tasks
  const priorityBreakdown = useMemo(() => {
    const activeTasks = tasks.filter((t) => !t.completed);
    const counts: Record<Priority, number> = {
      urgent: 0,
      high: 0,
      medium: 0,
      low: 0,
    };

    activeTasks.forEach((t) => {
      counts[t.priority]++;
    });

    return [
      { priority: 'urgent' as Priority, count: counts.urgent, color: 'bg-rose-500' },
      { priority: 'high' as Priority, count: counts.high, color: 'bg-amber-500' },
      { priority: 'medium' as Priority, count: counts.medium, color: 'bg-blue-500' },
      { priority: 'low' as Priority, count: counts.low, color: 'bg-neutral-400' },
    ];
  }, [tasks]);

  // Next 7-Day Workload Distribution
  const next7DaysWorkload = useMemo(() => {
    const days: { dateStr: string; dayName: string; count: number; isToday: boolean }[] = [];
    const activeTasks = tasks.filter((t) => !t.completed);

    for (let i = 0; i < 7; i++) {
      const dateStr = addDaysToToday(i);
      const d = parseLocalDate(dateStr);
      const dayName = i === 0 ? (locale === 'ta' ? 'இன்று' : 'Today') : d.toLocaleDateString(locale === 'ta' ? 'ta-IN' : 'en-US', { weekday: 'short' });
      const count = activeTasks.filter((t) => t.dueDate === dateStr).length;
      days.push({
        dateStr,
        dayName,
        count,
        isToday: i === 0,
      });
    }

    return days;
  }, [tasks, locale]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          {t.progress.title}
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-0.5">
          {t.progress.subtitle}
        </p>
      </div>

      {/* Top 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Overall Completion Rate */}
        <div className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-xs">
          <div className="flex items-center justify-between text-xs text-neutral-500 mb-2">
            <span>{t.progress.completionRate}</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {taskStats.rate}%
            </span>
            <span className="text-xs text-neutral-500">
              ({taskStats.completed}/{taskStats.total} tasks)
            </span>
          </div>
          <div className="mt-3 w-full h-2 rounded-full bg-neutral-100 dark:bg-neutral-800 overflow-hidden">
            <div
              className="h-full bg-emerald-600 rounded-full transition-all duration-500"
              style={{ width: `${taskStats.rate}%` }}
            />
          </div>
        </div>

        {/* Active vs Completed */}
        <div className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-xs">
          <div className="flex items-center justify-between text-xs text-neutral-500 mb-2">
            <span>Task Queue Status</span>
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="grid grid-cols-2 gap-3 mt-1">
            <div>
              <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                {taskStats.active}
              </div>
              <div className="text-xs text-neutral-500">{t.progress.activeTasks}</div>
            </div>
            <div>
              <div className="text-2xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                {taskStats.completed}
              </div>
              <div className="text-xs text-neutral-500">{t.progress.completedTasks}</div>
            </div>
          </div>
        </div>

        {/* Document & Expiry Health */}
        <div className="p-5 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-xs">
          <div className="flex items-center justify-between text-xs text-neutral-500 mb-2">
            <span>{t.progress.totalExpiries}</span>
            <ShieldCheck className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {expiryStats.total}
            </span>
            <span className="text-xs text-neutral-500">documents & policies</span>
          </div>
          <div className="mt-2 flex items-center gap-2 text-xs">
            <span className="text-emerald-600 font-medium font-mono tabular-nums">{expiryStats.valid} Safe</span>
            <span>·</span>
            <span className="text-amber-600 font-medium font-mono tabular-nums">{expiryStats.soon} Due Soon</span>
            {expiryStats.expired > 0 && (
              <>
                <span>·</span>
                <span className="text-rose-600 font-medium font-mono tabular-nums">{expiryStats.expired} Expired</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 7-Day Workload Distribution */}
      <div className="p-5 sm:p-6 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              {t.progress.upcomingWorkload}
            </h3>
          </div>
          <span className="text-xs text-neutral-500">Next 7 days</span>
        </div>

        <div className="grid grid-cols-7 gap-2 pt-2">
          {next7DaysWorkload.map((day) => {
            const hasLoad = day.count > 0;
            return (
              <div
                key={day.dateStr}
                className={`p-3 rounded-xl border text-center transition-all ${
                  day.isToday
                    ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-400 dark:border-emerald-600'
                    : 'bg-neutral-50 dark:bg-neutral-800/40 border-neutral-200 dark:border-neutral-800'
                }`}
              >
                <div className={`text-xs font-semibold ${day.isToday ? 'text-emerald-700 dark:text-emerald-300' : 'text-neutral-600 dark:text-neutral-400'}`}>
                  {day.dayName}
                </div>
                <div className="mt-1 text-xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
                  {day.count}
                </div>
                <div className="text-[10px] text-neutral-400 mt-0.5">
                  {day.count === 1 ? 'task' : 'tasks'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid: Category & Priority Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* By Category */}
        <div className="p-5 sm:p-6 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-neutral-500" />
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              {t.progress.byCategory}
            </h3>
          </div>

          <div className="space-y-3">
            {categoryBreakdown.map((item) => (
              <div key={item.category} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-neutral-700 dark:text-neutral-300">{item.label}</span>
                  <span className="font-mono tabular-nums text-neutral-500">
                    {item.count} ({item.percent}%)
                  </span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-neutral-100 dark:bg-neutral-800 overflow-hidden">
                  <div
                    className="h-full bg-neutral-900 dark:bg-neutral-100 rounded-full"
                    style={{ width: `${item.percent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* By Priority */}
        <div className="p-5 sm:p-6 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-neutral-500" />
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100">
              {t.progress.byPriority}
            </h3>
          </div>

          <div className="space-y-3">
            {priorityBreakdown.map((p) => {
              const totalActive = taskStats.active;
              const percent = totalActive > 0 ? Math.round((p.count / totalActive) * 100) : 0;
              return (
                <div key={p.priority} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-neutral-700 dark:text-neutral-300">
                      {t.priorities[p.priority]}
                    </span>
                    <span className="font-mono tabular-nums text-neutral-500">
                      {p.count} ({percent}%)
                    </span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-neutral-100 dark:bg-neutral-800 overflow-hidden">
                    <div
                      className={`h-full ${p.color} rounded-full`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
