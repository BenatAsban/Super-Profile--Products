import React, { useState, useMemo } from 'react';
import { ExpiryItem, ExpiryCategory } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { getExpiryStatus, formatFriendlyDate } from '../utils/dateUtils';
import { 
  FileText, 
  Plus, 
  Search, 
  ShieldAlert, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  ExternalLink, 
  MapPin, 
  RefreshCw, 
  Edit3, 
  Trash2,
  DollarSign
} from 'lucide-react';

interface ExpiryTrackerViewProps {
  expiries: ExpiryItem[];
  onOpenAddExpiry: () => void;
  onEditExpiry: (item: ExpiryItem) => void;
  onDeleteExpiry: (id: string) => void;
  onRenewExpiry: (item: ExpiryItem) => void;
}

type ExpiryFilter = 'all' | 'soon' | 'expired' | 'valid';

export const ExpiryTrackerView: React.FC<ExpiryTrackerViewProps> = ({
  expiries,
  onOpenAddExpiry,
  onEditExpiry,
  onDeleteExpiry,
  onRenewExpiry,
}) => {
  const { t, locale } = useTranslation();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ExpiryCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<ExpiryFilter>('all');

  // Status metrics
  const metrics = useMemo(() => {
    let expired = 0;
    let soon = 0; // <= 30d
    let valid = 0;

    expiries.forEach((item) => {
      const { status } = getExpiryStatus(item.expiryDate);
      if (status === 'expired') expired++;
      else if (status === 'urgent' || status === 'warning') soon++;
      else valid++;
    });

    return { total: expiries.length, expired, soon, valid };
  }, [expiries]);

  // Filtered and sorted
  const filteredExpiries = useMemo(() => {
    return expiries
      .filter((item) => {
        // Search
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = item.title.toLowerCase().includes(q);
          const matchRef = item.referenceNumber ? item.referenceNumber.toLowerCase().includes(q) : false;
          const matchLoc = item.storageLocation ? item.storageLocation.toLowerCase().includes(q) : false;
          if (!matchTitle && !matchRef && !matchLoc) return false;
        }

        // Category
        if (selectedCategory !== 'all' && item.category !== selectedCategory) {
          return false;
        }

        // Status
        const { status } = getExpiryStatus(item.expiryDate);
        if (statusFilter === 'expired') {
          return status === 'expired';
        }
        if (statusFilter === 'soon') {
          return status === 'urgent' || status === 'warning';
        }
        if (statusFilter === 'valid') {
          return status === 'good';
        }

        return true;
      })
      .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate));
  }, [expiries, searchQuery, selectedCategory, statusFilter]);

  const categories: ExpiryCategory[] = [
    'identification',
    'insurance',
    'subscription',
    'warranty',
    'vehicle',
    'certification',
    'financial',
    'other',
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            {t.expiries.title}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-0.5">
            {t.expiries.subtitle}
          </p>
        </div>

        <button
          onClick={onOpenAddExpiry}
          className="px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{t.actions.newExpiry}</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => setStatusFilter('all')}
          className={`p-3.5 rounded-xl border text-left transition-all ${
            statusFilter === 'all'
              ? 'bg-neutral-100 dark:bg-neutral-800 border-neutral-400 dark:border-neutral-600'
              : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800'
          }`}
        >
          <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">Total Tracked</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
            {metrics.total}
          </div>
        </button>

        <button
          onClick={() => setStatusFilter(statusFilter === 'soon' ? 'all' : 'soon')}
          className={`p-3.5 rounded-xl border text-left transition-all ${
            metrics.soon > 0
              ? statusFilter === 'soon'
                ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-500'
                : 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60'
              : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800'
          }`}
        >
          <div className="text-xs text-amber-600 dark:text-amber-400 font-medium mb-1 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>Expiring Soon (≤30d)</span>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-600 dark:text-amber-400">
            {metrics.soon}
          </div>
        </button>

        <button
          onClick={() => setStatusFilter(statusFilter === 'expired' ? 'all' : 'expired')}
          className={`p-3.5 rounded-xl border text-left transition-all ${
            metrics.expired > 0
              ? statusFilter === 'expired'
                ? 'bg-rose-100 dark:bg-rose-950/60 border-rose-500'
                : 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/60'
              : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800'
          }`}
        >
          <div className="text-xs text-rose-600 dark:text-rose-400 font-medium mb-1 flex items-center gap-1">
            <AlertCircle className="w-3 h-3" />
            <span>Expired</span>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-rose-600 dark:text-rose-400">
            {metrics.expired}
          </div>
        </button>

        <button
          onClick={() => setStatusFilter(statusFilter === 'valid' ? 'all' : 'valid')}
          className={`p-3.5 rounded-xl border text-left transition-all ${
            statusFilter === 'valid'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500'
              : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800'
          }`}
        >
          <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium mb-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Valid & Safe</span>
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
            {metrics.valid}
          </div>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-2.5">
        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, policy #, location..."
              className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="sm:w-56">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as any)}
              className="w-full px-2.5 py-1.5 text-xs sm:text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Document Types</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {t.expiryCategories[cat] || cat}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Status segmented controls */}
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none pt-1">
          {(
            [
              { id: 'all', label: t.expiries.filterAll },
              { id: 'soon', label: t.expiries.filterExpiringSoon },
              { id: 'expired', label: t.expiries.filterExpired },
              { id: 'valid', label: t.expiries.filterValid },
            ] as const
          ).map((filter) => (
            <button
              key={filter.id}
              onClick={() => setStatusFilter(filter.id)}
              className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                statusFilter === filter.id
                  ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-semibold shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 bg-neutral-100 dark:bg-neutral-800/60'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Expiry Items List */}
      {filteredExpiries.length === 0 ? (
        <div className="p-8 text-center rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
          <FileText className="w-10 h-10 text-neutral-400 mx-auto mb-2 opacity-60" />
          <h3 className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">
            {t.expiries.emptyTitle}
          </h3>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 max-w-sm mx-auto">
            {t.expiries.emptySub}
          </p>
          <button
            onClick={onOpenAddExpiry}
            className="mt-4 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors"
          >
            {t.actions.newExpiry}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredExpiries.map((item) => {
            const { status, daysRemaining, label } = getExpiryStatus(item.expiryDate);

            return (
              <div
                key={item.id}
                className={`group rounded-2xl border p-4 sm:p-5 transition-all bg-white dark:bg-neutral-900 ${
                  status === 'expired'
                    ? 'border-rose-300 dark:border-rose-900/80 bg-rose-50/20 dark:bg-rose-950/10'
                    : status === 'urgent'
                    ? 'border-amber-300 dark:border-amber-900/80 bg-amber-50/20 dark:bg-amber-950/10'
                    : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700'
                }`}
              >
                {/* Header row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                      {item.title}
                    </h3>

                    {/* Clean unboxed metadata with separators (Anti-slop rule) */}
                    <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-neutral-500 dark:text-neutral-400">
                      <span className="font-medium text-neutral-700 dark:text-neutral-300">
                        {t.expiryCategories[item.category] || item.category}
                      </span>
                      {item.referenceNumber && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono tabular-nums">{item.referenceNumber}</span>
                        </>
                      )}
                      {item.storageLocation && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3 opacity-60" />
                            <span>{item.storageLocation}</span>
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Top Right Action Icons */}
                  <div className="flex items-center gap-1 shrink-0 opacity-80 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      onClick={() => onEditExpiry(item)}
                      className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      title={t.actions.edit}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteExpiry(item.id)}
                      className="p-1.5 text-neutral-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      title={t.actions.delete}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Expiry Status Banner */}
                <div className="mt-3.5 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        status === 'expired'
                          ? 'bg-rose-500'
                          : status === 'urgent'
                          ? 'bg-amber-500'
                          : status === 'warning'
                          ? 'bg-amber-400'
                          : 'bg-emerald-500'
                      }`}
                    />
                    <div>
                      <span
                        className={`text-xs font-semibold font-mono tabular-nums ${
                          status === 'expired'
                            ? 'text-rose-600 dark:text-rose-400'
                            : status === 'urgent' || status === 'warning'
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {label}
                      </span>
                      <p className="text-[11px] text-neutral-400 font-mono tabular-nums">
                        Expires: {item.expiryDate}
                      </p>
                    </div>
                  </div>

                  {/* Renew Button */}
                  <button
                    type="button"
                    onClick={() => onRenewExpiry(item)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 transition-colors shrink-0"
                  >
                    <RefreshCw className="w-3 h-3 text-emerald-600" />
                    <span>{t.actions.renew}</span>
                  </button>
                </div>

                {/* Additional Info / Cost / URL */}
                {(item.renewalCost !== undefined || item.websiteUrl || item.notes) && (
                  <div className="mt-3 text-xs text-neutral-500 dark:text-neutral-400 space-y-1.5 pt-2 border-t border-neutral-100/70 dark:border-neutral-800/70">
                    {item.notes && (
                      <p className="line-clamp-2 text-neutral-600 dark:text-neutral-300">
                        {item.notes}
                      </p>
                    )}
                    <div className="flex items-center justify-between gap-2 pt-1">
                      {item.renewalCost !== undefined && (
                        <span className="font-mono tabular-nums font-medium text-neutral-700 dark:text-neutral-300 flex items-center gap-0.5">
                          <span>Est. Renewal:</span>
                          <span>{item.currency || '$'}{item.renewalCost.toFixed(2)}</span>
                        </span>
                      )}
                      {item.websiteUrl && (
                        <a
                          href={item.websiteUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:underline ml-auto font-medium"
                        >
                          <span>Portal</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
