import React, { useState } from 'react';
import { Task, Priority } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { 
  formatFriendlyDate, 
  isOverdue, 
  isToday 
} from '../utils/dateUtils';
import { 
  Check, 
  RotateCw, 
  Trash2, 
  Edit3, 
  ChevronDown, 
  ChevronUp, 
  AlertCircle,
  Clock
} from 'lucide-react';

interface TaskCardProps {
  task: Task;
  onToggleComplete: (task: Task) => void;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({
  task,
  onToggleComplete,
  onEdit,
  onDelete,
}) => {
  const { t, locale } = useTranslation();
  const [expandedNotes, setExpandedNotes] = useState(false);

  const overdue = !task.completed && isOverdue(task.dueDate);
  const dueToday = !task.completed && isToday(task.dueDate);

  const getPriorityStyle = (p: Priority) => {
    switch (p) {
      case 'urgent':
        return 'text-rose-600 dark:text-rose-400 font-semibold';
      case 'high':
        return 'text-amber-600 dark:text-amber-400 font-semibold';
      case 'medium':
        return 'text-neutral-700 dark:text-neutral-300';
      case 'low':
      default:
        return 'text-neutral-500 dark:text-neutral-400';
    }
  };

  const getRecurrenceLabel = () => {
    switch (task.recurrence) {
      case 'daily':
        return t.recurrence.daily;
      case 'weekly':
        return t.recurrence.weekly;
      case 'monthly':
        return t.recurrence.monthly;
      case 'quarterly':
        return t.recurrence.quarterly;
      case 'yearly':
        return t.recurrence.yearly;
      default:
        return null;
    }
  };

  const recurrenceText = getRecurrenceLabel();
  const categoryLabel = t.categories[task.category] || task.category;
  const priorityLabel = t.priorities[task.priority] || task.priority;
  const dateLabel = formatFriendlyDate(task.dueDate, locale);

  return (
    <div
      className={`group relative rounded-xl border p-4 transition-all duration-150 ${
        task.completed
          ? 'bg-neutral-50/70 dark:bg-neutral-900/40 border-neutral-200/80 dark:border-neutral-800/80 opacity-75'
          : overdue
          ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/60 shadow-xs'
          : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 shadow-xs hover:border-neutral-300 dark:hover:border-neutral-700'
      }`}
    >
      <div className="flex items-start gap-3.5">
        {/* Checkbox button */}
        <button
          type="button"
          onClick={() => onToggleComplete(task)}
          className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center transition-all shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
            task.completed
              ? 'bg-emerald-600 dark:bg-emerald-500 border-emerald-600 dark:border-emerald-500 text-white'
              : overdue
              ? 'border-rose-400 dark:border-rose-600 hover:border-rose-600 bg-white dark:bg-neutral-900'
              : 'border-neutral-300 dark:border-neutral-600 hover:border-emerald-600 dark:hover:border-emerald-400 bg-white dark:bg-neutral-900'
          }`}
          aria-label={task.completed ? t.actions.markIncomplete : t.actions.complete}
        >
          {task.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
        </button>

        {/* Content body */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h4
              className={`text-sm sm:text-base font-medium leading-snug transition-all ${
                task.completed
                  ? 'line-through text-neutral-400 dark:text-neutral-500'
                  : 'text-neutral-900 dark:text-neutral-100'
              }`}
            >
              {task.title}
            </h4>

            {/* Quick Actions (Edit, Delete) */}
            <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity shrink-0">
              <button
                type="button"
                onClick={() => onEdit(task)}
                className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title={t.actions.edit}
                aria-label={t.actions.edit}
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onDelete(task.id)}
                className="p-1 text-neutral-400 hover:text-rose-600 dark:hover:text-rose-400 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                title={t.actions.delete}
                aria-label={t.actions.delete}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Clean Unboxed Metadata with Typographic Separators (Zero-Pill Rule) */}
          <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-neutral-500 dark:text-neutral-400">
            {/* Category */}
            <span className="font-medium text-neutral-600 dark:text-neutral-300">
              {categoryLabel}
            </span>

            <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-600">·</span>

            {/* Due Date Indicator */}
            <span
              className={`flex items-center gap-1 tabular-nums ${
                overdue
                  ? 'text-rose-600 dark:text-rose-400 font-semibold'
                  : dueToday
                  ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                  : 'text-neutral-600 dark:text-neutral-400'
              }`}
            >
              {overdue ? (
                <AlertCircle className="w-3 h-3 shrink-0" />
              ) : (
                <Clock className="w-3 h-3 shrink-0 opacity-70" />
              )}
              <span>{dateLabel}</span>
            </span>

            {/* Recurrence Indicator */}
            {recurrenceText && (
              <>
                <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-600">·</span>
                <span className="flex items-center gap-1 text-neutral-600 dark:text-neutral-400">
                  <RotateCw className="w-3 h-3 shrink-0 opacity-70" />
                  <span>{recurrenceText}</span>
                </span>
              </>
            )}

            {/* Priority Indicator */}
            <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-600">·</span>
            <span className={getPriorityStyle(task.priority)}>
              {priorityLabel}
            </span>
          </div>

          {/* Optional Notes toggle & display */}
          {task.notes && (
            <div className="mt-2 text-xs">
              {expandedNotes ? (
                <div className="p-2.5 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-100 dark:border-neutral-800 text-neutral-600 dark:text-neutral-300 whitespace-pre-wrap leading-relaxed">
                  {task.notes}
                  <button
                    type="button"
                    onClick={() => setExpandedNotes(false)}
                    className="mt-1 flex items-center gap-1 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
                  >
                    <ChevronUp className="w-3 h-3" />
                    <span>Hide note</span>
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setExpandedNotes(true)}
                  className="flex items-center gap-1 text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300 transition-colors"
                >
                  <ChevronDown className="w-3 h-3" />
                  <span className="truncate max-w-xs">{task.notes}</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
