import React, { useState } from 'react';
import { CHECKLIST_PACKS, ChecklistPack, ChecklistItemTemplate } from '../utils/templates';
import { Task, Category } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { getTodayString, addDaysToToday } from '../utils/dateUtils';
import { 
  Receipt, 
  Home, 
  Car, 
  FileText, 
  HeartPulse, 
  ShieldCheck, 
  Check, 
  Plus, 
  Sparkles, 
  ChevronRight, 
  RotateCw,
  Info
} from 'lucide-react';

interface ChecklistTemplatesViewProps {
  existingTasks: Task[];
  onAddTasks: (newTasks: Omit<Task, 'id' | 'createdAt'>[]) => void;
  onNavigateToDashboard: () => void;
}

export const ChecklistTemplatesView: React.FC<ChecklistTemplatesViewProps> = ({
  existingTasks,
  onAddTasks,
  onNavigateToDashboard,
}) => {
  const { t } = useTranslation();
  const [selectedPackId, setSelectedPackId] = useState<string>(CHECKLIST_PACKS[0].id);
  const [selectedItemIds, setSelectedItemIds] = useState<Record<string, boolean>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const selectedPack = CHECKLIST_PACKS.find((p) => p.id === selectedPackId) || CHECKLIST_PACKS[0];

  // Map icon name to Lucide icon
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Receipt':
        return Receipt;
      case 'Home':
        return Home;
      case 'Car':
        return Car;
      case 'FileText':
        return FileText;
      case 'HeartPulse':
        return HeartPulse;
      case 'ShieldCheck':
        return ShieldCheck;
      default:
        return Sparkles;
    }
  };

  // Check if a template item is already present in tasks
  const isItemAlreadyAdded = (templateTitle: string) => {
    return existingTasks.some(
      (t) => t.title.toLowerCase().trim() === templateTitle.toLowerCase().trim() && !t.completed
    );
  };

  const toggleItemSelection = (id: string) => {
    setSelectedItemIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleSelectAllInPack = () => {
    const updated = { ...selectedItemIds };
    selectedPack.items.forEach((item) => {
      updated[item.id] = true;
    });
    setSelectedItemIds(updated);
  };

  const handleDeselectAllInPack = () => {
    const updated = { ...selectedItemIds };
    selectedPack.items.forEach((item) => {
      delete updated[item.id];
    });
    setSelectedItemIds(updated);
  };

  const handleAddSelected = () => {
    const itemsToAdd: Omit<Task, 'id' | 'createdAt'>[] = [];
    const today = getTodayString();

    selectedPack.items.forEach((item, index) => {
      if (selectedItemIds[item.id]) {
        // Stagger due dates slightly so user isn't hit with 10 things at the same hour
        const staggeredDate = index === 0 ? today : addDaysToToday(index * 2);
        itemsToAdd.push({
          title: item.title,
          category: item.category,
          priority: item.priority,
          dueDate: staggeredDate,
          recurrence: item.recurrence,
          completed: false,
          notes: item.notes,
          sourceTemplate: selectedPack.title,
        });
      }
    });

    if (itemsToAdd.length === 0) return;

    onAddTasks(itemsToAdd);

    // Clear selection for these items
    const updated = { ...selectedItemIds };
    selectedPack.items.forEach((item) => {
      delete updated[item.id];
    });
    setSelectedItemIds(updated);

    // Show toast
    setToastMessage(`Added ${itemsToAdd.length} task${itemsToAdd.length > 1 ? 's' : ''} to your dashboard!`);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const selectedCountInCurrentPack = selectedPack.items.filter((item) => selectedItemIds[item.id]).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center justify-between gap-3 px-4 py-3 bg-neutral-900 text-white rounded-xl shadow-lg border border-neutral-700 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span className="text-xs sm:text-sm font-medium">{toastMessage}</span>
          </div>
          <button
            onClick={onNavigateToDashboard}
            className="text-xs font-semibold text-emerald-400 hover:underline shrink-0"
          >
            View Dashboard →
          </button>
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
          {t.checklists.title}
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-0.5">
          {t.checklists.subtitle}
        </p>
      </div>

      {/* Main Grid: Left sidebar of packs, Right side pack items */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Pack Selector (4 cols on lg) */}
        <div className="lg:col-span-4 space-y-2">
          <h2 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-2">
            {t.checklists.browseTemplates}
          </h2>

          <div className="space-y-1.5">
            {CHECKLIST_PACKS.map((pack) => {
              const Icon = getIcon(pack.iconName);
              const isSelected = pack.id === selectedPackId;
              const alreadyInTasksCount = pack.items.filter((i) => isItemAlreadyAdded(i.title)).length;

              return (
                <button
                  key={pack.id}
                  type="button"
                  onClick={() => setSelectedPackId(pack.id)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 ${
                    isSelected
                      ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white shadow-xs'
                      : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-neutral-100 hover:border-neutral-300'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-white/10 dark:bg-neutral-900/10 text-white dark:text-neutral-900'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h3 className="text-xs sm:text-sm font-semibold truncate">
                        {pack.title}
                      </h3>
                      <ChevronRight className={`w-3.5 h-3.5 shrink-0 opacity-60 ${isSelected ? 'translate-x-0.5' : ''}`} />
                    </div>
                    <p
                      className={`text-[11px] line-clamp-1 mt-0.5 ${
                        isSelected ? 'text-neutral-300 dark:text-neutral-600' : 'text-neutral-500 dark:text-neutral-400'
                      }`}
                    >
                      {pack.description}
                    </p>
                    <div className="mt-1 flex items-center gap-2 text-[10px]">
                      <span className="font-mono tabular-nums opacity-80">{pack.items.length} tasks</span>
                      {alreadyInTasksCount > 0 && (
                        <>
                          <span>·</span>
                          <span className={isSelected ? 'text-emerald-300 dark:text-emerald-700 font-medium' : 'text-emerald-600 dark:text-emerald-400 font-medium'}>
                            {alreadyInTasksCount} active
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Pack Details & Items (8 cols on lg) */}
        <div className="lg:col-span-8 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 sm:p-6 shadow-xs space-y-5">
          {/* Pack Header */}
          <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-neutral-900 dark:text-neutral-100">
                  {selectedPack.title}
                </h2>
                <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-0.5">
                  {selectedPack.description}
                </p>
              </div>

              {/* Multi-action bar */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleSelectAllInPack}
                  className="px-2.5 py-1 text-xs text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 rounded border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                >
                  {t.actions.selectAll}
                </button>
                <button
                  type="button"
                  onClick={handleDeselectAllInPack}
                  className="px-2.5 py-1 text-xs text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 rounded border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                >
                  {t.actions.deselectAll}
                </button>
              </div>
            </div>
          </div>

          {/* Checklist Items */}
          <div className="space-y-3">
            {selectedPack.items.map((item) => {
              const isSelected = !!selectedItemIds[item.id];
              const alreadyAdded = isItemAlreadyAdded(item.title);

              return (
                <div
                  key={item.id}
                  onClick={() => toggleItemSelection(item.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                    isSelected
                      ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-400 dark:border-emerald-600'
                      : alreadyAdded
                      ? 'bg-neutral-50/70 dark:bg-neutral-800/40 border-neutral-200 dark:border-neutral-800'
                      : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-neutral-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleItemSelection(item.id);
                    }}
                    className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center transition-colors shrink-0 ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'border-neutral-300 dark:border-neutral-600 hover:border-emerald-500'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs sm:text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                        {item.title}
                      </h4>
                      {alreadyAdded && (
                        <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/50 shrink-0">
                          Already in tasks
                        </span>
                      )}
                    </div>

                    <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-neutral-500 dark:text-neutral-400">
                      <span className="font-medium">{t.categories[item.category] || item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1">
                        <RotateCw className="w-3 h-3 opacity-70" />
                        <span>{t.recurrence[item.recurrence]}</span>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className={item.priority === 'urgent' ? 'text-rose-600 font-semibold' : ''}>
                        {t.priorities[item.priority]}
                      </span>
                    </div>

                    {item.notes && (
                      <p className="mt-2 text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed bg-neutral-50 dark:bg-neutral-800/50 p-2 rounded-lg border border-neutral-100 dark:border-neutral-800">
                        {item.notes}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action CTA Bar */}
          <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
            <span className="text-xs text-neutral-500">
              <strong className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100">{selectedCountInCurrentPack}</strong> item{selectedCountInCurrentPack !== 1 ? 's' : ''} selected
            </span>

            <button
              type="button"
              disabled={selectedCountInCurrentPack === 0}
              onClick={handleAddSelected}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors shadow-xs ${
                selectedCountInCurrentPack > 0
                  ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white'
                  : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-400 cursor-not-allowed'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>{t.actions.addSelected} ({selectedCountInCurrentPack})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
