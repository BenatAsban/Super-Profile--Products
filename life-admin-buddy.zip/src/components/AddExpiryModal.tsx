import React, { useState, useEffect } from 'react';
import { ExpiryItem, ExpiryCategory } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { getTodayString, addDaysToToday } from '../utils/dateUtils';
import { X, FileText, Calendar, ShieldCheck, MapPin, DollarSign, Globe, AlignLeft } from 'lucide-react';

interface AddExpiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: Omit<ExpiryItem, 'id' | 'createdAt'> & { id?: string }) => void;
  initialItem?: ExpiryItem | null;
}

export const AddExpiryModal: React.FC<AddExpiryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialItem,
}) => {
  const { t } = useTranslation();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpiryCategory>('identification');
  const [expiryDate, setExpiryDate] = useState(addDaysToToday(365));
  const [referenceNumber, setReferenceNumber] = useState('');
  const [storageLocation, setStorageLocation] = useState('');
  const [renewalCost, setRenewalCost] = useState<string>('');
  const [currency, setCurrency] = useState('$');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (initialItem) {
      setTitle(initialItem.title);
      setCategory(initialItem.category);
      setExpiryDate(initialItem.expiryDate);
      setReferenceNumber(initialItem.referenceNumber || '');
      setStorageLocation(initialItem.storageLocation || '');
      setRenewalCost(initialItem.renewalCost !== undefined ? String(initialItem.renewalCost) : '');
      setCurrency(initialItem.currency || '$');
      setWebsiteUrl(initialItem.websiteUrl || '');
      setNotes(initialItem.notes || '');
    } else {
      setTitle('');
      setCategory('identification');
      setExpiryDate(addDaysToToday(365));
      setReferenceNumber('');
      setStorageLocation('');
      setRenewalCost('');
      setCurrency('$');
      setWebsiteUrl('');
      setNotes('');
    }
    setError('');
  }, [initialItem, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide document / item title');
      return;
    }
    if (!expiryDate) {
      setError('Please provide an expiry date');
      return;
    }

    onSave({
      id: initialItem?.id,
      title: title.trim(),
      category,
      expiryDate,
      referenceNumber: referenceNumber.trim() || undefined,
      storageLocation: storageLocation.trim() || undefined,
      renewalCost: renewalCost ? parseFloat(renewalCost) : undefined,
      currency: currency || '$',
      websiteUrl: websiteUrl.trim() || undefined,
      notes: notes.trim() || undefined,
      reminderDaysBefore: initialItem?.reminderDaysBefore || [30, 14, 7],
      lastRenewedDate: initialItem?.lastRenewedDate,
    });
    onClose();
  };

  const categories: ExpiryCategory[] = [
    'identification',
    'insurance',
    'subscription',
    'warranty',
    'vehicle',
    'certification',
    'financial',
    'other',
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs transition-opacity"
      role="dialog"
      aria-modal="true"
    >
      <div 
        className="w-full max-w-lg max-h-[90vh] flex flex-col bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-xl overflow-hidden transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 dark:border-neutral-800 shrink-0">
          <h3 className="text-base sm:text-lg font-semibold text-neutral-900 dark:text-neutral-100">
            {initialItem ? t.actions.edit : t.actions.newExpiry}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          {error && (
            <div className="p-3 text-xs text-rose-700 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-lg">
              {error}
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              Document or Asset Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Passport, Health Insurance Policy, Laptop Warranty..."
              className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              autoFocus
            />
          </div>

          {/* Category & Expiry Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                <FileText className="w-3.5 h-3.5 text-neutral-500" />
                <span>Document Category</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpiryCategory)}
                className="w-full px-3 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {t.expiryCategories[cat] || cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                <Calendar className="w-3.5 h-3.5 text-neutral-500" />
                <span>Expiry Date</span> <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono tabular-nums"
              />
            </div>
          </div>

          {/* Reference # and Storage Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-neutral-500" />
                <span>Policy / Reference # (Optional)</span>
              </label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder="e.g. POL-94821 or Serial #"
                className="w-full px-3 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                <span>Physical or Digital Storage</span>
              </label>
              <input
                type="text"
                value={storageLocation}
                onChange={(e) => setStorageLocation(e.target.value)}
                placeholder="e.g. Safe Box, Glove Box, Drive"
                className="w-full px-3 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Renewal Cost & Website URL */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                <DollarSign className="w-3.5 h-3.5 text-neutral-500" />
                <span>Estimated Renewal Cost</span>
              </label>
              <div className="flex items-center gap-1">
                <input
                  type="text"
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-12 px-2 py-2 text-sm text-center bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 focus:outline-none"
                />
                <input
                  type="number"
                  step="any"
                  value={renewalCost}
                  onChange={(e) => setRenewalCost(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums font-mono"
                />
              </div>
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                <Globe className="w-3.5 h-3.5 text-neutral-500" />
                <span>Renewal Portal / URL</span>
              </label>
              <input
                type="url"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
              <AlignLeft className="w-3.5 h-3.5 text-neutral-500" />
              <span>Notes & Renewal Guidance</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Needs eye test report, minimum 6 months validity required for travel..."
              className="w-full px-3.5 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
            />
          </div>

          {/* Footer Controls */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors"
            >
              {t.actions.cancel}
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 dark:bg-emerald-500 dark:hover:bg-emerald-600 rounded-lg transition-colors shadow-xs"
            >
              {initialItem ? t.actions.save : t.actions.newExpiry}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
