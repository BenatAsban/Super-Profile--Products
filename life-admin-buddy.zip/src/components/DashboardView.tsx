import React, { useState, useMemo } from 'react';
import { Task, Category, Priority } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { 
  isToday, 
  isOverdue, 
  isWithinNextDays, 
  getDaysDifference 
} from '../utils/dateUtils';
import { TaskCard } from './TaskCard';
import { 
  Calendar, 
  AlertCircle, 
  Clock, 
  CheckCircle2, 
  ShieldAlert, 
  Search, 
  SlidersHorizontal, 
  Sparkles, 
  Plus, 
  ChevronDown, 
  ChevronUp, 
  CheckCheck
} from 'lucide-react';

interface DashboardViewProps {
  tasks: Task[];
  onToggleComplete: (task: Task) => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (id: string) => void;
  onOpenQuickAdd: () => void;
  onNavigateToChecklists: () => void;
  onNavigateToExpiries: () => void;
  expiringSoonCount: number;
}

type StatusFilter = 'all' | 'today' | 'upcoming' | 'overdue' | 'completed';
type SortOption = 'dueDate' | 'priority' | 'title';

export const DashboardView: React.FC<DashboardViewProps> = ({
  tasks,
  onToggleComplete,
  onEditTask,
  onDeleteTask,
  onOpenQuickAdd,
  onNavigateToChecklists,
  onNavigateToExpiries,
  expiringSoonCount,
}) => {
  const { t, locale } = useTranslation();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all');
  const [selectedPriority, setSelectedPriority] = useState<Priority | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [sortBy, setSortBy] = useState<SortOption>('dueDate');
  const [showRecentCompleted, setShowRecentCompleted] = useState(false);

  // Stats calculation
  const stats = useMemo(() => {
    let dueToday = 0;
    let overdue = 0;
    let upcoming = 0;
    let completedToday = 0;

    tasks.forEach((task) => {
      if (task.completed) {
        if (task.completedAt && isToday(task.completedAt.slice(0, 10))) {
          completedToday++;
        }
      } else {
        if (isToday(task.dueDate)) {
          dueToday++;
        } else if (isOverdue(task.dueDate)) {
          overdue++;
        } else if (isWithinNextDays(task.dueDate, 7)) {
          upcoming++;
        }
      }
    });

    return { dueToday, overdue, upcoming, completedToday };
  }, [tasks]);

  // Filtered tasks
  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = task.title.toLowerCase().includes(q);
        const matchNotes = task.notes ? task.notes.toLowerCase().includes(q) : false;
        if (!matchTitle && !matchNotes) return false;
      }

      // Category
      if (selectedCategory !== 'all' && task.category !== selectedCategory) {
        return false;
      }

      // Priority
      if (selectedPriority !== 'all' && task.priority !== selectedPriority) {
        return false;
      }

      // Status
      if (statusFilter === 'today') {
        return !task.completed && isToday(task.dueDate);
      }
      if (statusFilter === 'overdue') {
        return !task.completed && isOverdue(task.dueDate);
      }
      if (statusFilter === 'upcoming') {
        return !task.completed && isWithinNextDays(task.dueDate, 7) && !isToday(task.dueDate) && !isOverdue(task.dueDate);
      }
      if (statusFilter === 'completed') {
        return task.completed;
      }

      // statusFilter === 'all': show incomplete tasks first or respect list
      return true;
    });
  }, [tasks, searchQuery, selectedCategory, selectedPriority, statusFilter]);

  // Sort tasks
  const sortedTasks = useMemo(() => {
    const list = [...filteredTasks];
    const priorityWeights: Record<Priority, number> = {
      urgent: 4,
      high: 3,
      medium: 2,
      low: 1,
    };

    return list.sort((a, b) => {
      // Completed items always pushed to bottom
      if (a.completed !== b.completed) {
        return a.completed ? 1 : -1;
      }

      if (sortBy === 'priority') {
        const diff = priorityWeights[b.priority] - priorityWeights[a.priority];
        if (diff !== 0) return diff;
        return a.dueDate.localeCompare(b.dueDate);
      }

      if (sortBy === 'title') {
        return a.title.localeCompare(b.title);
      }

      // Default: dueDate
      return a.dueDate.localeCompare(b.dueDate);
    });
  }, [filteredTasks, sortBy]);

  // Split into actionable groups when statusFilter is 'all'
  const overdueTasks = useMemo(() => {
    return sortedTasks.filter((t) => !t.completed && isOverdue(t.dueDate));
  }, [sortedTasks]);

  const todayTasks = useMemo(() => {
    return sortedTasks.filter((t) => !t.completed && isToday(t.dueDate));
  }, [sortedTasks]);

  const upcomingTasks = useMemo(() => {
    return sortedTasks.filter(
      (t) => !t.completed && isWithinNextDays(t.dueDate, 7) && !isToday(t.dueDate) && !isOverdue(t.dueDate)
    );
  }, [sortedTasks]);

  const futureTasks = useMemo(() => {
    return sortedTasks.filter(
      (t) => !t.completed && !isWithinNextDays(t.dueDate, 7) && !isToday(t.dueDate) && !isOverdue(t.dueDate)
    );
  }, [sortedTasks]);

  const completedTasks = useMemo(() => {
    return sortedTasks.filter((t) => t.completed);
  }, [sortedTasks]);

  const hasSpecificFilter = statusFilter !== 'all' || searchQuery.trim() !== '' || selectedCategory !== 'all' || selectedPriority !== 'all';

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Welcome & Scannable KPI Cards */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              {t.dashboard.welcomeHeading}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-0.5">
              {t.dashboard.welcomeSub}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onNavigateToChecklists}
              className="px-3.5 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-neutral-100 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg hover:border-neutral-300 transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Smart Packs</span>
            </button>
            <button
              onClick={onOpenQuickAdd}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 dark:bg-emerald-500 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t.actions.newTask}</span>
            </button>
          </div>
        </div>

        {/* 5-Card High-Density KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* Due Today */}
          <button
            onClick={() => setStatusFilter(statusFilter === 'today' ? 'all' : 'today')}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              statusFilter === 'today'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-600 shadow-xs'
                : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-neutral-300'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-1">
              <span>{t.dashboard.statsDueToday}</span>
              <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {stats.dueToday}
            </div>
          </button>

          {/* Overdue */}
          <button
            onClick={() => setStatusFilter(statusFilter === 'overdue' ? 'all' : 'overdue')}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              stats.overdue > 0
                ? statusFilter === 'overdue'
                  ? 'bg-rose-100 dark:bg-rose-950/60 border-rose-500 shadow-xs'
                  : 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/60'
                : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-1">
              <span className={stats.overdue > 0 ? 'text-rose-600 dark:text-rose-400 font-semibold' : ''}>
                {t.dashboard.statsOverdue}
              </span>
              <AlertCircle className={`w-3.5 h-3.5 ${stats.overdue > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-neutral-400'}`} />
            </div>
            <div className={`text-2xl font-bold font-mono tabular-nums ${stats.overdue > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-neutral-900 dark:text-neutral-100'}`}>
              {stats.overdue}
            </div>
          </button>

          {/* Next 7 Days */}
          <button
            onClick={() => setStatusFilter(statusFilter === 'upcoming' ? 'all' : 'upcoming')}
            className={`p-3.5 rounded-xl border text-left transition-all ${
              statusFilter === 'upcoming'
                ? 'bg-neutral-100 dark:bg-neutral-800 border-neutral-400 dark:border-neutral-600 shadow-xs'
                : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-neutral-300'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-1">
              <span>{t.dashboard.statsUpcoming}</span>
              <Clock className="w-3.5 h-3.5 text-neutral-500" />
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {stats.upcoming}
            </div>
          </button>

          {/* Expiries < 30d */}
          <button
            onClick={onNavigateToExpiries}
            className="p-3.5 rounded-xl border bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-amber-300 dark:hover:border-amber-800 text-left transition-all"
          >
            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-1">
              <span className={expiringSoonCount > 0 ? 'text-amber-600 dark:text-amber-400 font-medium' : ''}>
                {t.dashboard.statsExpiriesSoon}
              </span>
              <ShieldAlert className={`w-3.5 h-3.5 ${expiringSoonCount > 0 ? 'text-amber-500' : 'text-neutral-400'}`} />
            </div>
            <div className={`text-2xl font-bold font-mono tabular-nums ${expiringSoonCount > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-neutral-900 dark:text-neutral-100'}`}>
              {expiringSoonCount}
            </div>
          </button>

          {/* Completed Today */}
          <button
            onClick={() => setStatusFilter(statusFilter === 'completed' ? 'all' : 'completed')}
            className={`col-span-2 sm:col-span-1 p-3.5 rounded-xl border text-left transition-all ${
              statusFilter === 'completed'
                ? 'bg-neutral-100 dark:bg-neutral-800 border-neutral-400 dark:border-neutral-600 shadow-xs'
                : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-neutral-300'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 mb-1">
              <span>{t.dashboard.statsCompleted}</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-neutral-900 dark:text-neutral-100">
              {stats.completedToday}
            </div>
          </button>
        </div>
      </div>

      {/* Overdue Warning Callout (if any overdue tasks) */}
      {stats.overdue > 0 && statusFilter !== 'overdue' && (
        <div className="p-4 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            <span className="text-xs sm:text-sm font-medium text-rose-800 dark:text-rose-200">
              You have <strong className="font-mono tabular-nums">{stats.overdue}</strong> overdue {stats.overdue === 1 ? 'task' : 'tasks'} requiring attention.
            </span>
          </div>
          <button
            onClick={() => setStatusFilter('overdue')}
            className="text-xs font-semibold text-rose-700 dark:text-rose-300 hover:underline shrink-0"
          >
            View Overdue
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl space-y-2.5">
        <div className="flex flex-col sm:flex-row gap-2.5">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.actions.searchPlaceholder}
              className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <div className="sm:w-44">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as any)}
              className="w-full px-2.5 py-1.5 text-xs sm:text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">{t.categories.all}</option>
              <option value="bills">{t.categories.bills}</option>
              <option value="documents">{t.categories.documents}</option>
              <option value="home">{t.categories.home}</option>
              <option value="health">{t.categories.health}</option>
              <option value="vehicle">{t.categories.vehicle}</option>
              <option value="subscriptions">{t.categories.subscriptions}</option>
              <option value="personal">{t.categories.personal}</option>
              <option value="family">{t.categories.family}</option>
            </select>
          </div>

          {/* Priority Dropdown */}
          <div className="sm:w-36">
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value as any)}
              className="w-full px-2.5 py-1.5 text-xs sm:text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Priorities</option>
              <option value="urgent">{t.priorities.urgent}</option>
              <option value="high">{t.priorities.high}</option>
              <option value="medium">{t.priorities.medium}</option>
              <option value="low">{t.priorities.low}</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="sm:w-36">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="w-full px-2.5 py-1.5 text-xs sm:text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="dueDate">Sort: Due Date</option>
              <option value="priority">Sort: Priority</option>
              <option value="title">Sort: Title</option>
            </select>
          </div>
        </div>

        {/* Status Filter Segmented Buttons */}
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none pt-1">
          {(
            [
              { id: 'all', label: t.actions.all },
              { id: 'today', label: t.actions.dueToday },
              { id: 'upcoming', label: t.actions.upcoming },
              { id: 'overdue', label: t.actions.overdue },
              { id: 'completed', label: t.actions.completed },
            ] as const
          ).map((filter) => (
            <button
              key={filter.id}
              onClick={() => setStatusFilter(filter.id)}
              className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                statusFilter === filter.id
                  ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-semibold shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 bg-neutral-100 dark:bg-neutral-800/60'
              }`}
            >
              {filter.label}
            </button>
          ))}

          {hasSpecificFilter && (
            <button
              onClick={() => {
                setStatusFilter('all');
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedPriority('all');
              }}
              className="ml-auto text-xs text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-100 underline whitespace-nowrap px-2"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Task List Rendered by Sections or Flat List */}
      <div className="space-y-6">
        {hasSpecificFilter ? (
          /* Filtered Results View */
          <div>
            <div className="flex items-center justify-between mb-3 text-xs text-neutral-500 dark:text-neutral-400">
              <span>Found <strong className="font-mono tabular-nums text-neutral-900 dark:text-neutral-100">{sortedTasks.length}</strong> matching tasks</span>
            </div>

            {sortedTasks.length === 0 ? (
              <div className="p-8 text-center rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
                <SlidersHorizontal className="w-8 h-8 text-neutral-400 mx-auto mb-2 opacity-60" />
                <h3 className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">No tasks match your filter</h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Try adjusting your search terms or category filters.</p>
                <button
                  onClick={() => {
                    setStatusFilter('all');
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setSelectedPriority('all');
                  }}
                  className="mt-3 px-3 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300 border border-neutral-200 dark:border-neutral-700 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800"
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {sortedTasks.map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    onToggleComplete={onToggleComplete}
                    onEdit={onEditTask}
                    onDelete={onDeleteTask}
                  />
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Default Structured Sections View */
          <>
            {/* 1. Overdue Section (if any) */}
            {overdueTasks.length > 0 && (
              <section className="space-y-2.5">
                <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-semibold text-sm">
                  <AlertCircle className="w-4 h-4" />
                  <span>{t.dashboard.overdueWarning}</span>
                  <span className="text-xs font-mono tabular-nums font-bold px-1.5 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300">
                    {overdueTasks.length}
                  </span>
                </div>
                <div className="space-y-2.5">
                  {overdueTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onToggleComplete={onToggleComplete}
                      onEdit={onEditTask}
                      onDelete={onDeleteTask}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 2. Today's Focus Section */}
            <section className="space-y-2.5">
              <div className="flex items-center justify-between text-neutral-900 dark:text-neutral-100 font-semibold text-sm">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>{t.dashboard.todayFocus}</span>
                  <span className="text-xs font-mono tabular-nums text-neutral-500 font-normal">
                    ({todayTasks.length})
                  </span>
                </div>
              </div>

              {todayTasks.length === 0 ? (
                <div className="p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-center">
                  <CheckCheck className="w-6 h-6 text-emerald-600 dark:text-emerald-400 mx-auto mb-1.5 opacity-80" />
                  <p className="text-sm font-medium text-neutral-800 dark:text-neutral-200">
                    {t.dashboard.emptyToday}
                  </p>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                    {t.dashboard.emptyTodaySub}
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {todayTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onToggleComplete={onToggleComplete}
                      onEdit={onEditTask}
                      onDelete={onDeleteTask}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* 3. Upcoming 7 Days Section */}
            <section className="space-y-2.5">
              <div className="flex items-center gap-2 text-neutral-900 dark:text-neutral-100 font-semibold text-sm">
                <Clock className="w-4 h-4 text-neutral-500" />
                <span>{t.dashboard.upcoming7Days}</span>
                <span className="text-xs font-mono tabular-nums text-neutral-500 font-normal">
                  ({upcomingTasks.length})
                </span>
              </div>

              {upcomingTasks.length === 0 ? (
                <p className="text-xs text-neutral-400 py-2">
                  {t.dashboard.emptyUpcoming}
                </p>
              ) : (
                <div className="space-y-2.5">
                  {upcomingTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onToggleComplete={onToggleComplete}
                      onEdit={onEditTask}
                      onDelete={onDeleteTask}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* 4. Future Beyond 7 Days (if any) */}
            {futureTasks.length > 0 && (
              <section className="space-y-2.5">
                <div className="flex items-center gap-2 text-neutral-700 dark:text-neutral-300 font-medium text-xs">
                  <span>Scheduled Later ({futureTasks.length})</span>
                </div>
                <div className="space-y-2.5">
                  {futureTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onToggleComplete={onToggleComplete}
                      onEdit={onEditTask}
                      onDelete={onDeleteTask}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* 5. Recently Completed Collapsible */}
            {completedTasks.length > 0 && (
              <section className="pt-2">
                <button
                  type="button"
                  onClick={() => setShowRecentCompleted(!showRecentCompleted)}
                  className="flex items-center gap-2 text-xs font-medium text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 transition-colors"
                >
                  {showRecentCompleted ? (
                    <ChevronUp className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {t.dashboard.recentCompleted} ({completedTasks.length})
                  </span>
                </button>

                {showRecentCompleted && (
                  <div className="mt-3 space-y-2.5">
                    {completedTasks.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleComplete={onToggleComplete}
                        onEdit={onEditTask}
                        onDelete={onDeleteTask}
                      />
                    ))}
                  </div>
                )}
              </section>
            )}
          </>
        )}
      </div>
    </div>
  );
};
