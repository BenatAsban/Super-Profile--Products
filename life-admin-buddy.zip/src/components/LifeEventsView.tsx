import React, { useState } from 'react';
import { LifeEvent, LifeEventPhase, Task } from '../types';
import { useTranslation } from '../locales/TranslationContext';
import { addDaysToToday, getTodayString } from '../utils/dateUtils';
import { 
  Truck, 
  Briefcase, 
  Plane, 
  ShieldAlert, 
  Heart, 
  Calendar, 
  Check, 
  Plus, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle2, 
  Trash2,
  X
} from 'lucide-react';

interface LifeEventsViewProps {
  events: LifeEvent[];
  onTogglePhaseItem: (eventId: string, phaseId: string, itemId: string) => void;
  onImportPhaseToTasks: (tasks: Omit<Task, 'id' | 'createdAt'>[]) => void;
  onCreateCustomEvent: (event: LifeEvent) => void;
  onDeleteEvent: (id: string) => void;
  onNavigateToDashboard: () => void;
}

export const LifeEventsView: React.FC<LifeEventsViewProps> = ({
  events,
  onTogglePhaseItem,
  onImportPhaseToTasks,
  onCreateCustomEvent,
  onDeleteEvent,
  onNavigateToDashboard,
}) => {
  const { t } = useTranslation();
  const [selectedEventId, setSelectedEventId] = useState<string>(events[0]?.id || '');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // New custom event form state
  const [customTitle, setCustomTitle] = useState('');
  const [customDesc, setCustomDesc] = useState('');
  const [customPhase1Title, setCustomPhase1Title] = useState('');
  const [customPhase1Items, setCustomPhase1Items] = useState('');
  const [customPhase2Title, setCustomPhase2Title] = useState('');
  const [customPhase2Items, setCustomPhase2Items] = useState('');

  const selectedEvent = events.find((e) => e.id === selectedEventId) || events[0];

  const getEventIcon = (name: string) => {
    switch (name) {
      case 'Truck':
        return Truck;
      case 'Briefcase':
        return Briefcase;
      case 'Plane':
        return Plane;
      case 'ShieldAlert':
        return ShieldAlert;
      default:
        return Heart;
    }
  };

  // Calculate event progress %
  const calculateProgress = (event: LifeEvent) => {
    let total = 0;
    let completed = 0;
    event.phases.forEach((p) => {
      p.items.forEach((item) => {
        total++;
        if (item.completed) completed++;
      });
    });
    if (total === 0) return 0;
    return Math.round((completed / total) * 100);
  };

  const handleImportPhase = (phase: LifeEventPhase) => {
    const today = getTodayString();
    const newTasks: Omit<Task, 'id' | 'createdAt'>[] = phase.items.map((item, idx) => ({
      title: item.text,
      category: item.category,
      priority: 'high',
      dueDate: item.dueDateOffsetDays !== undefined && item.dueDateOffsetDays !== 0 
        ? addDaysToToday(Math.max(1, Math.abs(item.dueDateOffsetDays))) 
        : addDaysToToday(idx * 2),
      recurrence: 'none',
      completed: item.completed,
      sourceTemplate: `${selectedEvent.title} - ${phase.title}`,
    }));

    onImportPhaseToTasks(newTasks);
    setToastMessage(`Imported ${newTasks.length} tasks from "${phase.title}" into your dashboard!`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleSaveCustomEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim()) return;

    const p1Items = customPhase1Items
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((text, i) => ({
        id: `cp1-${Date.now()}-${i}`,
        text,
        category: 'personal' as const,
        completed: false,
      }));

    const p2Items = customPhase2Items
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((text, i) => ({
        id: `cp2-${Date.now()}-${i}`,
        text,
        category: 'personal' as const,
        completed: false,
      }));

    const newEvent: LifeEvent = {
      id: `custom-event-${Date.now()}`,
      title: customTitle.trim(),
      description: customDesc.trim() || 'Custom phased life milestone',
      iconName: 'Heart',
      isCustom: true,
      phases: [
        {
          id: `phase-1-${Date.now()}`,
          title: customPhase1Title.trim() || 'Phase 1: Planning',
          items: p1Items.length > 0 ? p1Items : [{ id: 'p1-1', text: 'Define budget and requirements', category: 'personal', completed: false }],
        },
        ...(p2Items.length > 0
          ? [
              {
                id: `phase-2-${Date.now()}`,
                title: customPhase2Title.trim() || 'Phase 2: Execution',
                items: p2Items,
              },
            ]
          : []),
      ],
    };

    onCreateCustomEvent(newEvent);
    setSelectedEventId(newEvent.id);
    setIsCreateModalOpen(false);
    setCustomTitle('');
    setCustomDesc('');
    setCustomPhase1Title('');
    setCustomPhase1Items('');
    setCustomPhase2Title('');
    setCustomPhase2Items('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center justify-between gap-3 px-4 py-3 bg-neutral-900 text-white rounded-xl shadow-lg border border-neutral-700 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span className="text-xs sm:text-sm font-medium">{toastMessage}</span>
          </div>
          <button
            onClick={onNavigateToDashboard}
            className="text-xs font-semibold text-emerald-400 hover:underline shrink-0"
          >
            Go to Tasks →
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
            {t.lifeEvents.title}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-0.5">
            {t.lifeEvents.subtitle}
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{t.lifeEvents.createCustom}</span>
        </button>
      </div>

      {/* Main Grid: Left events list, Right event phases */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Events List (4 cols) */}
        <div className="lg:col-span-4 space-y-2.5">
          <h2 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-2">
            Life Milestones
          </h2>

          <div className="space-y-2">
            {events.map((event) => {
              const Icon = getEventIcon(event.iconName);
              const isSelected = event.id === selectedEventId;
              const progress = calculateProgress(event);

              return (
                <div
                  key={event.id}
                  onClick={() => setSelectedEventId(event.id)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 relative ${
                    isSelected
                      ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white shadow-xs'
                      : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-neutral-100 hover:border-neutral-300'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-white/10 dark:bg-neutral-900/10 text-white dark:text-neutral-900'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h3 className="text-xs sm:text-sm font-semibold truncate">
                        {event.title}
                      </h3>
                      {event.isCustom && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (window.confirm('Delete this custom life event?')) {
                              onDeleteEvent(event.id);
                            }
                          }}
                          className="text-neutral-400 hover:text-rose-500 p-0.5"
                          title="Delete event"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <p
                      className={`text-[11px] line-clamp-1 mt-0.5 ${
                        isSelected ? 'text-neutral-300 dark:text-neutral-600' : 'text-neutral-500 dark:text-neutral-400'
                      }`}
                    >
                      {event.description}
                    </p>

                    {/* Progress Bar inside card */}
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full bg-neutral-200 dark:bg-neutral-700/60 overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-mono tabular-nums font-semibold shrink-0">
                        {progress}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Event Detail & Phased Checklists (8 cols) */}
        {selectedEvent && (
          <div className="lg:col-span-8 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 sm:p-6 shadow-xs space-y-6">
            {/* Header info */}
            <div className="border-b border-neutral-100 dark:border-neutral-800 pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <h2 className="text-base sm:text-lg font-bold text-neutral-900 dark:text-neutral-100">
                    {selectedEvent.title}
                  </h2>
                  <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-0.5">
                    {selectedEvent.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="px-3 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-xs font-medium text-neutral-700 dark:text-neutral-300 font-mono tabular-nums">
                    Overall Progress: <strong className="text-emerald-600 dark:text-emerald-400">{calculateProgress(selectedEvent)}%</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Phases Accordion / List */}
            <div className="space-y-5">
              {selectedEvent.phases.map((phase, pIdx) => {
                const phaseCompletedCount = phase.items.filter((i) => i.completed).length;
                const phaseTotalCount = phase.items.length;
                const phasePercent = phaseTotalCount > 0 ? Math.round((phaseCompletedCount / phaseTotalCount) * 100) : 0;

                return (
                  <div
                    key={phase.id}
                    className="p-4 sm:p-5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-800/20 space-y-3.5"
                  >
                    {/* Phase Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-neutral-200/60 dark:border-neutral-800 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                            0{pIdx + 1}.
                          </span>
                          <h3 className="text-sm sm:text-base font-semibold text-neutral-900 dark:text-neutral-100">
                            {phase.title}
                          </h3>
                        </div>
                        {phase.description && (
                          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                            {phase.description}
                          </p>
                        )}
                      </div>

                      {/* Phase Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-xs font-mono tabular-nums text-neutral-500">
                          {phaseCompletedCount}/{phaseTotalCount} done
                        </span>
                        <button
                          type="button"
                          onClick={() => handleImportPhase(phase)}
                          className="px-2.5 py-1 text-xs font-semibold rounded-md border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 transition-colors flex items-center gap-1 shadow-xs"
                          title="Import all phase tasks into your daily dashboard"
                        >
                          <Plus className="w-3 h-3 text-emerald-600" />
                          <span>{t.lifeEvents.addToDashboard}</span>
                        </button>
                      </div>
                    </div>

                    {/* Phase Items Checklist */}
                    <div className="space-y-2">
                      {phase.items.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => onTogglePhaseItem(selectedEvent.id, phase.id, item.id)}
                          className={`p-3 rounded-lg border transition-all cursor-pointer flex items-start gap-3 ${
                            item.completed
                              ? 'bg-neutral-100/60 dark:bg-neutral-800/40 border-neutral-200 dark:border-neutral-800 opacity-70'
                              : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-neutral-300'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onTogglePhaseItem(selectedEvent.id, phase.id, item.id);
                            }}
                            className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center transition-colors shrink-0 ${
                              item.completed
                                ? 'bg-emerald-600 text-white border-emerald-600'
                                : 'border-neutral-300 dark:border-neutral-600 hover:border-emerald-500'
                            }`}
                          >
                            {item.completed && <Check className="w-3 h-3 stroke-[3]" />}
                          </button>

                          <div className="flex-1 min-w-0">
                            <p
                              className={`text-xs sm:text-sm font-medium leading-relaxed ${
                                item.completed
                                  ? 'line-through text-neutral-400 dark:text-neutral-500'
                                  : 'text-neutral-800 dark:text-neutral-200'
                              }`}
                            >
                              {item.text}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Create Custom Event Modal */}
      {isCreateModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs transition-opacity"
          role="dialog"
          aria-modal="true"
        >
          <div 
            className="w-full max-w-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-xl overflow-hidden transition-all"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 dark:border-neutral-800">
              <h3 className="text-base sm:text-lg font-semibold text-neutral-900 dark:text-neutral-100">
                Create Custom Life Milestone
              </h3>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomEvent} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Milestone Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="e.g. Wedding Planning, Baby Arrival, Home Renovation"
                  className="w-full px-3.5 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1.5">
                  Brief Description
                </label>
                <input
                  type="text"
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  placeholder="e.g. Structured roadmap for a stress-free transition"
                  className="w-full px-3.5 py-2 text-sm bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Phase 1 */}
              <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50 space-y-2">
                <input
                  type="text"
                  value={customPhase1Title}
                  onChange={(e) => setCustomPhase1Title(e.target.value)}
                  placeholder="Phase 1 Title (e.g. 1 Month Out: Budget & Bookings)"
                  className="w-full px-3 py-1.5 text-xs font-semibold bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100"
                />
                <textarea
                  rows={3}
                  value={customPhase1Items}
                  onChange={(e) => setCustomPhase1Items(e.target.value)}
                  placeholder="Phase 1 checklist items (one per line)..."
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 resize-none"
                />
              </div>

              {/* Phase 2 */}
              <div className="p-3.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50 space-y-2">
                <input
                  type="text"
                  value={customPhase2Title}
                  onChange={(e) => setCustomPhase2Title(e.target.value)}
                  placeholder="Phase 2 Title (e.g. Final Week: Execution & Checklists)"
                  className="w-full px-3 py-1.5 text-xs font-semibold bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100"
                />
                <textarea
                  rows={3}
                  value={customPhase2Items}
                  onChange={(e) => setCustomPhase2Items(e.target.value)}
                  placeholder="Phase 2 checklist items (one per line)..."
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-neutral-100 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors shadow-xs"
                >
                  Create Milestone
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
