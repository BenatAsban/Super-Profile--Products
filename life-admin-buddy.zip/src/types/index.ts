export type Category =
  | 'bills'
  | 'documents'
  | 'home'
  | 'health'
  | 'vehicle'
  | 'subscriptions'
  | 'personal'
  | 'family';

export type Priority = 'urgent' | 'high' | 'medium' | 'low';

export type Recurrence = 'none' | 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';

export interface Task {
  id: string;
  title: string;
  category: Category;
  priority: Priority;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string; // HH:MM
  recurrence: Recurrence;
  completed: boolean;
  completedAt?: string; // ISO date string
  notes?: string;
  sourceTemplate?: string;
  createdAt: string;
}

export type ExpiryCategory =
  | 'identification'
  | 'insurance'
  | 'subscription'
  | 'warranty'
  | 'vehicle'
  | 'certification'
  | 'financial'
  | 'other';

export interface ExpiryItem {
  id: string;
  title: string;
  category: ExpiryCategory;
  expiryDate: string; // YYYY-MM-DD
  referenceNumber?: string;
  storageLocation?: string; // e.g. "Safe box", "Glove box", "Online portal"
  renewalCost?: number;
  currency?: string;
  notes?: string;
  websiteUrl?: string;
  reminderDaysBefore: number[]; // e.g. [30, 14, 7]
  lastRenewedDate?: string;
  createdAt: string;
}

export interface LifeEventPhase {
  id: string;
  title: string;
  description?: string;
  items: {
    id: string;
    text: string;
    category: Category;
    completed: boolean;
    dueDateOffsetDays?: number; // relative to event target date
  }[];
}

export interface LifeEvent {
  id: string;
  title: string;
  description: string;
  targetDate?: string;
  iconName: string;
  phases: LifeEventPhase[];
  isCustom?: boolean;
}

export interface AppData {
  tasks: Task[];
  expiries: ExpiryItem[];
  events: LifeEvent[];
  version: number;
}
