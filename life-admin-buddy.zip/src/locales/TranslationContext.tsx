import React, { createContext, useContext, useState, useEffect } from 'react';
import { Locale, translations, Translations } from './translations';

interface TranslationContextType {
  locale: Locale;
  setLocale: (l: Locale) => void;
  t: Translations;
}

const TranslationContext = createContext<TranslationContextType | null>(null);

const STORAGE_KEY = 'life_admin_buddy_locale';

export const TranslationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [locale, setLocaleState] = useState<Locale>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) as Locale;
      if (saved === 'ta' || saved === 'en') return saved;
    } catch {
      // fallback
    }
    return 'en';
  });

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale);
    try {
      localStorage.setItem(STORAGE_KEY, newLocale);
      document.documentElement.lang = newLocale;
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);

  const value: TranslationContextType = {
    locale,
    setLocale,
    t: translations[locale] || translations.en,
  };

  return <TranslationContext.Provider value={value}>{children}</TranslationContext.Provider>;
};

export function useTranslation(): TranslationContextType {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
}
