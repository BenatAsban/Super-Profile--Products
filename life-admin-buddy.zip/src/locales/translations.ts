export type Locale = 'en' | 'ta';

export interface Translations {
  appName: string;
  tagline: string;
  nav: {
    dashboard: string;
    checklists: string;
    expiries: string;
    lifeEvents: string;
    progress: string;
    settings: string;
  };
  actions: {
    quickAdd: string;
    newTask: string;
    newExpiry: string;
    edit: string;
    delete: string;
    complete: string;
    markIncomplete: string;
    renew: string;
    save: string;
    cancel: string;
    importAll: string;
    exportBackup: string;
    importBackup: string;
    resetDemo: string;
    clearAll: string;
    filter: string;
    searchPlaceholder: string;
    all: string;
    dueToday: string;
    upcoming: string;
    overdue: string;
    completed: string;
    active: string;
    addSelected: string;
    selectAll: string;
    deselectAll: string;
    confirmDelete: string;
  };
  categories: {
    bills: string;
    documents: string;
    home: string;
    health: string;
    vehicle: string;
    subscriptions: string;
    personal: string;
    family: string;
    all: string;
  };
  expiryCategories: {
    identification: string;
    insurance: string;
    subscription: string;
    warranty: string;
    vehicle: string;
    certification: string;
    financial: string;
    other: string;
  };
  priorities: {
    urgent: string;
    high: string;
    medium: string;
    low: string;
  };
  recurrence: {
    none: string;
    daily: string;
    weekly: string;
    monthly: string;
    quarterly: string;
    yearly: string;
  };
  dashboard: {
    welcomeHeading: string;
    welcomeSub: string;
    statsDueToday: string;
    statsOverdue: string;
    statsUpcoming: string;
    statsCompleted: string;
    statsExpiriesSoon: string;
    todayFocus: string;
    upcoming7Days: string;
    overdueWarning: string;
    emptyToday: string;
    emptyTodaySub: string;
    emptyUpcoming: string;
    emptyOverdue: string;
    recentCompleted: string;
    noRecentCompleted: string;
  };
  expiries: {
    title: string;
    subtitle: string;
    filterAll: string;
    filterExpiringSoon: string;
    filterExpired: string;
    filterValid: string;
    emptyTitle: string;
    emptySub: string;
    reference: string;
    location: string;
    renewalCost: string;
    renewDialogTitle: string;
    renewDialogSub: string;
  };
  checklists: {
    title: string;
    subtitle: string;
    browseTemplates: string;
    itemsCount: string;
    alreadyAdded: string;
    addedSuccess: string;
  };
  lifeEvents: {
    title: string;
    subtitle: string;
    phases: string;
    progress: string;
    addToDashboard: string;
    createCustom: string;
  };
  progress: {
    title: string;
    subtitle: string;
    completionRate: string;
    activeTasks: string;
    completedTasks: string;
    totalExpiries: string;
    byCategory: string;
    byPriority: string;
    upcomingWorkload: string;
  };
  settings: {
    title: string;
    themeTitle: string;
    themeLight: string;
    themeDark: string;
    themeSystem: string;
    languageTitle: string;
    dataTitle: string;
    dataDescription: string;
    privacyTitle: string;
    privacyBody: string;
    storageUsage: string;
  };
}

export const translations: Record<Locale, Translations> = {
  en: {
    appName: 'Life Admin Buddy',
    tagline: 'Never forget the small things that run your life',
    nav: {
      dashboard: 'Today',
      checklists: 'Smart Checklists',
      expiries: 'Expiry Tracker',
      lifeEvents: 'Life Events',
      progress: 'Insights',
      settings: 'Settings',
    },
    actions: {
      quickAdd: '+ Quick Add',
      newTask: 'New Task',
      newExpiry: 'Add Document / Expiry',
      edit: 'Edit',
      delete: 'Delete',
      complete: 'Complete',
      markIncomplete: 'Reopen',
      renew: 'Renew',
      save: 'Save Changes',
      cancel: 'Cancel',
      importAll: 'Add All to Tasks',
      exportBackup: 'Export Backup (JSON)',
      importBackup: 'Restore Backup',
      resetDemo: 'Reset Sample Data',
      clearAll: 'Clear All Data',
      filter: 'Filter',
      searchPlaceholder: 'Search tasks, documents, notes...',
      all: 'All',
      dueToday: 'Due Today',
      upcoming: 'Upcoming',
      overdue: 'Overdue',
      completed: 'Completed',
      active: 'Active',
      addSelected: 'Add Selected Items',
      selectAll: 'Select All',
      deselectAll: 'Deselect All',
      confirmDelete: 'Are you sure you want to delete this item?',
    },
    categories: {
      bills: 'Bills & Utilities',
      documents: 'Documents & Legal',
      home: 'Home Maintenance',
      health: 'Health & Medical',
      vehicle: 'Vehicle Care',
      subscriptions: 'Subscriptions',
      personal: 'Personal Care',
      family: 'Family & Pets',
      all: 'All Categories',
    },
    expiryCategories: {
      identification: 'ID & Passports',
      insurance: 'Insurance Policies',
      subscription: 'Digital Subscriptions',
      warranty: 'Appliance Warranties',
      vehicle: 'Vehicle Tax & MOT',
      certification: 'Certificates & Licences',
      financial: 'Cards & Banking',
      other: 'Other Documents',
    },
    priorities: {
      urgent: 'Urgent',
      high: 'High',
      medium: 'Medium',
      low: 'Low',
    },
    recurrence: {
      none: 'Does not repeat',
      daily: 'Daily',
      weekly: 'Weekly',
      monthly: 'Monthly',
      quarterly: 'Every 3 months',
      yearly: 'Yearly',
    },
    dashboard: {
      welcomeHeading: 'Life Admin Dashboard',
      welcomeSub: 'Keep on top of your essential household and personal bureaucracy.',
      statsDueToday: 'Due Today',
      statsOverdue: 'Overdue',
      statsUpcoming: 'Next 7 Days',
      statsCompleted: 'Completed Today',
      statsExpiriesSoon: 'Expiries < 30d',
      todayFocus: "Today's Priorities",
      upcoming7Days: 'Upcoming This Week',
      overdueWarning: 'Requires Immediate Attention',
      emptyToday: 'All clear for today!',
      emptyTodaySub: 'No pending tasks scheduled for today. You are fully up to date.',
      emptyUpcoming: 'No tasks coming up in the next 7 days.',
      emptyOverdue: 'No overdue tasks. Excellent job!',
      recentCompleted: 'Recently Completed',
      noRecentCompleted: 'No completed tasks yet today.',
    },
    expiries: {
      title: 'Expiry Tracker',
      subtitle: 'Track renewals for passports, driving licences, policies, and warranties before they lapse.',
      filterAll: 'All Items',
      filterExpiringSoon: 'Expiring Soon (≤30d)',
      filterExpired: 'Expired',
      filterValid: 'Valid & Safe',
      emptyTitle: 'No expiry records yet',
      emptySub: 'Add important personal documents, insurance cards, or vehicle tax dates to be reminded on time.',
      reference: 'Ref / Policy #',
      location: 'Stored at',
      renewalCost: 'Estimated Cost',
      renewDialogTitle: 'Renew Item',
      renewDialogSub: 'Update expiry date after renewing this document or policy.',
    },
    checklists: {
      title: 'Smart Life Checklists',
      subtitle: 'Curated templates of essential routine tasks adults often forget. Pick and add directly to your schedule.',
      browseTemplates: 'Available Life Packs',
      itemsCount: 'tasks included',
      alreadyAdded: 'Added',
      addedSuccess: 'Selected checklist tasks added to your dashboard!',
    },
    lifeEvents: {
      title: 'Life Events Planner',
      subtitle: 'Step-by-step master checklists for major milestones: moving home, starting a new job, trips, and emergencies.',
      phases: 'Phases',
      progress: 'Progress',
      addToDashboard: 'Add Phase to Active Tasks',
      createCustom: 'Custom Event',
    },
    progress: {
      title: 'Life Admin Insights',
      subtitle: 'Scannable analytics on your task execution, category balance, and deadline predictability.',
      completionRate: 'Overall Completion Rate',
      activeTasks: 'Active Tasks',
      completedTasks: 'Completed Tasks',
      totalExpiries: 'Tracked Expiries',
      byCategory: 'Tasks by Category',
      byPriority: 'Tasks by Priority',
      upcomingWorkload: 'Upcoming 7-Day Workload',
    },
    settings: {
      title: 'Preferences & Local Storage',
      themeTitle: 'Appearance Theme',
      themeLight: 'Light Mode',
      themeDark: 'Dark Mode',
      themeSystem: 'Match System',
      languageTitle: 'Language (மொழி)',
      dataTitle: 'Data Management & Privacy',
      dataDescription: 'All data is stored directly in your browser localStorage. No external servers or tracking cookies.',
      privacyTitle: '100% Local-First & Private',
      privacyBody: 'Life Admin Buddy never transmits your personal documents, dates, or tasks anywhere. Back up your data anytime using JSON export.',
      storageUsage: 'Local Storage State',
    },
  },
  ta: {
    appName: 'லைஃப் அட்மின் படி',
    tagline: 'வாழ்க்கையின் அத்தியாவசிய பணிகளை மறக்காமல் நிர்வகியுங்கள்',
    nav: {
      dashboard: 'இன்றைய பணிகள்',
      checklists: 'சரிபார்ப்புப் பட்டியல்',
      expiries: 'காலாவதி கண்காணிப்பு',
      lifeEvents: 'முக்கிய நிகழ்வுகள்',
      progress: 'புள்ளிவிவரம்',
      settings: 'அமைப்புகள்',
    },
    actions: {
      quickAdd: '+ புதிய பணி',
      newTask: 'புதிய பணி',
      newExpiry: 'ஆவணம் / காலாவதி சேர்க்க',
      edit: 'திருத்து',
      delete: 'நீக்கு',
      complete: 'முடிந்தது',
      markIncomplete: 'மீளமைக்க',
      renew: 'புதுப்பிக்க',
      save: 'சேமிக்க',
      cancel: 'ரத்து செய்',
      importAll: 'அனைத்தையும் பணிகளில் சேர்க்க',
      exportBackup: 'காப்புநகல் எடுக்க (JSON)',
      importBackup: 'காப்புநகலை மீட்டெடுக்க',
      resetDemo: 'மாதிரித் தரவை மீட்டமைக்க',
      clearAll: 'அனைத்து தரவையும் அழிக்க',
      filter: 'வடிகட்டு',
      searchPlaceholder: 'பணிகள், ஆவணங்கள் தேடுக...',
      all: 'அனைத்தும்',
      dueToday: 'இன்று முடிக்க வேண்டியவை',
      upcoming: 'வரவிருப்பவை',
      overdue: 'தாமதமானவை',
      completed: 'முடிக்கப்பட்டவை',
      active: 'செயலில் உள்ளவை',
      addSelected: 'தேர்ந்தெடுத்தவற்றை சேர்க்க',
      selectAll: 'அனைத்தையும் தேர்ந்தெடு',
      deselectAll: 'தேர்வை நீக்கு',
      confirmDelete: 'இதை நிச்சயமாக நீக்க விரும்புகிறீர்களா?',
    },
    categories: {
      bills: 'கட்டணங்கள் & பயன்பாடுகள்',
      documents: 'ஆவணங்கள் & சட்டம்',
      home: 'வீட்டுப் பராமரிப்பு',
      health: 'உடல்நலம் & மருத்துவம்',
      vehicle: 'வாகனப் பராமரிப்பு',
      subscriptions: 'சந்தாக்கள்',
      personal: 'தனிப்பட்டவை',
      family: 'குடும்பம் & செல்லப்பிராணிகள்',
      all: 'அனைத்து பிரிவுகள்',
    },
    expiryCategories: {
      identification: 'அடையாள அட்டை & பாஸ்போர்ட்',
      insurance: 'காப்பீட்டு பாலிசிகள்',
      subscription: 'டிஜிட்டல் சந்தாக்கள்',
      warranty: 'உத்தரவாத அட்டைகள்',
      vehicle: 'வாகன வரி & தணிக்கை',
      certification: 'சான்றிதழ்கள் & உரிமங்கள்',
      financial: 'வங்கி & அட்டைகள்',
      other: 'பிற ஆவணங்கள்',
    },
    priorities: {
      urgent: 'அவசரம்',
      high: 'அதிக முன்னுரிமை',
      medium: 'நடுத்தரம்',
      low: 'குறைந்த முன்னுரிமை',
    },
    recurrence: {
      none: 'மீண்டும் வராது',
      daily: 'தினசரி',
      weekly: 'வாராந்திர',
      monthly: 'மாதாந்திர',
      quarterly: '3 மாதங்களுக்கு ஒருமுறை',
      yearly: 'ஆண்டுதோறும்',
    },
    dashboard: {
      welcomeHeading: 'இன்றைய பணி மேலாண்மை',
      welcomeSub: 'உங்கள் வீட்டு மற்றும் தனிப்பட்ட பணிகளை எளிதாக நினைவில் கொள்ளுங்கள்.',
      statsDueToday: 'இன்று முடிய வேண்டியவை',
      statsOverdue: 'தாமதமானவை',
      statsUpcoming: 'அடுத்த 7 நாட்கள்',
      statsCompleted: 'இன்று முடித்தவை',
      statsExpiriesSoon: '30 நாட்களில் காலாவதியாகும்',
      todayFocus: 'இன்றைய முக்கிய பணிகள்',
      upcoming7Days: 'இந்த வார வரவுகள்',
      overdueWarning: 'உடனடி கவனம் தேவை',
      emptyToday: 'இன்று எந்த நிலுவை பணிகளும் இல்லை!',
      emptyTodaySub: 'அனைத்துப் பணிகளும் சரியான நேரத்தில் முடிக்கப்பட்டுள்ளன.',
      emptyUpcoming: 'அடுத்த 7 நாட்களில் பணிகள் எதுவும் இல்லை.',
      emptyOverdue: 'தாமதமான பணிகள் இல்லை. அற்புதம்!',
      recentCompleted: 'சமீபத்தில் முடித்தவை',
      noRecentCompleted: 'இன்று இன்னும் எந்தப் பணியும் முடிக்கப்படவில்லை.',
    },
    expiries: {
      title: 'ஆவணங்கள் காலாவதி கண்காணிப்பு',
      subtitle: 'பாஸ்போர்ட், ஓட்டுநர் உரிமம், காப்பீடு, உத்தரவாதம் காலாவதியாகும் முன் நினைவூட்டல்.',
      filterAll: 'அனைத்தும்',
      filterExpiringSoon: 'விரைவில் காலாவதியாகும் (≤30 நாட்கள்)',
      filterExpired: 'காலாவதியானவை',
      filterValid: 'செல்லுபடியாகும் ஆவணங்கள்',
      emptyTitle: 'ஆவணங்கள் எதுவும் பதிவு செய்யப்படவில்லை',
      emptySub: 'பாஸ்போர்ட், வாகன வரி, காப்பீட்டு விவரங்களைச் சேர்த்து சரியான நேரத்தில் எச்சரிக்கை பெறுங்கள்.',
      reference: 'எண் / பாலிசி #',
      location: 'பாதுகாக்கப்பட்டுள்ள இடம்',
      renewalCost: 'மதிப்பிடப்பட்ட கட்டணம்',
      renewDialogTitle: 'ஆவணத்தைப் புதுப்பிக்க',
      renewDialogSub: 'புதுப்பிக்கப்பட்ட பின் புதிய காலாவதி தேதியை உள்ளிடவும்.',
    },
    checklists: {
      title: 'ஸ்மார்ட் சரிபார்ப்புப் பட்டியல்',
      subtitle: 'மக்கள் எளிதில் மறக்கக்கூடிய அன்றாட வீட்டு மற்றும் வாழ்வியல் பணிகளின் ஆயத்தப் பட்டியல்.',
      browseTemplates: 'கிடைக்கும் பணித் தொகுப்புகள்',
      itemsCount: 'பணிகள் உள்ளன',
      alreadyAdded: 'சேர்க்கப்பட்டது',
      addedSuccess: 'தேர்ந்தெடுக்கப்பட்ட பணிகள் உங்கள் அட்டவணையில் சேர்க்கப்பட்டன!',
    },
    lifeEvents: {
      title: 'முக்கிய நிகழ்வுகள் திட்டமிடுபவர்',
      subtitle: 'வீடு மாறுதல், புதிய வேலை, பயணம் போன்ற முக்கிய நிகழ்வுகளுக்கான விரிவான படிநிலைகள்.',
      phases: 'படிநிலைகள்',
      progress: 'முன்னேற்றம்',
      addToDashboard: 'பணிகள் பலகையில் சேர்க்க',
      createCustom: 'சொந்த நிகழ்வு உருவாக்க',
    },
    progress: {
      title: 'பணி முன்னேற்ற புள்ளிவிவரங்கள்',
      subtitle: 'உங்கள் பணி நிறைவு விகிதம் மற்றும் வகை வாரியான விரிவான பார்வை.',
      completionRate: 'முழுமை பெற்ற விகிதம்',
      activeTasks: 'செயலில் உள்ள பணிகள்',
      completedTasks: 'முடிக்கப்பட்ட பணிகள்',
      totalExpiries: 'பதிவு செய்யப்பட்ட ஆவணங்கள்',
      byCategory: 'பிரிவு வாரியாக',
      byPriority: 'முன்னுரிமை வாரியாக',
      upcomingWorkload: 'அடுத்த 7 நாட்களின் பணிச்சுமை',
    },
    settings: {
      title: 'விருப்பங்கள் & சேமிப்பகம்',
      themeTitle: 'தோற்ற முறைமை',
      themeLight: 'வெளிச்ச முறை (Light)',
      themeDark: 'இருண்ட முறை (Dark)',
      themeSystem: 'கணினி முறைமை',
      languageTitle: 'மொழி (Language)',
      dataTitle: 'தரவு மேலாண்மை & தனியுரிமை',
      dataDescription: 'அனைத்து தரவுகளும் உங்கள் உலாவியில் மட்டுமே (localStorage) சேமிக்கப்படும்.',
      privacyTitle: '100% பாதுகாப்பானது & தனிப்பட்டது',
      privacyBody: 'உங்கள் விவரங்கள் எந்த சர்வர்களுக்கும் அனுப்பப்பட மாட்டாது. எப்போது வேண்டுமானாலும் JSON ஆக பதிவிறக்கம் செய்யலாம்.',
      storageUsage: 'சேமிப்பக நிலை',
    },
  },
};
