import { AppData, Task, ExpiryItem, LifeEvent } from '../types';
import { getInitialTasks, getInitialExpiries } from './sampleData';
import { getInitialLifeEvents } from './templates';

const STORAGE_KEY = 'life_admin_buddy_data_v1';
const CURRENT_VERSION = 1;

export function loadAppData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial: AppData = {
        tasks: getInitialTasks(),
        expiries: getInitialExpiries(),
        events: getInitialLifeEvents(),
        version: CURRENT_VERSION,
      };
      saveAppData(initial);
      return initial;
    }

    const parsed = JSON.parse(raw);
    if (parsed && Array.isArray(parsed.tasks) && Array.isArray(parsed.expiries)) {
      return {
        tasks: parsed.tasks,
        expiries: parsed.expiries,
        events: Array.isArray(parsed.events) && parsed.events.length > 0 ? parsed.events : getInitialLifeEvents(),
        version: parsed.version || CURRENT_VERSION,
      };
    }
  } catch (err) {
    console.error('Failed to parse saved AppData:', err);
  }

  // Fallback
  return {
    tasks: getInitialTasks(),
    expiries: getInitialExpiries(),
    events: getInitialLifeEvents(),
    version: CURRENT_VERSION,
  };
}

export function saveAppData(data: AppData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to save AppData to localStorage:', err);
  }
}

/**
 * Trigger browser download of full JSON backup
 */
export function exportBackup(data: AppData): void {
  const payload = JSON.stringify(data, null, 2);
  const blob = new Blob([payload], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const dateStr = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `life-admin-buddy-backup-${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Validate imported JSON
 */
export function validateImportData(obj: any): AppData | null {
  if (!obj || typeof obj !== 'object') return null;
  if (!Array.isArray(obj.tasks) || !Array.isArray(obj.expiries)) return null;

  return {
    tasks: obj.tasks,
    expiries: obj.expiries,
    events: Array.isArray(obj.events) ? obj.events : getInitialLifeEvents(),
    version: typeof obj.version === 'number' ? obj.version : CURRENT_VERSION,
  };
}

/**
 * Reset data to fresh default demo state
 */
export function resetToDemoData(): AppData {
  const fresh: AppData = {
    tasks: getInitialTasks(),
    expiries: getInitialExpiries(),
    events: getInitialLifeEvents(),
    version: CURRENT_VERSION,
  };
  saveAppData(fresh);
  return fresh;
}

/**
 * Clear all records
 */
export function clearAllData(): AppData {
  const empty: AppData = {
    tasks: [],
    expiries: [],
    events: getInitialLifeEvents(),
    version: CURRENT_VERSION,
  };
  saveAppData(empty);
  return empty;
}

/**
 * Calculate approximate storage footprint in KB
 */
export function getStorageUsageKB(): string {
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || '';
    const bytes = new Blob([raw]).size;
    return (bytes / 1024).toFixed(1);
  } catch {
    return '0.0';
  }
}
