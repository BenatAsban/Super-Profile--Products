import { Recurrence } from '../types';

/**
 * Returns today's date formatted as YYYY-MM-DD in local time
 */
export function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Parse a YYYY-MM-DD string into a local Date object (ignoring timezone offsets)
 */
export function parseLocalDate(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, (month || 1) - 1, day || 1);
}

/**
 * Format date to YYYY-MM-DD
 */
export function formatDateISO(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Returns difference in whole calendar days (target - reference).
 * Positive = future, 0 = today, negative = past (overdue).
 */
export function getDaysDifference(targetDateStr: string, referenceDateStr: string = getTodayString()): number {
  if (!targetDateStr) return 0;
  const target = parseLocalDate(targetDateStr).getTime();
  const reference = parseLocalDate(referenceDateStr).getTime();
  const diffMs = target - reference;
  return Math.round(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Friendly relative date label (e.g. "Today", "Tomorrow", "Yesterday", "In 3 days", "2 days overdue", "Oct 26, 2026")
 */
export function formatFriendlyDate(dateStr: string, locale: 'en' | 'ta' = 'en'): string {
  if (!dateStr) return '';
  const days = getDaysDifference(dateStr);

  if (locale === 'ta') {
    if (days === 0) return 'இன்று';
    if (days === 1) return 'நாளை';
    if (days === -1) return 'நேற்று';
    if (days > 1 && days <= 7) return `${days} நாட்களில்`;
    if (days < -1 && days >= -7) return `${Math.abs(days)} நாட்களுக்கு முன்`;
  } else {
    if (days === 0) return 'Today';
    if (days === 1) return 'Tomorrow';
    if (days === -1) return 'Yesterday';
    if (days > 1 && days <= 7) return `In ${days} days`;
    if (days < -1 && days >= -7) return `${Math.abs(days)}d overdue`;
  }

  const date = parseLocalDate(dateStr);
  return date.toLocaleDateString(locale === 'ta' ? 'ta-IN' : 'en-US', {
    month: 'short',
    day: 'numeric',
    year: date.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined,
  });
}

/**
 * Check if a date string is today
 */
export function isToday(dateStr: string): boolean {
  return getDaysDifference(dateStr) === 0;
}

/**
 * Check if a date is overdue (in the past and not today)
 */
export function isOverdue(dateStr: string): boolean {
  return getDaysDifference(dateStr) < 0;
}

/**
 * Check if a date is within next N days (inclusive of today)
 */
export function isWithinNextDays(dateStr: string, days: number = 7): boolean {
  const diff = getDaysDifference(dateStr);
  return diff >= 0 && diff <= days;
}

/**
 * Calculate the next due date for recurring items
 */
export function getNextRecurringDate(currentDateStr: string, recurrence: Recurrence): string {
  const date = parseLocalDate(currentDateStr);
  const now = new Date();
  
  // Base date should either be the scheduled date or today if scheduled date was far in the past
  let baseDate = date.getTime() < now.getTime() ? now : date;
  const next = new Date(baseDate);

  switch (recurrence) {
    case 'daily':
      next.setDate(next.getDate() + 1);
      break;
    case 'weekly':
      next.setDate(next.getDate() + 7);
      break;
    case 'monthly':
      next.setMonth(next.getMonth() + 1);
      break;
    case 'quarterly':
      next.setMonth(next.getMonth() + 3);
      break;
    case 'yearly':
      next.setFullYear(next.getFullYear() + 1);
      break;
    case 'none':
    default:
      return currentDateStr;
  }

  return formatDateISO(next);
}

/**
 * Expiry status helper
 */
export type ExpiryStatus = 'expired' | 'urgent' | 'warning' | 'good';

export function getExpiryStatus(expiryDateStr: string): {
  status: ExpiryStatus;
  daysRemaining: number;
  label: string;
} {
  const days = getDaysDifference(expiryDateStr);

  if (days < 0) {
    return {
      status: 'expired',
      daysRemaining: days,
      label: `Expired ${Math.abs(days)} days ago`,
    };
  }
  if (days <= 14) {
    return {
      status: 'urgent',
      daysRemaining: days,
      label: days === 0 ? 'Expires today' : days === 1 ? 'Expires tomorrow' : `Expires in ${days} days`,
    };
  }
  if (days <= 30) {
    return {
      status: 'warning',
      daysRemaining: days,
      label: `Expires in ${days} days`,
    };
  }
  if (days <= 90) {
    return {
      status: 'warning',
      daysRemaining: days,
      label: `Expires in ~${Math.round(days / 30)} months (${days}d)`,
    };
  }
  return {
    status: 'good',
    daysRemaining: days,
    label: `Valid (${days} days left)`,
  };
}

/**
 * Add days to current date string
 */
export function addDaysToToday(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return formatDateISO(d);
}
