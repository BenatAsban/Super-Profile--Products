import { Task, ExpiryItem, LifeEvent } from '../types';
import { getTodayString, addDaysToToday } from './dateUtils';

export function getInitialTasks(): Task[] {
  const today = getTodayString();
  const past2Days = addDaysToToday(-2);
  const tomorrow = addDaysToToday(1);
  const in3Days = addDaysToToday(3);
  const in5Days = addDaysToToday(5);
  const in10Days = addDaysToToday(10);

  return [
    {
      id: 'task-1',
      title: 'Pay monthly electricity & water bill',
      category: 'bills',
      priority: 'high',
      dueDate: today,
      recurrence: 'monthly',
      completed: false,
      notes: 'Portal login: State power distribution account #94821. Auto-pay fails if card is updated.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-2',
      title: 'Check car tire pressure & windshield washer fluid',
      category: 'vehicle',
      priority: 'medium',
      dueDate: today,
      recurrence: 'monthly',
      completed: false,
      notes: 'Front: 33 PSI, Rear: 35 PSI. Top up blue winter screenwash.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-3',
      title: 'Replace home air purifier HEPA filter',
      category: 'home',
      priority: 'urgent',
      dueDate: past2Days, // overdue
      recurrence: 'quarterly',
      completed: false,
      notes: 'Indicator light turned red. Replacement filter pack in hallway closet.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-4',
      title: 'Submit quarterly dental & health insurance receipts',
      category: 'health',
      priority: 'medium',
      dueDate: tomorrow,
      recurrence: 'quarterly',
      completed: false,
      notes: 'Claim window closes at month end. Submit via insurer mobile app.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-5',
      title: 'Review streaming subscriptions & cancel unused ones',
      category: 'subscriptions',
      priority: 'low',
      dueDate: in3Days,
      recurrence: 'monthly',
      completed: false,
      notes: 'Check Apple subscriptions & Google Play recurrent charges.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-6',
      title: 'Inspect bathroom caulking & test smoke alarm sirens',
      category: 'home',
      priority: 'medium',
      dueDate: in5Days,
      recurrence: 'quarterly',
      completed: false,
      notes: 'Hold test button for 5 seconds until beeps sound.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-7',
      title: 'Schedule annual vehicle safety inspection (MOT)',
      category: 'vehicle',
      priority: 'high',
      dueDate: in10Days,
      recurrence: 'yearly',
      completed: false,
      notes: 'Book at downtown certified testing station. Need V5C logbook.',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'task-8',
      title: 'Monthly bank statement check & fraud review',
      category: 'personal',
      priority: 'medium',
      dueDate: today,
      recurrence: 'monthly',
      completed: true,
      completedAt: new Date().toISOString(),
      notes: 'Verified all 3 credit card transactions for unexpected recurring charges.',
      createdAt: new Date().toISOString(),
    },
  ];
}

export function getInitialExpiries(): ExpiryItem[] {
  return [
    {
      id: 'exp-1',
      title: 'Vehicle Comprehensive Insurance',
      category: 'insurance',
      expiryDate: addDaysToToday(18), // Expiring soon (<30 days)
      referenceNumber: 'POL-AUTO-882194',
      storageLocation: 'Glove compartment folder & insurer app',
      renewalCost: 480,
      currency: '$',
      notes: 'Compare no-claims discount quotes at least 2 weeks before expiration.',
      reminderDaysBefore: [30, 14, 7],
      createdAt: new Date().toISOString(),
    },
    {
      id: 'exp-2',
      title: 'International Passport',
      category: 'identification',
      expiryDate: addDaysToToday(140), // Attention / Valid
      referenceNumber: 'P9284102B',
      storageLocation: 'Home fireproof document safe',
      renewalCost: 130,
      currency: '$',
      notes: 'Many countries require at least 6 months validity from departure date.',
      reminderDaysBefore: [180, 90, 30],
      createdAt: new Date().toISOString(),
    },
    {
      id: 'exp-3',
      title: 'Refrigerator Manufacturer Warranty',
      category: 'warranty',
      expiryDate: addDaysToToday(-12), // Expired
      referenceNumber: 'SN-SAMS-90218-X',
      storageLocation: 'Kitchen drawer envelope #2',
      notes: '2-year standard parts warranty has expired. Extended compressor warranty still covers 10 years.',
      reminderDaysBefore: [30],
      createdAt: new Date().toISOString(),
    },
    {
      id: 'exp-4',
      title: 'Driving Licence (Full)',
      category: 'identification',
      expiryDate: addDaysToToday(360),
      referenceNumber: 'LIC-7489201',
      storageLocation: 'Physical wallet & digital Gov ID',
      renewalCost: 40,
      currency: '$',
      notes: 'Requires eye test certification upon next renewal.',
      reminderDaysBefore: [60, 30],
      createdAt: new Date().toISOString(),
    },
    {
      id: 'exp-5',
      title: 'Cloud Storage 2TB Annual Plan',
      category: 'subscription',
      expiryDate: addDaysToToday(28), // Expiring soon
      referenceNumber: 'SUB-GDRV-ANNUAL',
      storageLocation: 'Online billing dashboard',
      renewalCost: 99,
      currency: '$',
      websiteUrl: 'https://one.google.com',
      notes: 'Billed to primary debit card. Check storage quota usage.',
      reminderDaysBefore: [30, 7],
      createdAt: new Date().toISOString(),
    },
  ];
}
