import { Category, Priority, Recurrence, LifeEvent } from '../types';

export interface ChecklistItemTemplate {
  id: string;
  title: string;
  category: Category;
  priority: Priority;
  recurrence: Recurrence;
  notes: string;
}

export interface ChecklistPack {
  id: string;
  title: string;
  description: string;
  category: Category;
  iconName: string;
  items: ChecklistItemTemplate[];
}

export const CHECKLIST_PACKS: ChecklistPack[] = [
  {
    id: 'pack-monthly-bills',
    title: 'Monthly Bills & Fixed Expenses',
    description: 'Never miss payment cycles, credit card due dates, and utility payments.',
    category: 'bills',
    iconName: 'Receipt',
    items: [
      {
        id: 'mb-1',
        title: 'Pay monthly electricity bill',
        category: 'bills',
        priority: 'high',
        recurrence: 'monthly',
        notes: 'Check meter reading against online bill to prevent estimated overcharge.',
      },
      {
        id: 'mb-2',
        title: 'Pay water & sewage utility bill',
        category: 'bills',
        priority: 'medium',
        recurrence: 'monthly',
        notes: 'Review water usage for hidden plumbing leaks.',
      },
      {
        id: 'mb-3',
        title: 'Pay residential broadband & fiber internet',
        category: 'bills',
        priority: 'high',
        recurrence: 'monthly',
        notes: 'Verify promo rate hasn’t expired into higher tier.',
      },
      {
        id: 'mb-4',
        title: 'Clear full statement balance on primary credit cards',
        category: 'bills',
        priority: 'urgent',
        recurrence: 'monthly',
        notes: 'Always pay statement balance in full to avoid 20%+ APR interest.',
      },
      {
        id: 'mb-5',
        title: 'Transfer planned amount to emergency savings fund',
        category: 'personal',
        priority: 'medium',
        recurrence: 'monthly',
        notes: 'Pay yourself first right after salary deposit.',
      },
    ],
  },
  {
    id: 'pack-home-maintenance',
    title: 'Home Maintenance & Safety',
    description: 'Small quarterly upkeep steps that prevent thousands in costly repairs.',
    category: 'home',
    iconName: 'Home',
    items: [
      {
        id: 'hm-1',
        title: 'Wash / replace air conditioner & HVAC filters',
        category: 'home',
        priority: 'medium',
        recurrence: 'monthly',
        notes: 'Clean filters save 15% on cooling bills and reduce indoor allergens.',
      },
      {
        id: 'hm-2',
        title: 'Test smoke and carbon monoxide detector alarms',
        category: 'home',
        priority: 'urgent',
        recurrence: 'quarterly',
        notes: 'Press and hold test button until 3 loud beeps sound. Replace 9V batteries if chirping.',
      },
      {
        id: 'hm-3',
        title: 'Inspect kitchen & bathroom sink drain traps and seals',
        category: 'home',
        priority: 'medium',
        recurrence: 'quarterly',
        notes: 'Check underneath sinks for slow leaks, damp smell, or swelling wood.',
      },
      {
        id: 'hm-4',
        title: 'Clean clothes dryer exhaust lint duct',
        category: 'home',
        priority: 'high',
        recurrence: 'quarterly',
        notes: 'Lint buildup is a leading cause of residential house fires.',
      },
      {
        id: 'hm-5',
        title: 'Vacuum refrigerator condenser coils behind / under unit',
        category: 'home',
        priority: 'low',
        recurrence: 'yearly',
        notes: 'Dusty coils make compressor run hot, shortening lifespan and wasting electricity.',
      },
    ],
  },
  {
    id: 'pack-vehicle-care',
    title: 'Vehicle Upkeep & Safety Check',
    description: 'Essential fluid checks, tire safety, and preventive vehicle steps.',
    category: 'vehicle',
    iconName: 'Car',
    items: [
      {
        id: 'vc-1',
        title: 'Check tire pressures (including spare) and tread depth',
        category: 'vehicle',
        priority: 'high',
        recurrence: 'monthly',
        notes: 'Check when cold. Recommended PSI is stamped on the driver door jamb sticker.',
      },
      {
        id: 'vc-2',
        title: 'Inspect windshield wiper blades & top up washer fluid',
        category: 'vehicle',
        priority: 'medium',
        recurrence: 'monthly',
        notes: 'Use rain-repellent or bug-cleaning formula depending on season.',
      },
      {
        id: 'vc-3',
        title: 'Check engine oil level & coolant level',
        category: 'vehicle',
        priority: 'high',
        recurrence: 'monthly',
        notes: 'Park on level ground. Wipe dipstick clean, re-insert, and inspect between min/max lines.',
      },
      {
        id: 'vc-4',
        title: 'Schedule tire rotation & wheel alignment check',
        category: 'vehicle',
        priority: 'medium',
        recurrence: 'quarterly',
        notes: 'Rotate tires every 8,000–10,000 km to guarantee even tread wear.',
      },
    ],
  },
  {
    id: 'pack-document-bureaucracy',
    title: 'Document Renewals & Bureaucracy',
    description: 'Renew legal documents, government registrations, and tax obligations.',
    category: 'documents',
    iconName: 'FileText',
    items: [
      {
        id: 'doc-1',
        title: 'Check passport expiry date (>6 months validity for travel)',
        category: 'documents',
        priority: 'high',
        recurrence: 'yearly',
        notes: 'Renew at least 6 months before planned international trips to avoid visa delays.',
      },
      {
        id: 'doc-2',
        title: 'File annual personal income tax returns',
        category: 'documents',
        priority: 'urgent',
        recurrence: 'yearly',
        notes: 'Gather W2/P60, interest statements, investment capital gains, and deduction proofs.',
      },
      {
        id: 'doc-3',
        title: 'Verify vehicle registration / road tax status',
        category: 'documents',
        priority: 'urgent',
        recurrence: 'yearly',
        notes: 'Driving with lapsed registration risks immediate fines and invalidates insurance.',
      },
      {
        id: 'doc-4',
        title: 'Review home/renters insurance coverage & inventory',
        category: 'documents',
        priority: 'medium',
        recurrence: 'yearly',
        notes: 'Take updated video walkthrough of electronics, jewelry, and major appliances.',
      },
    ],
  },
  {
    id: 'pack-health-medical',
    title: 'Health & Medical Preventive Care',
    description: 'Dentist, eye exams, routine blood panels, and medication management.',
    category: 'health',
    iconName: 'HeartPulse',
    items: [
      {
        id: 'hm-10',
        title: 'Schedule bi-annual dental cleaning & exam',
        category: 'health',
        priority: 'medium',
        recurrence: 'quarterly',
        notes: 'Prevents tartar buildup, periodontal issues, and discovers cavities early.',
      },
      {
        id: 'hm-11',
        title: 'Book annual preventive health checkup & blood work',
        category: 'health',
        priority: 'medium',
        recurrence: 'yearly',
        notes: 'Fasting lipid profile, HbA1c blood sugar, liver function, and kidney panel.',
      },
      {
        id: 'hm-12',
        title: 'Audit home first-aid kit & discard expired medicines',
        category: 'health',
        priority: 'low',
        recurrence: 'quarterly',
        notes: 'Check antiseptic ointments, painkillers, eye drops, and adhesive band-aids.',
      },
    ],
  },
  {
    id: 'pack-digital-hygiene',
    title: 'Digital Hygiene & Cyber Security',
    description: 'Password manager audits, backup verification, and account cleanup.',
    category: 'subscriptions',
    iconName: 'ShieldCheck',
    items: [
      {
        id: 'dh-1',
        title: 'Verify offline computer / phone cloud backup restore test',
        category: 'personal',
        priority: 'high',
        recurrence: 'monthly',
        notes: 'A backup is only as good as a proven test restore.',
      },
      {
        id: 'dh-2',
        title: 'Audit active credit card recurring subscriptions',
        category: 'subscriptions',
        priority: 'medium',
        recurrence: 'quarterly',
        notes: 'Cancel free trials that rolled over into monthly billing and forgotten services.',
      },
      {
        id: 'dh-3',
        title: 'Update router firmware & reboot main network access point',
        category: 'home',
        priority: 'low',
        recurrence: 'quarterly',
        notes: 'Patches known security vulnerabilities in home Wi-Fi gateways.',
      },
    ],
  },
];

export function getInitialLifeEvents(): LifeEvent[] {
  return [
    {
      id: 'event-moving-house',
      title: 'Moving House / Apartment Relocation',
      description: 'Comprehensive phased blueprint for shifting residence without chaos.',
      iconName: 'Truck',
      phases: [
        {
          id: 'mv-p1',
          title: '4 Weeks Out — Purge & Logistics',
          description: 'Sort belongings, book movers, notify stakeholders.',
          items: [
            { id: 'm1', text: 'Give official move-out notice to current landlord or prepare lease termination', category: 'documents', completed: false, dueDateOffsetDays: -28 },
            { id: 'm2', text: 'Book professional moving company or rent moving van with confirmed time slot', category: 'personal', completed: false, dueDateOffsetDays: -25 },
            { id: 'm3', text: 'Declutter room-by-room: sell or donate unwanted furniture and clothes', category: 'home', completed: false, dueDateOffsetDays: -21 },
            { id: 'm4', text: 'Acquire packing supplies: sturdy boxes, bubble wrap, tape, colored label markers', category: 'home', completed: false, dueDateOffsetDays: -20 },
          ],
        },
        {
          id: 'mv-p2',
          title: '2 Weeks Out — Utilities & Address Updates',
          description: 'Transfer utilities and update key institutions.',
          items: [
            { id: 'm5', text: 'Schedule disconnection of electricity, water, gas at old address', category: 'bills', completed: false, dueDateOffsetDays: -14 },
            { id: 'm6', text: 'Schedule activation of broadband internet and power at new home', category: 'bills', completed: false, dueDateOffsetDays: -12 },
            { id: 'm7', text: 'Set up postal mail forwarding with National Postal Service', category: 'documents', completed: false, dueDateOffsetDays: -10 },
            { id: 'm8', text: 'Update billing address for bank, credit cards, employer HR, and driving licence', category: 'documents', completed: false, dueDateOffsetDays: -8 },
          ],
        },
        {
          id: 'mv-p3',
          title: 'Moving Week — Packing & Handover',
          description: 'Final packing, inventory, and old property checkout.',
          items: [
            { id: 'm9', text: 'Pack "First Night Survival Kit": toilet paper, kettle, sheets, chargers, daily meds, change of clothes', category: 'personal', completed: false, dueDateOffsetDays: -2 },
            { id: 'm10', text: 'Defrost and empty refrigerator/freezer 24 hours before moving day', category: 'home', completed: false, dueDateOffsetDays: -1 },
            { id: 'm11', text: 'Photograph utility meters (gas/electric/water) at both old and new homes', category: 'documents', completed: false, dueDateOffsetDays: 0 },
            { id: 'm12', text: 'Conduct final handover walkthrough with landlord / agent and return all key sets', category: 'documents', completed: false, dueDateOffsetDays: 0 },
          ],
        },
        {
          id: 'mv-p4',
          title: 'Settling In — Week 1 at New Home',
          description: 'Safety, local services, and essential comfort.',
          items: [
            { id: 'm13', text: 'Locate main water shutoff valve, electrical breaker fuse box, and gas meter', category: 'home', completed: false, dueDateOffsetDays: 1 },
            { id: 'm14', text: 'Install fresh batteries in all smoke and CO detectors', category: 'home', completed: false, dueDateOffsetDays: 2 },
            { id: 'm15', text: 'Register with nearest local doctor/GP clinic and dental practice', category: 'health', completed: false, dueDateOffsetDays: 5 },
            { id: 'm16', text: 'Update electoral voter registration and local council tax account', category: 'documents', completed: false, dueDateOffsetDays: 7 },
          ],
        },
      ],
    },
    {
      id: 'event-new-job',
      title: 'Starting a New Job',
      description: 'Pre-boarding paperwork, 1st week setup, and establishing administrative foundations.',
      iconName: 'Briefcase',
      phases: [
        {
          id: 'nj-p1',
          title: 'Pre-Start Paperwork',
          description: 'Complete HR, bank, and background checks before Day 1.',
          items: [
            { id: 'j1', text: 'Sign employment agreement and review non-compete / IP clauses', category: 'documents', completed: false, dueDateOffsetDays: -14 },
            { id: 'j2', text: 'Submit bank direct-deposit routing information and tax declaration (W4/P45)', category: 'bills', completed: false, dueDateOffsetDays: -10 },
            { id: 'j3', text: 'Provide identity proof documents (passport/visa) for right-to-work verification', category: 'documents', completed: false, dueDateOffsetDays: -7 },
            { id: 'j4', text: 'Test commute route and timing during peak morning rush hour', category: 'personal', completed: false, dueDateOffsetDays: -3 },
          ],
        },
        {
          id: 'nj-p2',
          title: 'First Two Weeks — Setup & Benefits',
          description: 'Health insurance selection, hardware setup, and expectations.',
          items: [
            { id: 'j5', text: 'Review employer health, dental, and disability insurance options during enrollment window', category: 'health', completed: false, dueDateOffsetDays: 5 },
            { id: 'j6', text: 'Set up retirement / 401(k) / pension contribution up to maximum company match', category: 'bills', completed: false, dueDateOffsetDays: 10 },
            { id: 'j7', text: 'Schedule 30-day alignment 1-on-1 with manager to clarify success metrics', category: 'personal', completed: false, dueDateOffsetDays: 12 },
          ],
        },
      ],
    },
    {
      id: 'event-international-travel',
      title: 'International Travel Preparation',
      description: 'Avoid airport surprises: passports, visas, insurance, packing, and offline backups.',
      iconName: 'Plane',
      phases: [
        {
          id: 'it-p1',
          title: '4 Weeks Before Trip',
          description: 'Passport validity, visas, and reservations.',
          items: [
            { id: 't1', text: 'Confirm passport has minimum 6 months validity beyond return flight date', category: 'documents', completed: false, dueDateOffsetDays: -30 },
            { id: 't2', text: 'Check visa / electronic travel authorization (ESTA / ETA) requirements and apply', category: 'documents', completed: false, dueDateOffsetDays: -25 },
            { id: 't3', text: 'Purchase comprehensive travel medical insurance with repatriation cover', category: 'documents', completed: false, dueDateOffsetDays: -20 },
            { id: 't4', text: 'Check destination vaccination requirements and prescription medication legality', category: 'health', completed: false, dueDateOffsetDays: -15 },
          ],
        },
        {
          id: 'it-p2',
          title: '72 Hours Before Departure',
          description: 'Banking, connectivity, packing, and home security.',
          items: [
            { id: 't5', text: 'Set travel notice on debit/credit cards or ensure 0% foreign transaction fee card is ready', category: 'bills', completed: false, dueDateOffsetDays: -3 },
            { id: 't6', text: 'Download offline Google Maps regions and offline translation dictionaries', category: 'personal', completed: false, dueDateOffsetDays: -2 },
            { id: 't7', text: 'Photograph passport, visa, and reservations; save copies securely in cloud & email', category: 'documents', completed: false, dueDateOffsetDays: -2 },
            { id: 't8', text: 'Complete online airline check-in and download boarding passes to digital wallet', category: 'personal', completed: false, dueDateOffsetDays: -1 },
            { id: 't9', text: 'Arrange plant watering, pause subscription deliveries, and confirm door locks', category: 'home', completed: false, dueDateOffsetDays: -1 },
          ],
        },
      ],
    },
    {
      id: 'event-emergency-prep',
      title: 'Household Emergency & Disaster Readiness',
      description: 'Prepare vital grab-and-go documents, 72-hour provisions, and communication plan.',
      iconName: 'ShieldAlert',
      phases: [
        {
          id: 'ep-p1',
          title: 'Document & Family Plan',
          description: 'Ensure critical records and contact channels exist.',
          items: [
            { id: 'e1', text: 'Assemble water-resistant folder with passport copies, birth certificates, deeds, and insurance policies', category: 'documents', completed: false },
            { id: 'e2', text: 'Create physical laminated card with out-of-area emergency contacts and meeting spots', category: 'personal', completed: false },
            { id: 'e3', text: 'Keep emergency cash stash in small bills ($10/$20) in safe location (ATMs fail during blackouts)', category: 'bills', completed: false },
          ],
        },
        {
          id: 'ep-p2',
          title: '72-Hour Survival Kit',
          description: 'Water, food, power, and first-aid provisions.',
          items: [
            { id: 'e4', text: 'Store 3-day drinking water supply (at least 3 liters / 1 gallon per person per day)', category: 'home', completed: false },
            { id: 'e5', text: 'Pack non-perishable canned food + manual hand-crank can opener', category: 'home', completed: false },
            { id: 'e6', text: 'Keep fully charged 20,000mAh portable power bank with USB cables and multi-LED flashlight', category: 'home', completed: false },
            { id: 'e7', text: 'Stock 7-day reserve of critical prescription medications in airtight container', category: 'health', completed: false },
          ],
        },
      ],
    },
  ];
}
