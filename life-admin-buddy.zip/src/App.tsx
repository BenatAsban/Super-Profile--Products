import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { AppData, Task, ExpiryItem, LifeEvent } from './types';
import { 
  loadAppData, 
  saveAppData, 
  resetToDemoData, 
  clearAllData 
} from './utils/storage';
import { 
  getNextRecurringDate, 
  getDaysDifference, 
  getExpiryStatus, 
  isOverdue 
} from './utils/dateUtils';
import { TranslationProvider, useTranslation } from './locales/TranslationContext';
import { Header, ActiveTab } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { ChecklistTemplatesView } from './components/ChecklistTemplatesView';
import { ExpiryTrackerView } from './components/ExpiryTrackerView';
import { LifeEventsView } from './components/LifeEventsView';
import { ProgressView } from './components/ProgressView';
import { QuickAddModal } from './components/QuickAddModal';
import { AddExpiryModal } from './components/AddExpiryModal';
import { RenewExpiryModal } from './components/RenewExpiryModal';
import { SettingsModal } from './components/SettingsModal';
import { Check, ShieldCheck } from 'lucide-react';

function LifeAdminApp() {
  const { t } = useTranslation();

  // Load state from localStorage
  const [appData, setAppData] = useState<AppData>(() => loadAppData());

  // Navigation tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('life_admin_buddy_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  // Modal states
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const [isAddExpiryOpen, setIsAddExpiryOpen] = useState(false);
  const [editingExpiry, setEditingExpiry] = useState<ExpiryItem | null>(null);

  const [renewingExpiry, setRenewingExpiry] = useState<ExpiryItem | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  }, []);

  // Sync theme to <html> tag
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('life_admin_buddy_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('life_admin_buddy_theme', 'light');
    }
  }, [isDark]);

  // Persist appData whenever it changes
  useEffect(() => {
    saveAppData(appData);
  }, [appData]);

  // Global keyboard shortcuts (e.g., 'N' for new task)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input or textarea
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') {
        return;
      }

      if ((e.key === 'n' || e.key === 'N') && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        setEditingTask(null);
        setIsQuickAddOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Overdue count and Expiries < 30d count for badges
  const overdueCount = useMemo(() => {
    return appData.tasks.filter((t) => !t.completed && isOverdue(t.dueDate)).length;
  }, [appData.tasks]);

  const expiringSoonCount = useMemo(() => {
    return appData.expiries.filter((e) => {
      const { status } = getExpiryStatus(e.expiryDate);
      return status === 'urgent' || status === 'warning';
    }).length;
  }, [appData.expiries]);

  // Task Operations
  const handleToggleCompleteTask = useCallback((task: Task) => {
    setAppData((prev) => {
      const wasCompleted = task.completed;
      const isNowCompleted = !wasCompleted;

      // Update current task
      const updatedTasks = prev.tasks.map((t) => {
        if (t.id === task.id) {
          return {
            ...t,
            completed: isNowCompleted,
            completedAt: isNowCompleted ? new Date().toISOString() : undefined,
          };
        }
        return t;
      });

      // Recurrence rule: if marking complete and recurring, schedule the next iteration!
      if (isNowCompleted && task.recurrence !== 'none') {
        const nextDueDate = getNextRecurringDate(task.dueDate, task.recurrence);
        const nextTask: Task = {
          id: `task-${Date.now()}`,
          title: task.title,
          category: task.category,
          priority: task.priority,
          dueDate: nextDueDate,
          recurrence: task.recurrence,
          completed: false,
          notes: task.notes,
          sourceTemplate: task.sourceTemplate,
          createdAt: new Date().toISOString(),
        };
        showToast(`Completed! Next occurrence scheduled for ${nextDueDate}.`);
        return {
          ...prev,
          tasks: [nextTask, ...updatedTasks],
        };
      }

      return {
        ...prev,
        tasks: updatedTasks,
      };
    });
  }, [showToast]);

  const handleSaveTask = useCallback((taskData: Omit<Task, 'id' | 'createdAt'> & { id?: string }) => {
    setAppData((prev) => {
      if (taskData.id) {
        // Edit existing
        const updated = prev.tasks.map((t) => (t.id === taskData.id ? { ...t, ...taskData } : t));
        showToast('Task updated');
        return { ...prev, tasks: updated };
      } else {
        // Create new
        const newTask: Task = {
          ...taskData,
          id: `task-${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        showToast('New task added');
        return { ...prev, tasks: [newTask, ...prev.tasks] };
      }
    });
  }, [showToast]);

  const handleDeleteTask = useCallback((id: string) => {
    setAppData((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => t.id !== id),
    }));
    showToast('Task deleted');
  }, [showToast]);

  const handleAddMultipleTasks = useCallback((newTasks: Omit<Task, 'id' | 'createdAt'>[]) => {
    const formatted: Task[] = newTasks.map((t, idx) => ({
      ...t,
      id: `task-${Date.now()}-${idx}`,
      createdAt: new Date().toISOString(),
    }));

    setAppData((prev) => ({
      ...prev,
      tasks: [...formatted, ...prev.tasks],
    }));
  }, []);

  // Expiry Operations
  const handleSaveExpiry = useCallback((itemData: Omit<ExpiryItem, 'id' | 'createdAt'> & { id?: string }) => {
    setAppData((prev) => {
      if (itemData.id) {
        const updated = prev.expiries.map((e) => (e.id === itemData.id ? { ...e, ...itemData } : e));
        showToast('Expiry record updated');
        return { ...prev, expiries: updated };
      } else {
        const newItem: ExpiryItem = {
          ...itemData,
          id: `exp-${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        showToast('Document expiry tracked');
        return { ...prev, expiries: [newItem, ...prev.expiries] };
      }
    });
  }, [showToast]);

  const handleDeleteExpiry = useCallback((id: string) => {
    setAppData((prev) => ({
      ...prev,
      expiries: prev.expiries.filter((e) => e.id !== id),
    }));
    showToast('Expiry record removed');
  }, [showToast]);

  const handleConfirmRenewExpiry = useCallback((id: string, newExpiryDate: string) => {
    setAppData((prev) => ({
      ...prev,
      expiries: prev.expiries.map((e) => {
        if (e.id === id) {
          return {
            ...e,
            expiryDate: newExpiryDate,
            lastRenewedDate: new Date().toISOString(),
          };
        }
        return e;
      }),
    }));
    showToast('Item successfully renewed!');
  }, [showToast]);

  // Life Event Operations
  const handleTogglePhaseItem = useCallback((eventId: string, phaseId: string, itemId: string) => {
    setAppData((prev) => ({
      ...prev,
      events: prev.events.map((ev) => {
        if (ev.id !== eventId) return ev;
        return {
          ...ev,
          phases: ev.phases.map((ph) => {
            if (ph.id !== phaseId) return ph;
            return {
              ...ph,
              items: ph.items.map((it) => {
                if (it.id !== itemId) return it;
                return { ...it, completed: !it.completed };
              }),
            };
          }),
        };
      }),
    }));
  }, []);

  const handleCreateCustomEvent = useCallback((newEvent: LifeEvent) => {
    setAppData((prev) => ({
      ...prev,
      events: [...prev.events, newEvent],
    }));
    showToast('Custom life milestone created!');
  }, [showToast]);

  const handleDeleteEvent = useCallback((id: string) => {
    setAppData((prev) => ({
      ...prev,
      events: prev.events.filter((e) => e.id !== id),
    }));
    showToast('Milestone deleted');
  }, [showToast]);

  // Data Restore / Reset
  const handleRestoreData = useCallback((restored: AppData) => {
    setAppData(restored);
    showToast('Backup restored successfully!');
  }, [showToast]);

  const handleResetDemo = useCallback(() => {
    const fresh = resetToDemoData();
    setAppData(fresh);
    showToast('Reset to demo sample data');
  }, [showToast]);

  const handleClearAll = useCallback(() => {
    const empty = clearAllData();
    setAppData(empty);
    showToast('All data cleared');
  }, [showToast]);

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-xl shadow-xl border border-neutral-700 dark:border-neutral-200 animate-in fade-in slide-in-from-bottom-2 text-xs sm:text-sm font-medium">
          <Check className="w-4 h-4 text-emerald-400 dark:text-emerald-600 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQuickAdd={() => {
          setEditingTask(null);
          setIsQuickAddOpen(true);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isDark={isDark}
        onToggleTheme={() => setIsDark(!isDark)}
        overdueCount={overdueCount}
        expiringSoonCount={expiringSoonCount}
      />

      {/* Main Content Viewport */}
      <main className="flex-1">
        {activeTab === 'dashboard' && (
          <DashboardView
            tasks={appData.tasks}
            onToggleComplete={handleToggleCompleteTask}
            onEditTask={(task) => {
              setEditingTask(task);
              setIsQuickAddOpen(true);
            }}
            onDeleteTask={handleDeleteTask}
            onOpenQuickAdd={() => {
              setEditingTask(null);
              setIsQuickAddOpen(true);
            }}
            onNavigateToChecklists={() => setActiveTab('checklists')}
            onNavigateToExpiries={() => setActiveTab('expiries')}
            expiringSoonCount={expiringSoonCount}
          />
        )}

        {activeTab === 'checklists' && (
          <ChecklistTemplatesView
            existingTasks={appData.tasks}
            onAddTasks={handleAddMultipleTasks}
            onNavigateToDashboard={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'expiries' && (
          <ExpiryTrackerView
            expiries={appData.expiries}
            onOpenAddExpiry={() => {
              setEditingExpiry(null);
              setIsAddExpiryOpen(true);
            }}
            onEditExpiry={(item) => {
              setEditingExpiry(item);
              setIsAddExpiryOpen(true);
            }}
            onDeleteExpiry={handleDeleteExpiry}
            onRenewExpiry={(item) => setRenewingExpiry(item)}
          />
        )}

        {activeTab === 'lifeEvents' && (
          <LifeEventsView
            events={appData.events}
            onTogglePhaseItem={handleTogglePhaseItem}
            onImportPhaseToTasks={handleAddMultipleTasks}
            onCreateCustomEvent={handleCreateCustomEvent}
            onDeleteEvent={handleDeleteEvent}
            onNavigateToDashboard={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'progress' && (
          <ProgressView
            tasks={appData.tasks}
            expiries={appData.expiries}
          />
        )}
      </main>

      {/* Modals */}
      <QuickAddModal
        isOpen={isQuickAddOpen}
        onClose={() => {
          setIsQuickAddOpen(false);
          setEditingTask(null);
        }}
        onSave={handleSaveTask}
        initialTask={editingTask}
      />

      <AddExpiryModal
        isOpen={isAddExpiryOpen}
        onClose={() => {
          setIsAddExpiryOpen(false);
          setEditingExpiry(null);
        }}
        onSave={handleSaveExpiry}
        initialItem={editingExpiry}
      />

      <RenewExpiryModal
        isOpen={!!renewingExpiry}
        onClose={() => setRenewingExpiry(null)}
        item={renewingExpiry}
        onConfirmRenew={handleConfirmRenewExpiry}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        isDark={isDark}
        onToggleTheme={() => setIsDark(!isDark)}
        appData={appData}
        onRestoreData={handleRestoreData}
        onResetDemo={handleResetDemo}
        onClearAll={handleClearAll}
      />

      {/* Clean, Quiet Footer */}
      <footer className="mt-auto border-t border-neutral-200 dark:border-neutral-800 py-6 text-center text-xs text-neutral-500 dark:text-neutral-400 bg-white dark:bg-neutral-900 transition-colors">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-800 dark:text-neutral-200">Life Admin Buddy</span>
            <span aria-hidden="true">·</span>
            <span>Local-first & private</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Zero server tracking</span>
            </span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="hover:underline text-neutral-600 dark:text-neutral-300"
            >
              Backup & Data
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <TranslationProvider>
      <LifeAdminApp />
    </TranslationProvider>
  );
}
