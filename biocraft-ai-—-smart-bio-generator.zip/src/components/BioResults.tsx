import React, { useState } from 'react';
import {
  Copy,
  Check,
  RefreshCw,
  Eye,
  Edit3,
  Sparkles,
  AlertTriangle,
  Instagram,
  MessageSquare,
  Linkedin,
  Github,
  Twitter,
} from 'lucide-react';
import { GeneratedBio, PlatformId, BioStyleId } from '../types/bio';
import { PLATFORMS } from '../data/platforms';
import { BIO_STYLES } from '../data/styles';

interface BioResultsProps {
  bios: GeneratedBio[];
  onCopy: (text: string) => void;
  onRegenerateAll: () => void;
  onRegenerateSingle: (bioId: string, index: number) => void;
  onSelectForPreview: (bio: GeneratedBio) => void;
  selectedPreviewId?: string;
  onUpdateBioText: (bioId: string, newText: string) => void;
  onTriggerPresetSample: () => void;
}

export const BioResults: React.FC<BioResultsProps> = ({
  bios,
  onCopy,
  onRegenerateAll,
  onRegenerateSingle,
  onSelectForPreview,
  selectedPreviewId,
  onUpdateBioText,
  onTriggerPresetSample,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleCopyClick = (bio: GeneratedBio) => {
    onCopy(bio.text);
    setCopiedId(bio.id);
    setTimeout(() => {
      setCopiedId((prev) => (prev === bio.id ? null : prev));
    }, 2000);
  };

  const getPlatformIcon = (id: PlatformId) => {
    switch (id) {
      case 'instagram':
        return <Instagram className="w-3.5 h-3.5" />;
      case 'whatsapp':
        return <MessageSquare className="w-3.5 h-3.5" />;
      case 'linkedin':
        return <Linkedin className="w-3.5 h-3.5" />;
      case 'github':
        return <Github className="w-3.5 h-3.5" />;
      case 'twitter':
        return <Twitter className="w-3.5 h-3.5" />;
    }
  };

  // Empty state when user hasn't generated yet
  if (!bios || bios.length === 0) {
    return (
      <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-sm p-8 text-center flex flex-col items-center justify-center min-h-[380px]">
        <div className="w-14 h-14 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-4">
          <Sparkles className="w-7 h-7" />
        </div>
        <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
          Ready to Craft Your Bio
        </h3>
        <p className="text-sm text-neutral-500 dark:text-neutral-400 max-w-md mt-1.5 mb-6 [text-wrap:balance]">
          Choose a platform and tone on the left, then click Generate to create 3 tailored options.
          Or test an example right now.
        </p>
        <button
          onClick={onTriggerPresetSample}
          className="px-5 py-2.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 rounded-xl transition-colors border border-indigo-200/60 dark:border-indigo-800/60 flex items-center gap-2"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Load Example Preset</span>
        </button>
      </div>
    );
  }

  const platformInfo = PLATFORMS[bios[0].platform];

  return (
    <div className="space-y-4">
      {/* Results Header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider">
            Generated Bios
          </span>
          <span className="text-xs text-neutral-400">({bios.length} variations)</span>
        </div>
        <button
          onClick={onRegenerateAll}
          className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition-colors flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Regenerate All</span>
        </button>
      </div>

      {/* Bio Cards */}
      <div className="grid grid-cols-1 gap-4">
        {bios.map((bio, index) => {
          const isCopied = copiedId === bio.id;
          const isEditing = editingId === bio.id;
          const isSelectedForPreview = selectedPreviewId === bio.id;
          const charPercent = Math.min(100, Math.round((bio.charCount / bio.maxLimit) * 100));
          const isOverLimit = bio.charCount > bio.maxLimit;
          const styleConfig = BIO_STYLES[bio.style];

          return (
            <div
              key={bio.id}
              className={`group relative rounded-2xl bg-white dark:bg-neutral-900 border transition-all p-5 shadow-sm ${
                isSelectedForPreview
                  ? 'border-indigo-600 dark:border-indigo-500 ring-2 ring-indigo-500/20'
                  : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700'
              }`}
            >
              {/* Card Meta Row */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-neutral-100 dark:border-neutral-800/80">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 flex items-center gap-1.5">
                    {getPlatformIcon(bio.platform)}
                    <span>Option {index + 1}</span>
                  </span>
                  <span className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">
                    {styleConfig?.name || bio.style} style
                  </span>
                </div>

                {/* Character Counter with Progress bar */}
                <div className="flex items-center gap-2">
                  <div className="text-[11px] font-mono tabular-nums">
                    <span
                      className={`font-semibold ${
                        isOverLimit
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-neutral-700 dark:text-neutral-300'
                      }`}
                    >
                      {bio.charCount}
                    </span>
                    <span className="text-neutral-400">/{bio.maxLimit}</span>
                  </div>
                  {isOverLimit && (
                    <span
                      title="Bio exceeds platform recommended limit"
                      className="text-rose-500 flex items-center"
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>
              </div>

              {/* Bio Content Area (Editable or Static View) */}
              <div className="my-2">
                {isEditing ? (
                  <div className="space-y-2">
                    <textarea
                      value={bio.text}
                      onChange={(e) => onUpdateBioText(bio.id, e.target.value)}
                      rows={3}
                      className="w-full p-3 text-sm rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-indigo-400 dark:border-indigo-600 text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                    />
                    <div className="flex justify-end">
                      <button
                        onClick={() => setEditingId(null)}
                        className="px-3 py-1 text-xs font-medium bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-lg hover:opacity-90 transition-opacity"
                      >
                        Done Editing
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    onClick={() => setEditingId(bio.id)}
                    title="Click to edit bio text"
                    className="p-3.5 rounded-xl bg-neutral-50/70 dark:bg-neutral-800/40 border border-neutral-100 dark:border-neutral-800 text-sm sm:text-base text-neutral-800 dark:text-neutral-200 whitespace-pre-line leading-relaxed cursor-text hover:bg-neutral-100/60 dark:hover:bg-neutral-800/60 transition-colors"
                  >
                    {bio.text}
                  </div>
                )}
              </div>

              {/* Action Buttons Row */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-3 mt-3 border-t border-neutral-100 dark:border-neutral-800/80">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setEditingId(isEditing ? null : bio.id)}
                    className="px-2.5 py-1.5 text-xs text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{isEditing ? 'Close' : 'Edit'}</span>
                  </button>

                  <button
                    onClick={() => onRegenerateSingle(bio.id, index)}
                    title="Regenerate this specific variation"
                    className="px-2.5 py-1.5 text-xs text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Shuffle</span>
                  </button>

                  <button
                    onClick={() => onSelectForPreview(bio)}
                    className={`px-2.5 py-1.5 text-xs rounded-lg transition-colors flex items-center gap-1 ${
                      isSelectedForPreview
                        ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold'
                        : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{isSelectedForPreview ? 'Viewing on Profile' : 'Preview'}</span>
                  </button>
                </div>

                <button
                  onClick={() => handleCopyClick(bio)}
                  className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 active:scale-95 ${
                    isCopied
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm'
                  }`}
                >
                  {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? 'Copied!' : 'Copy Bio'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
