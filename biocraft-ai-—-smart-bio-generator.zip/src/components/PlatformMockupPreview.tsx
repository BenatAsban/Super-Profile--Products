import React, { useState } from 'react';
import {
  Instagram,
  MessageSquare,
  Linkedin,
  Github,
  Twitter,
  Link as LinkIcon,
  MapPin,
  Calendar,
  Users,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import { GeneratedBio, PlatformId, BioFormData } from '../types/bio';
import { PLATFORMS } from '../data/platforms';

interface PlatformMockupPreviewProps {
  currentBio: GeneratedBio | null;
  formData: BioFormData;
  onSelectPlatform: (platform: PlatformId) => void;
}

export const PlatformMockupPreview: React.FC<PlatformMockupPreviewProps> = ({
  currentBio,
  formData,
  onSelectPlatform,
}) => {
  const [activeTab, setActiveTab] = useState<PlatformId>(
    currentBio ? currentBio.platform : formData.platform
  );

  // Sync tab with generated bio platform when new bio arrives
  React.useEffect(() => {
    if (currentBio) {
      setActiveTab(currentBio.platform);
    }
  }, [currentBio]);

  const displayName = formData.name.trim() || 'Alex Vance';
  const handle = formData.name.trim().toLowerCase().replace(/\s+/g, '') || 'alexvance';
  const bioText = currentBio
    ? currentBio.text
    : formData.profession
    ? `${formData.profession} · Passionate about ${formData.interests || 'crafting ideas'}`
    : 'Select or generate a bio to see a realistic live preview of how it appears on your profile.';

  return (
    <div
      id="preview"
      className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-sm p-6 sm:p-8"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-100 dark:border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-50">
              Live Profile Preview
            </h3>
            <span className="text-xs font-mono text-neutral-400">
              ({PLATFORMS[activeTab].name})
            </span>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            See exactly how your bio looks inside the native profile interface.
          </p>
        </div>

        {/* Platform Switcher Buttons */}
        <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl overflow-x-auto">
          {(['instagram', 'whatsapp', 'linkedin', 'github', 'twitter'] as PlatformId[]).map(
            (platId) => {
              const isSelected = activeTab === platId;
              return (
                <button
                  key={platId}
                  onClick={() => {
                    setActiveTab(platId);
                    onSelectPlatform(platId);
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-50 shadow-sm font-semibold'
                      : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                  }`}
                >
                  {platId === 'instagram' && <Instagram className="w-3.5 h-3.5" />}
                  {platId === 'whatsapp' && <MessageSquare className="w-3.5 h-3.5" />}
                  {platId === 'linkedin' && <Linkedin className="w-3.5 h-3.5" />}
                  {platId === 'github' && <Github className="w-3.5 h-3.5" />}
                  {platId === 'twitter' && <Twitter className="w-3.5 h-3.5" />}
                  <span className="capitalize">{platId}</span>
                </button>
              );
            }
          )}
        </div>
      </div>

      {/* Realistic Platform Mockups */}
      <div className="mt-6 flex justify-center">
        {/* INSTAGRAM MOCKUP */}
        {activeTab === 'instagram' && (
          <div className="w-full max-w-md rounded-3xl bg-neutral-950 text-white p-5 sm:p-6 shadow-xl border border-neutral-800 font-sans">
            {/* Top Bar */}
            <div className="flex items-center justify-between pb-4 border-b border-neutral-800/80 text-xs font-semibold tracking-wide">
              <span>{handle}</span>
              <span className="text-neutral-400">···</span>
            </div>

            {/* Profile Info */}
            <div className="flex items-center gap-6 py-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 via-rose-500 to-purple-600 p-0.5 shrink-0">
                <div className="w-full h-full rounded-full bg-neutral-900 flex items-center justify-center font-bold text-lg text-white">
                  {displayName.charAt(0)}
                </div>
              </div>

              <div className="flex items-center justify-around flex-1 text-center">
                <div>
                  <div className="text-sm font-bold">142</div>
                  <div className="text-[11px] text-neutral-400">Posts</div>
                </div>
                <div>
                  <div className="text-sm font-bold">4.8k</div>
                  <div className="text-[11px] text-neutral-400">Followers</div>
                </div>
                <div>
                  <div className="text-sm font-bold">389</div>
                  <div className="text-[11px] text-neutral-400">Following</div>
                </div>
              </div>
            </div>

            {/* Bio Body */}
            <div className="space-y-1 text-xs">
              <div className="font-bold text-neutral-100">{displayName}</div>
              <div className="text-neutral-400 text-[11px]">
                {formData.profession || 'Creator & Innovator'}
              </div>
              <div className="text-neutral-200 whitespace-pre-line leading-relaxed pt-1">
                {bioText}
              </div>
              <div className="pt-1.5 flex items-center gap-1 text-sky-400 text-[11px] font-medium">
                <LinkIcon className="w-3 h-3" />
                <span className="truncate">biocraft.ai/{handle}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-2 mt-4">
              <div className="py-1.5 text-center text-xs font-semibold bg-neutral-800 rounded-lg text-neutral-200">
                Edit profile
              </div>
              <div className="py-1.5 text-center text-xs font-semibold bg-neutral-800 rounded-lg text-neutral-200">
                Share profile
              </div>
            </div>
          </div>
        )}

        {/* WHATSAPP MOCKUP */}
        {activeTab === 'whatsapp' && (
          <div className="w-full max-w-md rounded-3xl bg-[#0B141A] text-white p-5 sm:p-6 shadow-xl border border-neutral-800 font-sans">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 text-xs text-neutral-400">
              <span>Contact info</span>
              <span>Edit</span>
            </div>

            <div className="flex flex-col items-center py-4 text-center">
              <div className="w-20 h-20 rounded-full bg-emerald-600/30 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center font-bold text-2xl mb-3">
                {displayName.charAt(0)}
              </div>
              <div className="text-base font-bold text-neutral-100">{displayName}</div>
              <div className="text-xs text-neutral-400 mt-0.5">+1 (555) 019-2834</div>
            </div>

            {/* About Box */}
            <div className="mt-4 p-4 rounded-2xl bg-[#111B21] border border-neutral-800">
              <div className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider mb-1">
                About
              </div>
              <div className="text-sm text-neutral-100 whitespace-pre-line leading-relaxed font-sans">
                {bioText}
              </div>
              <div className="text-[10px] text-neutral-500 mt-2">Updated recently</div>
            </div>

            {/* Media/Status row */}
            <div className="mt-3 p-3 rounded-xl bg-[#111B21] flex items-center justify-between text-xs text-neutral-400">
              <span>Media, links, and docs</span>
              <span>18 ›</span>
            </div>
          </div>
        )}

        {/* LINKEDIN MOCKUP */}
        {activeTab === 'linkedin' && (
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 overflow-hidden shadow-xl">
            {/* Cover Banner */}
            <div className="h-20 bg-gradient-to-r from-blue-700 via-indigo-600 to-sky-700 relative" />

            <div className="px-5 pb-5">
              {/* Avatar */}
              <div className="-mt-10 mb-3 flex items-end justify-between">
                <div className="w-20 h-20 rounded-full border-4 border-white dark:border-neutral-900 bg-neutral-800 text-white flex items-center justify-center font-bold text-2xl shadow-sm">
                  {displayName.charAt(0)}
                </div>
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="px-3 py-1 rounded-full bg-blue-600 text-white font-semibold">
                    Open to work
                  </span>
                </div>
              </div>

              {/* Title & Bio Headline */}
              <div>
                <h4 className="text-base font-bold text-neutral-900 dark:text-neutral-50 flex items-center gap-1">
                  <span>{displayName}</span>
                  <CheckCircle className="w-3.5 h-3.5 text-blue-500" />
                </h4>
                <p className="text-xs font-normal text-neutral-700 dark:text-neutral-300 mt-1 leading-relaxed whitespace-pre-line">
                  {bioText}
                </p>
                <div className="flex items-center gap-3 mt-3 text-[11px] text-neutral-500 dark:text-neutral-400">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> San Francisco Bay Area
                  </span>
                  <span>·</span>
                  <span className="text-blue-600 dark:text-blue-400 font-semibold">
                    500+ connections
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 mt-4">
                <button className="flex-1 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-full">
                  Message
                </button>
                <button className="flex-1 py-1.5 text-xs font-semibold border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-full">
                  More
                </button>
              </div>
            </div>
          </div>
        )}

        {/* GITHUB MOCKUP */}
        {activeTab === 'github' && (
          <div className="w-full max-w-md rounded-2xl bg-[#0D1117] text-[#C9D1D9] border border-[#30363D] p-5 sm:p-6 shadow-xl font-sans">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-[#161B22] border border-[#30363D] flex items-center justify-center text-xl font-bold text-white">
                {displayName.charAt(0)}
              </div>
              <div>
                <div className="text-base font-bold text-white">{displayName}</div>
                <div className="text-xs text-[#8B949E]">{handle}</div>
              </div>
            </div>

            {/* Bio Markdown Box */}
            <div className="mt-4 pt-3 border-t border-[#21262D]">
              <div className="text-xs text-[#E6EDF3] whitespace-pre-line leading-relaxed font-sans">
                {bioText}
              </div>
            </div>

            <button className="w-full mt-4 py-1.5 text-xs font-semibold bg-[#21262D] hover:bg-[#30363D] text-[#C9D1D9] rounded-md border border-[#30363D] transition-colors">
              Follow
            </button>

            <div className="mt-4 space-y-1.5 text-xs text-[#8B949E]">
              <div className="flex items-center gap-2">
                <Users className="w-3.5 h-3.5" />
                <span>
                  <strong className="text-white">128</strong> followers ·{' '}
                  <strong className="text-white">64</strong> following
                </span>
              </div>
              <div className="flex items-center gap-2">
                <LinkIcon className="w-3.5 h-3.5" />
                <span className="text-[#58A6FF] truncate">https://github.com/{handle}</span>
              </div>
            </div>
          </div>
        )}

        {/* TWITTER / X MOCKUP */}
        {activeTab === 'twitter' && (
          <div className="w-full max-w-md rounded-2xl bg-black text-white border border-neutral-800 overflow-hidden shadow-xl font-sans">
            <div className="h-20 bg-neutral-900 border-b border-neutral-800" />
            <div className="px-5 pb-5">
              <div className="-mt-10 mb-2 flex items-end justify-between">
                <div className="w-20 h-20 rounded-full border-4 border-black bg-neutral-800 flex items-center justify-center font-bold text-2xl text-white">
                  {displayName.charAt(0)}
                </div>
                <button className="px-4 py-1.5 text-xs font-bold rounded-full bg-white text-black hover:bg-neutral-200 transition-colors">
                  Follow
                </button>
              </div>

              <div>
                <h4 className="text-base font-bold text-white flex items-center gap-1">
                  <span>{displayName}</span>
                  <CheckCircle className="w-3.5 h-3.5 text-sky-400" />
                </h4>
                <div className="text-xs text-neutral-500">@{handle}</div>

                <p className="text-xs sm:text-sm text-neutral-200 mt-2.5 whitespace-pre-line leading-relaxed">
                  {bioText}
                </p>

                <div className="flex flex-wrap items-center gap-3 mt-3 text-[11px] text-neutral-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> Joined March 2021
                  </span>
                  <span className="flex items-center gap-1 text-sky-400">
                    <LinkIcon className="w-3 h-3" /> x.com/{handle}
                  </span>
                </div>

                <div className="flex items-center gap-4 mt-3 text-xs">
                  <div>
                    <strong className="text-white font-bold">542</strong>{' '}
                    <span className="text-neutral-500">Following</span>
                  </div>
                  <div>
                    <strong className="text-white font-bold">3.9K</strong>{' '}
                    <span className="text-neutral-500">Followers</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
