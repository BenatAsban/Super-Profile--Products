import React from 'react';
import { ArrowRight, Sparkles, Instagram, MessageSquare, Linkedin, Github } from 'lucide-react';
import { PlatformId } from '../types/bio';

interface HeroProps {
  onGetStarted: () => void;
  onSelectPlatform: (platform: PlatformId) => void;
}

export const Hero: React.FC<HeroProps> = ({ onGetStarted, onSelectPlatform }) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24 border-b border-neutral-200/70 dark:border-neutral-800/70">
      {/* Background subtle radial gradient */}
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none -z-10 flex items-center justify-center opacity-60 dark:opacity-30"
      >
        <div className="w-[600px] h-[360px] bg-gradient-to-tr from-indigo-500/20 via-purple-500/15 to-pink-500/20 blur-3xl rounded-full" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          {/* Unboxed natural kicker */}
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 mb-4 tracking-wide">
            <span>Instant Social Identity</span>
            <span aria-hidden="true">·</span>
            <span>100% Local & Free</span>
            <span aria-hidden="true">·</span>
            <span>Zero Sign-Up</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-neutral-900 dark:text-white mb-6 [text-wrap:balance]">
            Your Personality.{' '}
            <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Your Bio.
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-neutral-600 dark:text-neutral-300 mb-8 max-w-2xl mx-auto leading-relaxed [text-wrap:balance]">
            Create a bio that feels uniquely you. Turn your niche, skills, and energy into
            compelling bios for Instagram, WhatsApp, LinkedIn, GitHub, and Twitter in seconds.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={onGetStarted}
              className="w-full sm:w-auto px-7 py-3.5 text-sm sm:text-base font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-95 rounded-xl shadow-md hover:shadow-indigo-500/20 transition-all flex items-center justify-center gap-2"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <a
              href="#platforms"
              className="w-full sm:w-auto px-6 py-3.5 text-sm sm:text-base font-semibold text-neutral-700 dark:text-neutral-200 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-xl transition-colors text-center"
            >
              Explore Platform Guidelines
            </a>
          </div>
        </div>

        {/* Platform Cards Grid */}
        <div className="mt-14 sm:mt-18 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* Instagram Card */}
          <div
            onClick={() => {
              onSelectPlatform('instagram');
              onGetStarted();
            }}
            className="cursor-pointer group p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-pink-300 dark:hover:border-pink-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-pink-500/10 text-pink-600 dark:text-pink-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Instagram className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono tabular-nums text-neutral-400 dark:text-neutral-500">
                  150 chars
                </span>
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-pink-600 dark:group-hover:text-pink-400 transition-colors">
                Instagram
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 mb-4">
                Punchy, clean linebreaks, personality-forward, and aesthetic.
              </p>
              <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 text-xs text-neutral-600 dark:text-neutral-300 font-mono leading-relaxed border border-neutral-100 dark:border-neutral-800">
                ✨ Senior Designer<br />
                ☕ Crafting sleek systems<br />
                👇 Portfolio & case studies
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
              <span>Create Instagram bio</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* WhatsApp Card */}
          <div
            onClick={() => {
              onSelectPlatform('whatsapp');
              onGetStarted();
            }}
            className="cursor-pointer group p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-emerald-300 dark:hover:border-emerald-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono tabular-nums text-neutral-400 dark:text-neutral-500">
                  139 chars
                </span>
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                WhatsApp
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 mb-4">
                Concise status thoughts, availability notices, and mindset quotes.
              </p>
              <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 text-xs text-neutral-600 dark:text-neutral-300 font-mono leading-relaxed border border-neutral-100 dark:border-neutral-800">
                Living simply. Creating digital tools. Focused on craft.
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
              <span>Create WhatsApp status</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* LinkedIn Card */}
          <div
            onClick={() => {
              onSelectPlatform('linkedin');
              onGetStarted();
            }}
            className="cursor-pointer group p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-blue-300 dark:hover:border-blue-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Linkedin className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono tabular-nums text-neutral-400 dark:text-neutral-500">
                  220 chars
                </span>
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                LinkedIn
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 mb-4">
                Professional headlines conveying value proposition, impact & domain.
              </p>
              <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 text-xs text-neutral-600 dark:text-neutral-300 font-mono leading-relaxed border border-neutral-100 dark:border-neutral-800">
                Staff Engineer | Helping fintech teams ship resilient architectures.
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
              <span>Create LinkedIn headline</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* GitHub Card */}
          <div
            onClick={() => {
              onSelectPlatform('github');
              onGetStarted();
            }}
            className="cursor-pointer group p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-purple-300 dark:hover:border-purple-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Github className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono tabular-nums text-neutral-400 dark:text-neutral-500">
                  200 chars
                </span>
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                GitHub
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 mb-4">
                Technical stacks, open-source spirit, and current build projects.
              </p>
              <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 text-xs text-neutral-600 dark:text-neutral-300 font-mono leading-relaxed border border-neutral-100 dark:border-neutral-800">
                Full-stack dev hacking with TS & Rust · Building open tooling.
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
              <span>Create GitHub bio</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
