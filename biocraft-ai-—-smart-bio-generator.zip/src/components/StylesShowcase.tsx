import React from 'react';
import { Sparkles, Briefcase, Smile, Zap, Compass, Heart, Feather } from 'lucide-react';
import { BioStyleId } from '../types/bio';
import { STYLE_LIST } from '../data/styles';

interface StylesShowcaseProps {
  onSelectStyle: (style: BioStyleId) => void;
}

export const StylesShowcase: React.FC<StylesShowcaseProps> = ({ onSelectStyle }) => {
  const getStyleIcon = (id: BioStyleId) => {
    switch (id) {
      case 'professional':
        return <Briefcase className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
      case 'cool':
        return <Zap className="w-5 h-5 text-amber-500 dark:text-amber-400" />;
      case 'minimal':
        return <Feather className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'funny':
        return <Smile className="w-5 h-5 text-rose-500 dark:text-rose-400" />;
      case 'motivational':
        return <Heart className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />;
      case 'creative':
        return <Compass className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
    }
  };

  return (
    <section id="styles" className="py-16 md:py-20 border-b border-neutral-200/80 dark:border-neutral-800/80 bg-neutral-100/40 dark:bg-neutral-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 mb-2 tracking-wide uppercase">
            <span>Tone Archetypes</span>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50 sm:text-4xl">
            Choose Your Voice
          </h2>
          <p className="mt-3 text-base text-neutral-600 dark:text-neutral-400">
            Tone shapes perception. Select the archetype that aligns with your personality and the
            impression you want to leave.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {STYLE_LIST.map((style) => {
            return (
              <div
                key={style.id}
                onClick={() => onSelectStyle(style.id)}
                className="cursor-pointer group p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-indigo-400 dark:hover:border-indigo-600 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    {getStyleIcon(style.id)}
                  </div>
                  <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                    {style.name}
                  </h3>
                  <div className="text-xs font-medium text-neutral-400 mt-0.5 mb-2.5">
                    {style.vibe}
                  </div>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                    {style.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                  <span>Use {style.name} style</span>
                  <span className="group-hover:translate-x-1 transition-transform">→</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
