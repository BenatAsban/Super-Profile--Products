import React from 'react';
import { ModalType } from './Modals';

interface FooterProps {
  onOpenModal: (type: ModalType) => void;
  onNavigateToGenerator: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenModal, onNavigateToGenerator }) => {
  return (
    <footer className="w-full border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand info */}
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 text-base font-bold text-neutral-900 dark:text-neutral-50">
              <span className="w-6 h-6 rounded-md bg-indigo-600 text-white flex items-center justify-center text-xs font-black">
                B
              </span>
              <span>BioCraft AI</span>
            </div>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 max-w-sm">
              Smart, personality-driven bio generator for Instagram, WhatsApp, LinkedIn, GitHub, and Twitter.
            </p>
          </div>

          {/* Navigation & Action Links */}
          <nav className="flex flex-wrap items-center justify-center gap-6 text-xs font-medium text-neutral-600 dark:text-neutral-400">
            <button
              onClick={onNavigateToGenerator}
              className="hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
            >
              Generator
            </button>
            <a
              href="#platforms"
              className="hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
            >
              Platforms
            </a>
            <a
              href="#styles"
              className="hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
            >
              Styles
            </a>
            <button
              onClick={() => onOpenModal('about')}
              className="hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
            >
              About
            </button>
            <button
              onClick={() => onOpenModal('privacy')}
              className="hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => onOpenModal('contact')}
              className="hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors"
            >
              Contact
            </button>
          </nav>
        </div>

        {/* Bottom copyright notice */}
        <div className="mt-8 pt-8 border-t border-neutral-100 dark:border-neutral-900 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 gap-4">
          <p>© 2026 BioCraft AI — Smart Bio Generator. All rights reserved.</p>
          <div className="flex items-center gap-2">
            <span>Client-side application</span>
            <span aria-hidden="true">·</span>
            <span>Zero cookies stored</span>
            <span aria-hidden="true">·</span>
            <span>Netlify ready</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
