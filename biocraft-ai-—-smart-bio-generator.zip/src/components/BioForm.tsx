import React, { useState } from 'react';
import {
  Sparkles,
  RotateCcw,
  Instagram,
  MessageSquare,
  Linkedin,
  Github,
  Twitter,
  Check,
  Zap,
  HelpCircle,
} from 'lucide-react';
import { BioFormData, PlatformId, BioStyleId } from '../types/bio';
import { PLATFORM_LIST } from '../data/platforms';
import { STYLE_LIST } from '../data/styles';
import { SAMPLE_PRESETS } from '../data/presets';

interface BioFormProps {
  formData: BioFormData;
  onChange: (updated: Partial<BioFormData>) => void;
  onGenerate: () => void;
  onClear: () => void;
  onLoadPreset: (presetIndex: number) => void;
  isGenerating?: boolean;
}

export const BioForm: React.FC<BioFormProps> = ({
  formData,
  onChange,
  onGenerate,
  onClear,
  onLoadPreset,
  isGenerating = false,
}) => {
  const [validationError, setValidationError] = useState<string | null>(null);

  const getPlatformIcon = (id: PlatformId) => {
    switch (id) {
      case 'instagram':
        return <Instagram className="w-4 h-4" />;
      case 'whatsapp':
        return <MessageSquare className="w-4 h-4" />;
      case 'linkedin':
        return <Linkedin className="w-4 h-4" />;
      case 'github':
        return <Github className="w-4 h-4" />;
      case 'twitter':
        return <Twitter className="w-4 h-4" />;
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.profession.trim()) {
      setValidationError('Please specify your profession or main focus to craft tailored bios.');
      return;
    }
    setValidationError(null);
    onGenerate();
  };

  const quickRoles = [
    'Software Engineer',
    'Product Designer',
    'Creator & YouTuber',
    'Founder & Indie Hacker',
    'Digital Marketer',
    'Photographer',
  ];

  const quickKeywords = [
    'React',
    'Design systems',
    'Specialty coffee',
    'Open source',
    'Minimalism',
    'AI & Automation',
    'Travel',
    'Fitness',
  ];

  const quickPersonalities = [
    'Witty & Playful',
    'Ambitious & Direct',
    'Calm & Thoughtful',
    'Creative & Aesthetic',
    'Nerdy & Enthusiastic',
  ];

  const addInterestKeyword = (keyword: string) => {
    const existing = formData.interests.trim();
    if (!existing) {
      onChange({ interests: keyword });
    } else if (!existing.toLowerCase().includes(keyword.toLowerCase())) {
      onChange({ interests: `${existing}, ${keyword}` });
    }
  };

  return (
    <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-sm p-6 sm:p-8">
      {/* Header and Quick Presets */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-100 dark:border-neutral-800">
        <div>
          <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-50 flex items-center gap-2">
            <span>Bio Generator</span>
            <span className="text-xs font-normal px-2.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60">
              Offline Algorithm
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
            Fill in your details or test a preset to generate 3 tailored bio variations.
          </p>
        </div>

        {/* Presets dropdown */}
        <div className="flex items-center gap-2">
          <label htmlFor="preset-select" className="text-xs text-neutral-500 whitespace-nowrap">
            Try Preset:
          </label>
          <select
            id="preset-select"
            defaultValue=""
            onChange={(e) => {
              if (e.target.value !== '') {
                onLoadPreset(Number(e.target.value));
                setValidationError(null);
                e.target.value = '';
              }
            }}
            className="text-xs font-medium py-1.5 px-3 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 border border-neutral-200 dark:border-neutral-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="" disabled>
              Select an example...
            </option>
            {SAMPLE_PRESETS.map((preset, idx) => (
              <option key={idx} value={idx}>
                {preset.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      <form onSubmit={handleFormSubmit} className="mt-6 space-y-6">
        {/* 1. Platform Selection */}
        <div>
          <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-2">
            Target Platform
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {PLATFORM_LIST.map((platform) => {
              const isSelected = formData.platform === platform.id;
              return (
                <button
                  key={platform.id}
                  type="button"
                  onClick={() => onChange({ platform: platform.id })}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-900 dark:text-indigo-200 shadow-sm'
                      : 'border-neutral-200 dark:border-neutral-800 bg-neutral-50/40 dark:bg-neutral-800/30 hover:border-neutral-300 dark:hover:border-neutral-700 text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span
                      className={
                        isSelected ? 'text-indigo-600 dark:text-indigo-400' : 'text-neutral-500'
                      }
                    >
                      {getPlatformIcon(platform.id)}
                    </span>
                    <span className="text-[10px] font-mono tabular-nums text-neutral-400">
                      {platform.charLimit}c
                    </span>
                  </div>
                  <div>
                    <div className="text-xs font-semibold">{platform.name}</div>
                    <div className="text-[10px] text-neutral-500 truncate">{platform.tagline}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Style Selection */}
        <div>
          <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider mb-2">
            Tone & Style
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {STYLE_LIST.map((style) => {
              const isSelected = formData.style === style.id;
              return (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => onChange({ style: style.id })}
                  className={`px-3 py-2.5 rounded-xl border text-center transition-all ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-600 text-white font-medium shadow-sm'
                      : 'border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-800/40 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  <div className="text-xs font-semibold">{style.label}</div>
                  <div
                    className={`text-[10px] truncate mt-0.5 ${
                      isSelected ? 'text-indigo-100' : 'text-neutral-400'
                    }`}
                  >
                    {style.vibe}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Core Input Fields Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
          {/* Name / Handle */}
          <div>
            <label
              htmlFor="field-name"
              className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1.5"
            >
              Name or Handle <span className="text-neutral-400">(optional)</span>
            </label>
            <input
              id="field-name"
              type="text"
              value={formData.name}
              onChange={(e) => onChange({ name: e.target.value })}
              placeholder="e.g. Alex Chen or @alexchen"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
          </div>

          {/* Profession */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="field-profession"
                className="block text-xs font-medium text-neutral-700 dark:text-neutral-300"
              >
                Profession / Primary Focus <span className="text-indigo-500">*</span>
              </label>
              <span className="text-[11px] text-neutral-400">Required</span>
            </div>
            <input
              id="field-profession"
              type="text"
              value={formData.profession}
              onChange={(e) => {
                onChange({ profession: e.target.value });
                if (validationError) setValidationError(null);
              }}
              placeholder="e.g. Senior Frontend Engineer, Indie Maker"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
            {/* Quick role suggestions */}
            <div className="flex flex-wrap gap-1 mt-2">
              {quickRoles.map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => onChange({ profession: role })}
                  className="text-[10px] px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 transition-colors"
                >
                  +{role}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Interests & Keywords */}
        <div>
          <label
            htmlFor="field-interests"
            className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1.5"
          >
            Interests, Skills & Keywords{' '}
            <span className="text-neutral-400">(comma-separated)</span>
          </label>
          <input
            id="field-interests"
            type="text"
            value={formData.interests}
            onChange={(e) => onChange({ interests: e.target.value })}
            placeholder="e.g. React, UX Architecture, Specialty Coffee, Open Source"
            className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
          />
          {/* Quick keyword chips */}
          <div className="flex flex-wrap items-center gap-1.5 mt-2">
            <span className="text-[11px] text-neutral-400">Quick add:</span>
            {quickKeywords.map((kw) => (
              <button
                key={kw}
                type="button"
                onClick={() => addInterestKeyword(kw)}
                className="text-[10px] px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
              >
                +{kw}
              </button>
            ))}
          </div>
        </div>

        {/* Personality / Vibe */}
        <div>
          <label
            htmlFor="field-personality"
            className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1.5"
          >
            Personality Vibe & Mood <span className="text-neutral-400">(optional)</span>
          </label>
          <input
            id="field-personality"
            type="text"
            value={formData.personality}
            onChange={(e) => onChange({ personality: e.target.value })}
            placeholder="e.g. witty and curious, ambitious, minimalist, deeply nerdy"
            className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
          />
          <div className="flex flex-wrap items-center gap-1.5 mt-2">
            <span className="text-[11px] text-neutral-400">Suggested:</span>
            {quickPersonalities.map((pers) => (
              <button
                key={pers}
                type="button"
                onClick={() => onChange({ personality: pers.toLowerCase() })}
                className="text-[10px] px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
              >
                {pers}
              </button>
            ))}
          </div>
        </div>

        {/* 4. Toggles */}
        <div className="flex flex-wrap items-center gap-6 pt-2 pb-1 border-t border-neutral-100 dark:border-neutral-800">
          <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-neutral-700 dark:text-neutral-300">
            <input
              type="checkbox"
              checked={formData.includeEmojis}
              onChange={(e) => onChange({ includeEmojis: e.target.checked })}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-neutral-300 dark:border-neutral-700 dark:bg-neutral-800"
            />
            <span>Include context emojis</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-neutral-700 dark:text-neutral-300">
            <input
              type="checkbox"
              checked={formData.includeCallToAction}
              onChange={(e) => onChange({ includeCallToAction: e.target.checked })}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-neutral-300 dark:border-neutral-700 dark:bg-neutral-800"
            />
            <span>Include Call to Action (link / contact hook)</span>
          </label>
        </div>

        {/* Validation message */}
        {validationError && (
          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-xs text-amber-800 dark:text-amber-300 flex items-center gap-2">
            <HelpCircle className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400" />
            <span>{validationError}</span>
          </div>
        )}

        {/* 5. Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-neutral-100 dark:border-neutral-800">
          <button
            type="button"
            onClick={onClear}
            className="w-full sm:w-auto px-4 py-2.5 text-xs font-semibold text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-xl transition-colors flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear Form</span>
          </button>

          <button
            type="submit"
            disabled={isGenerating}
            className="w-full sm:w-auto px-8 py-3 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-95 disabled:opacity-50 rounded-xl shadow-md hover:shadow-indigo-500/25 transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate 3 Bios</span>
          </button>
        </div>
      </form>
    </div>
  );
};
