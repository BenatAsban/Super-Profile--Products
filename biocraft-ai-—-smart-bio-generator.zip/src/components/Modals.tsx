import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Info, Mail, CheckCircle2, Send } from 'lucide-react';

export type ModalType = 'about' | 'privacy' | 'contact' | null;

interface ModalsProps {
  activeModal: ModalType;
  onClose: () => void;
  onShowToast: (title: string, description?: string) => void;
}

export const Modals: React.FC<ModalsProps> = ({ activeModal, onClose, onShowToast }) => {
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (activeModal) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [activeModal, onClose]);

  // Contact form state
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSent, setContactSent] = useState(false);
  const [contactError, setContactError] = useState<string | null>(null);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactEmail.trim() || !contactMessage.trim()) {
      setContactError('Please complete all fields before sending.');
      return;
    }
    if (!contactEmail.includes('@') || !contactEmail.includes('.')) {
      setContactError('Please enter a valid email address.');
      return;
    }

    setContactError(null);
    setContactSent(true);
    onShowToast('Message Sent', 'Thank you! Your feedback has been received.');
    setTimeout(() => {
      setContactSent(false);
      setContactName('');
      setContactEmail('');
      setContactMessage('');
      onClose();
    }, 2200);
  };

  if (!activeModal) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            {activeModal === 'about' && (
              <>
                <Info className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                  About BioCraft AI
                </h3>
              </>
            )}
            {activeModal === 'privacy' && (
              <>
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                  Privacy Policy
                </h3>
              </>
            )}
            {activeModal === 'contact' && (
              <>
                <Mail className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                  Contact & Support
                </h3>
              </>
            )}
          </div>
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm text-neutral-600 dark:text-neutral-300">
          {activeModal === 'about' && (
            <>
              <p className="leading-relaxed">
                <strong>BioCraft AI — Smart Bio Generator</strong> was engineered to solve a common
                headache: creating attractive, concise, and platform-compliant bios for social
                media in seconds.
              </p>
              <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-100 dark:border-neutral-800 space-y-2 text-xs">
                <div className="font-semibold text-neutral-900 dark:text-neutral-100">
                  Core Principles:
                </div>
                <div>
                  • <strong>100% In-Browser Execution</strong>: Zero API keys, zero external network
                  calls, instant responsiveness.
                </div>
                <div>
                  • <strong>Platform-Strict Limits</strong>: Respects character limits for Instagram
                  (150), WhatsApp (139), LinkedIn (220), GitHub (200), and Twitter (160).
                </div>
                <div>
                  • <strong>No Artificial Gimmicks</strong>: We never fake API calls or invent
                  telemetry. The algorithmic engine executes right in your browser.
                </div>
              </div>
              <p className="text-xs text-neutral-500 leading-relaxed">
                Whether you are an aspiring open-source hacker, an Instagram content creator, or an
                executive building your LinkedIn presence, BioCraft AI gives you the words that
                resonate.
              </p>
            </>
          )}

          {activeModal === 'privacy' && (
            <>
              <p className="leading-relaxed">
                At BioCraft AI, we take a zero-knowledge, local-first privacy approach.
              </p>
              <div className="space-y-3 text-xs leading-relaxed">
                <div>
                  <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1">
                    1. Zero Data Collection
                  </h4>
                  <p>
                    We do not store, log, or transmit your name, handle, profession, or generated bios
                    to any external server. All text processing is executed entirely within your web
                    browser.
                  </p>
                </div>
                <div>
                  <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1">
                    2. No Cookies or Trackers
                  </h4>
                  <p>
                    BioCraft AI does not use third-party analytics cookies, advertising pixels, or
                    fingerprinting technologies. Your theme preference (dark/light) is stored solely
                    in your device&apos;s local storage.
                  </p>
                </div>
                <div>
                  <h4 className="font-bold text-neutral-900 dark:text-neutral-100 mb-1">
                    3. Clipboard Security
                  </h4>
                  <p>
                    When you click &quot;Copy Bio&quot;, text is written directly to your clipboard
                    via the browser&apos;s native Navigator Clipboard API. No external service reads
                    or handles your clipboard content.
                  </p>
                </div>
              </div>
            </>
          )}

          {activeModal === 'contact' && (
            <>
              {contactSent ? (
                <div className="py-8 text-center flex flex-col items-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                    Message Dispatched!
                  </h4>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                    Thank you for reaching out. We will get back to you shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-3.5">
                  <p className="text-xs text-neutral-500 dark:text-neutral-400">
                    Have feedback, feature ideas, or partnership requests? Send a message directly.
                  </p>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                      Your Name
                    </label>
                    <input
                      type="text"
                      required
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="e.g. Alex Morgan"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="e.g. alex@example.com"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
                      Message
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder="How can we assist you with BioCraft AI?"
                      className="w-full px-3 py-2 text-xs rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  {contactError && (
                    <div className="text-xs text-rose-500">{contactError}</div>
                  )}

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow transition-colors flex items-center justify-center gap-2"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send Message</span>
                    </button>
                  </div>
                </form>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
