import React from 'react';
import {
  Instagram,
  MessageSquare,
  Linkedin,
  Github,
  Twitter,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { PlatformId } from '../types/bio';
import { PLATFORM_LIST } from '../data/platforms';

interface PlatformShowcaseProps {
  onSelectPlatform: (platform: PlatformId) => void;
}

export const PlatformShowcase: React.FC<PlatformShowcaseProps> = ({ onSelectPlatform }) => {
  const getIcon = (id: PlatformId) => {
    switch (id) {
      case 'instagram':
        return <Instagram className="w-5 h-5 text-pink-600 dark:text-pink-400" />;
      case 'whatsapp':
        return <MessageSquare className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
      case 'linkedin':
        return <Linkedin className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
      case 'github':
        return <Github className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
      case 'twitter':
        return <Twitter className="w-5 h-5 text-neutral-800 dark:text-neutral-200" />;
    }
  };

  return (
    <section id="platforms" className="py-16 md:py-24 border-b border-neutral-200/80 dark:border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 mb-2 tracking-wide uppercase">
            <span>Platform Formats & Best Practices</span>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50 sm:text-4xl">
            Optimized for Every Platform
          </h2>
          <p className="mt-3 text-base text-neutral-600 dark:text-neutral-400">
            Each network has distinct character boundaries and audience expectations. BioCraft AI
            engine adheres precisely to each platform's rules.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PLATFORM_LIST.map((platform) => {
            return (
              <div
                key={platform.id}
                className="rounded-2xl p-6 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center">
                      {getIcon(platform.id)}
                    </div>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                      Limit: {platform.charLimit} chars
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-neutral-900 dark:text-neutral-100">
                    {platform.name}
                  </h3>
                  <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold mt-0.5 mb-3">
                    {platform.tagline}
                  </p>

                  <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed mb-4">
                    {platform.tips}
                  </p>

                  <div className="space-y-1.5 pt-3 border-t border-neutral-100 dark:border-neutral-800 text-xs text-neutral-500 dark:text-neutral-400">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Best style: {platform.recommendedStyle}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Auto-formatted syntax</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-neutral-100 dark:border-neutral-800">
                  <button
                    onClick={() => onSelectPlatform(platform.id)}
                    className="w-full py-2 px-3 text-xs font-semibold text-neutral-700 dark:text-neutral-300 bg-neutral-50 dark:bg-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-xl transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Create {platform.name} Bio</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
