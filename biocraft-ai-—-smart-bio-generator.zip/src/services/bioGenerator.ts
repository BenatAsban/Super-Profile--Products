import { BioFormData, GeneratedBio, PlatformId, BioStyleId } from '../types/bio';
import { PLATFORMS } from '../data/platforms';

// Helper to pick random item from array
function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Helper to clean and format list of interests
function parseInterests(raw: string): string[] {
  if (!raw || !raw.trim()) return [];
  return raw
    .split(/[,|•/]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

// Helper to format name
function formatName(name: string): string {
  const trimmed = name.trim();
  if (!trimmed) return '';
  return trimmed.startsWith('@') ? trimmed : trimmed;
}

export function generateBios(data: BioFormData, variantSeed: number = 0): GeneratedBio[] {
  const platformConfig = PLATFORMS[data.platform];
  const charLimit = platformConfig.charLimit;

  const name = formatName(data.name);
  const profession = data.profession.trim() || 'Creator & Innovator';
  const interests = parseInterests(data.interests);
  const personality = data.personality.trim().toLowerCase() || 'curious';

  const primaryInterest = interests[0] || 'crafting ideas';
  const secondaryInterest = interests[1] || 'modern design';
  const thirdInterest = interests[2] || 'continuous learning';

  const em = data.includeEmojis;
  const cta = data.includeCallToAction;

  // Platform and style specific generators
  const generators: Array<() => string> = [];

  switch (data.platform) {
    case 'instagram':
      generators.push(
        () => generateInstagramBio(1, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateInstagramBio(2, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateInstagramBio(3, data.style, name, profession, interests, personality, em, cta, variantSeed)
      );
      break;

    case 'whatsapp':
      generators.push(
        () => generateWhatsAppBio(1, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateWhatsAppBio(2, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateWhatsAppBio(3, data.style, name, profession, interests, personality, em, cta, variantSeed)
      );
      break;

    case 'linkedin':
      generators.push(
        () => generateLinkedInBio(1, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateLinkedInBio(2, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateLinkedInBio(3, data.style, name, profession, interests, personality, em, cta, variantSeed)
      );
      break;

    case 'github':
      generators.push(
        () => generateGitHubBio(1, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateGitHubBio(2, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateGitHubBio(3, data.style, name, profession, interests, personality, em, cta, variantSeed)
      );
      break;

    case 'twitter':
      generators.push(
        () => generateTwitterBio(1, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateTwitterBio(2, data.style, name, profession, interests, personality, em, cta, variantSeed),
        () => generateTwitterBio(3, data.style, name, profession, interests, personality, em, cta, variantSeed)
      );
      break;

    default:
      generators.push(
        () => `${profession} · Passionate about ${primaryInterest}`,
        () => `Exploring ${primaryInterest} & ${secondaryInterest} with a ${personality} lens.`,
        () => `${name ? `${name} | ` : ''}${profession}. Always building.`
      );
  }

  return generators.map((gen, idx) => {
    const text = gen().trim();
    const charCount = text.length;
    return {
      id: `bio-${data.platform}-${data.style}-${idx}-${variantSeed}`,
      text,
      style: data.style,
      platform: data.platform,
      charCount,
      maxLimit: charLimit,
      isWithinLimit: charCount <= charLimit,
    };
  });
}

// -------------------------------------------------------------
// INSTAGRAM GENERATOR (Multi-line, clean aesthetic, formatted)
// -------------------------------------------------------------
function generateInstagramBio(
  optionIndex: number,
  style: BioStyleId,
  name: string,
  profession: string,
  interests: string[],
  personality: string,
  em: boolean,
  cta: boolean,
  seed: number
): string {
  const i1 = interests[0] || 'creativity';
  const i2 = interests[1] || 'design';
  const i3 = interests[2] || 'growth';

  const callToActionText = cta ? (em ? '👇 Explore my work' : 'Explore portfolio below') : '';

  if (style === 'minimal') {
    if (optionIndex === 1) {
      return [
        name ? `${name}` : profession,
        `${i1} · ${i2}`,
        personality ? `Quietly ${personality}` : 'Less noise. More signal.',
        callToActionText,
      ].filter(Boolean).join('\n');
    }
    if (optionIndex === 2) {
      return [
        profession,
        `Exploring ${i1}`,
        'Intentional living',
        callToActionText,
      ].filter(Boolean).join('\n');
    }
    return [
      name ? `${name} — ${profession}` : profession,
      `Obsessed with ${i1} & ${i2}`,
      callToActionText,
    ].filter(Boolean).join('\n');
  }

  if (style === 'professional') {
    if (optionIndex === 1) {
      return [
        em ? `💼 ${profession}` : profession,
        em ? `🎯 Specializing in ${i1}` : `Focus: ${i1} & ${i2}`,
        `Helping brands build standout experiences`,
        cta ? (em ? '📩 DM or link below for collaborations' : 'Inquiries & links below') : '',
      ].filter(Boolean).join('\n');
    }
    if (optionIndex === 2) {
      return [
        name ? `${name} | ${profession}` : profession,
        `Delivering impact across ${i1} & ${i2}`,
        `${personality.charAt(0).toUpperCase() + personality.slice(1)} approach to modern challenges`,
        callToActionText,
      ].filter(Boolean).join('\n');
    }
    return [
      em ? `🚀 ${profession}` : profession,
      `Scalable solutions · ${i1}`,
      `Committed to excellence & craft`,
      cta ? (em ? '🔗 Tap the link to connect' : 'Connect via link below') : '',
    ].filter(Boolean).join('\n');
  }

  if (style === 'cool') {
    if (optionIndex === 1) {
      return [
        em ? `⚡ ${profession}` : profession,
        `Living at the intersection of ${i1} & ${i2}`,
        `${personality} mind · big vision`,
        callToActionText,
      ].filter(Boolean).join('\n');
    }
    if (optionIndex === 2) {
      return [
        name ? `${name} ✨` : `${profession}`,
        `Curating vibes & mastering ${i1}`,
        'Offline when outdoors',
        callToActionText,
      ].filter(Boolean).join('\n');
    }
    return [
      profession,
      em ? `🔥 Making ${i1} look easy` : `Refining ${i1} daily`,
      `Driven by ${i2}`,
      cta ? (em ? '👀 Check what I’m up to' : 'Latest updates below') : '',
    ].filter(Boolean).join('\n');
  }

  if (style === 'funny') {
    if (optionIndex === 1) {
      return [
        em ? `☕ ${profession}` : profession,
        `Powered by iced coffee and ${i1}`,
        `Probably thinking about ${i2}`,
        cta ? (em ? '👇 Tap before I change my mind' : 'Link below before I forget') : '',
      ].filter(Boolean).join('\n');
    }
    if (optionIndex === 2) {
      return [
        `Professional ${profession.toLowerCase()}`,
        `Amateur enthusiast of ${i1}`,
        `10% ${personality}, 90% caffeine`,
        callToActionText,
      ].filter(Boolean).join('\n');
    }
    return [
      em ? `🥑 ${profession}` : profession,
      `Trying to look busy while doing ${i1}`,
      `Please don't ask me what day it is`,
      cta ? (em ? '🔗 Secret project link' : 'Project links below') : '',
    ].filter(Boolean).join('\n');
  }

  if (style === 'motivational') {
    if (optionIndex === 1) {
      return [
        em ? `✨ ${profession}` : profession,
        `Turning passion for ${i1} into purpose`,
        `Growth over perfection every single day`,
        cta ? (em ? '🌱 Join the journey below' : 'Join the journey below') : '',
      ].filter(Boolean).join('\n');
    }
    if (optionIndex === 2) {
      return [
        name ? `${name} | Purpose & Action` : profession,
        `Mastering ${i1} · Embracing the grind`,
        `Build the future you want to live in`,
        callToActionText,
      ].filter(Boolean).join('\n');
    }
    return [
      em ? `🏔️ ${profession}` : profession,
      `Chasing mastery in ${i1} & ${i2}`,
      `Believer in continuous evolution`,
      callToActionText,
    ].filter(Boolean).join('\n');
  }

  // Creative style
  if (optionIndex === 1) {
    return [
      em ? `🎨 ${profession}` : profession,
      `Translating ${i1} into tangible wonders`,
      `${personality} heart · unfiltered thoughts`,
      cta ? (em ? '✨ Wander through my universe' : 'Explore portfolio below') : '',
    ].filter(Boolean).join('\n');
  }
  if (optionIndex === 2) {
    return [
      name ? `${name}` : profession,
      `Weaving stories out of ${i1} & ${i2}`,
      'Finding poetry in unexpected spaces',
      callToActionText,
    ].filter(Boolean).join('\n');
  }
  return [
    em ? `🌙 ${profession}` : profession,
    `Architect of ideas around ${i1}`,
    `Forever experimenting`,
    callToActionText,
  ].filter(Boolean).join('\n');
}

// -------------------------------------------------------------
// WHATSAPP GENERATOR (Status / About - 139 char limit, punchy)
// -------------------------------------------------------------
function generateWhatsAppBio(
  optionIndex: number,
  style: BioStyleId,
  name: string,
  profession: string,
  interests: string[],
  personality: string,
  em: boolean,
  cta: boolean,
  seed: number
): string {
  const i1 = interests[0] || 'life';
  const i2 = interests[1] || 'progress';

  if (style === 'minimal') {
    const options = [
      `${profession} · ${i1}`,
      `Busy crafting ${i1}.`,
      `Silent mode. Focused on ${i1}.`,
    ];
    return options[optionIndex - 1] || options[0];
  }

  if (style === 'professional') {
    const options = [
      em ? `💼 Available for urgent calls only | ${profession}` : `In meetings or focused on ${profession}.`,
      `${profession} | Inquiries: please leave a message.`,
      em ? `🎯 Dedicated to ${i1}. Ping me for projects.` : `Consulting on ${i1} & ${profession}.`,
    ];
    return options[optionIndex - 1] || options[0];
  }

  if (style === 'cool') {
    const options = [
      em ? `⚡ Living simply. Creating ${i1}.` : `Doing what matters. Focused on ${i1}.`,
      `Currently out of the box. Ping me with ideas.`,
      em ? `☕ ${profession} by day, ${i1} by night.` : `${profession} by day, ${i1} by night.`,
    ];
    return options[optionIndex - 1] || options[0];
  }

  if (style === 'funny') {
    const options = [
      em ? `🔋 Battery at 2% just like my patience.` : `Offline doing ${i1} experiments.`,
      `I reply fast if you bring snacks.`,
      em ? `🙃 Probably overthinking something about ${i1}.` : `Overthinking ${i1} since 9am.`,
    ];
    return options[optionIndex - 1] || options[0];
  }

  if (style === 'motivational') {
    const options = [
      em ? `✨ Every day is a fresh draft. Keep going.` : `Work in silence, let the craft speak.`,
      `Chasing mastery in ${i1} with a ${personality} heart.`,
      em ? `🌱 Building quietly. Growing daily.` : `Small steps every day toward big goals.`,
    ];
    return options[optionIndex - 1] || options[0];
  }

  // Creative
  const options = [
    em ? `🌿 Finding music between the words.` : `Sketching ideas around ${i1}.`,
    `A ${personality} mind lost in ${i1}.`,
    em ? `✨ Somewhere between coffee and ${profession}.` : `Somewhere between coffee and ${profession}.`,
  ];
  return options[optionIndex - 1] || options[0];
}

// -------------------------------------------------------------
// LINKEDIN GENERATOR (Headline & Value Prop - 220 char limit)
// -------------------------------------------------------------
function generateLinkedInBio(
  optionIndex: number,
  style: BioStyleId,
  name: string,
  profession: string,
  interests: string[],
  personality: string,
  em: boolean,
  cta: boolean,
  seed: number
): string {
  const i1 = interests[0] || 'strategic initiatives';
  const i2 = interests[1] || 'high-impact execution';
  const ctaPhrase = cta ? 'Open to advisory & leadership roles.' : 'Passionate about team growth.';

  if (style === 'professional') {
    if (optionIndex === 1) {
      return `${profession} | Driving measurable impact in ${i1} & ${i2} | ${ctaPhrase}`;
    }
    if (optionIndex === 2) {
      return `${profession} helping high-growth organizations scale through ${i1}. Track record in ${i2} and team mentorship.`;
    }
    return `${profession} | Transforming complex challenges in ${i1} into elegant business outcomes. ${ctaPhrase}`;
  }

  if (style === 'minimal') {
    if (optionIndex === 1) {
      return `${profession} · ${i1} · ${i2}`;
    }
    if (optionIndex === 2) {
      return `${profession} specializing in ${i1}. Focused on quality over volume.`;
    }
    return `${profession} | Building scalable solutions in ${i1}.`;
  }

  if (style === 'cool') {
    if (optionIndex === 1) {
      return `${profession} rethinking how we approach ${i1}. Building fast, shipping cleanly.`;
    }
    if (optionIndex === 2) {
      return `${profession} · Focused on modern ${i1} & human-first design. Let's build something bold.`;
    }
    return `${profession} on a mission to make ${i1} simpler and more intuitive for everyone.`;
  }

  if (style === 'motivational') {
    if (optionIndex === 1) {
      return `${profession} passionate about unlocking potential in ${i1}. Empowering teams to build the future.`;
    }
    if (optionIndex === 2) {
      return `Championing continuous innovation in ${i1} as a ${profession}. Relentless pursuit of craft.`;
    }
    return `${profession} | Turning vision into reality through ${i1} and customer-obsessed execution.`;
  }

  if (style === 'creative') {
    if (optionIndex === 1) {
      return `${profession} merging artistic perspective with technical precision across ${i1} & ${i2}.`;
    }
    if (optionIndex === 2) {
      return `Storyteller & ${profession} | Crafting memorable experiences at the frontier of ${i1}.`;
    }
    return `${profession} · Connecting dots between ${i1}, culture, and sustainable innovation.`;
  }

  // Funny
  if (optionIndex === 1) {
    return `${profession} who translates business chaos into clear ${i1} systems (and drinks too much tea).`;
  }
  if (optionIndex === 2) {
    return `${profession} | Pretending to be an adult while solving hard problems in ${i1}.`;
  }
  return `${profession} turning coffee into ${i1} strategies that actually move the needle.`;
}

// -------------------------------------------------------------
// GITHUB GENERATOR (Developer & Open Source - 200 char limit)
// -------------------------------------------------------------
function generateGitHubBio(
  optionIndex: number,
  style: BioStyleId,
  name: string,
  profession: string,
  interests: string[],
  personality: string,
  em: boolean,
  cta: boolean,
  seed: number
): string {
  const i1 = interests[0] || 'TypeScript';
  const i2 = interests[1] || 'open-source';
  const i3 = interests[2] || 'architecture';

  if (style === 'minimal') {
    if (optionIndex === 1) {
      return `${profession} building with ${i1} & ${i2}.`;
    }
    if (optionIndex === 2) {
      return `${profession} · ${i1} / ${i2} / ${i3}`;
    }
    return `git commit -m "building in ${i1}"`;
  }

  if (style === 'cool') {
    if (optionIndex === 1) {
      return em
        ? `⚡ ${profession} | Shipping fast, breaking nothing | Building ${i1} tools`
        : `${profession} | Shipping fast, breaking nothing | Building ${i1} tools`;
    }
    if (optionIndex === 2) {
      return `${profession} hacking on ${i1} & ${i2}. Proud open-source enthusiast.`;
    }
    return `Crafting clean code & modular systems in ${i1}. Always curious.`;
  }

  if (style === 'professional') {
    if (optionIndex === 1) {
      return `${profession} | Architecting resilient systems in ${i1} & ${i2}. Open to collaboration.`;
    }
    if (optionIndex === 2) {
      return `${profession} dedicated to clean architecture, test-driven development, and ${i1}.`;
    }
    return `${profession} specializing in ${i1}. Committed to developer experience and documentation.`;
  }

  if (style === 'funny') {
    if (optionIndex === 1) {
      return em
        ? `🐛 ${profession} turning caffeine into git commits & ${i1} experiments`
        : `${profession} turning caffeine into git commits & ${i1} experiments`;
    }
    if (optionIndex === 2) {
      return `Works on my machine ¯\\_(ツ)_/¯ | Building ${i1} & ${i2}`;
    }
    return `${profession} | 99 bugs in the code, fix one, 127 bugs in the code.`;
  }

  if (style === 'motivational') {
    if (optionIndex === 1) {
      return em
        ? `🚀 ${profession} | Building open-source software that empowers developers worldwide`
        : `${profession} | Building open-source software that empowers developers worldwide`;
    }
    if (optionIndex === 2) {
      return `Writing code that matters. Deep diving into ${i1} and pushing technical boundaries.`;
    }
    return `${profession} | One commit at a time toward better software and open knowledge.`;
  }

  // Creative
  if (optionIndex === 1) {
    return `${profession} sculpting logic and digital dreams with ${i1} & ${i2}.`;
  }
  if (optionIndex === 2) {
    return `Pixel poet & ${profession} | Exploring experimental workflows in ${i1}.`;
  }
  return `${profession} weaving interactive art and robust architecture out of ${i1}.`;
}

// -------------------------------------------------------------
// TWITTER / X GENERATOR (160 char limit, punchy & engaging)
// -------------------------------------------------------------
function generateTwitterBio(
  optionIndex: number,
  style: BioStyleId,
  name: string,
  profession: string,
  interests: string[],
  personality: string,
  em: boolean,
  cta: boolean,
  seed: number
): string {
  const i1 = interests[0] || 'tech';
  const i2 = interests[1] || 'design';

  if (style === 'minimal') {
    if (optionIndex === 1) return `${profession} · Tweeting about ${i1}.`;
    if (optionIndex === 2) return `${profession}. Obsessed with ${i1} & ${i2}.`;
    return `${profession} · Building in public.`;
  }

  if (style === 'cool') {
    if (optionIndex === 1) {
      return em
        ? `⚡ ${profession} exploring ${i1}. Here for the banter & breakthroughs.`
        : `${profession} exploring ${i1}. Here for the banter & breakthroughs.`;
    }
    if (optionIndex === 2) {
      return `${profession} | Sharing real takes on ${i1} & building cool things.`;
    }
    return `Curating thoughts on ${i1}. Making moves, not excuses.`;
  }

  if (style === 'professional') {
    if (optionIndex === 1) {
      return `${profession} sharing insights on ${i1}, leadership, and industry trends.`;
    }
    if (optionIndex === 2) {
      return `${profession} | Discussing ${i1} & ${i2} | Opinions are my own.`;
    }
    return `Writing on the future of ${i1}. Helping teams navigate modern challenges.`;
  }

  if (style === 'funny') {
    if (optionIndex === 1) {
      return em
        ? `I have 99 tabs open and 98 of them are about ${i1} 🫠`
        : `I have 99 tabs open and 98 of them are about ${i1}.`;
    }
    if (optionIndex === 2) {
      return `${profession} by day, doomscroller by night. Occasional tweets on ${i1}.`;
    }
    return `Here to tweet my unsolicited thoughts on ${i1} and drink lukewarm tea.`;
  }

  if (style === 'motivational') {
    if (optionIndex === 1) {
      return em
        ? `🚀 Building in public | ${profession} | Documenting the journey in ${i1}`
        : `Building in public | ${profession} | Documenting the journey in ${i1}`;
    }
    if (optionIndex === 2) {
      return `Continuous learning. Sharing lessons in ${i1} and personal mastery.`;
    }
    return `${profession} | Believer in curiosity, consistency, and big leaps.`;
  }

  // Creative
  if (optionIndex === 1) {
    return `Daydreamer & ${profession}. Capturing flashes of inspiration in ${i1}.`;
  }
  if (optionIndex === 2) {
    return `${profession} | Living where ${i1} meets creative experimentation.`;
  }
  return `Collecting thoughts, crafting in ${i1}, and exploring unconventional ideas.`;
}
