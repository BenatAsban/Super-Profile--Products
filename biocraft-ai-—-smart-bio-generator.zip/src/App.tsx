import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { BioForm } from './components/BioForm';
import { BioResults } from './components/BioResults';
import { PlatformMockupPreview } from './components/PlatformMockupPreview';
import { PlatformShowcase } from './components/PlatformShowcase';
import { StylesShowcase } from './components/StylesShowcase';
import { Footer } from './components/Footer';
import { Modals, ModalType } from './components/Modals';
import { Toast, ToastMessage } from './components/Toast';
import { BioFormData, GeneratedBio, PlatformId, BioStyleId } from './types/bio';
import { generateBios } from './services/bioGenerator';
import { SAMPLE_PRESETS } from './data/presets';

const INITIAL_FORM_DATA: BioFormData = {
  name: 'Alex Vance',
  profession: 'Full-Stack Developer & Designer',
  interests: 'TypeScript, Tailwind CSS, Specialty Coffee, UI/UX',
  personality: 'creative and detail-oriented',
  platform: 'instagram',
  style: 'cool',
  includeEmojis: true,
  includeCallToAction: true,
};

export default function App() {
  // 1. Dark Mode State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('biocraft-theme');
      if (stored) return stored === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('biocraft-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('biocraft-theme', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  // 2. Form & Generation State
  const [formData, setFormData] = useState<BioFormData>(INITIAL_FORM_DATA);
  const [seed, setSeed] = useState<number>(1);
  const [bios, setBios] = useState<GeneratedBio[]>(() => {
    return generateBios(INITIAL_FORM_DATA, 1);
  });
  const [selectedBioForPreview, setSelectedBioForPreview] = useState<GeneratedBio | null>(() => {
    const initial = generateBios(INITIAL_FORM_DATA, 1);
    return initial[0] || null;
  });

  // 3. Toasts & Modals State
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [activeModal, setActiveModal] = useState<ModalType>(null);

  const addToast = (type: 'success' | 'error' | 'info', title: string, description?: string) => {
    const newToast: ToastMessage = {
      id: `toast-${Date.now()}-${Math.random()}`,
      type,
      title,
      description,
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // 4. Form Field Updates
  const handleFormChange = (updated: Partial<BioFormData>) => {
    setFormData((prev) => ({ ...prev, ...updated }));
  };

  // 5. Bio Generation Handler
  const handleGenerate = () => {
    const nextSeed = seed + 1;
    setSeed(nextSeed);
    const newBios = generateBios(formData, nextSeed);
    setBios(newBios);
    if (newBios.length > 0) {
      setSelectedBioForPreview(newBios[0]);
    }
    addToast('success', 'Bios Generated!', `Created 3 ${formData.style} variations for ${formData.platform}.`);
  };

  // 6. Reset / Clear Form
  const handleClear = () => {
    const emptyForm: BioFormData = {
      name: '',
      profession: '',
      interests: '',
      personality: '',
      platform: formData.platform,
      style: formData.style,
      includeEmojis: true,
      includeCallToAction: false,
    };
    setFormData(emptyForm);
    setBios([]);
    setSelectedBioForPreview(null);
    addToast('info', 'Form Cleared', 'All fields have been reset.');
  };

  // 7. Load Preset Sample
  const handleLoadPreset = (index: number) => {
    const preset = SAMPLE_PRESETS[index];
    if (preset) {
      setFormData(preset.data);
      const nextSeed = seed + 1;
      setSeed(nextSeed);
      const newBios = generateBios(preset.data, nextSeed);
      setBios(newBios);
      if (newBios.length > 0) {
        setSelectedBioForPreview(newBios[0]);
      }
      addToast('info', `Preset Loaded`, `Applied "${preset.title}" template.`);
    }
  };

  // 8. Clipboard Copy with Fallback
  const handleCopy = async (text: string) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        // Fallback for non-secure or older contexts
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        textArea.remove();
      }
      addToast('success', 'Copied to Clipboard!', 'Your bio is ready to paste into your profile.');
    } catch (err) {
      console.error('Failed to copy to clipboard', err);
      addToast('error', 'Copy Failed', 'Please manually select and copy the bio text.');
    }
  };

  // 9. Single Bio Shuffle
  const handleRegenerateSingle = (bioId: string, index: number) => {
    const newSeed = seed + Math.floor(Math.random() * 50) + 1;
    const freshBatch = generateBios(formData, newSeed);
    if (freshBatch[index]) {
      const updated = [...bios];
      updated[index] = freshBatch[index];
      setBios(updated);
      if (selectedBioForPreview?.id === bioId) {
        setSelectedBioForPreview(freshBatch[index]);
      }
      addToast('info', 'Variation Refreshed', `Shuffled Option ${index + 1}.`);
    }
  };

  // 10. In-place text update
  const handleUpdateBioText = (bioId: string, newText: string) => {
    setBios((prev) =>
      prev.map((b) => {
        if (b.id === bioId) {
          const charCount = newText.length;
          const updated = {
            ...b,
            text: newText,
            charCount,
            isWithinLimit: charCount <= b.maxLimit,
          };
          if (selectedBioForPreview?.id === bioId) {
            setSelectedBioForPreview(updated);
          }
          return updated;
        }
        return b;
      })
    );
  };

  // 11. Navigation Scroll Helper
  const scrollToGenerator = () => {
    const el = document.getElementById('generator');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors duration-200">
      {/* Toast Notifications */}
      <Toast toasts={toasts} onDismiss={dismissToast} />

      {/* Header */}
      <Header
        darkMode={darkMode}
        onToggleDarkMode={toggleDarkMode}
        onNavigateToGenerator={scrollToGenerator}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onGetStarted={scrollToGenerator}
          onSelectPlatform={(plat) => {
            handleFormChange({ platform: plat });
            scrollToGenerator();
          }}
        />

        {/* Bio Generator & Results Workspace */}
        <section id="generator" className="py-12 md:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h2 className="text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50 sm:text-4xl">
              Bio Studio
            </h2>
            <p className="mt-2 text-sm sm:text-base text-neutral-600 dark:text-neutral-400">
              Customize your inputs, choose your desired tone, and copy your favorite bio with a
              single click.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left: Input Form */}
            <div className="lg:col-span-7">
              <BioForm
                formData={formData}
                onChange={handleFormChange}
                onGenerate={handleGenerate}
                onClear={handleClear}
                onLoadPreset={handleLoadPreset}
              />
            </div>

            {/* Right: Generated Results */}
            <div className="lg:col-span-5">
              <BioResults
                bios={bios}
                onCopy={handleCopy}
                onRegenerateAll={handleGenerate}
                onRegenerateSingle={handleRegenerateSingle}
                onSelectForPreview={(bio) => {
                  setSelectedBioForPreview(bio);
                  const previewEl = document.getElementById('preview');
                  if (previewEl) {
                    previewEl.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                selectedPreviewId={selectedBioForPreview?.id}
                onUpdateBioText={handleUpdateBioText}
                onTriggerPresetSample={() => handleLoadPreset(0)}
              />
            </div>
          </div>
        </section>

        {/* Interactive Platform Mockup Previewer */}
        <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <PlatformMockupPreview
            currentBio={selectedBioForPreview}
            formData={formData}
            onSelectPlatform={(plat) => handleFormChange({ platform: plat })}
          />
        </section>

        {/* Platforms Showcase Section */}
        <PlatformShowcase
          onSelectPlatform={(plat) => {
            handleFormChange({ platform: plat });
            scrollToGenerator();
          }}
        />

        {/* Styles Showcase Section */}
        <StylesShowcase
          onSelectStyle={(style) => {
            handleFormChange({ style });
            scrollToGenerator();
          }}
        />
      </main>

      {/* Footer */}
      <Footer
        onOpenModal={(type) => setActiveModal(type)}
        onNavigateToGenerator={scrollToGenerator}
      />

      {/* Modals for About, Privacy, Contact */}
      <Modals
        activeModal={activeModal}
        onClose={() => setActiveModal(null)}
        onShowToast={(title, desc) => addToast('success', title, desc)}
      />
    </div>
  );
}
