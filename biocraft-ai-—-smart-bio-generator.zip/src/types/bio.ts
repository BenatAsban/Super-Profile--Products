export type PlatformId = 'instagram' | 'whatsapp' | 'linkedin' | 'github' | 'twitter';

export type BioStyleId = 'professional' | 'cool' | 'minimal' | 'funny' | 'motivational' | 'creative';

export interface BioFormData {
  name: string;
  profession: string;
  interests: string;
  personality: string;
  platform: PlatformId;
  style: BioStyleId;
  includeEmojis: boolean;
  includeCallToAction: boolean;
}

export interface GeneratedBio {
  id: string;
  text: string;
  style: BioStyleId;
  platform: PlatformId;
  charCount: number;
  maxLimit: number;
  isWithinLimit: boolean;
  tags?: string[];
}

export interface PlatformConfig {
  id: PlatformId;
  name: string;
  tagline: string;
  charLimit: number;
  recommendedStyle: string;
  tips: string;
  accentColor: string;
  badgeBg: string;
}

export interface StyleConfig {
  id: BioStyleId;
  name: string;
  label: string;
  description: string;
  vibe: string;
}

export interface PresetProfile {
  title: string;
  data: BioFormData;
}
