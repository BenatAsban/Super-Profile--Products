import { PresetProfile } from '../types/bio';

export const SAMPLE_PRESETS: PresetProfile[] = [
  {
    title: 'Frontend Developer',
    data: {
      name: 'Maya Lin',
      profession: 'Senior Frontend Engineer',
      interests: 'React, TypeScript, CSS architecture, accessibility',
      personality: 'detail-oriented and curious',
      platform: 'github',
      style: 'cool',
      includeEmojis: true,
      includeCallToAction: true,
    },
  },
  {
    title: 'Instagram Creator',
    data: {
      name: 'Julian Vance',
      profession: 'Visual Storyteller & Photographer',
      interests: 'Street photography, espresso, analog film, Tokyo',
      personality: 'aesthetic and adventurous',
      platform: 'instagram',
      style: 'creative',
      includeEmojis: true,
      includeCallToAction: false,
    },
  },
  {
    title: 'LinkedIn Product Lead',
    data: {
      name: 'Elena Rostova',
      profession: 'Product Leader & Strategist',
      interests: '0-to-1 SaaS, user research, data analytics, scaling teams',
      personality: 'strategic, empathetic, and metrics-driven',
      platform: 'linkedin',
      style: 'professional',
      includeEmojis: false,
      includeCallToAction: true,
    },
  },
  {
    title: 'WhatsApp Mindset',
    data: {
      name: 'David Kim',
      profession: 'Architect & Maker',
      interests: 'Sustainable design, trail running, quiet mornings',
      personality: 'minimalist and thoughtful',
      platform: 'whatsapp',
      style: 'minimal',
      includeEmojis: false,
      includeCallToAction: false,
    },
  },
  {
    title: 'Twitter Indie Hacker',
    data: {
      name: 'Samira Patel',
      profession: 'Solo Founder & Bootstrapper',
      interests: 'Micro-SaaS, building in public, automation, caffeine',
      personality: 'scrappy, witty, and transparent',
      platform: 'twitter',
      style: 'funny',
      includeEmojis: true,
      includeCallToAction: true,
    },
  },
];
