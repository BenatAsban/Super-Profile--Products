import { PlatformConfig, PlatformId } from '../types/bio';

export const PLATFORMS: Record<PlatformId, PlatformConfig> = {
  instagram: {
    id: 'instagram',
    name: 'Instagram',
    tagline: 'Visual & Punchy',
    charLimit: 150,
    recommendedStyle: 'Creative / Cool',
    tips: 'Use clean line breaks and key emojis. Keep it under 150 characters to avoid truncation.',
    accentColor: '#E1306C',
    badgeBg: 'bg-pink-50 text-pink-700 dark:bg-pink-950/40 dark:text-pink-300 border-pink-200 dark:border-pink-900',
  },
  whatsapp: {
    id: 'whatsapp',
    name: 'WhatsApp',
    tagline: 'Personal & Direct',
    charLimit: 139,
    recommendedStyle: 'Minimal / Motivational',
    tips: 'WhatsApp "About" status displays best in 1–2 short lines or a thought-provoking quote.',
    accentColor: '#25D366',
    badgeBg: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900',
  },
  linkedin: {
    id: 'linkedin',
    name: 'LinkedIn',
    tagline: 'Executive & Credible',
    charLimit: 220,
    recommendedStyle: 'Professional / Motivational',
    tips: 'Highlight your unique value proposition, industry niche, and core impact metrics.',
    accentColor: '#0A66C2',
    badgeBg: 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border-blue-200 dark:border-blue-900',
  },
  github: {
    id: 'github',
    name: 'GitHub',
    tagline: 'Technical & Developer-First',
    charLimit: 200,
    recommendedStyle: 'Minimal / Creative',
    tips: 'Showcase your tech stack, open-source focus, current build project, and geeky personality.',
    accentColor: '#24292F',
    badgeBg: 'bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300 border-purple-200 dark:border-purple-900',
  },
  twitter: {
    id: 'twitter',
    name: 'Twitter / X',
    tagline: 'Sharp & Conversational',
    charLimit: 160,
    recommendedStyle: 'Cool / Funny',
    tips: 'Blend your niche expertise with witty commentary or personal quirks.',
    accentColor: '#0F1419',
    badgeBg: 'bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-200 border-neutral-300 dark:border-neutral-700',
  },
};

export const PLATFORM_LIST = Object.values(PLATFORMS);
