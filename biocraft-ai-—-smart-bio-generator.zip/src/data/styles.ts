import { BioStyleId, StyleConfig } from '../types/bio';

export const BIO_STYLES: Record<BioStyleId, StyleConfig> = {
  professional: {
    id: 'professional',
    name: 'Professional',
    label: 'Professional',
    description: 'Polished, authoritative, and focused on value delivery and domain mastery.',
    vibe: 'Polished & Credible',
  },
  cool: {
    id: 'cool',
    name: 'Cool',
    label: 'Cool & Modern',
    description: 'Effortless, contemporary, and relaxed with an understated punch.',
    vibe: 'Modern & Confident',
  },
  minimal: {
    id: 'minimal',
    name: 'Minimal',
    label: 'Ultra Minimal',
    description: 'Clean, stripped back, high signal-to-noise ratio. Zero fluff.',
    vibe: 'Crisp & Direct',
  },
  funny: {
    id: 'funny',
    name: 'Funny',
    label: 'Witty & Playful',
    description: 'Self-aware humor, clever analogies, and charming relatability.',
    vibe: 'Humorous & Relatable',
  },
  motivational: {
    id: 'motivational',
    name: 'Motivational',
    label: 'Inspiring & Driven',
    description: 'Growth-minded, forward-looking, and energizing purpose statements.',
    vibe: 'Ambitious & Purpose-driven',
  },
  creative: {
    id: 'creative',
    name: 'Creative',
    label: 'Artistic & Unique',
    description: 'Imaginative phrasing, vivid metaphors, and standout individuality.',
    vibe: 'Original & Expressive',
  },
};

export const STYLE_LIST = Object.values(BIO_STYLES);
