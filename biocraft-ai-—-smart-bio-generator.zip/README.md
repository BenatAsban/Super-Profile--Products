# BioCraft AI — Smart Bio Generator

BioCraft AI is a modern, responsive, client-side web application designed to help creators, developers, founders, and professionals generate attractive, personality-driven social media bios for Instagram, WhatsApp, LinkedIn, GitHub, and Twitter in seconds.

---

## Key Features

- **Multi-Platform Support**: Tailored bio structures and strict character limit enforcement for:
  - **Instagram** (150 chars max, aesthetic line breaks, emoji-friendly)
  - **WhatsApp** (139 chars max, punchy about / status style)
  - **LinkedIn** (220 chars max, value proposition & career impact)
  - **GitHub** (200 chars max, developer stack, open-source focus)
  - **Twitter / X** (160 chars max, sharp & conversational)
- **6 Distinct Tone Archetypes**:
  - Professional (Polished & credible)
  - Cool & Modern (Effortless & confident)
  - Ultra Minimal (High signal-to-noise ratio)
  - Witty & Playful (Charming, relatable humor)
  - Inspiring & Driven (Growth-minded & ambitious)
  - Artistic & Unique (Creative metaphors & individuality)
- **Local Algorithmic Generator**: 100% in-browser generation. No API keys, no backend latency, zero external data leakage.
- **Interactive Live Profile Mockups**: See how your bio looks in real-time inside native mockups for Instagram, WhatsApp, LinkedIn, GitHub, and Twitter.
- **Inline Editing & Character Meter**: Edit text directly in results with real-time character count tracking and limit alerts.
- **One-Click Clipboard Copying**: Seamless clipboard integration with fallback support and instant toast feedback.
- **Sample Presets**: Instantly load pre-configured profiles (Frontend Developer, Instagram Creator, Product Lead, etc.).
- **Light & Dark Mode**: Persistent theme toggle respecting system preferences.
- **Zero Tracking**: 100% privacy-friendly with zero analytics or tracking cookies.

---

## Tech Stack

- **React 19**
- **TypeScript**
- **Vite 8**
- **Tailwind CSS v4**
- **Lucide React** (icons)

---

## Local Development Setup

To run BioCraft AI locally on your machine:

1. **Clone or navigate to the project directory**:
   ```bash
   cd biocraft-ai
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start the development server**:
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

---

## Production Build

To test the production build locally:

```bash
npm run build
npm run preview
```

---

## Netlify Deployment Guide

BioCraft AI is a pure client-side Single Page Application (SPA), making it fast and simple to deploy to Netlify.

### Method 1: Git-Connected Deployment (Recommended)

1. Push this repository to GitHub, GitLab, or Bitbucket.
2. Log in to [Netlify](https://app.netlify.com/).
3. Click **"Add new site"** > **"Import an existing project"**.
4. Select your Git provider and repository.
5. In the build settings, configure:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
6. Click **"Deploy site"**. Netlify will build and deploy your site in seconds.

### Method 2: Netlify CLI Deployment

1. Install the Netlify CLI globally:
   ```bash
   npm install -g netlify-cli
   ```
2. Build the production bundle:
   ```bash
   npm run build
   ```
3. Deploy to Netlify:
   ```bash
   netlify deploy --prod --dir=dist
   ```

### Method 3: Drag & Drop (Netlify Drop)

1. Build the production bundle locally:
   ```bash
   npm run build
   ```
2. Go to [Netlify Drop](https://app.netlify.com/drop).
3. Drag and drop the generated `dist` folder directly onto the page.

---

## License

Apache-2.0 License.
