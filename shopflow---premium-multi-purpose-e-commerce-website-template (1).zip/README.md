# 🛍️ ShopFlow - Premium Multi-Purpose E-Commerce Website Template

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com)

**ShopFlow** is a modern, production-grade, full-stack E-Commerce website template engineered for fashion boutiques, bespoke jewellery shops, home bakeries, handmade craft sellers, and Instagram businesses.

Designed for digital product selling on **Super Profile** and **Payhip**, ShopFlow empowers store owners to sell online with zero technical friction.

---

## 🌟 Key Features

### 🛒 Customer Storefront
- **Dynamic Announcement Bar:** Real-time promo notifications configurable from the admin panel.
- **Hero Banner:** High-converting CTA with promo badges and seasonal highlights.
- **Live Search & Autocomplete:** Real-time query search across products, descriptions, and categories.
- **Product Filtering & Sorting:** Category pills, live price range slider, in-stock toggle, and popularity/price sorting.
- **Product Details & Gallery:** Multi-image gallery with thumbnail switcher, size pills, color swatches, and stock alerts.
- **PIN Code Delivery Checker:** Instant delivery feasibility and Cash on Delivery estimator.
- **Customer Reviews & Ratings:** Verified purchase reviews with star ratings and direct submission modal.
- **Slide-Over Bag & Dedicated Cart:** Free shipping progress bar, promo coupon applicator, and quantity adjuster.
- **3 Payment Options:**
  1. **Cash on Delivery (COD)** with zero advance required.
  2. **Online Payment via Razorpay:** UPI (Google Pay, PhonePe, Paytm), RuPay/Visa/Mastercard, NetBanking.
  3. **1-Click WhatsApp Ordering:** Generates official pre-formatted order summary directly in WhatsApp chat.
- **Live Order Tracking:** Real-time visual timeline from `Order Placed` to `Out for Delivery` and `Delivered`.
- **Wishlist & Customer Accounts:** Wishlist persistence and customer order history.
- **Dark & Light Mode:** Seamless theme toggle with persistent storage.

### ⚡ Admin Dashboard (SaaS-Style)
- **Executive KPIs:** Total Revenue, Orders, Products, Customers, Pending Orders, and Low Stock Alerts.
- **Visual Analytics:** Interactive Recharts area chart for monthly revenue trends and fulfillment status breakdown.
- **Product Management:** Full CRUD (add, edit, delete, stock control, image URLs, sizes, colors, tags, featured flag).
- **Order Fulfillment:** Live status updates (`Placed`, `Confirmed`, `Processing`, `Shipped`, `Delivered`, `Cancelled`), payment verification, and tracking number assignment.
- **Customer Directory:** Track registered and guest customers with total order volume and contact phone.
- **Coupon Manager:** Create percentage or fixed discount coupons with minimum order values and expirations.
- **Store Customizer:** Customize store name, logo, currency symbol, WhatsApp number, free shipping threshold, and hero banner.
- **1-Click Template ZIP Export:** Bundles the complete project into a downloadable `.zip` file for digital product buyers.

---

## 🚀 Quick Start Guide (Local Setup)

### 1. Install Dependencies
\`\`\`bash
npm install
\`\`\`

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
\`\`\`bash
cp .env.example .env
\`\`\`

### 3. Run Development Server
\`\`\`bash
npm run dev
\`\`\`
Visit **http://localhost:3000** in your browser.

---

## 🔐 Default Admin Credentials

- **Admin Portal URL:** `http://localhost:3000/admin`
- **Email:** `admin@shopflow.com`
- **Password:** `admin1234`

*(Alternatively, use the **1-Click Demo Logins** button in the sign-in modal)*

---

## ☁️ 1-Click Render Deployment Instructions

Follow these simple steps to deploy ShopFlow live on Render:

1. Create a free account at [render.com](https://render.com).
2. Push your project to **GitHub**.
3. On Render, click **New +** and select **Web Service**.
4. Connect your GitHub repository.
5. Configure the service settings:
   - **Environment:** `Node`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
6. Add the following **Environment Variables** in Render's dashboard:
   - `NODE_ENV`: `production`
   - `JWT_SECRET`: A secure random 32+ character string
   - `MONGODB_URI`: Your MongoDB Atlas connection string (see below)
   - `RAZORPAY_KEY_ID`: Your Razorpay Key ID (optional)
   - `RAZORPAY_KEY_SECRET`: Your Razorpay Key Secret (optional)
7. Click **Create Web Service**. Your store will be live in 2 minutes!

---

## 🍃 MongoDB Atlas Setup

1. Create a free account at [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas).
2. Build a free **M0 Sandbox Cluster**.
3. Under **Database Access**, create a database user with username and password.
4. Under **Network Access**, add IP `0.0.0.0/0` (Allow access from anywhere).
5. Click **Connect** &gt; **Connect your application** &gt; copy the connection string:
   \`\`\`
   mongodb+srv://<username>:<password>@cluster0.abcde.mongodb.net/shopflow?retryWrites=true&w=majority
   \`\`\`
6. Paste into your `.env` or Render environment settings as `MONGODB_URI`.

*Note: ShopFlow features an adaptive dual-storage layer. If no MongoDB URI is supplied, it automatically runs using its embedded local persistence layer with pre-seeded demo records!*

---

## 💳 Razorpay Online Payments Setup

1. Register at [razorpay.com](https://razorpay.com).
2. Go to **Settings &gt; API Keys** &gt; generate your **Key ID** and **Key Secret**.
3. Add `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` to `.env`.
4. Online payments will automatically activate with server-side HMAC SHA256 verification.
5. In development or without keys, the checkout includes a clean test sandbox payment simulator.

---

## 💬 WhatsApp Business Ordering

1. Navigate to **Admin Dashboard &gt; Store Customizer**.
2. Enter your business WhatsApp number with country code (e.g. `919876543210` for India).
3. When customers click **"Order via WhatsApp"**, ShopFlow opens official `https://wa.me/...` with an itemized receipt, reference ID, customer name, and address ready to send!

---

## 📦 Selling on Super Profile & Payhip

1. Open your admin dashboard and click **"Export Template ZIP"** (or click the download button in the footer).
2. Upload the downloaded `.zip` file as the digital product on [Super Profile](https://superprofile.bio) or [Payhip](https://payhip.com).
3. Set your price and link this README as the customer documentation!

---

## 📄 License
Commercial License - Purchasers may use this template for unlimited personal and client e-commerce websites.
