import mongoose, { Schema, Document, Model } from 'mongoose';

// User Schema
export interface IUser extends Document {
  name: string;
  email: string;
  password?: string;
  role: 'customer' | 'admin';
  phone?: string;
  addresses: Array<{
    street: string;
    city: string;
    state: string;
    pincode: string;
    isDefault?: boolean;
  }>;
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema = new Schema<IUser>(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['customer', 'admin'], default: 'customer' },
    phone: { type: String, default: '' },
    addresses: [
      {
        street: { type: String, required: true },
        city: { type: String, required: true },
        state: { type: String, required: true },
        pincode: { type: String, required: true },
        isDefault: { type: Boolean, default: false }
      }
    ]
  },
  { timestamps: true }
);

// Product Schema
export interface IProduct extends Document {
  title: string;
  slug: string;
  description: string;
  category: string;
  price: number;
  discountPrice?: number;
  images: string[];
  stock: number;
  sizes: string[];
  colors: Array<{ name: string; hex: string }>;
  tags: string[];
  isFeatured: boolean;
  isPublished: boolean;
  rating: number;
  numReviews: number;
  createdAt: Date;
  updatedAt: Date;
}

const ProductSchema = new Schema<IProduct>(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true },
    description: { type: String, required: true },
    category: { type: String, required: true, index: true },
    price: { type: Number, required: true, min: 0 },
    discountPrice: { type: Number, default: null },
    images: { type: [String], default: [] },
    stock: { type: Number, required: true, default: 0, min: 0 },
    sizes: { type: [String], default: [] },
    colors: [
      {
        name: { type: String, required: true },
        hex: { type: String, required: true }
      }
    ],
    tags: { type: [String], default: [] },
    isFeatured: { type: Boolean, default: false },
    isPublished: { type: Boolean, default: true },
    rating: { type: Number, default: 5.0 },
    numReviews: { type: Number, default: 0 }
  },
  { timestamps: true }
);

// Category Schema
export interface ICategory extends Document {
  name: string;
  slug: string;
  image: string;
  description: string;
  createdAt: Date;
}

const CategorySchema = new Schema<ICategory>(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true },
    image: { type: String, default: '' },
    description: { type: String, default: '' }
  },
  { timestamps: true }
);

// Order Schema
export interface IOrderItem {
  id: string;
  title: string;
  price: number;
  quantity: number;
  size?: string;
  color?: string;
  image?: string;
}

export interface IOrder extends Document {
  orderId: string;
  userId?: string;
  customerInfo: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
  };
  items: IOrderItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  couponCode?: string;
  paymentMethod: 'cod' | 'razorpay' | 'whatsapp';
  paymentStatus: 'pending' | 'paid' | 'failed';
  orderStatus: 'placed' | 'confirmed' | 'processing' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled';
  trackingNumber?: string;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const OrderSchema = new Schema<IOrder>(
  {
    orderId: { type: String, required: true, unique: true, index: true },
    userId: { type: String, default: null },
    customerInfo: {
      name: { type: String, required: true },
      email: { type: String, required: true },
      phone: { type: String, required: true },
      address: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String, required: true },
      pincode: { type: String, required: true }
    },
    items: [
      {
        id: { type: String, required: true },
        title: { type: String, required: true },
        price: { type: Number, required: true },
        quantity: { type: Number, required: true, min: 1 },
        size: { type: String, default: '' },
        color: { type: String, default: '' },
        image: { type: String, default: '' }
      }
    ],
    subtotal: { type: Number, required: true },
    shipping: { type: Number, default: 0 },
    discount: { type: Number, default: 0 },
    total: { type: Number, required: true },
    couponCode: { type: String, default: '' },
    paymentMethod: {
      type: String,
      enum: ['cod', 'razorpay', 'whatsapp'],
      default: 'cod'
    },
    paymentStatus: {
      type: String,
      enum: ['pending', 'paid', 'failed'],
      default: 'pending'
    },
    orderStatus: {
      type: String,
      enum: ['placed', 'confirmed', 'processing', 'shipped', 'out_for_delivery', 'delivered', 'cancelled'],
      default: 'placed'
    },
    trackingNumber: { type: String, default: '' },
    razorpayOrderId: { type: String, default: '' },
    razorpayPaymentId: { type: String, default: '' },
    notes: { type: String, default: '' }
  },
  { timestamps: true }
);

// Coupon Schema
export interface ICoupon extends Document {
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  maxDiscount: number;
  expiresAt: Date;
  isActive: boolean;
  usageCount: number;
}

const CouponSchema = new Schema<ICoupon>(
  {
    code: { type: String, required: true, unique: true, uppercase: true, trim: true },
    discountType: { type: String, enum: ['percentage', 'fixed'], default: 'percentage' },
    discountValue: { type: Number, required: true, min: 0 },
    minOrderValue: { type: Number, default: 0 },
    maxDiscount: { type: Number, default: 1000 },
    expiresAt: { type: Date, required: true },
    isActive: { type: Boolean, default: true },
    usageCount: { type: Number, default: 0 }
  },
  { timestamps: true }
);

// Review Schema
export interface IReview extends Document {
  productId: string;
  userName: string;
  userEmail: string;
  rating: number;
  comment: string;
  isVerifiedPurchase: boolean;
  createdAt: Date;
}

const ReviewSchema = new Schema<IReview>(
  {
    productId: { type: String, required: true, index: true },
    userName: { type: String, required: true, trim: true },
    userEmail: { type: String, required: true, lowercase: true, trim: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, required: true },
    isVerifiedPurchase: { type: Boolean, default: true }
  },
  { timestamps: true }
);

// Wishlist Schema
export interface IWishlist extends Document {
  userId: string;
  productIds: string[];
}

const WishlistSchema = new Schema<IWishlist>(
  {
    userId: { type: String, required: true, unique: true },
    productIds: { type: [String], default: [] }
  },
  { timestamps: true }
);

// StoreSettings Schema
export interface IStoreSettings extends Document {
  storeName: string;
  tagline: string;
  logoUrl: string;
  announcementText: string;
  showAnnouncement: boolean;
  currencySymbol: string;
  currencyCode: string;
  whatsappNumber: string;
  supportPhone: string;
  supportEmail: string;
  address: string;
  freeShippingThreshold: number;
  shippingCharge: number;
  heroTitle: string;
  heroSubtitle: string;
  heroCtaText: string;
  heroImageUrl: string;
  primaryColor: string;
  socialLinks: {
    instagram?: string;
    facebook?: string;
    whatsapp?: string;
    pinterest?: string;
  };
}

const StoreSettingsSchema = new Schema<IStoreSettings>(
  {
    storeName: { type: String, default: 'ShopFlow' },
    tagline: { type: String, default: '' },
    logoUrl: { type: String, default: '' },
    announcementText: { type: String, default: '' },
    showAnnouncement: { type: Boolean, default: true },
    currencySymbol: { type: String, default: '₹' },
    currencyCode: { type: String, default: 'INR' },
    whatsappNumber: { type: String, default: '' },
    supportPhone: { type: String, default: '' },
    supportEmail: { type: String, default: '' },
    address: { type: String, default: '' },
    freeShippingThreshold: { type: Number, default: 999 },
    shippingCharge: { type: Number, default: 99 },
    heroTitle: { type: String, default: '' },
    heroSubtitle: { type: String, default: '' },
    heroCtaText: { type: String, default: 'Shop Now' },
    heroImageUrl: { type: String, default: '' },
    primaryColor: { type: String, default: '#0f172a' },
    socialLinks: {
      instagram: { type: String, default: '' },
      facebook: { type: String, default: '' },
      whatsapp: { type: String, default: '' },
      pinterest: { type: String, default: '' }
    }
  },
  { timestamps: true }
);

// Export models (prevent re-compilation in dev)
export const UserModel: Model<IUser> = mongoose.models.User || mongoose.model<IUser>('User', UserSchema);
export const ProductModel: Model<IProduct> = mongoose.models.Product || mongoose.model<IProduct>('Product', ProductSchema);
export const CategoryModel: Model<ICategory> = mongoose.models.Category || mongoose.model<ICategory>('Category', CategorySchema);
export const OrderModel: Model<IOrder> = mongoose.models.Order || mongoose.model<IOrder>('Order', OrderSchema);
export const CouponModel: Model<ICoupon> = mongoose.models.Coupon || mongoose.model<ICoupon>('Coupon', CouponSchema);
export const ReviewModel: Model<IReview> = mongoose.models.Review || mongoose.model<IReview>('Review', ReviewSchema);
export const WishlistModel: Model<IWishlist> = mongoose.models.Wishlist || mongoose.model<IWishlist>('Wishlist', WishlistSchema);
export const StoreSettingsModel: Model<IStoreSettings> = mongoose.models.StoreSettings || mongoose.model<IStoreSettings>('StoreSettings', StoreSettingsSchema);
