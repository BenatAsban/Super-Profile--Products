import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { generateToken, AuthRequest } from '../middleware/auth.ts';
import { memoryStore } from '../config/db.ts';

export async function register(req: Request, res: Response) {
  try {
    const { name, email, password, phone } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'Name, email, and password are required.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const existing = memoryStore.users.find(u => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      return res.status(400).json({ success: false, message: 'An account with this email already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = {
      id: `usr-${Date.now()}`,
      name: name.trim(),
      email: cleanEmail,
      password: hashedPassword,
      role: 'customer',
      phone: phone || '',
      addresses: [],
      createdAt: new Date().toISOString()
    };

    memoryStore.users.push(newUser);

    const token = generateToken({
      id: newUser.id,
      email: newUser.email,
      role: newUser.role as 'customer' | 'admin',
      name: newUser.name
    });

    const { password: _, ...userWithoutPass } = newUser;
    return res.status(201).json({
      success: true,
      message: 'Registration successful! Welcome to ShopFlow.',
      token,
      user: userWithoutPass
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message || 'Registration failed.' });
  }
}

export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const user = memoryStore.users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = generateToken({
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name
    });

    const { password: _, ...userWithoutPass } = user;
    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: userWithoutPass
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message || 'Login failed.' });
  }
}

export async function getMe(req: AuthRequest, res: Response) {
  try {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }

    const user = memoryStore.users.find(u => u.id === req.user?.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const { password, ...userWithoutPass } = user;
    return res.json({ success: true, user: userWithoutPass });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Error retrieving user profile.' });
  }
}

export async function updateProfile(req: AuthRequest, res: Response) {
  try {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }

    const userIndex = memoryStore.users.findIndex(u => u.id === req.user?.id);
    if (userIndex === -1) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const { name, phone, addresses, newPassword } = req.body;
    const user = memoryStore.users[userIndex];

    if (name) user.name = name.trim();
    if (phone !== undefined) user.phone = phone;
    if (addresses) user.addresses = addresses;

    if (newPassword && newPassword.length >= 6) {
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(newPassword, salt);
    }

    const { password, ...userWithoutPass } = user;
    return res.json({ success: true, message: 'Profile updated successfully.', user: userWithoutPass });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Error updating profile.' });
  }
}

// Admin Initial Setup (allowed if no admin exists or with setup key)
export async function createInitialAdmin(req: Request, res: Response) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password || password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password (min 6 chars) are required.'
      });
    }

    const cleanEmail = email.trim().toLowerCase();
    const existingAdmin = memoryStore.users.find(u => u.role === 'admin' && u.email.toLowerCase() === cleanEmail);
    if (existingAdmin) {
      return res.status(400).json({
        success: false,
        message: 'Admin with this email already exists.'
      });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const adminUser = {
      id: `usr-admin-${Date.now()}`,
      name: name.trim(),
      email: cleanEmail,
      password: hashedPassword,
      role: 'admin',
      phone: '',
      addresses: [],
      createdAt: new Date().toISOString()
    };

    memoryStore.users.push(adminUser);

    const token = generateToken({
      id: adminUser.id,
      email: adminUser.email,
      role: 'admin',
      name: adminUser.name
    });

    const { password: _, ...userWithoutPass } = adminUser;
    return res.status(201).json({
      success: true,
      message: 'Admin account created successfully.',
      token,
      user: userWithoutPass
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to create admin.' });
  }
}
