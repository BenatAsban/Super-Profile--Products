import { Request, Response } from 'express';
import { memoryStore } from '../config/db.ts';

export async function getProducts(req: Request, res: Response) {
  try {
    const {
      category,
      search,
      minPrice,
      maxPrice,
      sort,
      featured,
      page = '1',
      limit = '12'
    } = req.query;

    let items = [...memoryStore.products];

    // Filter published only unless requested by admin
    const isAdmin = (req as any).user?.role === 'admin';
    if (!isAdmin) {
      items = items.filter(p => p.isPublished !== false);
    }

    // Category filter
    if (category && category !== 'all') {
      items = items.filter(p => p.category.toLowerCase() === (category as string).toLowerCase());
    }

    // Search query
    if (search) {
      const q = (search as string).toLowerCase().trim();
      items = items.filter(
        p =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          (p.tags && p.tags.some((t: string) => t.toLowerCase().includes(q))) ||
          p.category.toLowerCase().includes(q)
      );
    }

    // Featured filter
    if (featured === 'true') {
      items = items.filter(p => p.isFeatured === true);
    }

    // Price range filter
    if (minPrice) {
      const min = parseFloat(minPrice as string);
      items = items.filter(p => (p.discountPrice || p.price) >= min);
    }
    if (maxPrice) {
      const max = parseFloat(maxPrice as string);
      items = items.filter(p => (p.discountPrice || p.price) <= max);
    }

    // Sorting
    switch (sort) {
      case 'price-asc':
        items.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
        break;
      case 'price-desc':
        items.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
        break;
      case 'newest':
        items.sort((a, b) => (b.createdAt ? new Date(b.createdAt).getTime() : 0) - (a.createdAt ? new Date(a.createdAt).getTime() : 0));
        break;
      case 'rating':
        items.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'popularity':
      default:
        items.sort((a, b) => (b.numReviews || 0) - (a.numReviews || 0));
        break;
    }

    const totalCount = items.length;
    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 12;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = items.slice(startIndex, startIndex + limitNum);

    return res.json({
      success: true,
      products: paginatedItems,
      total: totalCount,
      page: pageNum,
      totalPages: Math.ceil(totalCount / limitNum)
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to fetch products.' });
  }
}

export async function getProductByIdOrSlug(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const product = memoryStore.products.find(
      p => p.id === id || p.slug === id || p._id === id
    );

    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    // Get related products from same category
    const related = memoryStore.products
      .filter(p => p.category === product.category && p.id !== product.id && p.isPublished !== false)
      .slice(0, 4);

    return res.json({
      success: true,
      product,
      related
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Error retrieving product.' });
  }
}

export async function createProduct(req: Request, res: Response) {
  try {
    const {
      title,
      description,
      category,
      price,
      discountPrice,
      images,
      stock,
      sizes,
      colors,
      tags,
      isFeatured,
      isPublished
    } = req.body;

    if (!title || !description || !category || price === undefined) {
      return res.status(400).json({ success: false, message: 'Title, description, category, and price are required.' });
    }

    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '') + '-' + Math.floor(Math.random() * 1000);

    const newProduct = {
      id: `prod-${Date.now()}`,
      title: title.trim(),
      slug,
      description: description.trim(),
      category: category.toLowerCase().trim(),
      price: Number(price),
      discountPrice: discountPrice ? Number(discountPrice) : null,
      images: Array.isArray(images) && images.length > 0 ? images : [
        'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'
      ],
      stock: Number(stock) || 0,
      sizes: Array.isArray(sizes) ? sizes : [],
      colors: Array.isArray(colors) ? colors : [],
      tags: Array.isArray(tags) ? tags : [],
      isFeatured: Boolean(isFeatured),
      isPublished: isPublished !== false,
      rating: 5.0,
      numReviews: 0,
      createdAt: new Date().toISOString()
    };

    memoryStore.products.unshift(newProduct);

    return res.status(201).json({
      success: true,
      message: 'Product created successfully.',
      product: newProduct
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to create product.' });
  }
}

export async function updateProduct(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const index = memoryStore.products.findIndex(p => p.id === id || p.slug === id);

    if (index === -1) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    const current = memoryStore.products[index];
    const updated = {
      ...current,
      ...req.body,
      id: current.id, // preserve immutable ID
      price: req.body.price !== undefined ? Number(req.body.price) : current.price,
      discountPrice: req.body.discountPrice !== undefined ? (req.body.discountPrice ? Number(req.body.discountPrice) : null) : current.discountPrice,
      stock: req.body.stock !== undefined ? Number(req.body.stock) : current.stock,
      updatedAt: new Date().toISOString()
    };

    memoryStore.products[index] = updated;

    return res.json({
      success: true,
      message: 'Product updated successfully.',
      product: updated
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to update product.' });
  }
}

export async function deleteProduct(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const index = memoryStore.products.findIndex(p => p.id === id || p.slug === id);

    if (index === -1) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    const deleted = memoryStore.products.splice(index, 1);
    return res.json({
      success: true,
      message: 'Product deleted successfully.',
      product: deleted[0]
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to delete product.' });
  }
}
