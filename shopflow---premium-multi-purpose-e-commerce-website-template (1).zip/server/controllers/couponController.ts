import { Request, Response } from 'express';
import { memoryStore } from '../config/db.ts';

export async function validateCoupon(req: Request, res: Response) {
  try {
    const { code, subtotal } = req.body;
    if (!code) {
      return res.status(400).json({ success: false, message: 'Please enter a coupon code.' });
    }

    const cleanCode = code.trim().toUpperCase();
    const coupon = memoryStore.coupons.find(c => c.code.toUpperCase() === cleanCode);

    if (!coupon) {
      return res.status(404).json({ success: false, message: 'Invalid coupon code.' });
    }

    if (coupon.isActive === false) {
      return res.status(400).json({ success: false, message: 'This coupon is currently inactive.' });
    }

    if (coupon.expiresAt && new Date(coupon.expiresAt).getTime() < Date.now()) {
      return res.status(400).json({ success: false, message: 'This coupon has expired.' });
    }

    const orderSubtotal = Number(subtotal) || 0;
    if (coupon.minOrderValue && orderSubtotal < coupon.minOrderValue) {
      return res.status(400).json({
        success: false,
        message: `This coupon requires a minimum cart value of ${memoryStore.settings.currencySymbol || '₹'}${coupon.minOrderValue}.`
      });
    }

    let discount = 0;
    if (coupon.discountType === 'percentage') {
      const calculated = Math.round((orderSubtotal * coupon.discountValue) / 100);
      discount = Math.min(calculated, coupon.maxDiscount || calculated);
    } else {
      discount = Math.min(coupon.discountValue, orderSubtotal);
    }

    return res.json({
      success: true,
      message: `Coupon "${coupon.code}" applied successfully!`,
      coupon: {
        code: coupon.code,
        discountType: coupon.discountType,
        discountValue: coupon.discountValue,
        discountAmount: discount
      }
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Error validating coupon.' });
  }
}

export async function getCoupons(req: Request, res: Response) {
  try {
    return res.json({ success: true, coupons: memoryStore.coupons });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to fetch coupons.' });
  }
}

export async function createCoupon(req: Request, res: Response) {
  try {
    const { code, discountType, discountValue, minOrderValue, maxDiscount, expiresAt } = req.body;

    if (!code || discountValue === undefined) {
      return res.status(400).json({ success: false, message: 'Coupon code and discount value are required.' });
    }

    const cleanCode = code.trim().toUpperCase();
    const existing = memoryStore.coupons.find(c => c.code.toUpperCase() === cleanCode);
    if (existing) {
      return res.status(400).json({ success: false, message: 'A coupon with this code already exists.' });
    }

    const newCoupon = {
      code: cleanCode,
      discountType: discountType || 'percentage',
      discountValue: Number(discountValue),
      minOrderValue: Number(minOrderValue) || 0,
      maxDiscount: maxDiscount ? Number(maxDiscount) : 1000,
      expiresAt: expiresAt || new Date(Date.now() + 90 * 86400000).toISOString(),
      isActive: true,
      usageCount: 0
    };

    memoryStore.coupons.unshift(newCoupon);
    return res.status(201).json({ success: true, message: 'Coupon created successfully.', coupon: newCoupon });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to create coupon.' });
  }
}

export async function toggleCoupon(req: Request, res: Response) {
  try {
    const { code } = req.params;
    const cleanCode = code.trim().toUpperCase();
    const coupon = memoryStore.coupons.find(c => c.code.toUpperCase() === cleanCode);
    if (!coupon) {
      return res.status(404).json({ success: false, message: 'Coupon not found.' });
    }

    coupon.isActive = !coupon.isActive;
    return res.json({
      success: true,
      message: `Coupon is now ${coupon.isActive ? 'active' : 'inactive'}.`,
      coupon
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to update coupon.' });
  }
}

export async function deleteCoupon(req: Request, res: Response) {
  try {
    const { code } = req.params;
    const cleanCode = code.trim().toUpperCase();
    const index = memoryStore.coupons.findIndex(c => c.code.toUpperCase() === cleanCode);
    if (index === -1) {
      return res.status(404).json({ success: false, message: 'Coupon not found.' });
    }

    const deleted = memoryStore.coupons.splice(index, 1);
    return res.json({ success: true, message: 'Coupon deleted.', coupon: deleted[0] });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to delete coupon.' });
  }
}
