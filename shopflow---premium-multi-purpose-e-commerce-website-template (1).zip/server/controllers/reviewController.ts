import { Request, Response } from 'express';
import { memoryStore } from '../config/db.ts';

export async function getProductReviews(req: Request, res: Response) {
  try {
    const { productId } = req.params;
    const reviews = memoryStore.reviews.filter(r => r.productId === productId);
    reviews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // Calculate rating breakdown
    const total = reviews.length;
    const avg = total > 0 ? reviews.reduce((sum, r) => sum + r.rating, 0) / total : 5.0;

    return res.json({
      success: true,
      reviews,
      stats: {
        average: Number(avg.toFixed(1)),
        total
      }
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to fetch reviews.' });
  }
}

export async function addReview(req: Request, res: Response) {
  try {
    const { productId, userName, userEmail, rating, comment } = req.body;

    if (!productId || !userName || !rating || !comment) {
      return res.status(400).json({
        success: false,
        message: 'Product, name, rating, and review comments are required.'
      });
    }

    const newReview = {
      id: `rev-${Date.now()}`,
      productId,
      userName: userName.trim(),
      userEmail: userEmail?.trim() || '',
      rating: Math.min(5, Math.max(1, Number(rating))),
      comment: comment.trim(),
      isVerifiedPurchase: true,
      createdAt: new Date().toISOString()
    };

    memoryStore.reviews.unshift(newReview);

    // Update product rating and numReviews
    const product = memoryStore.products.find(p => p.id === productId || p.slug === productId);
    if (product) {
      const productReviews = memoryStore.reviews.filter(r => r.productId === productId);
      const sum = productReviews.reduce((acc, r) => acc + r.rating, 0);
      product.rating = Number((sum / productReviews.length).toFixed(1));
      product.numReviews = productReviews.length;
    }

    return res.status(201).json({
      success: true,
      message: 'Thank you for your review!',
      review: newReview
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to submit review.' });
  }
}
