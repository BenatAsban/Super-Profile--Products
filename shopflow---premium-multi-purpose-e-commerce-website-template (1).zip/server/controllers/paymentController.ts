import { Request, Response } from 'express';
import crypto from 'crypto';

export async function getPaymentConfig(req: Request, res: Response) {
  const isRazorpayConfigured = Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);

  return res.json({
    success: true,
    methods: {
      cod: {
        enabled: true,
        title: "Cash on Delivery (COD)",
        description: "Pay with cash or UPI on delivery"
      },
      whatsapp: {
        enabled: true,
        title: "Order via WhatsApp",
        description: "Instant direct chat & confirmation with store owner"
      },
      razorpay: {
        enabled: isRazorpayConfigured,
        configured: isRazorpayConfigured,
        keyId: process.env.RAZORPAY_KEY_ID || null,
        title: "Online Payment (UPI, Cards, NetBanking)",
        description: isRazorpayConfigured
          ? "Fast & secure Indian payment gateway via Razorpay"
          : "Gateway not configured. Add RAZORPAY_KEY_ID in .env to activate."
      }
    }
  });
}

export async function createRazorpayOrder(req: Request, res: Response) {
  try {
    const { amount, receipt } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid payment amount.' });
    }

    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;

    if (!keyId || !keySecret) {
      // In development / demo when keys are not yet added by the buyer:
      // We return a clear message instructing the buyer or providing a simulated test session.
      return res.status(200).json({
        success: true,
        isTestMode: true,
        message: 'Razorpay keys not configured. Running in Demo Payment Mode.',
        orderId: `order_demo_${Date.now()}`,
        amount: Math.round(amount * 100),
        currency: 'INR',
        keyId: 'rzp_test_placeholder'
      });
    }

    // Call official Razorpay Orders API
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
    const response = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${auth}`
      },
      body: JSON.stringify({
        amount: Math.round(amount * 100), // amount in paise
        currency: 'INR',
        receipt: receipt || `receipt_${Date.now()}`
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        success: false,
        message: data.error?.description || 'Failed to initiate Razorpay order.'
      });
    }

    return res.json({
      success: true,
      isTestMode: false,
      orderId: data.id,
      amount: data.amount,
      currency: data.currency,
      keyId
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message || 'Payment processing failed.' });
  }
}

export async function verifyRazorpaySignature(req: Request, res: Response) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;

    if (!keySecret) {
      // Demo sandbox verification
      if (razorpay_order_id?.startsWith('order_demo_')) {
        return res.json({
          success: true,
          message: 'Demo payment confirmed.',
          verified: true
        });
      }
      return res.status(400).json({
        success: false,
        message: 'Payment verification failed: Gateway secret key not set in environment.'
      });
    }

    const body = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expectedSignature = crypto
      .createHmac('sha256', keySecret)
      .update(body.toString())
      .digest('hex');

    const isAuthentic = expectedSignature === razorpay_signature;

    if (isAuthentic) {
      return res.json({
        success: true,
        message: 'Payment successfully verified by Razorpay signature.',
        verified: true
      });
    } else {
      return res.status(400).json({
        success: false,
        message: 'Invalid signature. Gateway verification failed.',
        verified: false
      });
    }
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Signature verification error.' });
  }
}
