import { Request, Response } from 'express';
import { memoryStore } from '../config/db.ts';
import { AuthRequest } from '../middleware/auth.ts';

export async function createOrder(req: Request, res: Response) {
  try {
    const {
      customerInfo,
      items,
      couponCode,
      paymentMethod,
      notes
    } = req.body;

    if (!customerInfo || !customerInfo.name || !customerInfo.phone || !customerInfo.address) {
      return res.status(400).json({
        success: false,
        message: 'Name, phone number, and delivery address are required.'
      });
    }

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Your cart is empty. Please add items before checking out.'
      });
    }

    // Verify items and calculate subtotal
    let subtotal = 0;
    const validatedItems = [];

    for (const item of items) {
      const product = memoryStore.products.find(p => p.id === item.id || p.slug === item.id);
      const unitPrice = product ? (product.discountPrice || product.price) : Number(item.price);
      const qty = Math.max(1, Number(item.quantity) || 1);

      if (product) {
        // Check stock
        if (product.stock < qty) {
          return res.status(400).json({
            success: false,
            message: `Only ${product.stock} units available for "${product.title}". Please adjust quantity.`
          });
        }
        // Decrement stock
        product.stock = Math.max(0, product.stock - qty);
      }

      subtotal += unitPrice * qty;
      validatedItems.push({
        id: item.id,
        title: item.title || product?.title || 'Product',
        price: unitPrice,
        quantity: qty,
        size: item.size || '',
        color: item.color || '',
        image: item.image || product?.images?.[0] || ''
      });
    }

    // Validate coupon if applied
    let discount = 0;
    let appliedCoupon = null;
    if (couponCode) {
      const cleanCode = couponCode.trim().toUpperCase();
      const coupon = memoryStore.coupons.find(
        c => c.code.toUpperCase() === cleanCode && c.isActive !== false
      );

      if (coupon) {
        const isNotExpired = !coupon.expiresAt || new Date(coupon.expiresAt).getTime() > Date.now();
        const meetsMin = subtotal >= (coupon.minOrderValue || 0);

        if (isNotExpired && meetsMin) {
          appliedCoupon = coupon;
          if (coupon.discountType === 'percentage') {
            const calculated = Math.round((subtotal * coupon.discountValue) / 100);
            discount = Math.min(calculated, coupon.maxDiscount || calculated);
          } else {
            discount = Math.min(coupon.discountValue, subtotal);
          }
          coupon.usageCount = (coupon.usageCount || 0) + 1;
        }
      }
    }

    // Shipping calculation
    const settings = memoryStore.settings;
    const freeShippingThreshold = settings.freeShippingThreshold || 999;
    const shippingCharge = settings.shippingCharge || 99;
    const shipping = subtotal >= freeShippingThreshold ? 0 : shippingCharge;

    const total = Math.max(0, subtotal - discount + shipping);

    // Generate unique order ID
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const year = new Date().getFullYear();
    const orderId = `SF-${year}-${randomSuffix}`;

    // Generate courier tracking mock number
    const trackingNumber = `TRACK-${Math.floor(10000000 + Math.random() * 90000000)}`;

    const newOrder = {
      orderId,
      userId: (req as any).user?.id || null,
      customerInfo: {
        name: customerInfo.name.trim(),
        email: customerInfo.email?.trim() || '',
        phone: customerInfo.phone.trim(),
        address: customerInfo.address.trim(),
        city: customerInfo.city?.trim() || '',
        state: customerInfo.state?.trim() || '',
        pincode: customerInfo.pincode?.trim() || ''
      },
      items: validatedItems,
      subtotal,
      shipping,
      discount,
      total,
      couponCode: appliedCoupon ? appliedCoupon.code : '',
      paymentMethod: paymentMethod || 'cod',
      paymentStatus: paymentMethod === 'razorpay' ? 'paid' : 'pending',
      orderStatus: 'placed',
      trackingNumber,
      notes: notes || '',
      createdAt: new Date().toISOString()
    };

    memoryStore.orders.unshift(newOrder);

    return res.status(201).json({
      success: true,
      message: 'Order placed successfully!',
      order: newOrder
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message || 'Failed to place order.' });
  }
}

export async function getOrders(req: Request, res: Response) {
  try {
    const { status, paymentStatus, search, page = '1', limit = '10' } = req.query;

    let orders = [...memoryStore.orders];

    if (status && status !== 'all') {
      orders = orders.filter(o => o.orderStatus === status);
    }

    if (paymentStatus && paymentStatus !== 'all') {
      orders = orders.filter(o => o.paymentStatus === paymentStatus);
    }

    if (search) {
      const q = (search as string).toLowerCase().trim();
      orders = orders.filter(
        o =>
          o.orderId.toLowerCase().includes(q) ||
          o.customerInfo.name.toLowerCase().includes(q) ||
          o.customerInfo.email.toLowerCase().includes(q) ||
          o.customerInfo.phone.includes(q)
      );
    }

    // Sort newest first
    orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const totalCount = orders.length;
    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 10;
    const startIndex = (pageNum - 1) * limitNum;
    const paginated = orders.slice(startIndex, startIndex + limitNum);

    return res.json({
      success: true,
      orders: paginated,
      total: totalCount,
      page: pageNum,
      totalPages: Math.ceil(totalCount / limitNum)
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to fetch orders.' });
  }
}

export async function getOrderById(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const order = memoryStore.orders.find(o => o.orderId === id || o.id === id);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    return res.json({ success: true, order });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Error retrieving order.' });
  }
}

export async function trackOrder(req: Request, res: Response) {
  try {
    const { orderId, phone } = req.body;

    if (!orderId || !phone) {
      return res.status(400).json({
        success: false,
        message: 'Order ID and registered phone number are required.'
      });
    }

    const cleanOrderId = orderId.trim().toUpperCase();
    const cleanPhone = phone.replace(/[^0-9]/g, '');

    const order = memoryStore.orders.find(o => {
      const matchId = o.orderId.toUpperCase() === cleanOrderId;
      const orderPhone = (o.customerInfo.phone || '').replace(/[^0-9]/g, '');
      const matchPhone = orderPhone.endsWith(cleanPhone) || cleanPhone.endsWith(orderPhone);
      return matchId && matchPhone;
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'No matching order found for this Order ID and Phone number combination.'
      });
    }

    return res.json({
      success: true,
      order
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to track order.' });
  }
}

export async function getMyOrders(req: AuthRequest, res: Response) {
  try {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }

    const userOrders = memoryStore.orders.filter(
      o => o.userId === req.user?.id || o.customerInfo.email.toLowerCase() === req.user?.email.toLowerCase()
    );

    userOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return res.json({ success: true, orders: userOrders });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to fetch user orders.' });
  }
}

export async function updateOrderStatus(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const { orderStatus, trackingNumber } = req.body;

    const validStatuses = ['placed', 'confirmed', 'processing', 'shipped', 'out_for_delivery', 'delivered', 'cancelled'];
    if (!validStatuses.includes(orderStatus)) {
      return res.status(400).json({ success: false, message: 'Invalid order status value.' });
    }

    const order = memoryStore.orders.find(o => o.orderId === id || o.id === id);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    order.orderStatus = orderStatus;
    if (trackingNumber !== undefined) {
      order.trackingNumber = trackingNumber;
    }
    order.updatedAt = new Date().toISOString();

    return res.json({
      success: true,
      message: `Order status updated to "${orderStatus}".`,
      order
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to update order status.' });
  }
}

export async function updatePaymentStatus(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const { paymentStatus } = req.body;

    const validStatuses = ['pending', 'paid', 'failed'];
    if (!validStatuses.includes(paymentStatus)) {
      return res.status(400).json({ success: false, message: 'Invalid payment status value.' });
    }

    const order = memoryStore.orders.find(o => o.orderId === id || o.id === id);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    order.paymentStatus = paymentStatus;
    order.updatedAt = new Date().toISOString();

    return res.json({
      success: true,
      message: `Payment status updated to "${paymentStatus}".`,
      order
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to update payment status.' });
  }
}
