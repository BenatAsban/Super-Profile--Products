import { Request, Response } from 'express';
import { memoryStore } from '../config/db.ts';

export async function getCategories(req: Request, res: Response) {
  try {
    // augment categories with active item counts
    const categoriesWithCount = memoryStore.categories.map(cat => {
      const count = memoryStore.products.filter(p => p.category.toLowerCase() === cat.slug.toLowerCase()).length;
      return {
        ...cat,
        itemCount: count
      };
    });

    return res.json({ success: true, categories: categoriesWithCount });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to fetch categories.' });
  }
}

export async function createCategory(req: Request, res: Response) {
  try {
    const { name, image, description } = req.body;
    if (!name) {
      return res.status(400).json({ success: false, message: 'Category name is required.' });
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const exists = memoryStore.categories.some(c => c.slug === slug);
    if (exists) {
      return res.status(400).json({ success: false, message: 'Category with this name already exists.' });
    }

    const newCategory = {
      id: `cat-${Date.now()}`,
      name: name.trim(),
      slug,
      image: image || 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=80',
      description: description || ''
    };

    memoryStore.categories.push(newCategory);
    return res.status(201).json({ success: true, message: 'Category created successfully.', category: newCategory });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to create category.' });
  }
}

export async function updateCategory(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const index = memoryStore.categories.findIndex(c => c.id === id || c.slug === id);
    if (index === -1) {
      return res.status(404).json({ success: false, message: 'Category not found.' });
    }

    const current = memoryStore.categories[index];
    const updated = {
      ...current,
      ...req.body,
      id: current.id
    };

    memoryStore.categories[index] = updated;
    return res.json({ success: true, message: 'Category updated successfully.', category: updated });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to update category.' });
  }
}

export async function deleteCategory(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const index = memoryStore.categories.findIndex(c => c.id === id || c.slug === id);
    if (index === -1) {
      return res.status(404).json({ success: false, message: 'Category not found.' });
    }

    const deleted = memoryStore.categories.splice(index, 1);
    return res.json({ success: true, message: 'Category deleted.', category: deleted[0] });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: 'Failed to delete category.' });
  }
}
