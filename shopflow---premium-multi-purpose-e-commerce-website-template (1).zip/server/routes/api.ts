import { Router } from 'express';
import { requireAdmin, requireAuth } from '../middleware/auth.ts';
import * as authController from '../controllers/authController.ts';
import * as productController from '../controllers/productController.ts';
import * as categoryController from '../controllers/categoryController.ts';
import * as orderController from '../controllers/orderController.ts';
import * as couponController from '../controllers/couponController.ts';
import * as reviewController from '../controllers/reviewController.ts';
import * as settingsController from '../controllers/settingsController.ts';
import * as paymentController from '../controllers/paymentController.ts';

const router = Router();

// Health check endpoint for Render / monitoring
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'ShopFlow E-Commerce API',
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

// Authentication routes
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);
router.get('/auth/me', requireAuth, authController.getMe);
router.put('/auth/profile', requireAuth, authController.updateProfile);
router.post('/auth/init-admin', authController.createInitialAdmin);

// Product routes
router.get('/products', productController.getProducts);
router.get('/products/:id', productController.getProductByIdOrSlug);
router.post('/products', requireAdmin, productController.createProduct);
router.put('/products/:id', requireAdmin, productController.updateProduct);
router.delete('/products/:id', requireAdmin, productController.deleteProduct);

// Category routes
router.get('/categories', categoryController.getCategories);
router.post('/categories', requireAdmin, categoryController.createCategory);
router.put('/categories/:id', requireAdmin, categoryController.updateCategory);
router.delete('/categories/:id', requireAdmin, categoryController.deleteCategory);

// Order routes
router.post('/orders', orderController.createOrder);
router.get('/orders', requireAdmin, orderController.getOrders);
router.get('/orders/my-orders', requireAuth, orderController.getMyOrders);
router.post('/orders/track', orderController.trackOrder);
router.get('/orders/:id', orderController.getOrderById);
router.patch('/orders/:id/status', requireAdmin, orderController.updateOrderStatus);
router.patch('/orders/:id/payment', requireAdmin, orderController.updatePaymentStatus);

// Coupon routes
router.post('/coupons/validate', couponController.validateCoupon);
router.get('/coupons', requireAdmin, couponController.getCoupons);
router.post('/coupons', requireAdmin, couponController.createCoupon);
router.patch('/coupons/:code/toggle', requireAdmin, couponController.toggleCoupon);
router.delete('/coupons/:code', requireAdmin, couponController.deleteCoupon);

// Review routes
router.get('/reviews/:productId', reviewController.getProductReviews);
router.post('/reviews', reviewController.addReview);

// Store Settings & Admin Analytics
router.get('/settings', settingsController.getSettings);
router.put('/settings', requireAdmin, settingsController.updateSettings);
router.get('/settings/status', settingsController.getSystemStatus);
router.post('/settings/reset', requireAdmin, settingsController.resetData);
router.get('/settings/admin-stats', requireAdmin, settingsController.getAdminStats);

// Payments (Razorpay & Config)
router.get('/payment/config', paymentController.getPaymentConfig);
router.post('/payment/razorpay-order', paymentController.createRazorpayOrder);
router.post('/payment/verify-signature', paymentController.verifyRazorpaySignature);

export default router;
