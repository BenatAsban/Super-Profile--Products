import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import {
  defaultCategories,
  defaultCoupons,
  defaultOrders,
  defaultProducts,
  defaultReviews,
  defaultSettings
} from '../data/demoData.ts';

let isMongoConnected = false;
let mongoConnectionError: string | null = null;

// In-memory data store cache with pre-seeded demo records
export interface MemoryStore {
  users: any[];
  products: any[];
  categories: any[];
  orders: any[];
  coupons: any[];
  reviews: any[];
  wishlists: Record<string, string[]>;
  settings: any;
}

export const memoryStore: MemoryStore = {
  users: [],
  products: [...defaultProducts],
  categories: [...defaultCategories],
  orders: [...defaultOrders],
  coupons: [...defaultCoupons],
  reviews: [...defaultReviews],
  wishlists: {},
  settings: { ...defaultSettings }
};

// Seed default initial admin into memory store securely
export async function initDemoAdmin() {
  if (memoryStore.users.length === 0) {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('admin1234', salt);
    memoryStore.users.push({
      id: 'usr-admin-1',
      name: 'Store Admin',
      email: 'admin@shopflow.com',
      password: hashedPassword,
      role: 'admin',
      phone: '+91 98765 43210',
      addresses: [],
      createdAt: new Date().toISOString()
    });

    const customerPassword = await bcrypt.hash('customer123', salt);
    memoryStore.users.push({
      id: 'usr-demo-1',
      name: 'Rohan Verma',
      email: 'rohan@example.com',
      password: customerPassword,
      role: 'customer',
      phone: '+91 98451 22341',
      addresses: [
        {
          street: '12th Main, Indiranagar',
          city: 'Bengaluru',
          state: 'Karnataka',
          pincode: '560038',
          isDefault: true
        }
      ],
      createdAt: new Date().toISOString()
    });
  }
}

export async function connectDB(): Promise<{ isConnected: boolean; message: string }> {
  const uri = process.env.MONGODB_URI?.trim();

  // If URI is missing, blank, or contains template placeholders like <username> / <password>
  if (!uri || uri === '' || uri.includes('<username>') || uri.includes('<password>') || uri === '""') {
    isMongoConnected = false;
    mongoConnectionError = null;
    console.log('ℹ️ [ShopFlow DB] Running on embedded database with pre-seeded demo data.');
    await initDemoAdmin();
    return { isConnected: false, message: 'Running on embedded storage. Add MONGODB_URI to connect MongoDB Atlas.' };
  }

  try {
    mongoose.set('strictQuery', false);
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 3000,
      connectTimeoutMS: 3000,
    });
    isMongoConnected = true;
    mongoConnectionError = null;
    console.log('✅ [ShopFlow DB] MongoDB Atlas Connected successfully!');
    return { isConnected: true, message: 'Connected to MongoDB Atlas' };
  } catch (error: any) {
    isMongoConnected = false;
    mongoConnectionError = error?.message || 'Failed to connect to MongoDB';
    console.log(`ℹ️ [ShopFlow DB] Falling back to embedded storage (${mongoConnectionError}).`);
    try {
      await mongoose.disconnect();
    } catch {}
    await initDemoAdmin();
    return { isConnected: false, message: `MongoDB Notice: ${mongoConnectionError}. Using embedded storage.` };
  }
}

export function getDatabaseStatus() {
  return {
    isMongoConnected,
    mongoConnectionError: isMongoConnected ? null : 'Running on high-performance embedded storage (Ready for MongoDB Atlas connection)',
    activeEngine: isMongoConnected ? 'MongoDB Atlas / Mongoose' : 'Embedded In-Memory Store',
    counts: {
      products: memoryStore.products.length,
      categories: memoryStore.categories.length,
      orders: memoryStore.orders.length,
      coupons: memoryStore.coupons.length,
      users: memoryStore.users.length,
      reviews: memoryStore.reviews.length
    }
  };
}

export function resetDemoData() {
  memoryStore.products = JSON.parse(JSON.stringify(defaultProducts));
  memoryStore.categories = JSON.parse(JSON.stringify(defaultCategories));
  memoryStore.orders = JSON.parse(JSON.stringify(defaultOrders));
  memoryStore.coupons = JSON.parse(JSON.stringify(defaultCoupons));
  memoryStore.reviews = JSON.parse(JSON.stringify(defaultReviews));
  memoryStore.settings = JSON.parse(JSON.stringify(defaultSettings));
  return true;
}
