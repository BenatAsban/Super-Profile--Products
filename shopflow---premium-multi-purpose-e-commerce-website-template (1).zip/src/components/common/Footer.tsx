import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import {
  Mail,
  Phone,
  MapPin,
  Download,
  ShieldCheck,
  Truck,
  RefreshCw,
  Heart,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { generateAndDownloadProjectZip } from '../../utils/exportZip';

export const Footer: React.FC = () => {
  const { settings, showToast } = useShop();
  const [downloading, setDownloading] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      showToast('Packaging ShopFlow template ZIP file...', 'info');
      await generateAndDownloadProjectZip(settings.storeName);
      showToast('Template ZIP downloaded successfully!', 'success');
    } catch (err: any) {
      showToast('Failed to generate ZIP package.', 'error');
    } finally {
      setDownloading(false);
    }
  };

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
      showToast('Thank you! 10% coupon code: WELCOME10', 'success');
      setNewsletterEmail('');
    }
  };

  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      {/* Trust Highlights Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-slate-850">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-slate-850 flex items-center justify-center text-slate-100 shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">Free Express Shipping</h4>
              <p className="text-[11px] text-slate-400">On all orders over {settings.currencySymbol}{settings.freeShippingThreshold}</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-slate-850 flex items-center justify-center text-slate-100 shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">Secure Payments</h4>
              <p className="text-[11px] text-slate-400">UPI, NetBanking, COD & WhatsApp</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-slate-850 flex items-center justify-center text-slate-100 shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">7-Day Easy Returns</h4>
              <p className="text-[11px] text-slate-400">Hassle-free exchanges & refunds</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-slate-850 flex items-center justify-center text-slate-100 shrink-0">
              <Heart className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-semibold text-white">Handcrafted Quality</h4>
              <p className="text-[11px] text-slate-400">100% authentic curated artisan goods</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Information */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-2.5">
              {settings.logoUrl ? (
                <img src={settings.logoUrl} alt={settings.storeName} className="w-8 h-8 rounded-lg object-cover" />
              ) : (
                <div className="w-8 h-8 rounded-lg bg-white text-slate-900 flex items-center justify-center font-bold text-base">
                  S
                </div>
              )}
              <span className="font-bold text-xl tracking-tight text-white font-serif">
                {settings.storeName}
              </span>
            </Link>
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              {settings.tagline || 'Curated lifestyle, contemporary fashion, bespoke jewellery, and handmade boutique essentials.'}
            </p>

            <div className="space-y-2 text-xs text-slate-400 pt-2">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <span>{settings.address}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{settings.supportEmail}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{settings.supportPhone}</span>
              </div>
            </div>

            {/* Template Download Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleDownloadZip}
                disabled={downloading}
                className="inline-flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl text-xs font-semibold border border-slate-700 transition shadow-sm disabled:opacity-50"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>{downloading ? 'Creating ZIP Package...' : 'Download Template ZIP (Super Profile / Payhip)'}</span>
              </button>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">Shop Collections</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link to="/shop?category=fashion" className="hover:text-white transition">Fashion & Apparel</Link>
              </li>
              <li>
                <Link to="/shop?category=jewellery" className="hover:text-white transition">Fine Jewellery</Link>
              </li>
              <li>
                <Link to="/shop?category=home-decor" className="hover:text-white transition">Home Decor & Living</Link>
              </li>
              <li>
                <Link to="/shop?category=bakery" className="hover:text-white transition">Artisan Bakery & Treats</Link>
              </li>
              <li>
                <Link to="/shop?category=handmade-gifts" className="hover:text-white transition">Handmade & Gifts</Link>
              </li>
              <li>
                <Link to="/shop?category=accessories" className="hover:text-white transition">Accessories & Leather</Link>
              </li>
            </ul>
          </div>

          {/* Quick Help */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">Customer Care</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link to="/track-order" className="hover:text-white transition flex items-center gap-1.5">
                  <span>Track Your Order</span>
                </Link>
              </li>
              <li>
                <a
                  href={`https://wa.me/${settings.whatsappNumber}?text=Hi%2C%20I%20have%20an%20enquiry%20regarding%20my%20order`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition flex items-center gap-1.5 text-emerald-400"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp Support</span>
                </a>
              </li>
              <li>
                <Link to="/shop" className="hover:text-white transition">Shipping Policy</Link>
              </li>
              <li>
                <Link to="/shop" className="hover:text-white transition">Returns & Exchanges</Link>
              </li>
              <li>
                <Link to="/admin" className="hover:text-amber-400 transition text-slate-500">
                  Admin Dashboard
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter Box */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Get 10% Off</h4>
            <p className="text-xs text-slate-400">
              Subscribe to receive private sale invitations, preview drops, and artisan stories.
            </p>
            {subscribed ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-800 rounded-xl text-xs text-emerald-300 font-medium">
                🎉 Subscribed! Use coupon <strong className="text-white">WELCOME10</strong> at checkout.
              </div>
            ) : (
              <form onSubmit={handleNewsletter} className="space-y-2">
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={e => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-white"
                />
                <button
                  type="submit"
                  className="w-full py-2 px-3 bg-white text-slate-950 rounded-lg text-xs font-semibold hover:bg-slate-100 transition"
                >
                  Join VIP Circle
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Bar with Payment Icons & Copyright */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-slate-850 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <div>
          © {new Date().getFullYear()} {settings.storeName}. All rights reserved. Powered by ShopFlow E-Commerce Platform.
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[11px] bg-slate-850 px-2 py-0.5 rounded text-slate-400 font-mono">UPI</span>
          <span className="text-[11px] bg-slate-850 px-2 py-0.5 rounded text-slate-400 font-mono">RuPay</span>
          <span className="text-[11px] bg-slate-850 px-2 py-0.5 rounded text-slate-400 font-mono">Visa / MC</span>
          <span className="text-[11px] bg-slate-850 px-2 py-0.5 rounded text-slate-400 font-mono">Razorpay</span>
          <span className="text-[11px] bg-emerald-950/80 text-emerald-400 px-2 py-0.5 rounded font-mono">WhatsApp Order</span>
          <span className="text-[11px] bg-slate-850 px-2 py-0.5 rounded text-slate-400 font-mono">COD</span>
        </div>
      </div>
    </footer>
  );
};
