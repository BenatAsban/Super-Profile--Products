import React from 'react';
import { Product } from '../../types';
import { useShop } from '../../context/ShopContext';
import { Heart, Star, ShoppingBag, Eye } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, toggleWishlist, isWishlisted, formatCurrency } = useShop();
  const navigate = useNavigate();

  const wishlisted = isWishlisted(product.id);
  const hasDiscount = Boolean(product.discountPrice && product.discountPrice < product.price);
  const discountPercent = hasDiscount
    ? Math.round(((product.price - (product.discountPrice || product.price)) / product.price) * 100)
    : 0;

  const displayPrice = product.discountPrice || product.price;

  return (
    <div className="group relative bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:border-slate-300 dark:hover:border-slate-700 flex flex-col">
      {/* Product Image Area */}
      <div className="relative aspect-[4/5] bg-slate-100 dark:bg-slate-800 overflow-hidden cursor-pointer" onClick={() => navigate(`/product/${product.slug || product.id}`)}>
        <img
          src={product.images[0]}
          alt={product.title}
          loading="lazy"
          className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
        />

        {/* Hover Secondary Image if available */}
        {product.images[1] && (
          <img
            src={product.images[1]}
            alt={product.title}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover object-center opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          />
        )}

        {/* Badges Overlay */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {hasDiscount && (
            <span className="px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase bg-rose-600 text-white rounded-md shadow-sm">
              {discountPercent}% OFF
            </span>
          )}
          {product.tags?.includes('Best Seller') && (
            <span className="px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase bg-amber-500 text-white rounded-md shadow-sm">
              Best Seller
            </span>
          )}
          {product.tags?.includes('New') && (
            <span className="px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-md shadow-sm">
              New
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition shadow-sm z-10 ${
            wishlisted
              ? 'bg-rose-50 text-rose-500 dark:bg-rose-950/80 dark:text-rose-400'
              : 'bg-white/80 dark:bg-slate-900/80 text-slate-600 dark:text-slate-300 hover:text-rose-500'
          }`}
          title={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart className={`w-4 h-4 ${wishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>

        {/* Quick View Floating Action */}
        <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0 flex gap-2 z-10">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product, 1, product.sizes?.[0], product.colors?.[0]?.name);
            }}
            disabled={product.stock <= 0}
            className="flex-1 py-2 px-3 bg-slate-900/90 hover:bg-slate-900 dark:bg-white/90 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-semibold rounded-xl backdrop-blur-md shadow-lg transition flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{product.stock > 0 ? 'Quick Add' : 'Out of Stock'}</span>
          </button>
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1 font-medium">
            <span>{product.category}</span>
            {product.rating > 0 && (
              <span className="flex items-center gap-1 text-slate-700 dark:text-slate-300 font-semibold normal-case">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                {product.rating} ({product.numReviews})
              </span>
            )}
          </div>

          <Link
            to={`/product/${product.slug || product.id}`}
            className="block text-sm font-semibold text-slate-900 dark:text-white line-clamp-1 hover:text-slate-600 dark:hover:text-slate-300 transition"
          >
            {product.title}
          </Link>
        </div>

        <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-base font-bold text-slate-900 dark:text-white">
              {formatCurrency(displayPrice)}
            </span>
            {hasDiscount && (
              <span className="text-xs text-slate-400 line-through">
                {formatCurrency(product.price)}
              </span>
            )}
          </div>

          {product.stock <= 5 && product.stock > 0 && (
            <span className="text-[10px] font-semibold text-rose-500 bg-rose-50 dark:bg-rose-950/40 px-1.5 py-0.5 rounded">
              Only {product.stock} left!
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
