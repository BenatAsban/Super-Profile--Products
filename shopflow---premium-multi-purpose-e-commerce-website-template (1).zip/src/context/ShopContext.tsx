import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product, StoreSettings, User } from '../types';
import { api, getStoredToken, setStoredToken } from '../services/api';

interface AppliedCoupon {
  code: string;
  discountType: string;
  discountValue: number;
  discountAmount: number;
}

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface ShopContextType {
  settings: StoreSettings;
  setSettings: React.Dispatch<React.SetStateAction<StoreSettings>>;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, size?: string, color?: string) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, newQty: number) => void;
  clearCart: () => void;
  cartCount: number;
  subtotal: number;
  shippingFee: number;
  appliedCoupon: AppliedCoupon | null;
  applyCoupon: (code: string) => Promise<boolean>;
  removeCoupon: () => void;
  finalTotal: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  user: User | null;
  token: string | null;
  login: (email: string, pass: string) => Promise<{ success: boolean; message: string }>;
  register: (name: string, email: string, pass: string, phone?: string) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  isAdmin: boolean;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  formatCurrency: (amount: number) => string;
  generateWhatsAppLink: (orderDetails: {
    items: Array<{ title: string; price: number; quantity: number; size?: string; color?: string }>;
    total: number;
    orderId?: string;
    customerName?: string;
    address?: string;
  }) => string;
  refreshSettings: () => Promise<void>;
}

const defaultSettingsFallback: StoreSettings = {
  storeName: "ShopFlow",
  tagline: "Curated lifestyle, fashion & artisan essentials",
  logoUrl: "https://images.unsplash.com/photo-1544441893-675973e31985?w=150&auto=format&fit=crop&q=80",
  announcementText: "✨ Festive Season Sale: Get 15% OFF on orders above ₹1,499 | Use Code: FESTIVE15",
  showAnnouncement: true,
  currencySymbol: "₹",
  currencyCode: "INR",
  whatsappNumber: "919876543210",
  supportPhone: "+91 98765 43210",
  supportEmail: "hello@shopflowstore.com",
  address: "ShopFlow Studio, Indiranagar 100ft Road, Bengaluru, Karnataka 560038",
  freeShippingThreshold: 999,
  shippingCharge: 99,
  heroTitle: "Elegance in Every Detail, Curated for You.",
  heroSubtitle: "Discover handpicked contemporary fashion, bespoke jewellery, handcrafted ceramics, and delightful gifts designed for modern living.",
  heroCtaText: "Explore Collection",
  heroImageUrl: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&auto=format&fit=crop&q=80",
  primaryColor: "#0f172a",
  socialLinks: {
    instagram: "https://instagram.com",
    facebook: "https://facebook.com",
    whatsapp: "https://wa.me/919876543210",
    pinterest: "https://pinterest.com"
  }
};

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<StoreSettings>(defaultSettingsFallback);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('shopflow_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('shopflow_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedCoupon, setAppliedCoupon] = useState<AppliedCoupon | null>(() => {
    try {
      const saved = localStorage.getItem('shopflow_coupon');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(getStoredToken());
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('shopflow_theme');
      return (saved === 'dark' || saved === 'light') ? saved : 'light';
    } catch {
      return 'light';
    }
  });

  // Load store settings from backend
  const refreshSettings = async () => {
    try {
      const res = await api.getSettings();
      if (res?.settings) {
        setSettings(res.settings);
      }
    } catch (e) {
      console.warn('Using default settings fallback');
    }
  };

  useEffect(() => {
    refreshSettings();
  }, []);

  // Sync theme to HTML class
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('shopflow_theme', theme);
  }, [theme]);

  // Persist cart
  useEffect(() => {
    localStorage.setItem('shopflow_cart', JSON.stringify(cart));
  }, [cart]);

  // Persist wishlist
  useEffect(() => {
    localStorage.setItem('shopflow_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // Check auth on startup
  useEffect(() => {
    if (token) {
      api.getMe()
        .then(res => {
          if (res?.user) setUser(res.user);
        })
        .catch(() => {
          setStoredToken(null);
          setToken(null);
          setUser(null);
        });
    }
  }, [token]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const addToCart = (product: Product, quantity = 1, size?: string, color?: string) => {
    const unitPrice = product.discountPrice || product.price;
    const cartItemId = `${product.id}_${size || 'def'}_${color || 'def'}`;

    setCart(prev => {
      const existing = prev.find(item => item.id === cartItemId);
      if (existing) {
        const newQty = Math.min(existing.quantity + quantity, product.stock);
        return prev.map(item =>
          item.id === cartItemId ? { ...item, quantity: newQty } : item
        );
      } else {
        return [
          ...prev,
          {
            id: cartItemId,
            productId: product.id,
            title: product.title,
            price: unitPrice,
            quantity: Math.min(quantity, product.stock),
            size,
            color,
            image: product.images[0],
            maxStock: product.stock
          }
        ];
      }
    });

    showToast(`Added "${product.title}" to cart.`, 'success');
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
    showToast('Item removed from cart.', 'info');
  };

  const updateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart(prev =>
      prev.map(item => {
        if (item.id === cartItemId) {
          const clamped = Math.min(newQty, item.maxStock || 99);
          return { ...item, quantity: clamped };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
    localStorage.removeItem('shopflow_coupon');
  };

  const toggleWishlist = (productId: string) => {
    setWishlist(prev => {
      if (prev.includes(productId)) {
        showToast('Removed from wishlist.', 'info');
        return prev.filter(id => id !== productId);
      } else {
        showToast('Saved to wishlist!', 'success');
        return [...prev, productId];
      }
    });
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const freeThreshold = settings.freeShippingThreshold || 999;
  const standardShipping = settings.shippingCharge || 99;
  const shippingFee = subtotal >= freeThreshold || cart.length === 0 ? 0 : standardShipping;

  const discountAmount = appliedCoupon ? appliedCoupon.discountAmount : 0;
  const finalTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const applyCoupon = async (code: string): Promise<boolean> => {
    try {
      const res = await api.validateCoupon(code, subtotal);
      if (res.success && res.coupon) {
        const couponObj: AppliedCoupon = {
          code: res.coupon.code,
          discountType: res.coupon.discountType,
          discountValue: res.coupon.discountValue,
          discountAmount: res.coupon.discountAmount
        };
        setAppliedCoupon(couponObj);
        localStorage.setItem('shopflow_coupon', JSON.stringify(couponObj));
        showToast(res.message || 'Coupon applied!', 'success');
        return true;
      }
      return false;
    } catch (err: any) {
      showToast(err.message || 'Invalid coupon code', 'error');
      return false;
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    localStorage.removeItem('shopflow_coupon');
    showToast('Coupon removed.', 'info');
  };

  const login = async (email: string, pass: string) => {
    try {
      const res = await api.login({ email, password: pass });
      if (res.success && res.token) {
        setStoredToken(res.token);
        setToken(res.token);
        setUser(res.user);
        showToast(`Welcome back, ${res.user.name}!`, 'success');
        return { success: true, message: res.message };
      }
      return { success: false, message: res.message || 'Login failed' };
    } catch (err: any) {
      showToast(err.message || 'Login failed', 'error');
      return { success: false, message: err.message };
    }
  };

  const register = async (name: string, email: string, pass: string, phone?: string) => {
    try {
      const res = await api.register({ name, email, password: pass, phone });
      if (res.success && res.token) {
        setStoredToken(res.token);
        setToken(res.token);
        setUser(res.user);
        showToast(`Account created! Welcome, ${res.user.name}!`, 'success');
        return { success: true, message: res.message };
      }
      return { success: false, message: res.message || 'Registration failed' };
    } catch (err: any) {
      showToast(err.message || 'Registration failed', 'error');
      return { success: false, message: err.message };
    }
  };

  const logout = () => {
    setStoredToken(null);
    setToken(null);
    setUser(null);
    showToast('Logged out successfully.', 'info');
  };

  const formatCurrency = (amount: number) => {
    const symbol = settings.currencySymbol || '₹';
    return `${symbol}${amount.toLocaleString('en-IN')}`;
  };

  const generateWhatsAppLink = (orderDetails: {
    items: Array<{ title: string; price: number; quantity: number; size?: string; color?: string }>;
    total: number;
    orderId?: string;
    customerName?: string;
    address?: string;
  }) => {
    const rawNumber = settings.whatsappNumber || '919876543210';
    const cleanNumber = rawNumber.replace(/[^0-9]/g, '');

    const lines: string[] = [];
    lines.push(`*🛍️ NEW ORDER ENQUIRY - ${settings.storeName}*`);
    if (orderDetails.orderId) {
      lines.push(`*Order Reference:* ${orderDetails.orderId}`);
    }
    if (orderDetails.customerName) {
      lines.push(`*Customer:* ${orderDetails.customerName}`);
    }
    if (orderDetails.address) {
      lines.push(`*Delivery Address:* ${orderDetails.address}`);
    }
    lines.push('');
    lines.push('*Ordered Items:*');
    orderDetails.items.forEach((item, idx) => {
      const variantStr = [item.size, item.color].filter(Boolean).join(' | ');
      lines.push(`${idx + 1}. *${item.title}* ${variantStr ? `(${variantStr})` : ''}`);
      lines.push(`   Qty: ${item.quantity} x ${formatCurrency(item.price)} = ${formatCurrency(item.price * item.quantity)}`);
    });
    lines.push('');
    lines.push(`*Total Amount:* *${formatCurrency(orderDetails.total)}*`);
    lines.push('');
    lines.push('Hi! I would like to confirm my order. Please share payment/delivery confirmation details.');

    const encoded = encodeURIComponent(lines.join('\n'));
    return `https://wa.me/${cleanNumber}?text=${encoded}`;
  };

  return (
    <ShopContext.Provider
      value={{
        settings,
        setSettings,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartCount,
        subtotal,
        shippingFee,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        finalTotal,
        isCartOpen,
        setIsCartOpen,
        wishlist,
        toggleWishlist,
        isWishlisted,
        user,
        token,
        login,
        register,
        logout,
        isAdmin: user?.role === 'admin',
        theme,
        toggleTheme,
        toasts,
        showToast,
        formatCurrency,
        generateWhatsAppLink,
        refreshSettings
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
