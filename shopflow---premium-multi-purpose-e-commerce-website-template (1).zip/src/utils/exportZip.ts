import JSZip from 'jszip';

export async function generateAndDownloadProjectZip(storeName = 'ShopFlow') {
  const zip = new JSZip();

  // Root configuration files
  zip.file(
    'package.json',
    JSON.stringify(
      {
        name: 'shopflow-ecommerce-template',
        private: true,
        version: '1.0.0',
        type: 'module',
        scripts: {
          dev: 'tsx server.ts',
          build: 'vite build',
          start: 'NODE_ENV=production tsx server.ts',
          preview: 'vite preview',
          lint: 'tsc --noEmit'
        },
        dependencies: {
          express: '^4.21.2',
          mongoose: '^8.10.0',
          bcryptjs: '^2.4.3',
          jsonwebtoken: '^9.0.2',
          dotenv: '^17.2.3',
          react: '^19.0.1',
          'react-dom': '^19.0.1',
          'react-router-dom': '^7.2.0',
          'lucide-react': '^0.546.0',
          recharts: '^2.15.1',
          motion: '^12.23.24',
          jszip: '^3.10.1',
          '@tailwindcss/vite': '^4.3.3',
          tailwindcss: '^4.3.3',
          vite: '^8.3.0'
        },
        devDependencies: {
          '@types/express': '^4.17.21',
          '@types/node': '^22.14.0',
          '@types/react': '^19.3.0',
          '@types/react-dom': '^19.3.0',
          '@types/bcryptjs': '^2.4.6',
          '@types/jsonwebtoken': '^9.0.8',
          tsx: '^4.21.0',
          typescript: '^7.0.2'
        }
      },
      null,
      2
    )
  );

  zip.file(
    '.env.example',
    `# ==========================================
# SHOPFLOW ENVIRONMENT CONFIGURATION
# ==========================================

# Server Port (Render sets this automatically in production)
PORT=3000
NODE_ENV=development

# Database Connection (MongoDB Atlas)
# Leave blank to run with seamless embedded storage
MONGODB_URI=mongodb+srv://username:password@cluster0.abcde.mongodb.net/shopflow?retryWrites=true&w=majority

# JWT Authentication Secret Key
JWT_SECRET=super_secure_random_jwt_secret_change_me_in_production_2026

# Razorpay Online Payment Gateway (Optional - for Indian UPI & Cards)
RAZORPAY_KEY_ID=rzp_test_YourKeyIdHere
RAZORPAY_KEY_SECRET=YourRazorpaySecretKeyHere

# WhatsApp Business Order Phone Number (with Country Code, no + or spaces)
VITE_WHATSAPP_NUMBER=919876543210
`
  );

  zip.file(
    'render.yaml',
    `services:
  - type: web
    name: shopflow-ecommerce
    env: node
    plan: free
    buildCommand: npm install --legacy-peer-deps && npm run build
    startCommand: npm start
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: 10000
      - key: JWT_SECRET
        generateValue: true
      - key: MONGODB_URI
        sync: false
      - key: RAZORPAY_KEY_ID
        sync: false
      - key: RAZORPAY_KEY_SECRET
        sync: false
`
  );

  zip.file(
    '.gitignore',
    `node_modules/
dist/
.env
.DS_Store
*.log
`
  );

  zip.file(
    'README.md',
    `# 🛍️ ${storeName} - Premium E-Commerce Platform

A production-ready, full-stack E-Commerce template designed for fashion boutiques, jewellery shops, artisan bakeries, and digital storefronts.

Sold on **Super Profile** and **Payhip**.

---

## ⚡ Quick Start Guide (5 Minutes)

### 1. Install Dependencies
\`\`\`bash
npm install
\`\`\`

### 2. Configure Environment Variables
Copy \`.env.example\` to \`.env\`:
\`\`\`bash
cp .env.example .env
\`\`\`

### 3. Start Local Development Server
\`\`\`bash
npm run dev
\`\`\`
Visit **http://localhost:3000** in your browser.

---

## 🚀 1-Click Render Deployment

1. Create a free account at [render.com](https://render.com).
2. Connect your GitHub repository.
3. Choose **Web Service**.
4. Set Build Command:
   \`npm install && npm run build\`
5. Set Start Command:
   \`npm start\`
6. Add environment variables:
   - \`MONGODB_URI\`: Your MongoDB Atlas connection string
   - \`JWT_SECRET\`: Any strong 32+ character random secret
   - \`RAZORPAY_KEY_ID\` & \`RAZORPAY_KEY_SECRET\` (Optional for online payments)
7. Click **Deploy Web Service**!

---

## 🔐 Default Admin Account
- **Email:** \`admin@shopflow.com\`
- **Password:** \`admin1234\`
- **Admin Panel:** \`http://localhost:3000/admin\`

*(Be sure to update password or create your personal admin account upon deploying!)*

---

## 🌟 Key Features
- **Storefront:** Hero banners, category showcase, product grids, search, filters.
- **Product Details:** High-res gallery, size & color selectors, stock count, reviews.
- **Cart & Checkout:** Dynamic discount coupons, free shipping calculation.
- **Payment Options:** Cash on Delivery (COD), Razorpay UPI/Cards, and 1-Click WhatsApp Ordering!
- **Order Tracking:** Real-time tracking timeline by Order ID and Phone.
- **Admin Dashboard:** Revenue charts, product CRUD, inventory, order status updates, coupon management.
`
  );

  // Generate blob and trigger download
  const content = await zip.generateAsync({ type: 'blob' });
  const downloadUrl = URL.createObjectURL(content);
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = `${storeName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-template-v1.0.zip`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(downloadUrl);
}
