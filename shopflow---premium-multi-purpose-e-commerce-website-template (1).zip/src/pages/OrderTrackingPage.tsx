import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { Order } from '../types';
import { api } from '../services/api';
import {
  Truck,
  Search,
  CheckCircle2,
  Clock,
  Package,
  MapPin,
  AlertCircle,
  MessageSquare,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';

const STATUS_STEPS = [
  { key: 'placed', label: 'Order Placed', desc: 'Order received and logged' },
  { key: 'confirmed', label: 'Confirmed', desc: 'Inventory verified by seller' },
  { key: 'processing', label: 'Processing', desc: 'Carefully packaged in studio' },
  { key: 'shipped', label: 'Shipped', desc: 'Handed to courier partner' },
  { key: 'out_for_delivery', label: 'Out for Delivery', desc: 'On its way to your doorstep' },
  { key: 'delivered', label: 'Delivered', desc: 'Package safely delivered' }
];

export const OrderTrackingPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const { formatCurrency, settings } = useShop();

  const [orderId, setOrderId] = useState(searchParams.get('orderId') || '');
  const [phone, setPhone] = useState(searchParams.get('phone') || '');
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Auto-search if query params exist
  useEffect(() => {
    const qId = searchParams.get('orderId');
    const qPhone = searchParams.get('phone');
    if (qId && qPhone) {
      handleSearch(qId, qPhone);
    }
  }, [searchParams]);

  const handleSearch = async (targetId?: string, targetPhone?: string) => {
    const searchId = targetId || orderId;
    const searchPhone = targetPhone || phone;

    if (!searchId.trim() || !searchPhone.trim()) {
      setError('Please enter both your Order ID and Registered Phone number.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.trackOrder(searchId.trim(), searchPhone.trim());
      if (res.success && res.order) {
        setOrder(res.order);
      } else {
        setError('No matching order found. Please verify Order ID and Phone number.');
        setOrder(null);
      }
    } catch (err: any) {
      setError(err.message || 'Unable to track order. Please check your credentials.');
      setOrder(null);
    } finally {
      setLoading(false);
    }
  };

  const getStepIndex = (status: string) => {
    return STATUS_STEPS.findIndex(s => s.key === status);
  };

  const currentStepIndex = order ? getStepIndex(order.orderStatus) : -1;
  const isCancelled = order?.orderStatus === 'cancelled';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-white mb-2">
          <Truck className="w-6 h-6" />
        </div>
        <h1 className="text-2xl sm:text-4xl font-bold text-slate-900 dark:text-white font-serif">
          Track Your Order
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
          Enter your Order ID (e.g. <span className="font-mono text-slate-800 dark:text-slate-200">SF-2026-8941</span>) and registered phone number to view live courier status.
        </p>
      </div>

      {/* Lookup Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl max-w-xl mx-auto">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSearch();
          }}
          className="space-y-4"
        >
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Order ID
            </label>
            <input
              type="text"
              required
              value={orderId}
              onChange={e => setOrderId(e.target.value.toUpperCase())}
              placeholder="e.g. SF-2026-8941"
              className="w-full px-4 py-2.5 text-xs font-mono uppercase bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Registered Phone Number
            </label>
            <input
              type="tel"
              required
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="e.g. +91 98451 22341 or 9845122341"
              className="w-full px-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-600 dark:text-rose-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-semibold text-xs sm:text-sm hover:bg-slate-800 transition shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>Track Package</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Live Order Status Display */}
      {order && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-8 animate-fadeIn">
          {/* Header Overview */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Order Tracking Status
              </span>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white font-mono mt-0.5">
                {order.orderId}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${
                isCancelled
                  ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                  : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
              }`}>
                {order.orderStatus.replace(/_/g, ' ')}
              </span>

              <a
                href={`https://wa.me/${settings.whatsappNumber}?text=Hi!%20Checking%20status%20for%20order%20${order.orderId}`}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1 bg-emerald-600 text-white rounded-full text-xs font-semibold hover:bg-emerald-700 transition flex items-center gap-1.5 shadow-sm"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp Query</span>
              </a>
            </div>
          </div>

          {/* Cancelled Banner */}
          {isCancelled ? (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-2xl text-xs text-rose-700 dark:text-rose-300 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <div>
                <p className="font-bold">This order was cancelled.</p>
                <p className="text-[11px]">If you made an online payment, refund is processed to the source account within 5-7 business days.</p>
              </div>
            </div>
          ) : (
            /* Visual Progress Stepper Timeline */
            <div className="py-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                {STATUS_STEPS.map((step, idx) => {
                  const isCompleted = idx <= currentStepIndex;
                  const isCurrent = idx === currentStepIndex;

                  return (
                    <div
                      key={step.key}
                      className={`relative p-3.5 rounded-2xl border transition ${
                        isCurrent
                          ? 'border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800 shadow-md ring-2 ring-slate-900/10'
                          : isCompleted
                          ? 'border-emerald-200 dark:border-emerald-900 bg-emerald-50/50 dark:bg-emerald-950/20'
                          : 'border-slate-200 dark:border-slate-800 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          isCompleted
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                        }`}>
                          {isCompleted ? '✓' : idx + 1}
                        </div>
                        {isCurrent && (
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                        )}
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
                        {step.label}
                      </h4>
                      <p className="text-[10px] text-slate-500 mt-1 leading-snug">
                        {step.desc}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Courier Details & Shipping Address */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
            <div className="space-y-2">
              <h4 className="font-bold uppercase tracking-wider text-slate-400 text-[10px]">
                Courier & Waybill Info
              </h4>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-1.5">
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  Carrier: Bluedart Express / Delhivery
                </p>
                <p className="text-slate-500">
                  Tracking AWB:{' '}
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {order.trackingNumber || 'SF-AWB-8891244'}
                  </span>
                </p>
                <p className="text-emerald-600 dark:text-emerald-400 font-medium pt-1">
                  Estimated Delivery: 2 to 4 business days
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold uppercase tracking-wider text-slate-400 text-[10px]">
                Destination Address
              </h4>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-1 text-slate-600 dark:text-slate-300">
                <p className="font-bold text-slate-900 dark:text-white">{order.customerInfo.name}</p>
                <p>{order.customerInfo.address}</p>
                <p>{order.customerInfo.city}, {order.customerInfo.state} - {order.customerInfo.pincode}</p>
                <p className="text-slate-400 pt-1">Phone: {order.customerInfo.phone}</p>
              </div>
            </div>
          </div>

          {/* Ordered Line Items */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold uppercase tracking-wider text-slate-400 text-[10px]">
              Shipment Contents ({order.items.length} items)
            </h4>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {order.items.map((item, idx) => (
                <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    {item.image && (
                      <img
                        src={item.image}
                        alt=""
                        className="w-10 h-10 rounded-lg object-cover bg-slate-100 dark:bg-slate-800 shrink-0"
                      />
                    )}
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-white">{item.title}</p>
                      <p className="text-[11px] text-slate-400">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {formatCurrency(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
