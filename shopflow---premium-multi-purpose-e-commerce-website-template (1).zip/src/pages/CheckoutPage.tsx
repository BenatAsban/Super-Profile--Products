import React, { useState, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import {
  CreditCard,
  Truck,
  MessageSquare,
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  Sparkles
} from 'lucide-react';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    clearCart,
    subtotal,
    shippingFee,
    appliedCoupon,
    finalTotal,
    formatCurrency,
    settings,
    user,
    showToast,
    generateWhatsAppLink
  } = useShop();

  const navigate = useNavigate();

  // Form Fields
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [address, setAddress] = useState(user?.addresses?.[0]?.street || '');
  const [city, setCity] = useState(user?.addresses?.[0]?.city || '');
  const [state, setState] = useState(user?.addresses?.[0]?.state || 'Karnataka');
  const [pincode, setPincode] = useState(user?.addresses?.[0]?.pincode || '');
  const [notes, setNotes] = useState('');

  // Payment Selection: 'cod' | 'razorpay' | 'whatsapp'
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'razorpay' | 'whatsapp'>('cod');
  const [paymentConfig, setPaymentConfig] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Razorpay Test Modal state
  const [showRazorpayModal, setShowRazorpayModal] = useState(false);
  const [pendingRazorpayOrder, setPendingRazorpayOrder] = useState<any>(null);
  const [simulatingPayment, setSimulatingPayment] = useState(false);

  useEffect(() => {
    if (cart.length === 0) {
      navigate('/cart');
    }
  }, [cart, navigate]);

  useEffect(() => {
    async function loadPaymentConfig() {
      try {
        const res = await api.getPaymentConfig();
        if (res?.methods) {
          setPaymentConfig(res.methods);
        }
      } catch (e) {
        console.warn('Could not load payment configuration');
      }
    }
    loadPaymentConfig();
  }, []);

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim() || !phone.trim() || !address.trim() || !pincode.trim()) {
      setError('Please complete all mandatory delivery details.');
      return;
    }

    if (pincode.trim().length !== 6 || !/^\d+$/.test(pincode.trim())) {
      setError('Please enter a valid 6-digit Indian PIN code.');
      return;
    }

    setLoading(true);

    try {
      if (paymentMethod === 'razorpay') {
        // Initiate Razorpay payment flow
        const rzpRes = await api.createRazorpayOrder(finalTotal, `rcpt_${Date.now()}`);
        if (!rzpRes.success) {
          throw new Error(rzpRes.message || 'Failed to initiate Razorpay transaction.');
        }

        // Store order context and trigger Razorpay checkout modal
        setPendingRazorpayOrder(rzpRes);
        setShowRazorpayModal(true);
        setLoading(false);
        return;
      }

      // COD or WhatsApp order creation
      const orderPayload = {
        customerInfo: {
          name: name.trim(),
          email: email.trim() || 'customer@shopflow.com',
          phone: phone.trim(),
          address: address.trim(),
          city: city.trim() || 'Bengaluru',
          state: state.trim() || 'Karnataka',
          pincode: pincode.trim()
        },
        items: cart,
        couponCode: appliedCoupon?.code,
        paymentMethod,
        notes
      };

      const res = await api.createOrder(orderPayload);
      if (res.success && res.order) {
        clearCart();

        if (paymentMethod === 'whatsapp') {
          // Open WhatsApp with complete order summary and navigate to confirmation
          const waUrl = generateWhatsAppLink({
            items: cart,
            total: finalTotal,
            orderId: res.order.orderId,
            customerName: name.trim(),
            address: `${address.trim()}, ${city.trim()} - ${pincode.trim()}`
          });
          window.open(waUrl, '_blank');
        }

        showToast('Order confirmed successfully!', 'success');
        navigate(`/order-confirmation/${res.order.orderId}`);
      } else {
        throw new Error(res.message || 'Failed to create order.');
      }
    } catch (err: any) {
      setError(err.message || 'Order submission error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Callback after Razorpay payment verification succeeds
  const completeRazorpayOrder = async (isSuccess: boolean) => {
    if (!isSuccess) {
      setShowRazorpayModal(false);
      showToast('Payment was cancelled or failed.', 'error');
      return;
    }

    setSimulatingPayment(true);
    try {
      const orderPayload = {
        customerInfo: {
          name: name.trim(),
          email: email.trim() || 'customer@shopflow.com',
          phone: phone.trim(),
          address: address.trim(),
          city: city.trim() || 'Bengaluru',
          state: state.trim() || 'Karnataka',
          pincode: pincode.trim()
        },
        items: cart,
        couponCode: appliedCoupon?.code,
        paymentMethod: 'razorpay',
        notes: `Paid via Razorpay. Ref: ${pendingRazorpayOrder?.orderId}`
      };

      const res = await api.createOrder(orderPayload);
      if (res.success && res.order) {
        clearCart();
        setShowRazorpayModal(false);
        showToast('Payment verified! Order placed successfully.', 'success');
        navigate(`/order-confirmation/${res.order.orderId}`);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to finalize verified order.');
      setShowRazorpayModal(false);
    } finally {
      setSimulatingPayment(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="pb-6 border-b border-slate-200 dark:border-slate-800 mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white font-serif">
          Secure Checkout
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Provide your delivery details and choose your preferred payment option
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-xs sm:text-sm text-rose-600 dark:text-rose-400 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Delivery & Payment Details (7 cols on lg) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Step 1: Customer Contact Information */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <span className="w-6 h-6 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold flex items-center justify-center">
                1
              </span>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Contact & Customer Information
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Aditi Rao"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Mobile Number *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="e.g. +91 98451 22341"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address (For invoice & order updates)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="aditi@example.com"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Step 2: Delivery Address */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <span className="w-6 h-6 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold flex items-center justify-center">
                2
              </span>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Delivery Address
              </h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  House / Flat No., Street, Landmark *
                </label>
                <textarea
                  rows={2}
                  required
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="Flat 301, Sunshine Heights, 12th Main Road"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    placeholder="Bengaluru"
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    State *
                  </label>
                  <input
                    type="text"
                    required
                    value={state}
                    onChange={e => setState(e.target.value)}
                    placeholder="Karnataka"
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    PIN Code (6 digits) *
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    value={pincode}
                    onChange={e => setPincode(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="560038"
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Order Notes / Delivery Instructions (Optional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. Leave with gate security or call before delivery"
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Step 3: Payment Method Selection */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <span className="w-6 h-6 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-bold flex items-center justify-center">
                3
              </span>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Payment Option
              </h3>
            </div>

            <div className="space-y-3">
              {/* Option 1: Cash on Delivery */}
              <label
                className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition ${
                  paymentMethod === 'cod'
                    ? 'border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'cod'}
                  onChange={() => setPaymentMethod('cod')}
                  className="mt-1 text-slate-900 focus:ring-0"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 font-semibold text-xs sm:text-sm text-slate-900 dark:text-white">
                    <Truck className="w-4 h-4 text-slate-700 dark:text-slate-300" />
                    <span>Cash on Delivery (COD)</span>
                    <span className="bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] px-2 py-0.5 rounded font-bold">
                      Zero Advance
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Pay safely at your doorstep using cash or UPI upon delivery.
                  </p>
                </div>
              </label>

              {/* Option 2: Online Payment / Razorpay */}
              <label
                className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition ${
                  paymentMethod === 'razorpay'
                    ? 'border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'razorpay'}
                  onChange={() => setPaymentMethod('razorpay')}
                  className="mt-1 text-slate-900 focus:ring-0"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 font-semibold text-xs sm:text-sm text-slate-900 dark:text-white">
                    <CreditCard className="w-4 h-4 text-slate-700 dark:text-slate-300" />
                    <span>Online Payment (UPI, Credit/Debit Cards, NetBanking)</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Secure gateway powered by Razorpay.
                    {!paymentConfig?.razorpay?.configured && (
                      <span className="block text-[11px] text-amber-600 dark:text-amber-400 mt-0.5">
                        (Demo Mode Active: Sandbox simulator enabled for testing until owner sets RAZORPAY_KEY_ID in .env)
                      </span>
                    )}
                  </p>
                </div>
              </label>

              {/* Option 3: WhatsApp Order */}
              <label
                className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition ${
                  paymentMethod === 'whatsapp'
                    ? 'border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  checked={paymentMethod === 'whatsapp'}
                  onChange={() => setPaymentMethod('whatsapp')}
                  className="mt-1 text-slate-900 focus:ring-0"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 font-semibold text-xs sm:text-sm text-slate-900 dark:text-white">
                    <MessageSquare className="w-4 h-4 text-emerald-600" />
                    <span>Order via WhatsApp Chat</span>
                    <span className="bg-emerald-500 text-white text-[10px] px-2 py-0.5 rounded font-bold">
                      Direct Support
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Generates a pre-filled WhatsApp message sent straight to the store owner's WhatsApp number for instant confirmation.
                  </p>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Order Review Sidebar (5 cols on lg) */}
        <div className="lg:col-span-5 space-y-5">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Order Review ({cart.reduce((s, i) => s + i.quantity, 0)} items)
            </h3>

            {/* Compact items list */}
            <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 pr-1 space-y-2">
              {cart.map(item => (
                <div key={item.id} className="pt-2 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={item.image}
                      alt=""
                      className="w-10 h-10 rounded-lg object-cover bg-slate-100 dark:bg-slate-800 shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="font-semibold text-slate-900 dark:text-white truncate">{item.title}</p>
                      <p className="text-[11px] text-slate-400">
                        Qty: {item.quantity} {item.size ? `• Size: ${item.size}` : ''}
                      </p>
                    </div>
                  </div>
                  <span className="font-bold text-slate-900 dark:text-white shrink-0">
                    {formatCurrency(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            {/* Totals Breakdown */}
            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 pt-3 border-t border-slate-200 dark:border-slate-800">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-slate-900 dark:text-white">{formatCurrency(subtotal)}</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-medium">
                  <span>Coupon Discount ({appliedCoupon.code})</span>
                  <span>-{formatCurrency(appliedCoupon.discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Shipping Fee</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {shippingFee === 0 ? <span className="text-emerald-600 font-bold">FREE</span> : formatCurrency(shippingFee)}
                </span>
              </div>
              <div className="flex justify-between text-base font-bold text-slate-900 dark:text-white pt-3 border-t border-slate-200 dark:border-slate-700">
                <span>Total to Pay</span>
                <span>{formatCurrency(finalTotal)}</span>
              </div>
            </div>

            {/* Place Order CTA Button */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 px-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold text-sm hover:bg-slate-800 dark:hover:bg-slate-100 transition shadow-xl flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <span className="inline-block w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>
                      {paymentMethod === 'cod' && 'Confirm Cash on Delivery Order'}
                      {paymentMethod === 'razorpay' && 'Pay & Confirm Order Online'}
                      {paymentMethod === 'whatsapp' && 'Proceed to WhatsApp Order'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 pt-1">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>256-Bit SSL Encrypted & Verified Checkout</span>
            </div>
          </div>
        </div>
      </form>

      {/* Razorpay Simulation / Online Payment Modal */}
      {showRazorpayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-5">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
                <CreditCard className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Razorpay Online Payment
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Ref: {pendingRazorpayOrder?.orderId || 'rzp_order_demo'}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-center space-y-1">
              <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Amount to Pay</p>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                {formatCurrency(finalTotal)}
              </h2>
            </div>

            <div className="text-xs text-slate-500 space-y-2">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-medium">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>Supports UPI (Google Pay, PhonePe, Paytm), All Bank Cards & NetBanking.</span>
              </div>
              <p className="text-[11px] text-slate-400 italic">
                * Note: In demo sandbox environments without live merchant keys, clicking "Simulate Success" simulates an official verified webhook response.
              </p>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => completeRazorpayOrder(false)}
                className="flex-1 py-2.5 px-3 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={simulatingPayment}
                onClick={() => completeRazorpayOrder(true)}
                className="flex-1 py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {simulatingPayment ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Simulate Success</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
