import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { Product, Category } from '../types';
import { api } from '../services/api';
import { ProductCard } from '../components/product/ProductCard';
import { Search, SlidersHorizontal, ArrowUpDown, X, Check, Sparkles } from 'lucide-react';

export const ShopPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { formatCurrency } = useShop();

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter states from searchParams or defaults
  const activeCategory = searchParams.get('category') || 'all';
  const searchQuery = searchParams.get('search') || '';
  const sortOption = searchParams.get('sort') || 'popularity';
  const [inStockOnly, setInStockOnly] = useState(false);
  const [priceRange, setPriceRange] = useState<number>(5000);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  useEffect(() => {
    async function fetchCatalog() {
      try {
        setLoading(true);
        const [prodRes, catRes] = await Promise.all([
          api.getProducts({
            category: activeCategory !== 'all' ? activeCategory : undefined,
            search: searchQuery || undefined,
            sort: sortOption,
            limit: 50
          }),
          api.getCategories()
        ]);

        if (prodRes?.products) {
          setProducts(prodRes.products);
        }
        if (catRes?.categories) {
          setCategories(catRes.categories);
        }
      } catch (err) {
        console.error('Failed to load shop catalog:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchCatalog();
  }, [activeCategory, searchQuery, sortOption]);

  const updateParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value && value !== 'all') {
      next.set(key, value);
    } else {
      next.delete(key);
    }
    setSearchParams(next);
  };

  const clearAllFilters = () => {
    setSearchParams(new URLSearchParams());
    setInStockOnly(false);
    setPriceRange(5000);
  };

  // Client-side quick filter for price & inStock
  const filteredProducts = products.filter(p => {
    const price = p.discountPrice || p.price;
    if (price > priceRange) return false;
    if (inStockOnly && p.stock <= 0) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Page Title & Search Bar Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white font-serif">
            {activeCategory !== 'all'
              ? categories.find(c => c.slug === activeCategory)?.name || 'Curated Collection'
              : 'All Products'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Showing {filteredProducts.length} items crafted with detail
          </p>
        </div>

        {/* Live Search and Sort Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => updateParam('search', e.target.value)}
              placeholder="Search products..."
              className="w-full pl-9 pr-8 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white"
            />
            {searchQuery && (
              <button
                onClick={() => updateParam('search', '')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <select
              value={sortOption}
              onChange={e => updateParam('sort', e.target.value)}
              className="py-2 px-3 text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none"
            >
              <option value="popularity">Sort: Most Popular</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
              <option value="newest">Newest Arrivals</option>
            </select>

            <button
              type="button"
              onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
              className="md:hidden p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <SlidersHorizontal className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pt-8">
        {/* Sidebar Filters */}
        <aside className={`md:block space-y-6 ${mobileFilterOpen ? 'block' : 'hidden'}`}>
          {/* Categories Filter */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Categories</h3>
            <div className="flex flex-col space-y-1">
              <button
                type="button"
                onClick={() => updateParam('category', 'all')}
                className={`text-left px-3 py-2 rounded-xl text-xs font-medium transition flex items-center justify-between ${
                  activeCategory === 'all'
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span>All Collections</span>
                <span>{products.length}</span>
              </button>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => updateParam('category', cat.slug)}
                  className={`text-left px-3 py-2 rounded-xl text-xs font-medium transition flex items-center justify-between ${
                    activeCategory === cat.slug
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold shadow-sm'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <span>{cat.name}</span>
                  <span className="text-[11px] opacity-70">{cat.itemCount || ''}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs font-semibold mb-2">
              <span className="text-slate-700 dark:text-slate-300">Max Price</span>
              <span className="text-slate-900 dark:text-white font-bold">{formatCurrency(priceRange)}</span>
            </div>
            <input
              type="range"
              min={500}
              max={5000}
              step={100}
              value={priceRange}
              onChange={e => setPriceRange(Number(e.target.value))}
              className="w-full accent-slate-900 dark:accent-white cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>{formatCurrency(500)}</span>
              <span>{formatCurrency(5000)}</span>
            </div>
          </div>

          {/* In-Stock Only */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={e => setInStockOnly(e.target.checked)}
                className="w-4 h-4 rounded text-slate-900 focus:ring-0 dark:bg-slate-800 border-slate-300 dark:border-slate-700"
              />
              <span>In-Stock Items Only</span>
            </label>
          </div>

          {/* Reset Filters */}
          {(activeCategory !== 'all' || searchQuery || inStockOnly || priceRange < 5000) && (
            <button
              type="button"
              onClick={clearAllFilters}
              className="w-full py-2 px-3 text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 rounded-xl hover:bg-rose-100 transition"
            >
              Clear All Filters
            </button>
          )}
        </aside>

        {/* Product Catalog Grid */}
        <div className="md:col-span-3">
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="aspect-[4/5] bg-slate-200 dark:bg-slate-800 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-20 px-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-4 text-slate-400">
                <Search className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                No matching products found
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mb-6">
                Try loosening your filters, adjusting the price slider, or searching with another keyword.
              </p>
              <button
                type="button"
                onClick={clearAllFilters}
                className="px-5 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold hover:bg-slate-800 transition"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
              {filteredProducts.map(prod => (
                <ProductCard key={prod.id} product={prod} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
