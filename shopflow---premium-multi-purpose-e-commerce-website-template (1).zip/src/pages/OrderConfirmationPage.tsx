import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { Order } from '../types';
import { api } from '../services/api';
import {
  CheckCircle2,
  Package,
  Truck,
  MessageSquare,
  Printer,
  ArrowRight,
  ShieldCheck,
  Calendar,
  CreditCard
} from 'lucide-react';

export const OrderConfirmationPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { formatCurrency, settings, generateWhatsAppLink } = useShop();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadOrder() {
      if (!id) return;
      try {
        setLoading(true);
        const res = await api.getOrder(id);
        if (res?.order) {
          setOrder(res.order);
        }
      } catch (err) {
        console.error('Failed to retrieve order:', err);
      } finally {
        setLoading(false);
      }
    }
    loadOrder();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center animate-pulse">
        <div className="w-16 h-16 bg-slate-200 dark:bg-slate-800 rounded-full mx-auto mb-4" />
        <div className="h-6 bg-slate-200 dark:bg-slate-800 rounded-lg w-1/2 mx-auto mb-3" />
        <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded-lg w-1/3 mx-auto" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Order Not Found</h2>
        <p className="text-xs text-slate-500 mb-6">Could not locate order details for reference "{id}".</p>
        <Link
          to="/"
          className="px-5 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold"
        >
          Return to Storefront
        </Link>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  const whatsappChatUrl = `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent(
    `Hi! I have placed order ${order.orderId} on ${settings.storeName}. Customer: ${order.customerInfo.name}. Could you confirm delivery timeline?`
  )}`;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-8">
      {/* Celebration Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 mb-1 shadow-lg ring-8 ring-emerald-50 dark:ring-emerald-950/30">
          <CheckCircle2 className="w-9 h-9" />
        </div>
        <h1 className="text-2xl sm:text-4xl font-bold text-slate-900 dark:text-white font-serif">
          Thank You! Your Order is Confirmed
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
          We have received your order <strong className="text-slate-900 dark:text-white font-mono">{order.orderId}</strong> and are preparing it with care.
        </p>

        {/* Action Pills */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
          <Link
            to={`/track-order?orderId=${order.orderId}&phone=${encodeURIComponent(order.customerInfo.phone)}`}
            className="px-5 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold hover:bg-slate-800 transition shadow-sm flex items-center gap-2"
          >
            <Truck className="w-4 h-4" />
            <span>Track Order Status</span>
          </Link>

          <a
            href={whatsappChatUrl}
            target="_blank"
            rel="noreferrer"
            className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-semibold hover:bg-emerald-700 transition shadow-sm flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Chat on WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-2.5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold hover:bg-slate-50 transition flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            <span>Print Receipt</span>
          </button>
        </div>
      </div>

      {/* Order Summary Receipt Box */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        {/* Meta Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-6 border-b border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">Order Reference</span>
            <span className="font-bold text-slate-900 dark:text-white font-mono text-sm">{order.orderId}</span>
          </div>

          <div>
            <span className="text-slate-400 block text-[11px]">Order Date</span>
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              {new Date(order.createdAt).toLocaleDateString('en-IN', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
              })}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block text-[11px]">Payment Mode</span>
            <span className="font-semibold text-slate-800 dark:text-slate-200 uppercase">
              {order.paymentMethod === 'cod' && 'Cash on Delivery'}
              {order.paymentMethod === 'razorpay' && 'Razorpay (Paid)'}
              {order.paymentMethod === 'whatsapp' && 'WhatsApp Enquiry'}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block text-[11px]">Order Status</span>
            <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
              {order.orderStatus.replace(/_/g, ' ')}
            </span>
          </div>
        </div>

        {/* Customer & Shipping Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pb-6 border-b border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <h4 className="font-bold uppercase tracking-wider text-slate-400 text-[10px] mb-2">
              Delivery Address
            </h4>
            <div className="space-y-1 text-slate-700 dark:text-slate-300">
              <p className="font-bold text-slate-900 dark:text-white text-sm">{order.customerInfo.name}</p>
              <p>{order.customerInfo.address}</p>
              <p>{order.customerInfo.city}, {order.customerInfo.state} - {order.customerInfo.pincode}</p>
              <p className="text-slate-500 pt-1">Phone: {order.customerInfo.phone}</p>
            </div>
          </div>

          <div>
            <h4 className="font-bold uppercase tracking-wider text-slate-400 text-[10px] mb-2">
              Shipping & Courier Info
            </h4>
            <div className="space-y-1 text-slate-700 dark:text-slate-300">
              <p className="font-semibold text-slate-900 dark:text-white">Express Delivery (Bluedart / Delhivery)</p>
              <p className="text-slate-500">
                Tracking Number:{' '}
                <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                  {order.trackingNumber || 'Assigned on dispatch'}
                </span>
              </p>
              <p className="text-emerald-600 dark:text-emerald-400 font-medium pt-1">
                Estimated Delivery: 2 to 4 business days
              </p>
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="space-y-3">
          <h4 className="font-bold uppercase tracking-wider text-slate-400 text-[10px]">
            Ordered Items
          </h4>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {order.items.map((item, idx) => (
              <div key={idx} className="py-3 flex items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-3 min-w-0">
                  {item.image && (
                    <img
                      src={item.image}
                      alt=""
                      className="w-12 h-12 rounded-lg object-cover bg-slate-100 dark:bg-slate-800 shrink-0"
                    />
                  )}
                  <div className="min-w-0">
                    <p className="font-bold text-slate-900 dark:text-white truncate">{item.title}</p>
                    <p className="text-[11px] text-slate-400">
                      Qty: {item.quantity} {item.size ? `• Size: ${item.size}` : ''} {item.color ? `• Color: ${item.color}` : ''}
                    </p>
                  </div>
                </div>

                <span className="font-bold text-slate-900 dark:text-white shrink-0">
                  {formatCurrency(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Totals Breakdown */}
        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2 text-xs text-slate-600 dark:text-slate-300">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span className="font-semibold text-slate-900 dark:text-white">{formatCurrency(order.subtotal)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-medium">
              <span>Discount {order.couponCode ? `(${order.couponCode})` : ''}</span>
              <span>-{formatCurrency(order.discount)}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span>Shipping</span>
            <span className="font-semibold text-slate-900 dark:text-white">
              {order.shipping === 0 ? <span className="text-emerald-600 font-bold">FREE</span> : formatCurrency(order.shipping)}
            </span>
          </div>
          <div className="flex justify-between text-base font-bold text-slate-900 dark:text-white pt-3 border-t border-slate-200 dark:border-slate-700">
            <span>Total Paid / Payable</span>
            <span>{formatCurrency(order.total)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
