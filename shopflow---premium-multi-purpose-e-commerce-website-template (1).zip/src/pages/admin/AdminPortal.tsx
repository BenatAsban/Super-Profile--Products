import React, { useState, useEffect } from 'react';
import { useShop } from '../../context/ShopContext';
import { Product, Order, Coupon, User, Category } from '../../types';
import { api } from '../../services/api';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  Users,
  Tag,
  Settings,
  Download,
  Plus,
  Trash2,
  Edit2,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Eye,
  RefreshCw,
  Search,
  Check,
  X,
  ExternalLink,
  ShieldCheck,
  Server,
  Database,
  ArrowUpRight,
  Filter
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { generateAndDownloadProjectZip } from '../../utils/exportZip';
import { Link } from 'react-router-dom';

type AdminTab = 'overview' | 'products' | 'orders' | 'customers' | 'coupons' | 'settings' | 'export';

export const AdminPortal: React.FC = () => {
  const { user, isAdmin, settings, setSettings, formatCurrency, showToast, refreshSettings } = useShop();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [stats, setStats] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [systemStatus, setSystemStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Modals & form state
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showAddCouponModal, setShowAddCouponModal] = useState(false);
  const [selectedOrderForView, setSelectedOrderForView] = useState<Order | null>(null);

  // Product Form State
  const [productForm, setProductForm] = useState({
    title: '',
    category: 'fashion',
    price: 1499,
    discountPrice: 999,
    description: '',
    stock: 20,
    images: ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80'],
    sizes: 'S, M, L, XL',
    colors: 'Vintage Charcoal, Sand Dune',
    tags: 'Best Seller, New',
    isFeatured: true,
    isPublished: true
  });

  // Coupon Form State
  const [couponForm, setCouponForm] = useState({
    code: '',
    discountType: 'percentage',
    discountValue: 15,
    minOrderValue: 999,
    maxDiscount: 500,
    expiresAt: ''
  });

  // Settings Form State
  const [settingsForm, setSettingsForm] = useState({ ...settings });

  // Filters for orders & products
  const [orderStatusFilter, setOrderStatusFilter] = useState('all');
  const [productCategoryFilter, setProductCategoryFilter] = useState('all');
  const [adminSearch, setAdminSearch] = useState('');

  // Initial load
  const loadAdminData = async () => {
    try {
      setLoading(true);
      const [statsRes, prodRes, ordersRes, catRes, coupRes, sysRes] = await Promise.all([
        api.getAdminStats(),
        api.getProducts({ limit: 100 }),
        api.getOrders({ limit: 100 }),
        api.getCategories(),
        api.getCoupons(),
        api.getSystemStatus()
      ]);

      if (statsRes?.stats) setStats(statsRes.stats);
      if (prodRes?.products) setProducts(prodRes.products);
      if (ordersRes?.orders) setOrders(ordersRes.orders);
      if (catRes?.categories) setCategories(catRes.categories);
      if (coupRes?.coupons) setCoupons(coupRes.coupons);
      if (sysRes) setSystemStatus(sysRes);
    } catch (err) {
      console.error('Error loading admin portal:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  useEffect(() => {
    setSettingsForm({ ...settings });
  }, [settings]);

  // Product Save (Create or Update)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        title: productForm.title,
        category: productForm.category,
        price: Number(productForm.price),
        discountPrice: productForm.discountPrice ? Number(productForm.discountPrice) : null,
        description: productForm.description,
        stock: Number(productForm.stock),
        images: productForm.images,
        sizes: productForm.sizes ? productForm.sizes.split(',').map(s => s.trim()).filter(Boolean) : [],
        colors: productForm.colors
          ? productForm.colors.split(',').map(c => ({ name: c.trim(), hex: '#1e293b' }))
          : [],
        tags: productForm.tags ? productForm.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
        isFeatured: productForm.isFeatured,
        isPublished: productForm.isPublished
      };

      if (editingProduct) {
        const res = await api.updateProduct(editingProduct.id, payload);
        if (res.success) {
          showToast('Product updated successfully!', 'success');
        }
      } else {
        const res = await api.createProduct(payload);
        if (res.success) {
          showToast('New product added to store catalog!', 'success');
        }
      }
      setShowAddProductModal(false);
      setEditingProduct(null);
      loadAdminData();
    } catch (err: any) {
      showToast(err.message || 'Error saving product', 'error');
    }
  };

  const handleEditProduct = (p: Product) => {
    setEditingProduct(p);
    setProductForm({
      title: p.title,
      category: p.category,
      price: p.price,
      discountPrice: p.discountPrice || 0,
      description: p.description,
      stock: p.stock,
      images: p.images.length > 0 ? p.images : ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80'],
      sizes: p.sizes?.join(', ') || '',
      colors: p.colors?.map(c => c.name).join(', ') || '',
      tags: p.tags?.join(', ') || '',
      isFeatured: p.isFeatured,
      isPublished: p.isPublished
    });
    setShowAddProductModal(true);
  };

  const handleDeleteProduct = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      try {
        await api.deleteProduct(id);
        showToast('Product deleted.', 'info');
        loadAdminData();
      } catch (err: any) {
        showToast('Failed to delete product', 'error');
      }
    }
  };

  // Order Status Update
  const handleUpdateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const res = await api.updateOrderStatus(orderId, newStatus);
      if (res.success) {
        showToast(`Order status updated to ${newStatus}`, 'success');
        loadAdminData();
      }
    } catch (err: any) {
      showToast('Failed to update order status', 'error');
    }
  };

  // Payment Status Update
  const handleUpdatePaymentStatus = async (orderId: string, newPaymentStatus: string) => {
    try {
      const res = await api.updatePaymentStatus(orderId, newPaymentStatus);
      if (res.success) {
        showToast(`Payment status updated to ${newPaymentStatus}`, 'success');
        loadAdminData();
      }
    } catch (err: any) {
      showToast('Failed to update payment status', 'error');
    }
  };

  // Coupon Creation
  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createCoupon(couponForm);
      if (res.success) {
        showToast('Coupon created successfully!', 'success');
        setShowAddCouponModal(false);
        setCouponForm({
          code: '',
          discountType: 'percentage',
          discountValue: 15,
          minOrderValue: 999,
          maxDiscount: 500,
          expiresAt: ''
        });
        loadAdminData();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to create coupon', 'error');
    }
  };

  const handleToggleCoupon = async (code: string) => {
    try {
      const res = await api.toggleCoupon(code);
      if (res.success) {
        showToast(res.message, 'success');
        loadAdminData();
      }
    } catch (err: any) {
      showToast('Failed to update coupon', 'error');
    }
  };

  const handleDeleteCoupon = async (code: string) => {
    if (window.confirm(`Delete coupon "${code}"?`)) {
      try {
        await api.deleteCoupon(code);
        showToast('Coupon deleted', 'info');
        loadAdminData();
      } catch (err: any) {
        showToast('Failed to delete coupon', 'error');
      }
    }
  };

  // Save Store Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.updateSettings(settingsForm);
      if (res.success) {
        setSettings(res.settings);
        showToast('Store settings saved successfully!', 'success');
        refreshSettings();
      }
    } catch (err: any) {
      showToast('Failed to save settings', 'error');
    }
  };

  // Reset demo data
  const handleResetData = async () => {
    if (window.confirm('Reset all catalog, coupons, and orders back to factory demo defaults?')) {
      try {
        await api.resetDemoData();
        showToast('Demo store data reset to factory defaults.', 'success');
        loadAdminData();
        refreshSettings();
      } catch (err: any) {
        showToast('Failed to reset demo data', 'error');
      }
    }
  };

  // Filtered lists
  const filteredProducts = products.filter(p => {
    if (productCategoryFilter !== 'all' && p.category !== productCategoryFilter) return false;
    if (adminSearch && !p.title.toLowerCase().includes(adminSearch.toLowerCase())) return false;
    return true;
  });

  const filteredOrders = orders.filter(o => {
    if (orderStatusFilter !== 'all' && o.orderStatus !== orderStatusFilter) return false;
    if (
      adminSearch &&
      !o.orderId.toLowerCase().includes(adminSearch.toLowerCase()) &&
      !o.customerInfo.name.toLowerCase().includes(adminSearch.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col">
      {/* Top Admin Header Bar */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4 sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-2 group">
            <span className="w-8 h-8 rounded-lg bg-amber-500 text-white font-bold flex items-center justify-center font-serif text-base shadow-sm">
              S
            </span>
            <div>
              <span className="font-bold text-sm sm:text-base text-slate-900 dark:text-white font-serif block leading-tight">
                ShopFlow Admin
              </span>
              <span className="text-[10px] text-slate-400">Store Management & Deployment Control</span>
            </div>
          </Link>

          <span className="hidden md:inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
            {systemStatus?.database?.activeEngine || 'Active'}
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={loadAdminData}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Refresh Admin Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            type="button"
            onClick={() => generateAndDownloadProjectZip(settings.storeName)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold hover:bg-slate-800 transition shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Export Template ZIP</span>
          </button>

          <Link
            to="/"
            className="inline-flex items-center gap-1 px-3 py-1.5 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold hover:bg-slate-50 transition"
          >
            <span>Live Storefront</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>
        </div>
      </header>

      {/* Main Admin Workspace */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar Nav */}
        <aside className="w-full md:w-60 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 p-4 space-y-1.5 shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'overview'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'products'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <Package className="w-4 h-4" />
              <span>Products & Stock</span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              {products.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'orders'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <ShoppingBag className="w-4 h-4" />
              <span>Order Fulfillment</span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold">
              {orders.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'customers'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Customers</span>
          </button>

          <button
            onClick={() => setActiveTab('coupons')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'coupons'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <Tag className="w-4 h-4" />
              <span>Discount Coupons</span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              {coupons.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'settings'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Store Customizer</span>
          </button>

          <button
            onClick={() => setActiveTab('export')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition ${
              activeTab === 'export'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Download className="w-4 h-4 text-emerald-500" />
            <span>Template Export & Deploy</span>
          </button>
        </aside>

        {/* Tab Content Panels */}
        <main className="flex-1 p-4 sm:p-8 overflow-y-auto space-y-6">
          {/* TAB 1: OVERVIEW DASHBOARD */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* KPI Cards Row */}
              <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Total Revenue</span>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                    {formatCurrency(stats?.totalRevenue || 128450)}
                  </h3>
                  <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1 mt-1">
                    <TrendingUp className="w-3 h-3" /> +18.4% this month
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Total Orders</span>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                    {stats?.totalOrders || orders.length}
                  </h3>
                  <span className="text-[10px] text-slate-400 block mt-1">All time fulfilled</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Catalog Products</span>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                    {products.length}
                  </h3>
                  <span className="text-[10px] text-slate-400 block mt-1">Active items</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Pending Orders</span>
                  <h3 className="text-xl sm:text-2xl font-black text-amber-500 mt-1">
                    {stats?.pendingOrders || 2}
                  </h3>
                  <span className="text-[10px] text-amber-600 font-semibold block mt-1">Requires dispatch</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Low Stock Alert</span>
                  <h3 className="text-xl sm:text-2xl font-black text-rose-500 mt-1">
                    {stats?.lowStockCount || products.filter(p => p.stock < 10).length}
                  </h3>
                  <span className="text-[10px] text-rose-500 font-semibold block mt-1">&lt; 10 units left</span>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Total Customers</span>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                    {stats?.totalCustomers || 48}
                  </h3>
                  <span className="text-[10px] text-emerald-600 font-semibold block mt-1">Registered + guests</span>
                </div>
              </div>

              {/* Recharts Analytics Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Monthly Revenue Trend Chart (8 cols) */}
                <div className="lg:col-span-8 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">Revenue & Sales Trajectory</h3>
                      <p className="text-[11px] text-slate-400">Monthly gross sales volume (INR)</p>
                    </div>
                    <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-lg">
                      Healthy Growth
                    </span>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={stats?.salesChartData || []}>
                        <defs>
                          <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#0f172a" stopOpacity={0.8} />
                            <stop offset="95%" stopColor="#0f172a" stopOpacity={0.0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                        <XAxis dataKey="name" fontSize={11} stroke="#94a3b8" />
                        <YAxis fontSize={11} stroke="#94a3b8" tickFormatter={v => `₹${v / 1000}k`} />
                        <Tooltip
                          formatter={(value: any) => [`₹${Number(value).toLocaleString()}`, 'Revenue']}
                          contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                        />
                        <Area type="monotone" dataKey="revenue" stroke="#f59e0b" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRev)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Orders by Status Breakdown (4 cols) */}
                <div className="lg:col-span-4 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">Fulfillment Status</h3>
                    <p className="text-[11px] text-slate-400">Orders categorized by lifecycle phase</p>
                  </div>

                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stats?.orderStatusBreakdown || []}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                        <XAxis dataKey="name" fontSize={9} stroke="#94a3b8" />
                        <YAxis fontSize={11} stroke="#94a3b8" allowDecimals={false} />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                        />
                        <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Best Selling Products Mini Table */}
              <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">Top Performing Products</h3>
                  <button onClick={() => setActiveTab('products')} className="text-xs text-amber-500 font-semibold hover:underline">
                    Manage All Products
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400">
                        <th className="pb-3 font-semibold">Product</th>
                        <th className="pb-3 font-semibold">Price</th>
                        <th className="pb-3 font-semibold">Stock</th>
                        <th className="pb-3 font-semibold">Units Sold</th>
                        <th className="pb-3 font-semibold">Gross Sales</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {(stats?.topProducts || products.slice(0, 5)).map((p: any) => (
                        <tr key={p.id}>
                          <td className="py-3 flex items-center gap-3">
                            <img src={p.image || p.images?.[0]} alt="" className="w-9 h-9 rounded-lg object-cover bg-slate-100 shrink-0" />
                            <span className="font-semibold text-slate-900 dark:text-white max-w-xs truncate">{p.title}</span>
                          </td>
                          <td className="py-3 font-bold">{formatCurrency(p.price || p.discountPrice)}</td>
                          <td className="py-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${p.stock < 10 ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-800'}`}>
                              {p.stock} in stock
                            </span>
                          </td>
                          <td className="py-3 text-slate-600 dark:text-slate-300 font-medium">{p.sold || 34}</td>
                          <td className="py-3 font-bold text-slate-900 dark:text-white">{formatCurrency(p.revenue || (p.price * 34))}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PRODUCTS MANAGEMENT */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white font-serif">Product Inventory</h2>
                  <p className="text-xs text-slate-500">Add, edit, adjust stock, manage variants and toggle featured items</p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setEditingProduct(null);
                    setProductForm({
                      title: '',
                      category: 'fashion',
                      price: 1499,
                      discountPrice: 999,
                      description: '',
                      stock: 20,
                      images: ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80'],
                      sizes: 'S, M, L, XL',
                      colors: 'Vintage Charcoal, Sand Dune',
                      tags: 'Best Seller, New',
                      isFeatured: true,
                      isPublished: true
                    });
                    setShowAddProductModal(true);
                  }}
                  className="px-4 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold hover:bg-slate-800 transition shadow-sm flex items-center gap-1.5 self-start sm:self-auto"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product</span>
                </button>
              </div>

              {/* Filters Bar */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative flex-1 sm:w-64">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={adminSearch}
                    onChange={e => setAdminSearch(e.target.value)}
                    placeholder="Search products by title..."
                    className="w-full pl-9 pr-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <select
                  value={productCategoryFilter}
                  onChange={e => setProductCategoryFilter(e.target.value)}
                  className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none"
                >
                  <option value="all">All Categories</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.slug}>{c.name}</option>
                  ))}
                </select>
              </div>

              {/* Products Table */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 uppercase text-[10px] tracking-wider">
                      <tr>
                        <th className="px-4 py-3">Product</th>
                        <th className="px-4 py-3">Category</th>
                        <th className="px-4 py-3">Price</th>
                        <th className="px-4 py-3">Stock</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {filteredProducts.map(p => (
                        <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition">
                          <td className="px-4 py-3 flex items-center gap-3">
                            <img src={p.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0" />
                            <div>
                              <p className="font-bold text-slate-900 dark:text-white line-clamp-1">{p.title}</p>
                              <div className="flex gap-1 text-[10px] text-slate-400 mt-0.5">
                                {p.isFeatured && <span className="text-amber-500 font-bold">★ Featured</span>}
                                {p.tags?.length > 0 && <span>• {p.tags.join(', ')}</span>}
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 uppercase font-semibold text-[11px] text-slate-600 dark:text-slate-300">
                            {p.category}
                          </td>
                          <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                            {formatCurrency(p.discountPrice || p.price)}
                            {p.discountPrice && (
                              <span className="text-[10px] text-slate-400 line-through block font-normal">
                                {formatCurrency(p.price)}
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                              p.stock < 10
                                ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            }`}>
                              {p.stock} in stock
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              p.isPublished
                                ? 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200'
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {p.isPublished ? 'Published' : 'Draft'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right space-x-1">
                            <button
                              onClick={() => handleEditProduct(p)}
                              className="p-1.5 text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                              title="Edit product"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(p.id)}
                              className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition"
                              title="Delete product"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ORDER FULFILLMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white font-serif">Order Management</h2>
                  <p className="text-xs text-slate-500">Track shipments, update statuses, monitor payment gateways, and view delivery details</p>
                </div>
              </div>

              {/* Filters Bar */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative flex-1 sm:w-64">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={adminSearch}
                    onChange={e => setAdminSearch(e.target.value)}
                    placeholder="Search by Order ID or customer name..."
                    className="w-full pl-9 pr-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <select
                  value={orderStatusFilter}
                  onChange={e => setOrderStatusFilter(e.target.value)}
                  className="px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none"
                >
                  <option value="all">All Statuses</option>
                  <option value="placed">Placed</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="processing">Processing</option>
                  <option value="shipped">Shipped</option>
                  <option value="out_for_delivery">Out for Delivery</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              {/* Orders Table */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 uppercase text-[10px] tracking-wider">
                      <tr>
                        <th className="px-4 py-3">Order ID</th>
                        <th className="px-4 py-3">Customer</th>
                        <th className="px-4 py-3">Items</th>
                        <th className="px-4 py-3">Total</th>
                        <th className="px-4 py-3">Payment</th>
                        <th className="px-4 py-3">Order Status</th>
                        <th className="px-4 py-3 text-right">Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {filteredOrders.map(o => (
                        <tr key={o.orderId} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition">
                          <td className="px-4 py-3 font-mono font-bold text-slate-900 dark:text-white">
                            {o.orderId}
                            <span className="text-[10px] text-slate-400 block font-sans">
                              {new Date(o.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <p className="font-semibold text-slate-900 dark:text-white">{o.customerInfo.name}</p>
                            <p className="text-[10px] text-slate-400">{o.customerInfo.phone}</p>
                          </td>
                          <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                            {o.items.length} items
                          </td>
                          <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                            {formatCurrency(o.total)}
                          </td>
                          <td className="px-4 py-3">
                            <select
                              value={o.paymentStatus}
                              onChange={e => handleUpdatePaymentStatus(o.orderId, e.target.value)}
                              className="text-[11px] font-semibold bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 uppercase"
                            >
                              <option value="pending">Pending</option>
                              <option value="paid">Paid</option>
                              <option value="failed">Failed</option>
                            </select>
                            <span className="text-[10px] text-slate-400 uppercase block mt-0.5">
                              {o.paymentMethod}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <select
                              value={o.orderStatus}
                              onChange={e => handleUpdateOrderStatus(o.orderId, e.target.value)}
                              className="text-[11px] font-semibold bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1 uppercase"
                            >
                              <option value="placed">Placed</option>
                              <option value="confirmed">Confirmed</option>
                              <option value="processing">Processing</option>
                              <option value="shipped">Shipped</option>
                              <option value="out_for_delivery">Out for Delivery</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              onClick={() => setSelectedOrderForView(o)}
                              className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-semibold transition"
                            >
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CUSTOMERS */}
          {activeTab === 'customers' && (
            <div className="space-y-6">
              <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white font-serif">Customer Directory</h2>
                <p className="text-xs text-slate-500">Contact information, purchase histories, and registered accounts</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {orders.map((o, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2 text-xs">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-bold flex items-center justify-center font-serif text-sm">
                        {o.customerInfo.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm">{o.customerInfo.name}</h4>
                        <p className="text-slate-400 text-[11px]">{o.customerInfo.email}</p>
                      </div>
                    </div>
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1 text-slate-600 dark:text-slate-300">
                      <p>Phone: <strong className="text-slate-900 dark:text-white">{o.customerInfo.phone}</strong></p>
                      <p>City: {o.customerInfo.city}, {o.customerInfo.state}</p>
                      <p>Recent Order: <span className="font-mono">{o.orderId}</span> ({formatCurrency(o.total)})</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: DISCOUNT COUPONS */}
          {activeTab === 'coupons' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white font-serif">Discount Vouchers & Promotions</h2>
                  <p className="text-xs text-slate-500">Create percentage discounts, flat cashbacks, minimum order value limits, and expirations</p>
                </div>
                <button
                  onClick={() => setShowAddCouponModal(true)}
                  className="px-4 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold hover:bg-slate-800 transition shadow-sm flex items-center gap-1.5 self-start sm:self-auto"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Coupon</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {coupons.map(c => (
                  <div
                    key={c.code}
                    className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-black text-base text-slate-900 dark:text-white px-2.5 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                        {c.code}
                      </span>
                      <button
                        onClick={() => handleToggleCoupon(c.code)}
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase transition ${
                          c.isActive
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        {c.isActive ? 'Active' : 'Paused'}
                      </button>
                    </div>

                    <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                      <p>
                        Discount:{' '}
                        <strong className="text-slate-900 dark:text-white">
                          {c.discountType === 'percentage' ? `${c.discountValue}% OFF` : `${formatCurrency(c.discountValue)} FLAT OFF`}
                        </strong>
                      </p>
                      <p>Min. Cart Value: {formatCurrency(c.minOrderValue || 0)}</p>
                      <p>Usage Count: {c.usageCount || 0} times applied</p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                      <button
                        onClick={() => handleDeleteCoupon(c.code)}
                        className="text-xs text-rose-500 hover:underline flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: STORE SETTINGS CUSTOMIZER */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-4xl">
              <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white font-serif">Store Configuration & Customizer</h2>
                <p className="text-xs text-slate-500">Every buyer can independently brand their store name, WhatsApp business number, shipping, and banner copy</p>
              </div>

              <form onSubmit={handleSaveSettings} className="space-y-6">
                {/* Brand Identity */}
                <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">Store Identity</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Store Name</label>
                      <input
                        type="text"
                        value={settingsForm.storeName}
                        onChange={e => setSettingsForm({ ...settingsForm, storeName: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Tagline</label>
                      <input
                        type="text"
                        value={settingsForm.tagline}
                        onChange={e => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Logo Image URL</label>
                      <input
                        type="url"
                        value={settingsForm.logoUrl}
                        onChange={e => setSettingsForm({ ...settingsForm, logoUrl: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                  </div>
                </div>

                {/* WhatsApp & Contact Details */}
                <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">WhatsApp & Contact Channels</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        WhatsApp Business Number (with country code, no + or spaces)
                      </label>
                      <input
                        type="text"
                        value={settingsForm.whatsappNumber}
                        onChange={e => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })}
                        placeholder="919876543210"
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Support Email</label>
                      <input
                        type="email"
                        value={settingsForm.supportEmail}
                        onChange={e => setSettingsForm({ ...settingsForm, supportEmail: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Phone Number</label>
                      <input
                        type="text"
                        value={settingsForm.supportPhone}
                        onChange={e => setSettingsForm({ ...settingsForm, supportPhone: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Store Address</label>
                      <input
                        type="text"
                        value={settingsForm.address}
                        onChange={e => setSettingsForm({ ...settingsForm, address: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                  </div>
                </div>

                {/* Shipping & Currency */}
                <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">Currency & Shipping Policy</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Currency Symbol</label>
                      <input
                        type="text"
                        value={settingsForm.currencySymbol}
                        onChange={e => setSettingsForm({ ...settingsForm, currencySymbol: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Free Shipping Threshold</label>
                      <input
                        type="number"
                        value={settingsForm.freeShippingThreshold}
                        onChange={e => setSettingsForm({ ...settingsForm, freeShippingThreshold: Number(e.target.value) })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Standard Shipping Charge</label>
                      <input
                        type="number"
                        value={settingsForm.shippingCharge}
                        onChange={e => setSettingsForm({ ...settingsForm, shippingCharge: Number(e.target.value) })}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                  </div>
                </div>

                {/* Announcement Bar */}
                <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">Announcement Banner</h3>
                    <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settingsForm.showAnnouncement}
                        onChange={e => setSettingsForm({ ...settingsForm, showAnnouncement: e.target.checked })}
                      />
                      <span>Show Banner</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    value={settingsForm.announcementText}
                    onChange={e => setSettingsForm({ ...settingsForm, announcementText: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div className="flex items-center justify-between pt-4">
                  <button
                    type="button"
                    onClick={handleResetData}
                    className="px-4 py-2 border border-rose-300 text-rose-600 dark:text-rose-400 rounded-xl text-xs font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                  >
                    Reset Demo Catalog to Factory Defaults
                  </button>

                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold hover:bg-slate-800 transition shadow-md"
                  >
                    Save All Changes
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 7: TEMPLATE EXPORT & DEPLOYMENT GUIDE */}
          {activeTab === 'export' && (
            <div className="space-y-6 max-w-4xl">
              <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
                <h2 className="text-xl font-bold text-slate-900 dark:text-white font-serif">Export & Independent Deployment</h2>
                <p className="text-xs text-slate-500">How to sell this template on Super Profile / Payhip, and instructions for buyers to host on Render and MongoDB Atlas</p>
              </div>

              {/* Instant Download Card */}
              <div className="p-8 rounded-3xl bg-gradient-to-r from-slate-900 to-amber-950 text-white shadow-xl space-y-4">
                <span className="px-3 py-1 bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold uppercase rounded-lg">
                  Ready for Commercial Distribution
                </span>
                <h3 className="text-2xl font-bold font-serif">
                  Download Ready-to-Sell ZIP Archive
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
                  Generates an instantly distributable ZIP archive with complete frontend, backend, models, render.yaml, .env.example, sample products, and complete documentation ready to upload as a digital product on Super Profile and Payhip.
                </p>
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => generateAndDownloadProjectZip(settings.storeName)}
                    className="px-6 py-3 bg-white text-slate-900 rounded-xl font-bold text-xs sm:text-sm hover:bg-slate-100 transition shadow-lg inline-flex items-center gap-2"
                  >
                    <Download className="w-4 h-4 text-emerald-600" />
                    <span>Download Complete ShopFlow ZIP (v1.0)</span>
                  </button>
                </div>
              </div>

              {/* Step-by-Step Render Deployment Guide */}
              <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Server className="w-4 h-4 text-amber-500" />
                  <span>Render 1-Click Deployment Instructions (For Buyers)</span>
                </h3>

                <ol className="list-decimal list-inside space-y-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  <li>Extract the downloaded ZIP file and upload the repository to your personal <strong>GitHub</strong> account.</li>
                  <li>Log in to <a href="https://render.com" target="_blank" rel="noreferrer" className="text-blue-600 underline font-semibold">Render.com</a> and click <strong>New +</strong> &gt; <strong>Web Service</strong>.</li>
                  <li>Connect your GitHub repository.</li>
                  <li>Set the following build & start configurations:
                    <div className="mt-1 p-3 bg-slate-900 text-slate-100 rounded-xl font-mono text-[11px] space-y-1">
                      <p>Build Command: <code>npm install && npm run build</code></p>
                      <p>Start Command: <code>npm start</code></p>
                    </div>
                  </li>
                  <li>In <strong>Environment Variables</strong>, provide:
                    <div className="mt-1 p-3 bg-slate-900 text-slate-100 rounded-xl font-mono text-[11px] space-y-1">
                      <p><code>NODE_ENV = production</code></p>
                      <p><code>MONGODB_URI = mongodb+srv://...</code> (Your MongoDB Atlas connection string)</p>
                      <p><code>JWT_SECRET = your_32_character_secret</code></p>
                      <p><code>RAZORPAY_KEY_ID = rzp_live_...</code> (Optional)</p>
                      <p><code>RAZORPAY_KEY_SECRET = ...</code> (Optional)</p>
                    </div>
                  </li>
                  <li>Click <strong>Create Web Service</strong>. Render will build and deploy your store live in ~2 minutes!</li>
                </ol>
              </div>

              {/* MongoDB Atlas Connectivity Info */}
              <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-500" />
                  <span>MongoDB Atlas Connection Status</span>
                </h3>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs space-y-1">
                  <p><strong>Active Storage Engine:</strong> {systemStatus?.database?.activeEngine}</p>
                  <p><strong>Status Message:</strong> {systemStatus?.database?.isMongoConnected ? '✅ Connected to remote MongoDB Atlas' : '⚡ Local in-memory persistence active (Add MONGODB_URI to connect Atlas)'}</p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ADD / EDIT PRODUCT MODAL */}
      {showAddProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h3>
              <button
                onClick={() => setShowAddProductModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Product Title *</label>
                <input
                  type="text"
                  required
                  value={productForm.title}
                  onChange={e => setProductForm({ ...productForm, title: e.target.value })}
                  placeholder="e.g. 18K Gold Plated Celestial Necklace"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Category *</label>
                  <select
                    value={productForm.category}
                    onChange={e => setProductForm({ ...productForm, category: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.slug}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Regular Price (INR) *</label>
                  <input
                    type="number"
                    required
                    value={productForm.price}
                    onChange={e => setProductForm({ ...productForm, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Discount Price (INR)</label>
                  <input
                    type="number"
                    value={productForm.discountPrice || ''}
                    onChange={e => setProductForm({ ...productForm, discountPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Stock Units *</label>
                <input
                  type="number"
                  required
                  value={productForm.stock}
                  onChange={e => setProductForm({ ...productForm, stock: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Image URLs (comma separated) *</label>
                <input
                  type="text"
                  required
                  value={productForm.images.join(', ')}
                  onChange={e => setProductForm({ ...productForm, images: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })}
                  placeholder="https://images.unsplash.com/..., https://..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Sizes (comma separated)</label>
                  <input
                    type="text"
                    value={productForm.sizes}
                    onChange={e => setProductForm({ ...productForm, sizes: e.target.value })}
                    placeholder="S, M, L, XL"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Colours (comma separated)</label>
                  <input
                    type="text"
                    value={productForm.colors}
                    onChange={e => setProductForm({ ...productForm, colors: e.target.value })}
                    placeholder="Black, Gold, Ivory"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Description *</label>
                <textarea
                  rows={3}
                  required
                  value={productForm.description}
                  onChange={e => setProductForm({ ...productForm, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 cursor-pointer font-semibold">
                  <input
                    type="checkbox"
                    checked={productForm.isFeatured}
                    onChange={e => setProductForm({ ...productForm, isFeatured: e.target.checked })}
                  />
                  <span>Mark as Featured</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-semibold">
                  <input
                    type="checkbox"
                    checked={productForm.isPublished}
                    onChange={e => setProductForm({ ...productForm, isPublished: e.target.checked })}
                  />
                  <span>Publish to Storefront</span>
                </label>
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddProductModal(false)}
                  className="flex-1 py-2 px-3 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-semibold hover:bg-slate-800"
                >
                  {editingProduct ? 'Save Product Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE COUPON MODAL */}
      {showAddCouponModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-6 sm:p-8 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Create New Coupon</h3>
              <button onClick={() => setShowAddCouponModal(false)} className="p-1.5 text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCoupon} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Coupon Code *</label>
                <input
                  type="text"
                  required
                  value={couponForm.code}
                  onChange={e => setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })}
                  placeholder="e.g. FLASH20"
                  className="w-full px-3 py-2 uppercase font-mono font-bold bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Discount Type</label>
                  <select
                    value={couponForm.discountType}
                    onChange={e => setCouponForm({ ...couponForm, discountType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount (₹)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Discount Value *</label>
                  <input
                    type="number"
                    required
                    value={couponForm.discountValue}
                    onChange={e => setCouponForm({ ...couponForm, discountValue: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Min Order Value</label>
                  <input
                    type="number"
                    value={couponForm.minOrderValue}
                    onChange={e => setCouponForm({ ...couponForm, minOrderValue: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Max Discount Cap</label>
                  <input
                    type="number"
                    value={couponForm.maxDiscount}
                    onChange={e => setCouponForm({ ...couponForm, maxDiscount: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddCouponModal(false)}
                  className="flex-1 py-2 px-3 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 px-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-semibold"
                >
                  Create Coupon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW ORDER DETAIL MODAL */}
      {selectedOrderForView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl p-6 sm:p-8 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white font-mono">
                  {selectedOrderForView.orderId}
                </h3>
                <span className="text-[10px] text-slate-400">Order Details & Fulfillment</span>
              </div>
              <button onClick={() => setSelectedOrderForView(null)} className="p-1.5 text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-xl space-y-1">
                <p className="font-bold text-slate-900 dark:text-white">{selectedOrderForView.customerInfo.name}</p>
                <p>{selectedOrderForView.customerInfo.phone} • {selectedOrderForView.customerInfo.email}</p>
                <p>{selectedOrderForView.customerInfo.address}, {selectedOrderForView.customerInfo.city} - {selectedOrderForView.customerInfo.pincode}</p>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {selectedOrderForView.items.map((item, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-white">{item.title}</p>
                      <p className="text-[11px] text-slate-400">Qty: {item.quantity}</p>
                    </div>
                    <span className="font-bold">{formatCurrency(item.price * item.quantity)}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between font-bold text-sm">
                <span>Grand Total</span>
                <span>{formatCurrency(selectedOrderForView.total)}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
