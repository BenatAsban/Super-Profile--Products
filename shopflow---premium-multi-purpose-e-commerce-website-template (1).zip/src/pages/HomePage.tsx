import React, { useEffect, useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Product, Category } from '../types';
import { api } from '../services/api';
import { ProductCard } from '../components/product/ProductCard';
import {
  ArrowRight,
  Sparkles,
  ShoppingBag,
  Star,
  ShieldCheck,
  Truck,
  Heart,
  MessageSquare,
  Gift,
  ChevronRight
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export const HomePage: React.FC = () => {
  const { settings, formatCurrency } = useShop();
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [bestSellers, setBestSellers] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function loadHomeData() {
      try {
        setLoading(true);
        const [prodRes, catRes] = await Promise.all([
          api.getProducts({ limit: 12 }),
          api.getCategories()
        ]);

        if (prodRes?.products) {
          setFeaturedProducts(prodRes.products.filter(p => p.isFeatured));
          setBestSellers(prodRes.products.slice(0, 4));
        }
        if (catRes?.categories) {
          setCategories(catRes.categories);
        }
      } catch (err) {
        console.error('Error loading home data:', err);
      } finally {
        setLoading(false);
      }
    }
    loadHomeData();
  }, []);

  return (
    <div className="space-y-16 sm:space-y-24 pb-16">
      {/* Hero Banner Section */}
      <section className="relative overflow-hidden bg-slate-100 dark:bg-slate-900 border-b border-slate-200/80 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Copy & CTAs */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/5 dark:bg-white/10 text-slate-800 dark:text-slate-200 text-xs font-semibold backdrop-blur-sm">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>New Seasonal Collection Drop</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 dark:text-white font-serif leading-[1.15]">
                {settings.heroTitle || 'Elegance in Every Detail, Curated for You.'}
              </h1>

              <p className="text-sm sm:text-base lg:text-lg text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
                {settings.heroSubtitle ||
                  'Discover handpicked contemporary fashion, bespoke jewellery, handcrafted ceramics, and delightful gifts designed for modern living.'}
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
                <Link
                  to="/shop"
                  className="w-full sm:w-auto px-7 py-3.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-semibold text-sm hover:bg-slate-800 dark:hover:bg-slate-100 transition shadow-lg flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{settings.heroCtaText || 'Explore Collection'}</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <a
                  href={`https://wa.me/${settings.whatsappNumber}?text=Hi!%20I%20am%20browsing%20${settings.storeName}%20and%20would%20love%20recommendations!`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold text-sm transition shadow-md flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp Enquiries</span>
                </a>
              </div>

              {/* Mini Social Proof */}
              <div className="pt-6 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-500 dark:text-slate-400">
                <div className="flex items-center gap-1.5">
                  <div className="flex text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">4.9/5 Rating</span>
                </div>
                <span>•</span>
                <span>Over 12,000+ Happy Customers</span>
                <span>•</span>
                <span>Free Shipping over {formatCurrency(settings.freeShippingThreshold)}</span>
              </div>
            </div>

            {/* Right Column: Hero Showcase Visual */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800 relative">
                  <img
                    src={settings.heroImageUrl || 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&auto=format&fit=crop&q=80'}
                    alt="Hero Showcase"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                  <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-white/40 shadow-xl flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Special Promo</p>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">Use Coupon FESTIVE15</h4>
                    </div>
                    <span className="px-3 py-1 bg-amber-500 text-white rounded-lg text-xs font-bold shadow-sm">
                      15% OFF
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Curated Spaces</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white font-serif mt-1">
              Shop by Category
            </h2>
          </div>
          <Link
            to="/shop"
            className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white hover:underline flex items-center gap-1 self-start sm:self-auto"
          >
            <span>View All Collections</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map(cat => (
            <Link
              key={cat.id}
              to={`/shop?category=${cat.slug}`}
              className="group relative rounded-2xl overflow-hidden aspect-[3/4] bg-slate-100 dark:bg-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-200/60 dark:border-slate-800 flex flex-col justify-end p-4"
            >
              <img
                src={cat.image}
                alt={cat.name}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent group-hover:from-black/90 transition" />
              <div className="relative z-10 text-white">
                <h3 className="font-bold text-sm sm:text-base leading-snug drop-shadow-sm">{cat.name}</h3>
                <p className="text-[11px] text-slate-300 mt-0.5">{cat.itemCount || 0} Products</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Editor's Choice</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white font-serif mt-1">
              Featured Highlights
            </h2>
          </div>
          <Link
            to="/shop"
            className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white hover:underline flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Explore All</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="aspect-[4/5] bg-slate-200 dark:bg-slate-800 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
            {featuredProducts.slice(0, 8).map(prod => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        )}
      </section>

      {/* Promotional Banner Card */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950 p-8 sm:p-14 text-white shadow-2xl">
          <div className="relative z-10 max-w-xl space-y-4">
            <span className="inline-block px-3 py-1 bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-bold uppercase tracking-wider rounded-lg">
              Limited Period Offer
            </span>
            <h3 className="text-2xl sm:text-4xl font-bold font-serif leading-tight">
              Enjoy 15% OFF on orders over {formatCurrency(1499)}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Upgrade your wardrobe, home styling, and gifting with premium handcrafted treasures. Use coupon code <strong className="text-white font-mono bg-white/10 px-2 py-0.5 rounded">FESTIVE15</strong> during checkout.
            </p>
            <div className="pt-2">
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 px-6 py-3 bg-white text-slate-900 rounded-xl font-semibold text-xs sm:text-sm hover:bg-slate-100 transition shadow-lg"
              >
                <span>Shop the Sale</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Best Sellers Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Customer Favorites</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white font-serif mt-1">
              Best Sellers
            </h2>
          </div>
          <Link
            to="/shop?sort=popularity"
            className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white hover:underline flex items-center gap-1 self-start sm:self-auto"
          >
            <span>See Top Rated</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
          {bestSellers.map(prod => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* Customer Testimonials */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Verified Reviews</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white font-serif mt-1">
            Loved by Thousands of Shoppers
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex text-amber-400 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 italic leading-relaxed">
                "{`The linen shirt and evil eye pendant were packaged like luxury high-street goods! Arrived in Bangalore within 48 hours. Absolute perfection.`}"
              </p>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 font-bold text-xs flex items-center justify-center text-slate-800 dark:text-slate-200">
                P
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white">Pooja Sharma</h5>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Verified Buyer • Bangalore</p>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex text-amber-400 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 italic leading-relaxed">
                "{`Ordered via WhatsApp chat in under 2 minutes. The Belgian truffle box was delicious and arrived with chilled ice packaging intact.`}"
              </p>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 font-bold text-xs flex items-center justify-center text-slate-800 dark:text-slate-200">
                A
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white">Arjun Verma</h5>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Verified Buyer • New Delhi</p>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex text-amber-400 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 italic leading-relaxed">
                "{`The ceramic vases look like an expensive Scandinavian design studio piece. Solid build, matte textured finish. Highly recommend!`}"
              </p>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 font-bold text-xs flex items-center justify-center text-slate-800 dark:text-slate-200">
                A
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white">Ananya Iyer</h5>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">Verified Buyer • Mumbai</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Floating WhatsApp Action Pill */}
      <div className="fixed bottom-6 left-6 z-40">
        <a
          href={`https://wa.me/${settings.whatsappNumber}?text=Hi!%20I%20have%20a%20question%20about%20your%20products.`}
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full font-semibold text-xs shadow-2xl transition hover:scale-105"
        >
          <MessageSquare className="w-4 h-4" />
          <span className="hidden sm:inline">Chat on WhatsApp</span>
        </a>
      </div>
    </div>
  );
};
