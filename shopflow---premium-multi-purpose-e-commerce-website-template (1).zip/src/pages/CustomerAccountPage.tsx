import React, { useEffect, useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Order } from '../types';
import { api } from '../services/api';
import { Link, useNavigate } from 'react-router-dom';
import {
  User as UserIcon,
  Package,
  Truck,
  LogOut,
  Sliders,
  Clock,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export const CustomerAccountPage: React.FC = () => {
  const { user, token, logout, isAdmin, formatCurrency, showToast } = useShop();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) {
      navigate('/');
      return;
    }

    async function loadUserOrders() {
      try {
        setLoading(true);
        const res = await api.getMyOrders();
        if (res?.orders) {
          setOrders(res.orders);
        }
      } catch (err) {
        console.error('Failed to load user orders:', err);
      } finally {
        setLoading(false);
      }
    }
    loadUserOrders();
  }, [token, navigate]);

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      {/* Account Overview Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 flex items-center justify-center font-bold text-2xl font-serif">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white font-serif">
                {user.name}
              </h1>
              {isAdmin && (
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                  Store Admin
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">{user.email}</p>
            {user.phone && <p className="text-xs text-slate-400">{user.phone}</p>}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {isAdmin && (
            <Link
              to="/admin"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-semibold shadow-sm flex items-center gap-1.5 transition"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Open Admin Panel</span>
            </Link>
          )}

          <button
            type="button"
            onClick={logout}
            className="px-4 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 rounded-xl text-xs font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/40 transition flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Orders History Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white font-serif">
            Order History ({orders.length})
          </h2>
          <Link to="/shop" className="text-xs font-semibold text-slate-600 dark:text-slate-300 hover:underline">
            Shop More
          </Link>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-400 animate-pulse">Loading order history...</div>
        ) : orders.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
            <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-1">No Orders Yet</h4>
            <p className="text-xs text-slate-500 mb-4">You haven't placed any orders with this account yet.</p>
            <Link
              to="/shop"
              className="px-5 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl text-xs font-semibold"
            >
              Start Shopping
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => (
              <div
                key={order.orderId}
                className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800 text-xs">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white font-mono text-sm">
                      {order.orderId}
                    </span>
                    <span className="text-slate-400 block text-[11px]">
                      Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200">
                      {order.orderStatus.replace(/_/g, ' ')}
                    </span>
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                      {formatCurrency(order.total)}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3">
                        {item.image && (
                          <img src={item.image} alt="" className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0" />
                        )}
                        <div>
                          <p className="font-medium text-slate-800 dark:text-slate-200">{item.title}</p>
                          <p className="text-[11px] text-slate-400">
                            Qty: {item.quantity} {item.size ? `• Size: ${item.size}` : ''}
                          </p>
                        </div>
                      </div>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {formatCurrency(item.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <span className="text-slate-500">
                    Payment:{' '}
                    <strong className="text-slate-800 dark:text-slate-200 uppercase">
                      {order.paymentMethod} ({order.paymentStatus})
                    </strong>
                  </span>

                  <Link
                    to={`/track-order?orderId=${order.orderId}&phone=${encodeURIComponent(order.customerInfo.phone)}`}
                    className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-lg font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center gap-1.5"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>Track Shipment</span>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
