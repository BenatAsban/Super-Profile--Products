import { Product, Category, Coupon, Order, StoreSettings, Review } from '../types';

export const initialSettings: StoreSettings = {
  storeName: "ShopFlow",
  tagline: "Curated lifestyle, fashion & artisan essentials",
  logoUrl: "https://images.unsplash.com/photo-1544441893-675973e31985?w=150&auto=format&fit=crop&q=80",
  announcementText: "✨ Festive Sale: 15% OFF on orders above ₹1,499 | Use Code: FESTIVE15",
  showAnnouncement: true,
  currencySymbol: "₹",
  currencyCode: "INR",
  whatsappNumber: "919876543210",
  supportPhone: "+91 98765 43210",
  supportEmail: "hello@shopflowstore.com",
  address: "ShopFlow Studio, 402 Indiranagar 100ft Road, Bengaluru, Karnataka 560038",
  freeShippingThreshold: 999,
  shippingCharge: 99,
  heroTitle: "Elegance in Every Detail, Curated for You.",
  heroSubtitle: "Discover handpicked contemporary fashion, bespoke jewellery, handcrafted ceramics, and delightful gifts designed for modern living.",
  heroCtaText: "Explore Collection",
  heroImageUrl: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&auto=format&fit=crop&q=80",
  primaryColor: "#0f172a",
  socialLinks: {
    instagram: "https://instagram.com",
    facebook: "https://facebook.com",
    whatsapp: "https://wa.me/919876543210",
    pinterest: "https://pinterest.com"
  }
};

export const initialCategories: Category[] = [
  {
    id: "cat-1",
    name: "Fashion & Apparel",
    slug: "fashion",
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=80",
    description: "Premium handcrafted apparel, bespoke linen, and relaxed silhouettes.",
    itemCount: 2
  },
  {
    id: "cat-2",
    name: "Fine Jewellery",
    slug: "jewellery",
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80",
    description: "18k gold vermeil, anti-tarnish stainless steel, and heritage pearls.",
    itemCount: 2
  },
  {
    id: "cat-3",
    name: "Home Decor & Living",
    slug: "home-decor",
    image: "https://images.unsplash.com/photo-1616046229478-9901c5536a45?w=600&auto=format&fit=crop&q=80",
    description: "Minimalist ceramic vases, bohemian weaves, and soy wax candles.",
    itemCount: 2
  },
  {
    id: "cat-4",
    name: "Artisan Bakery & Treats",
    slug: "bakery",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&auto=format&fit=crop&q=80",
    description: "Handcrafted Belgian truffles, macarons, and sourdough delicacies.",
    itemCount: 2
  },
  {
    id: "cat-5",
    name: "Handmade & Gifts",
    slug: "handmade-gifts",
    image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600&auto=format&fit=crop&q=80",
    description: "Artisan gift hampers, personalized leather keepsakes, and floral boxes.",
    itemCount: 1
  },
  {
    id: "cat-6",
    name: "Accessories & Leather",
    slug: "accessories",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80",
    description: "Minimalist watches, veg-tan leather wallets, and silk scarves.",
    itemCount: 1
  }
];

export const initialProducts: Product[] = [
  {
    id: "prod-1",
    title: "Oversized Vintage Washed Cotton Tee",
    slug: "oversized-vintage-washed-cotton-tee",
    category: "fashion",
    price: 1499,
    discountPrice: 999,
    description: "Crafted from 240 GSM 100% super-combed organic cotton, this boxy oversized t-shirt features dropped shoulders, ribbed crew neckline, and a vintage acid-washed aesthetic.",
    images: [
      "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 28,
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "Vintage Charcoal", hex: "#2b2b2b" },
      { name: "Sand Dune", hex: "#d8c7b5" }
    ],
    tags: ["Best Seller", "New", "100% Cotton"],
    isFeatured: true,
    isPublished: true,
    rating: 4.9,
    numReviews: 42
  },
  {
    id: "prod-2",
    title: "Artisanal Pure Khadi Linen Resort Shirt",
    slug: "artisanal-pure-khadi-linen-resort-shirt",
    category: "fashion",
    price: 2499,
    discountPrice: 1899,
    description: "Hand-spun and handwoven pure linen shirt with a relaxed Cuban collar and natural wooden buttons.",
    images: [
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 14,
    sizes: ["M", "L", "XL"],
    colors: [
      { name: "Ivory Ecru", hex: "#f5f5f0" },
      { name: "Olive Earth", hex: "#556b2f" }
    ],
    tags: ["Eco-friendly", "Handmade"],
    isFeatured: true,
    isPublished: true,
    rating: 4.8,
    numReviews: 29
  },
  {
    id: "prod-3",
    title: "18K Gold Vermeil Celestial Evil Eye Pendant",
    slug: "18k-gold-vermeil-celestial-evil-eye-pendant",
    category: "jewellery",
    price: 2299,
    discountPrice: 1699,
    description: "Hand-set with ethically sourced mother of pearl and brilliant cubic zirconia, finished in a 2.5 micron thick 18K gold layer over sterling silver.",
    images: [
      "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1611591475870-7607a909a341?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 19,
    sizes: ["One Size (45cm + 5cm extension)"],
    colors: [
      { name: "18K Yellow Gold", hex: "#d4af37" },
      { name: "Rhodium Silver", hex: "#e0e0e0" }
    ],
    tags: ["Waterproof", "Anti-Tarnish", "Top Rated"],
    isFeatured: true,
    isPublished: true,
    rating: 5.0,
    numReviews: 68
  },
  {
    id: "prod-4",
    title: "Heritage Baroque Pearl & Emerald Choker",
    slug: "heritage-baroque-pearl-emerald-choker",
    category: "jewellery",
    price: 3499,
    discountPrice: 2899,
    description: "Hand-strung genuine freshwater baroque pearls punctuated with natural green Brazilian emerald beads and a magnetic micro-pave clasp.",
    images: [
      "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 8,
    sizes: ["Standard 38cm"],
    colors: [
      { name: "Natural Pearl & Emerald", hex: "#f0ede5" }
    ],
    tags: ["Limited Edition", "Luxury"],
    isFeatured: true,
    isPublished: true,
    rating: 4.9,
    numReviews: 18
  },
  {
    id: "prod-5",
    title: "Hand-Thrown Wabi-Sabi Ceramic Vase Pair",
    slug: "hand-thrown-wabi-sabi-ceramic-vase-pair",
    category: "home-decor",
    price: 1899,
    discountPrice: 1399,
    description: "Set of two textured terracotta clay vases shaped by local potters. Matte speckled glaze with gentle ergonomic curves.",
    images: [
      "https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 15,
    sizes: ["Set of 2 (6\" & 8\")"],
    colors: [
      { name: "Raw Oatmeal", hex: "#d7cec7" }
    ],
    tags: ["Handmade", "Bestseller"],
    isFeatured: true,
    isPublished: true,
    rating: 4.7,
    numReviews: 31
  },
  {
    id: "prod-6",
    title: "Aromatherapy Amber Glass Soy Wax Candle Trio",
    slug: "aromatherapy-amber-glass-soy-wax-candle-trio",
    category: "home-decor",
    price: 1299,
    discountPrice: 899,
    description: "100% natural soy wax hand-poured with crackling wooden wicks. Fragrances include Mysore Sandalwood & Cedar, French Vanilla Orchid, and Bergamot Neroli.",
    images: [
      "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 35,
    sizes: ["Set of 3 x 120g"],
    colors: [
      { name: "Amber Glass", hex: "#9b6016" }
    ],
    tags: ["Toxic Free", "Gift Ready"],
    isFeatured: false,
    isPublished: true,
    rating: 4.9,
    numReviews: 54
  },
  {
    id: "prod-7",
    title: "Belgian Dark Chocolate & Hazelnut Truffle Box",
    slug: "belgian-dark-chocolate-hazelnut-truffle-box",
    category: "bakery",
    price: 1199,
    discountPrice: 849,
    description: "Box of 16 artisan truffles made with 70% Callebaut single-origin cocoa, toasted Piedmont hazelnuts, and dusted with edible 24k gold leaf flakes.",
    images: [
      "https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 22,
    sizes: ["Box of 16 Pieces"],
    colors: [
      { name: "Gourmet Assorted", hex: "#432818" }
    ],
    tags: ["Freshly Made", "Eggless", "Festive Favorite"],
    isFeatured: true,
    isPublished: true,
    rating: 5.0,
    numReviews: 87
  },
  {
    id: "prod-8",
    title: "French Pastel Macaron Deluxe Gift Box (Set of 12)",
    slug: "french-pastel-macaron-deluxe-gift-box",
    category: "bakery",
    price: 1399,
    discountPrice: 1099,
    description: "Authentic Parisian macarons with delicate crisp almond shells and velvety ganache centers: Raspberry Rose, Pistachio, Madagascar Salted Caramel, and Lavender Lemon.",
    images: [
      "https://images.unsplash.com/photo-1569864321347-190159230543?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 16,
    sizes: ["Box of 12 Assorted"],
    colors: [
      { name: "Pastel Palette", hex: "#fbcfe8" }
    ],
    tags: ["Gift Box", "Fresh Dispatch"],
    isFeatured: false,
    isPublished: true,
    rating: 4.8,
    numReviews: 45
  },
  {
    id: "prod-9",
    title: "Handcrafted Vegetable-Tanned Leather Bi-Fold Wallet",
    slug: "handcrafted-vegetable-tanned-leather-bi-fold-wallet",
    category: "accessories",
    price: 2199,
    discountPrice: 1599,
    description: "Sourced from premier tanneries, saddle-stitched by hand with waxed linen thread. Features 6 card slots, 2 hidden pockets, and a full cash compartment.",
    images: [
      "https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 12,
    sizes: ["11cm x 9cm"],
    colors: [
      { name: "Cognac Tan", hex: "#9a491e" }
    ],
    tags: ["Full Grain Leather"],
    isFeatured: true,
    isPublished: true,
    rating: 4.9,
    numReviews: 39
  },
  {
    id: "prod-10",
    title: "Personalized Monogrammed Botanical Journal & Pen Set",
    slug: "personalized-monogrammed-botanical-journal-set",
    category: "handmade-gifts",
    price: 1499,
    discountPrice: 1199,
    description: "Hardcover journal wrapped in recycled handmade cotton paper embedded with wildflower seeds. Includes 160 unruled pages, paired with a matching brass gel pen.",
    images: [
      "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop&q=80"
    ],
    stock: 25,
    sizes: ["A5 Size"],
    colors: [
      { name: "Botanical Forest", hex: "#2d4a22" }
    ],
    tags: ["Eco-friendly", "Customizable"],
    isFeatured: false,
    isPublished: true,
    rating: 4.9,
    numReviews: 27
  }
];

export const initialCoupons: Coupon[] = [
  {
    code: "WELCOME10",
    discountType: "percentage",
    discountValue: 10,
    minOrderValue: 499,
    maxDiscount: 300,
    expiresAt: "2027-12-31T23:59:59.000Z",
    isActive: true,
    usageCount: 142
  },
  {
    code: "FESTIVE15",
    discountType: "percentage",
    discountValue: 15,
    minOrderValue: 1499,
    maxDiscount: 750,
    expiresAt: "2027-12-31T23:59:59.000Z",
    isActive: true,
    usageCount: 95
  },
  {
    code: "FLAT200",
    discountType: "fixed",
    discountValue: 200,
    minOrderValue: 999,
    maxDiscount: 200,
    expiresAt: "2027-12-31T23:59:59.000Z",
    isActive: true,
    usageCount: 68
  }
];

export const initialOrders: Order[] = [
  {
    orderId: "SF-2026-8941",
    customerInfo: {
      name: "Pooja Sharma",
      email: "pooja.sharma@example.com",
      phone: "+91 98451 22341",
      address: "Flat 402, Sunshine Crest, 12th Main Indiranagar",
      city: "Bengaluru",
      state: "Karnataka",
      pincode: "560038"
    },
    items: [
      {
        id: "prod-1",
        title: "Oversized Vintage Washed Cotton Tee",
        price: 999,
        quantity: 2,
        size: "L",
        color: "Vintage Charcoal",
        image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80"
      }
    ],
    subtotal: 1998,
    shipping: 0,
    discount: 299,
    total: 1699,
    couponCode: "FESTIVE15",
    paymentMethod: "cod",
    paymentStatus: "pending",
    orderStatus: "shipped",
    trackingNumber: "DELHIVERY-77821945",
    createdAt: new Date(Date.now() - 36 * 3600 * 1000).toISOString()
  }
];

export const initialReviews: Review[] = [
  {
    id: "rev-1",
    productId: "prod-1",
    userName: "Rohan Nair",
    rating: 5,
    comment: "The cotton GSM feels ridiculously heavy and premium! Drop shoulders give that high-end drape.",
    isVerifiedPurchase: true,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString()
  },
  {
    id: "rev-2",
    productId: "prod-3",
    userName: "Meera Sen",
    rating: 5,
    comment: "Worn it in shower and gym—zero tarnishing, shiny as day one! Beautiful evil eye detailing.",
    isVerifiedPurchase: true,
    createdAt: new Date(Date.now() - 86400000 * 9).toISOString()
  }
];
