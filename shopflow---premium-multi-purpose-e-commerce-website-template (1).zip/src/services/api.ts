import {
  Product,
  Category,
  Order,
  Coupon,
  Review,
  User,
  StoreSettings
} from '../types';
import {
  initialSettings,
  initialCategories,
  initialProducts,
  initialCoupons,
  initialOrders,
  initialReviews
} from '../data/storeData';

const TOKEN_KEY = 'shopflow_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

// ----------------------------------------------------
// LOCAL STORAGE STORAGE ENGINE (Active on Netlify / Static Deployments)
// ----------------------------------------------------
function getLocal<T>(key: string, fallback: T): T {
  try {
    const val = localStorage.getItem(`shopflow_net_${key}`);
    return val ? JSON.parse(val) : fallback;
  } catch {
    return fallback;
  }
}

function setLocal<T>(key: string, val: T): void {
  try {
    localStorage.setItem(`shopflow_net_${key}`, JSON.stringify(val));
  } catch {}
}

const localStore = {
  getSettings: (): StoreSettings => getLocal('settings', initialSettings),
  setSettings: (s: StoreSettings) => setLocal('settings', s),

  getProducts: (): Product[] => getLocal('products', initialProducts),
  setProducts: (p: Product[]) => setLocal('products', p),

  getCategories: (): Category[] => getLocal('categories', initialCategories),
  setCategories: (c: Category[]) => setLocal('categories', c),

  getOrders: (): Order[] => getLocal('orders', initialOrders),
  setOrders: (o: Order[]) => setLocal('orders', o),

  getCoupons: (): Coupon[] => getLocal('coupons', initialCoupons),
  setCoupons: (c: Coupon[]) => setLocal('coupons', c),

  getReviews: (): Review[] => getLocal('reviews', initialReviews),
  setReviews: (r: Review[]) => setLocal('reviews', r),

  getUser: (): User | null => getLocal('user', {
    id: 'usr-admin-demo',
    name: 'Store Admin',
    email: 'admin@shopflow.com',
    role: 'admin',
    phone: '+91 98765 43210',
    createdAt: new Date().toISOString()
  })
};

// Resilient API requester: attempts server first, automatically falls back to local data on Netlify
async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {})
  };

  try {
    const response = await fetch(endpoint, {
      ...options,
      headers
    });

    if (response.ok) {
      const data = await response.json().catch(() => null);
      if (data) return data as T;
    }
  } catch (e) {
    // Server not running or static environment (e.g. Netlify)
  }

  // If fetch failed, throw so client-side fallback takes over
  throw new Error(`Fallback to client storage for ${endpoint}`);
}

export const api = {
  // Store Settings
  getSettings: async () => {
    try {
      return await request<{ success: boolean; settings: StoreSettings }>('/api/settings');
    } catch {
      return { success: true, settings: localStore.getSettings() };
    }
  },
  updateSettings: async (settings: Partial<StoreSettings>) => {
    try {
      return await request<{ success: boolean; message: string; settings: StoreSettings }>('/api/settings', {
        method: 'PUT',
        body: JSON.stringify(settings)
      });
    } catch {
      const cur = localStore.getSettings();
      const updated = { ...cur, ...settings };
      localStore.setSettings(updated);
      return { success: true, message: 'Settings saved locally.', settings: updated };
    }
  },
  getSystemStatus: async () => {
    try {
      return await request<any>('/api/settings/status');
    } catch {
      return {
        success: true,
        database: {
          isMongoConnected: false,
          activeEngine: 'Netlify Static / Local Storage',
          counts: {
            products: localStore.getProducts().length,
            categories: localStore.getCategories().length,
            orders: localStore.getOrders().length,
            coupons: localStore.getCoupons().length,
            users: 1
          }
        },
        payments: {
          codEnabled: true,
          whatsappEnabled: true,
          razorpayConfigured: false
        }
      };
    }
  },
  resetDemoData: async () => {
    try {
      return await request<{ success: boolean; message: string }>('/api/settings/reset', { method: 'POST' });
    } catch {
      localStore.setProducts(initialProducts);
      localStore.setCategories(initialCategories);
      localStore.setOrders(initialOrders);
      localStore.setCoupons(initialCoupons);
      localStore.setSettings(initialSettings);
      return { success: true, message: 'Store reset to default values.' };
    }
  },
  getAdminStats: async () => {
    try {
      return await request<any>('/api/settings/admin-stats');
    } catch {
      const orders = localStore.getOrders();
      const products = localStore.getProducts();
      const totalRev = orders.reduce((s, o) => s + o.total, 0);

      return {
        success: true,
        stats: {
          totalRevenue: totalRev,
          totalOrders: orders.length,
          totalProducts: products.length,
          totalCustomers: orders.length + 5,
          pendingOrders: orders.filter(o => o.orderStatus === 'placed' || o.orderStatus === 'processing').length,
          lowStockCount: products.filter(p => p.stock < 10).length,
          salesChartData: [
            { name: 'May', revenue: 42000 },
            { name: 'Jun', revenue: 58000 },
            { name: 'Jul', revenue: 72000 },
            { name: 'Aug', revenue: 89000 },
            { name: 'Sep', revenue: 105000 },
            { name: 'Oct', revenue: 128450 }
          ],
          orderStatusBreakdown: [
            { name: 'PLACED', count: 1 },
            { name: 'CONFIRMED', count: 2 },
            { name: 'PROCESSING', count: 1 },
            { name: 'SHIPPED', count: 3 },
            { name: 'DELIVERED', count: 5 }
          ],
          topProducts: products.slice(0, 5).map(p => ({
            id: p.id,
            title: p.title,
            price: p.discountPrice || p.price,
            stock: p.stock,
            sold: 34,
            revenue: (p.discountPrice || p.price) * 34,
            image: p.images[0]
          }))
        }
      };
    }
  },

  // Products
  getProducts: async (params?: {
    category?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
    featured?: boolean;
    page?: number;
    limit?: number;
  }) => {
    try {
      const query = new URLSearchParams();
      if (params?.category) query.set('category', params.category);
      if (params?.search) query.set('search', params.search);
      if (params?.minPrice !== undefined) query.set('minPrice', params.minPrice.toString());
      if (params?.maxPrice !== undefined) query.set('maxPrice', params.maxPrice.toString());
      if (params?.sort) query.set('sort', params.sort);
      if (params?.featured) query.set('featured', 'true');
      if (params?.page) query.set('page', params.page.toString());
      if (params?.limit) query.set('limit', params.limit.toString());
      return await request<{ success: boolean; products: Product[]; total: number; page: number; totalPages: number }>(
        `/api/products?${query.toString()}`
      );
    } catch {
      let items = localStore.getProducts();

      if (params?.category && params.category !== 'all') {
        items = items.filter(p => p.category.toLowerCase() === params.category!.toLowerCase());
      }
      if (params?.search) {
        const q = params.search.toLowerCase();
        items = items.filter(p => p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
      }
      if (params?.featured) {
        items = items.filter(p => p.isFeatured);
      }
      if (params?.sort === 'price-asc') {
        items.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
      } else if (params?.sort === 'price-desc') {
        items.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
      }

      return {
        success: true,
        products: items,
        total: items.length,
        page: 1,
        totalPages: 1
      };
    }
  },
  getProduct: async (idOrSlug: string) => {
    try {
      return await request<{ success: boolean; product: Product; related: Product[] }>(`/api/products/${idOrSlug}`);
    } catch {
      const products = localStore.getProducts();
      const product = products.find(p => p.id === idOrSlug || p.slug === idOrSlug) || products[0];
      const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);
      return { success: true, product, related };
    }
  },
  createProduct: async (productData: any) => {
    try {
      return await request<{ success: boolean; message: string; product: Product }>('/api/products', {
        method: 'POST',
        body: JSON.stringify(productData)
      });
    } catch {
      const products = localStore.getProducts();
      const newProd: Product = {
        ...productData,
        id: `prod-${Date.now()}`,
        slug: productData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Math.floor(Math.random() * 1000),
        rating: 5,
        numReviews: 0,
        createdAt: new Date().toISOString()
      };
      products.unshift(newProd);
      localStore.setProducts(products);
      return { success: true, message: 'Product created locally.', product: newProd };
    }
  },
  updateProduct: async (id: string, productData: any) => {
    try {
      return await request<{ success: boolean; message: string; product: Product }>(`/api/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(productData)
      });
    } catch {
      const products = localStore.getProducts();
      const idx = products.findIndex(p => p.id === id || p.slug === id);
      if (idx !== -1) {
        products[idx] = { ...products[idx], ...productData };
        localStore.setProducts(products);
        return { success: true, message: 'Product updated.', product: products[idx] };
      }
      throw new Error('Product not found');
    }
  },
  deleteProduct: async (id: string) => {
    try {
      return await request<{ success: boolean; message: string; product: Product }>(`/api/products/${id}`, {
        method: 'DELETE'
      });
    } catch {
      let products = localStore.getProducts();
      const deleted = products.find(p => p.id === id);
      products = products.filter(p => p.id !== id);
      localStore.setProducts(products);
      return { success: true, message: 'Product deleted.', product: deleted! };
    }
  },

  // Categories
  getCategories: async () => {
    try {
      return await request<{ success: boolean; categories: Category[] }>('/api/categories');
    } catch {
      return { success: true, categories: localStore.getCategories() };
    }
  },

  // Orders
  createOrder: async (orderData: any) => {
    try {
      return await request<{ success: boolean; message: string; order: Order }>('/api/orders', {
        method: 'POST',
        body: JSON.stringify(orderData)
      });
    } catch {
      const orders = localStore.getOrders();
      const rand = Math.floor(1000 + Math.random() * 9000);
      const year = new Date().getFullYear();
      const orderId = `SF-${year}-${rand}`;

      const newOrder: Order = {
        orderId,
        customerInfo: orderData.customerInfo,
        items: orderData.items,
        subtotal: orderData.items.reduce((s: number, i: any) => s + i.price * i.quantity, 0),
        shipping: 0,
        discount: orderData.couponCode ? 150 : 0,
        total: orderData.items.reduce((s: number, i: any) => s + i.price * i.quantity, 0),
        paymentMethod: orderData.paymentMethod || 'cod',
        paymentStatus: orderData.paymentMethod === 'razorpay' ? 'paid' : 'pending',
        orderStatus: 'placed',
        trackingNumber: `TRACK-${Math.floor(10000000 + Math.random() * 90000000)}`,
        createdAt: new Date().toISOString()
      };

      orders.unshift(newOrder);
      localStore.setOrders(orders);
      return { success: true, message: 'Order placed successfully.', order: newOrder };
    }
  },
  getOrders: async () => {
    try {
      return await request<{ success: boolean; orders: Order[] }>('/api/orders');
    } catch {
      return { success: true, orders: localStore.getOrders() };
    }
  },
  getMyOrders: async () => {
    try {
      return await request<{ success: boolean; orders: Order[] }>('/api/orders/my-orders');
    } catch {
      return { success: true, orders: localStore.getOrders() };
    }
  },
  getOrder: async (id: string) => {
    try {
      return await request<{ success: boolean; order: Order }>(`/api/orders/${id}`);
    } catch {
      const orders = localStore.getOrders();
      const order = orders.find(o => o.orderId === id || o.id === id) || orders[0];
      return { success: true, order };
    }
  },
  trackOrder: async (orderId: string, phone: string) => {
    try {
      return await request<{ success: boolean; order: Order }>('/api/orders/track', {
        method: 'POST',
        body: JSON.stringify({ orderId, phone })
      });
    } catch {
      const orders = localStore.getOrders();
      const cleanId = orderId.trim().toUpperCase();
      const order = orders.find(o => o.orderId.toUpperCase() === cleanId) || orders[0];
      return { success: true, order };
    }
  },
  updateOrderStatus: async (id: string, orderStatus: string) => {
    try {
      return await request<{ success: boolean; message: string; order: Order }>(`/api/orders/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ orderStatus })
      });
    } catch {
      const orders = localStore.getOrders();
      const order = orders.find(o => o.orderId === id || o.id === id);
      if (order) order.orderStatus = orderStatus as any;
      localStore.setOrders(orders);
      return { success: true, message: `Status updated to ${orderStatus}`, order: order! };
    }
  },
  updatePaymentStatus: async (id: string, paymentStatus: string) => {
    try {
      return await request<{ success: boolean; message: string; order: Order }>(`/api/orders/${id}/payment`, {
        method: 'PATCH',
        body: JSON.stringify({ paymentStatus })
      });
    } catch {
      const orders = localStore.getOrders();
      const order = orders.find(o => o.orderId === id || o.id === id);
      if (order) order.paymentStatus = paymentStatus as any;
      localStore.setOrders(orders);
      return { success: true, message: `Payment updated to ${paymentStatus}`, order: order! };
    }
  },

  // Coupons
  validateCoupon: async (code: string, subtotal: number) => {
    try {
      return await request<any>('/api/coupons/validate', {
        method: 'POST',
        body: JSON.stringify({ code, subtotal })
      });
    } catch {
      const coupons = localStore.getCoupons();
      const found = coupons.find(c => c.code.toUpperCase() === code.trim().toUpperCase() && c.isActive);
      if (!found) throw new Error('Invalid coupon code');

      let discountAmount = 0;
      if (found.discountType === 'percentage') {
        discountAmount = Math.round((subtotal * found.discountValue) / 100);
      } else {
        discountAmount = found.discountValue;
      }

      return {
        success: true,
        message: `Coupon ${found.code} applied!`,
        coupon: {
          code: found.code,
          discountType: found.discountType,
          discountValue: found.discountValue,
          discountAmount
        }
      };
    }
  },
  getCoupons: async () => {
    try {
      return await request<{ success: boolean; coupons: Coupon[] }>('/api/coupons');
    } catch {
      return { success: true, coupons: localStore.getCoupons() };
    }
  },
  createCoupon: async (couponData: any) => {
    try {
      return await request<any>('/api/coupons', {
        method: 'POST',
        body: JSON.stringify(couponData)
      });
    } catch {
      const coupons = localStore.getCoupons();
      const newCoupon: Coupon = {
        code: couponData.code.toUpperCase(),
        discountType: couponData.discountType,
        discountValue: Number(couponData.discountValue),
        minOrderValue: Number(couponData.minOrderValue) || 0,
        maxDiscount: Number(couponData.maxDiscount) || 1000,
        expiresAt: '2027-12-31',
        isActive: true,
        usageCount: 0
      };
      coupons.unshift(newCoupon);
      localStore.setCoupons(coupons);
      return { success: true, message: 'Coupon created.', coupon: newCoupon };
    }
  },
  toggleCoupon: async (code: string) => {
    try {
      return await request<any>(`/api/coupons/${code}/toggle`, { method: 'PATCH' });
    } catch {
      const coupons = localStore.getCoupons();
      const c = coupons.find(item => item.code === code);
      if (c) c.isActive = !c.isActive;
      localStore.setCoupons(coupons);
      return { success: true, message: `Coupon ${c?.isActive ? 'active' : 'paused'}`, coupon: c! };
    }
  },
  deleteCoupon: async (code: string) => {
    try {
      return await request<any>(`/api/coupons/${code}`, { method: 'DELETE' });
    } catch {
      let coupons = localStore.getCoupons();
      coupons = coupons.filter(c => c.code !== code);
      localStore.setCoupons(coupons);
      return { success: true, message: 'Coupon deleted.' };
    }
  },

  // Reviews
  getReviews: async (productId: string) => {
    try {
      return await request<any>(`/api/reviews/${productId}`);
    } catch {
      const reviews = localStore.getReviews().filter(r => r.productId === productId);
      return { success: true, reviews, stats: { average: 5, total: reviews.length } };
    }
  },
  addReview: async (reviewData: any) => {
    try {
      return await request<any>('/api/reviews', { method: 'POST', body: JSON.stringify(reviewData) });
    } catch {
      const reviews = localStore.getReviews();
      const newRev: Review = {
        id: `rev-${Date.now()}`,
        productId: reviewData.productId,
        userName: reviewData.userName,
        rating: reviewData.rating,
        comment: reviewData.comment,
        isVerifiedPurchase: true,
        createdAt: new Date().toISOString()
      };
      reviews.unshift(newRev);
      localStore.setReviews(reviews);
      return { success: true, message: 'Review added.', review: newRev };
    }
  },

  // Auth
  register: async (userData: any) => {
    try {
      return await request<any>('/api/auth/register', { method: 'POST', body: JSON.stringify(userData) });
    } catch {
      const user: User = {
        id: `usr-${Date.now()}`,
        name: userData.name,
        email: userData.email,
        role: 'customer'
      };
      setStoredToken('static_demo_jwt_token');
      return { success: true, message: 'Signed up successfully.', token: 'static_demo_jwt_token', user };
    }
  },
  login: async (credentials: any) => {
    try {
      return await request<any>('/api/auth/login', { method: 'POST', body: JSON.stringify(credentials) });
    } catch {
      const isAdminUser = credentials.email.includes('admin');
      const user: User = {
        id: isAdminUser ? 'usr-admin-demo' : 'usr-cust-demo',
        name: isAdminUser ? 'Store Admin' : 'Customer',
        email: credentials.email,
        role: isAdminUser ? 'admin' : 'customer'
      };
      setStoredToken('static_demo_jwt_token');
      return { success: true, message: 'Login successful.', token: 'static_demo_jwt_token', user };
    }
  },
  getMe: async () => {
    try {
      return await request<any>('/api/auth/me');
    } catch {
      return { success: true, user: localStore.getUser()! };
    }
  },

  // Payments
  getPaymentConfig: async () => {
    try {
      return await request<any>('/api/payment/config');
    } catch {
      return {
        success: true,
        methods: {
          cod: { enabled: true, title: 'Cash on Delivery (COD)' },
          whatsapp: { enabled: true, title: 'Order via WhatsApp' },
          razorpay: { enabled: false, title: 'Online Payment' }
        }
      };
    }
  },
  createRazorpayOrder: async (amount: number) => {
    try {
      return await request<any>('/api/payment/razorpay-order', {
        method: 'POST',
        body: JSON.stringify({ amount })
      });
    } catch {
      return {
        success: true,
        orderId: `order_demo_${Date.now()}`,
        amount: Math.round(amount * 100),
        currency: 'INR'
      };
    }
  }
};
