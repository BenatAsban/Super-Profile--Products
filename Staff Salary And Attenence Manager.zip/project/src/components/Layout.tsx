import { useState, useCallback } from 'react';
import { Link, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import {
  LayoutDashboard, Users, CalendarCheck, Wallet, Receipt,
  FileText, BarChart3, Settings as SettingsIcon, Home, Menu, X,
  Store,
} from 'lucide-react';
import { cn } from '@/lib/cn';
import { useData } from '@/context/DataContext';

const navItems = [
  { to: '/app/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/app/employees', label: 'Employees', icon: Users },
  { to: '/app/attendance', label: 'Attendance', icon: CalendarCheck },
  { to: '/app/advances', label: 'Advances', icon: Wallet },
  { to: '/app/adjustments', label: 'Adjustments', icon: Receipt },
  { to: '/app/payroll', label: 'Payroll', icon: FileText },
  { to: '/app/reports', label: 'Reports', icon: BarChart3 },
  { to: '/app/settings', label: 'Settings', icon: SettingsIcon },
];

export function Layout({ children }: { children: ReactNode }) {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data } = useData();

  const closeMobile = useCallback(() => setMobileOpen(false), []);

  const isActive = (to: string) => location.pathname === to || location.pathname.startsWith(to + '/');

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex w-60 flex-col bg-white border-r border-slate-200 fixed inset-y-0 left-0 z-30">
        <SidebarContent businessName={data.settings.businessName} isActive={isActive} closeMobile={closeMobile} />
      </aside>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={closeMobile} />
          <aside className="absolute inset-y-0 left-0 w-64 bg-white shadow-xl flex flex-col">
            <SidebarContent businessName={data.settings.businessName} isActive={isActive} closeMobile={closeMobile} showClose />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 md:ml-60 flex flex-col min-w-0">
        {/* Mobile header */}
        <header className="md:hidden sticky top-0 z-20 bg-white border-b border-slate-200 px-4 h-14 flex items-center justify-between">
          <button onClick={() => setMobileOpen(true)} className="p-2 -ml-2 text-slate-600 hover:bg-slate-100 rounded-lg">
            <Menu size={22} />
          </button>
          <Link to="/app/dashboard" className="flex items-center gap-2 font-semibold text-slate-800">
            <Store size={18} className="text-emerald-600" />
            <span className="text-sm">Staff Manager</span>
          </Link>
          <Link to="/" className="p-2 -mr-2 text-slate-500 hover:bg-slate-100 rounded-lg">
            <Home size={20} />
          </Link>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">{children}</main>
      </div>
    </div>
  );
}

function SidebarContent({
  businessName,
  isActive,
  closeMobile,
  showClose,
}: {
  businessName: string;
  isActive: (to: string) => boolean;
  closeMobile: () => void;
  showClose?: boolean;
}) {
  return (
    <>
      <div className="px-5 h-16 flex items-center justify-between border-b border-slate-100">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white shrink-0">
            <Store size={20} />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-slate-800 leading-tight truncate">Staff Manager</p>
            <p className="text-[11px] text-slate-400 leading-tight">India 2026</p>
          </div>
        </Link>
        {showClose && (
          <button onClick={closeMobile} className="p-1.5 text-slate-400 hover:bg-slate-100 rounded-lg">
            <X size={20} />
          </button>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={closeMobile}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                isActive(item.to)
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              )}
            >
              <Icon size={18} className="shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="px-4 py-3 border-t border-slate-100">
        <Link
          to="/"
          className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-700"
        >
          <Home size={16} />
          Back to Home
        </Link>
        {businessName && (
          <p className="mt-2 text-xs text-slate-400 truncate">{businessName}</p>
        )}
      </div>
    </>
  );
}
