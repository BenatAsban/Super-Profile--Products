import { useState } from 'react';
import type { Employee, Settings } from '@/lib/types';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { uid, todayISO } from '@/lib/format';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: (emp: Employee) => void;
  existing?: Employee | null;
  settings: Settings;
  existingIds: string[];
}

export function EmployeeForm({ open, onClose, onSave, existing, settings, existingIds }: Props) {
  const [form, setForm] = useState<Partial<Employee>>(
    existing || {
      employeeId: '',
      fullName: '',
      phone: '',
      email: '',
      department: '',
      joiningDate: todayISO(),
      status: 'active',
      salaryType: 'monthly',
      monthlySalary: 0,
      dailyWageRate: 0,
      standardHoursPerDay: settings.defaultWorkingHours || 8,
      overtimeRatePerHour: settings.defaultOvertimeRate || 50,
      weeklyOffDays: settings.defaultWeeklyOffDays || ['Sunday'],
      notes: '',
    }
  );
  const [errors, setErrors] = useState<Record<string, string>>({});

  const update = (field: keyof Employee, value: unknown) => {
    setForm((f) => ({ ...f, [field]: value }));
  };

  const toggleWeeklyOff = (day: string) => {
    const current = form.weeklyOffDays || [];
    update('weeklyOffDays', current.includes(day) ? current.filter((d) => d !== day) : [...current, day]);
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.fullName?.trim()) e.fullName = 'Full name is required';
    if (!form.phone?.trim()) e.phone = 'Phone number is required';
    else if (!/^[6-9]\d{9}$/.test(form.phone.replace(/\s/g, ''))) e.phone = 'Enter a valid 10-digit Indian mobile number';
    if (!form.employeeId?.trim()) e.employeeId = 'Employee ID is required';
    else if (existingIds.includes(form.employeeId) && form.employeeId !== existing?.employeeId)
      e.employeeId = 'This Employee ID already exists';
    if (!form.department?.trim()) e.department = 'Department or role is required';
    if (!form.joiningDate) e.joiningDate = 'Joining date is required';
    if (form.salaryType === 'monthly' && (!form.monthlySalary || form.monthlySalary <= 0))
      e.monthlySalary = 'Monthly salary must be greater than 0';
    if (form.salaryType === 'daily' && (!form.dailyWageRate || form.dailyWageRate <= 0))
      e.dailyWageRate = 'Daily wage rate must be greater than 0';
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      e.email = 'Enter a valid email address';
    if (form.overtimeRatePerHour !== undefined && form.overtimeRatePerHour < 0)
      e.overtimeRatePerHour = 'Overtime rate cannot be negative';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;
    const emp: Employee = {
      id: existing?.id || uid('e_'),
      employeeId: form.employeeId!.trim(),
      fullName: form.fullName!.trim(),
      phone: form.phone!.trim(),
      email: form.email?.trim() || undefined,
      department: form.department!.trim(),
      joiningDate: form.joiningDate!,
      status: form.status || 'active',
      salaryType: form.salaryType || 'monthly',
      monthlySalary: form.salaryType === 'monthly' ? Number(form.monthlySalary) || 0 : undefined,
      dailyWageRate: form.salaryType === 'daily' ? Number(form.dailyWageRate) || 0 : undefined,
      standardHoursPerDay: Number(form.standardHoursPerDay) || 8,
      overtimeRatePerHour: Number(form.overtimeRatePerHour) || 0,
      weeklyOffDays: form.weeklyOffDays || [],
      notes: form.notes?.trim() || undefined,
      createdAt: existing?.createdAt || new Date().toISOString(),
    };
    onSave(emp);
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={existing ? 'Edit Employee' : 'Add Employee'}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>{existing ? 'Save Changes' : 'Add Employee'}</Button>
        </>
      }
    >
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Employee ID" required error={errors.employeeId} hint="Auto-generated, editable. Must be unique.">
          <Input
            value={form.employeeId || ''}
            onChange={(e) => update('employeeId', e.target.value)}
            error={!!errors.employeeId}
            placeholder="EMP001"
          />
        </Field>
        <Field label="Full Name" required error={errors.fullName}>
          <Input
            value={form.fullName || ''}
            onChange={(e) => update('fullName', e.target.value)}
            error={!!errors.fullName}
            placeholder="Ramesh Kumar"
          />
        </Field>
        <Field label="Phone Number" required error={errors.phone}>
          <Input
            value={form.phone || ''}
            onChange={(e) => update('phone', e.target.value)}
            error={!!errors.phone}
            placeholder="9876543210"
            maxLength={10}
          />
        </Field>
        <Field label="Email" error={errors.email} hint="Optional">
          <Input
            value={form.email || ''}
            onChange={(e) => update('email', e.target.value)}
            error={!!errors.email}
            placeholder="name@example.com"
          />
        </Field>
        <Field label="Department / Job Role" required error={errors.department}>
          <Input
            value={form.department || ''}
            onChange={(e) => update('department', e.target.value)}
            error={!!errors.department}
            placeholder="Sales, Kitchen, Counter..."
          />
        </Field>
        <Field label="Joining Date" required error={errors.joiningDate}>
          <Input
            type="date"
            value={form.joiningDate || ''}
            onChange={(e) => update('joiningDate', e.target.value)}
            error={!!errors.joiningDate}
          />
        </Field>
        <Field label="Employment Status" required>
          <Select
            value={form.status}
            onChange={(e) => update('status', e.target.value)}
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </Select>
        </Field>
        <Field label="Salary Type" required>
          <Select
            value={form.salaryType}
            onChange={(e) => update('salaryType', e.target.value)}
          >
            <option value="monthly">Monthly Salary</option>
            <option value="daily">Daily Wage</option>
          </Select>
        </Field>
        {form.salaryType === 'monthly' ? (
          <Field label="Monthly Salary (₹)" required error={errors.monthlySalary}>
            <Input
              type="number"
              min={0}
              value={form.monthlySalary ?? ''}
              onChange={(e) => update('monthlySalary', Number(e.target.value))}
              error={!!errors.monthlySalary}
              placeholder="15000"
            />
          </Field>
        ) : (
          <Field label="Daily Wage Rate (₹)" required error={errors.dailyWageRate}>
            <Input
              type="number"
              min={0}
              value={form.dailyWageRate ?? ''}
              onChange={(e) => update('dailyWageRate', Number(e.target.value))}
              error={!!errors.dailyWageRate}
              placeholder="500"
            />
          </Field>
        )}
        <Field label="Standard Working Hours/Day">
          <Input
            type="number"
            min={1}
            max={24}
            value={form.standardHoursPerDay ?? 8}
            onChange={(e) => update('standardHoursPerDay', Number(e.target.value))}
          />
        </Field>
        <Field label="Overtime Rate per Hour (₹)" error={errors.overtimeRatePerHour}>
          <Input
            type="number"
            min={0}
            value={form.overtimeRatePerHour ?? 0}
            onChange={(e) => update('overtimeRatePerHour', Number(e.target.value))}
            error={!!errors.overtimeRatePerHour}
            placeholder="50"
          />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Weekly Off Days">
            <div className="flex flex-wrap gap-2">
              {DAYS.map((day) => (
                <button
                  key={day}
                  type="button"
                  onClick={() => toggleWeeklyOff(day)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
                    (form.weeklyOffDays || []).includes(day)
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {day.slice(0, 3)}
                </button>
              ))}
            </div>
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="Notes" hint="Optional">
            <Textarea
              value={form.notes || ''}
              onChange={(e) => update('notes', e.target.value)}
              placeholder="Any additional information..."
            />
          </Field>
        </div>
      </div>
    </Modal>
  );
}
