import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import type { ReactNode } from 'react';
import { DataProvider } from '@/context/DataContext';
import { Layout } from '@/components/Layout';
import { LandingPage } from '@/pages/LandingPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { EmployeesPage } from '@/pages/EmployeesPage';
import { EmployeeProfilePage } from '@/pages/EmployeeProfilePage';
import { AttendancePage } from '@/pages/AttendancePage';
import { AdvancesPage } from '@/pages/AdvancesPage';
import { AdjustmentsPage } from '@/pages/AdjustmentsPage';
import { PayrollPage } from '@/pages/PayrollPage';
import { ReportsPage } from '@/pages/ReportsPage';
import { SettingsPage } from '@/pages/SettingsPage';

function AppLayout({ children }: { children: ReactNode }) {
  return <Layout>{children}</Layout>;
}

function App() {
  return (
    <DataProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/app" element={<AppLayout><DashboardPage /></AppLayout>}>
            <Route index element={<Navigate to="/app/dashboard" replace />} />
          </Route>
          <Route path="/app/dashboard" element={<AppLayout><DashboardPage /></AppLayout>} />
          <Route path="/app/employees" element={<AppLayout><EmployeesPage /></AppLayout>} />
          <Route path="/app/employees/:id" element={<AppLayout><EmployeeProfilePage /></AppLayout>} />
          <Route path="/app/attendance" element={<AppLayout><AttendancePage /></AppLayout>} />
          <Route path="/app/advances" element={<AppLayout><AdvancesPage /></AppLayout>} />
          <Route path="/app/adjustments" element={<AppLayout><AdjustmentsPage /></AppLayout>} />
          <Route path="/app/payroll" element={<AppLayout><PayrollPage /></AppLayout>} />
          <Route path="/app/reports" element={<AppLayout><ReportsPage /></AppLayout>} />
          <Route path="/app/settings" element={<AppLayout><SettingsPage /></AppLayout>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </DataProvider>
  );
}

export default App;
