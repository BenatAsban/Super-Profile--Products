import { useMemo, useState } from 'react';
import {
  Wallet, Plus, Download, IndianRupee, Search,
} from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Modal } from '@/components/ui/Modal';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { EmptyState, PageHeader, ConfirmDialog } from '@/components/ui/Misc';
import { useToast } from '@/hooks/useToast';
import { formatINR, formatDate, currentMonthKey, monthKey, monthLabel, uid, todayISO } from '@/lib/format';
import { downloadCSV } from '@/lib/export';
import { outstandingAdvance } from '@/lib/salary';
import type { Advance, PaymentMethod } from '@/lib/types';

export function AdvancesPage() {
  const { data, addAdvance, updateAdvance, addRecovery } = useData();
  const { showToast } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [recoveryOpen, setRecoveryOpen] = useState<Advance | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Advance | null>(null);
  const [search, setSearch] = useState('');
  const [monthFilter, setMonthFilter] = useState('all');

  const activeEmployees = data.employees.filter((e) => e.status === 'active');

  const filtered = useMemo(() => {
    return data.advances
      .filter((a) => {
        if (monthFilter !== 'all' && monthKey(a.advanceDate) !== monthFilter) return false;
        if (search) {
          const emp = data.employees.find((e) => e.id === a.employeeId);
          const q = search.toLowerCase();
          return (
            emp?.fullName.toLowerCase().includes(q) ||
            emp?.employeeId.toLowerCase().includes(q) ||
            (a.referenceNumber || '').toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => b.advanceDate.localeCompare(a.advanceDate));
  }, [data.advances, data.employees, search, monthFilter]);

  const totalOutstanding = useMemo(() => {
    return data.advances.reduce(
      (sum, a) => sum + outstandingAdvance(a, data.recoveries),
      0
    );
  }, [data.advances, data.recoveries]);

  const totalThisMonth = useMemo(() => {
    return data.advances
      .filter((a) => monthKey(a.advanceDate) === currentMonthKey())
      .reduce((s, a) => s + a.amount, 0);
  }, [data.advances]);

  const exportCSV = () => {
    const rows: (string | number)[][] = [
      ['Employee ID', 'Name', 'Date', 'Amount', 'Method', 'Reference', 'Recovered', 'Outstanding', 'Status'],
    ];
    for (const a of filtered) {
      const emp = data.employees.find((e) => e.id === a.employeeId);
      const recovered = a.amount - outstandingAdvance(a, data.recoveries);
      rows.push([
        emp?.employeeId || '',
        emp?.fullName || 'Unknown',
        a.advanceDate,
        a.amount,
        a.paymentMethod,
        a.referenceNumber || '',
        recovered,
        outstandingAdvance(a, data.recoveries),
        a.status,
      ]);
    }
    downloadCSV('advances', rows);
    showToast('Advances exported');
  };

  return (
    <div>
      <PageHeader
        title="Advances"
        subtitle="Track salary advances and recoveries"
        action={
          <>
            <Button variant="outline" size="sm" onClick={exportCSV}><Download size={16} /> Export</Button>
            <Button size="sm" onClick={() => setFormOpen(true)}><Plus size={16} /> Add Advance</Button>
          </>
        }
      />

      <div className="grid sm:grid-cols-2 gap-3 mb-4">
        <div className="rounded-xl border border-orange-200 bg-orange-50 p-4">
          <p className="text-xs text-orange-600 font-medium">Total Outstanding Advances</p>
          <p className="text-2xl font-bold text-orange-700 mt-1">{formatINR(totalOutstanding)}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500 font-medium">Advances This Month</p>
          <p className="text-2xl font-bold text-slate-800 mt-1">{formatINR(totalThisMonth)}</p>
        </div>
      </div>

      <Card className="mb-4">
        <CardBody className="!py-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search employee or reference..." className="pl-10" />
            </div>
            <Select value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)} className="sm:w-44">
              <option value="all">All Months</option>
              {Array.from(new Set(data.advances.map((a) => monthKey(a.advanceDate)))).sort().reverse().map((m) => (
                <option key={m} value={m}>{monthLabel(m)}</option>
              ))}
            </Select>
          </div>
        </CardBody>
      </Card>

      {data.advances.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Wallet size={32} />}
            title="No advances recorded"
            description="Record a salary advance given to an employee. Advances are not automatically deducted — you choose when to recover them through payroll."
            action={<Button onClick={() => setFormOpen(true)}><Plus size={16} /> Add Advance</Button>}
          />
        </Card>
      ) : filtered.length === 0 ? (
        <Card><EmptyState title="No advances found" description="Try adjusting filters." /></Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((adv) => {
            const emp = data.employees.find((e) => e.id === adv.employeeId);
            const remaining = outstandingAdvance(adv, data.recoveries);
            const recovered = adv.amount - remaining;
            return (
              <Card key={adv.id}>
                <CardBody className="!py-3">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-lg bg-orange-50 flex items-center justify-center text-orange-600 shrink-0">
                        <IndianRupee size={18} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-700 truncate">
                          {emp?.fullName || 'Unknown Employee'}
                        </p>
                        <p className="text-xs text-slate-400">
                          {formatDate(adv.advanceDate)} · {adv.paymentMethod}
                          {adv.referenceNumber && ` · ${adv.referenceNumber}`}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-bold text-slate-800">{formatINR(adv.amount)}</p>
                        <p className="text-xs text-orange-600">{formatINR(remaining)} left</p>
                      </div>
                      <Badge color={remaining > 0 ? 'orange' : 'emerald'}>
                        {remaining > 0 ? 'Outstanding' : 'Settled'}
                      </Badge>
                      {remaining > 0 && (
                        <Button size="sm" variant="outline" onClick={() => setRecoveryOpen(adv)}>
                          Recover
                        </Button>
                      )}
                    </div>
                  </div>

                  {recovered > 0 && (
                    <div className="mt-2 pt-2 border-t border-slate-100">
                      <p className="text-xs text-slate-400">
                        {formatINR(recovered)} recovered · {adv.notes || 'No notes'}
                      </p>
                    </div>
                  )}
                </CardBody>
              </Card>
            );
          })}
        </div>
      )}

      <AdvanceForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        employees={activeEmployees}
        onSave={(adv) => {
          addAdvance(adv);
          setFormOpen(false);
          showToast('Advance recorded');
        }}
      />

      <RecoveryModal
        advance={recoveryOpen}
        onClose={() => setRecoveryOpen(null)}
        maxAmount={recoveryOpen ? outstandingAdvance(recoveryOpen, data.recoveries) : 0}
        onConfirm={(amount, notes) => {
          if (!recoveryOpen) return;
          addRecovery({
            id: uid('rec_'),
            advanceId: recoveryOpen.id,
            employeeId: recoveryOpen.employeeId,
            amount,
            date: todayISO(),
            source: 'manual',
            notes,
            createdAt: new Date().toISOString(),
          });
          if (outstandingAdvance(recoveryOpen, data.recoveries) - amount <= 0) {
            updateAdvance(recoveryOpen.id, { status: 'closed' });
          }
          setRecoveryOpen(null);
          showToast('Recovery recorded');
        }}
      />

      <ConfirmDialog
        open={!!cancelTarget}
        onClose={() => setCancelTarget(null)}
        onConfirm={() => {
          if (!cancelTarget) return;
          updateAdvance(cancelTarget.id, { status: 'closed' });
          showToast('Advance cancelled', 'info');
        }}
        title="Cancel Advance?"
        message="This will close the advance. Recovery history will be preserved. This action can be undone by editing the advance."
        confirmLabel="Cancel Advance"
      />
    </div>
  );
}

function AdvanceForm({
  open, onClose, employees, onSave,
}: {
  open: boolean;
  onClose: () => void;
  employees: ReturnType<typeof useData>['data']['employees'];
  onSave: (a: Advance) => void;
}) {
  const [form, setForm] = useState<Partial<Advance>>({
    employeeId: '',
    advanceDate: todayISO(),
    amount: 0,
    paymentMethod: 'cash',
    referenceNumber: '',
    notes: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSave = () => {
    const e: Record<string, string> = {};
    if (!form.employeeId) e.employeeId = 'Select an employee';
    if (!form.amount || form.amount <= 0) e.amount = 'Amount must be greater than 0';
    if (!form.advanceDate) e.advanceDate = 'Date is required';
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    onSave({
      id: uid('adv_'),
      employeeId: form.employeeId!,
      advanceDate: form.advanceDate!,
      amount: Number(form.amount),
      paymentMethod: (form.paymentMethod as PaymentMethod) || 'cash',
      referenceNumber: form.referenceNumber?.trim() || undefined,
      notes: form.notes?.trim() || undefined,
      status: 'active',
      createdAt: new Date().toISOString(),
    });
    setForm({ employeeId: '', advanceDate: todayISO(), amount: 0, paymentMethod: 'cash', referenceNumber: '', notes: '' });
  };

  if (employees.length === 0) {
    return (
      <Modal open={open} onClose={onClose} title="Add Advance" footer={<Button variant="outline" onClick={onClose}>Close</Button>}>
        <EmptyState title="No active employees" description="Add employees first before recording advances." />
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add Salary Advance"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Record Advance</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label="Employee" required error={errors.employeeId}>
          <Select value={form.employeeId} onChange={(e) => setForm((f) => ({ ...f, employeeId: e.target.value }))} error={!!errors.employeeId}>
            <option value="">Select employee...</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>{emp.fullName} ({emp.employeeId})</option>
            ))}
          </Select>
        </Field>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Advance Date" required error={errors.advanceDate}>
            <Input type="date" value={form.advanceDate} onChange={(e) => setForm((f) => ({ ...f, advanceDate: e.target.value }))} error={!!errors.advanceDate} />
          </Field>
          <Field label="Amount (₹)" required error={errors.amount}>
            <Input type="number" min={1} value={form.amount ?? ''} onChange={(e) => setForm((f) => ({ ...f, amount: Number(e.target.value) }))} error={!!errors.amount} placeholder="2000" />
          </Field>
        </div>
        <Field label="Payment Method">
          <Select value={form.paymentMethod} onChange={(e) => setForm((f) => ({ ...f, paymentMethod: e.target.value as PaymentMethod }))}>
            <option value="cash">Cash</option>
            <option value="upi">UPI</option>
            <option value="bank-transfer">Bank Transfer</option>
            <option value="other">Other</option>
          </Select>
        </Field>
        <Field label="Reference Number" hint="Optional">
          <Input value={form.referenceNumber} onChange={(e) => setForm((f) => ({ ...f, referenceNumber: e.target.value }))} placeholder="UTR, cheque no..." />
        </Field>
        <Field label="Notes" hint="Optional">
          <Textarea value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} placeholder="Reason for advance..." />
        </Field>
        <div className="rounded-lg bg-amber-50 border border-amber-200 p-3">
          <p className="text-xs text-amber-700">
            Recording an advance does not automatically deduct it from salary. You can recover it later through payroll or a manual recovery.
          </p>
        </div>
      </div>
    </Modal>
  );
}

function RecoveryModal({
  advance, onClose, onConfirm, maxAmount,
}: {
  advance: Advance | null;
  onClose: () => void;
  onConfirm: (amount: number, notes?: string) => void;
  maxAmount: number;
}) {
  const [amount, setAmount] = useState(0);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  const handleConfirm = () => {
    if (amount <= 0) { setError('Amount must be greater than 0'); return; }
    if (amount > maxAmount) { setError(`Amount cannot exceed ${formatINR(maxAmount)}`); return; }
    onConfirm(amount, notes.trim() || undefined);
    setAmount(0);
    setNotes('');
    setError('');
  };

  return (
    <Modal
      open={!!advance}
      onClose={onClose}
      title="Record Advance Recovery"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleConfirm}>Record Recovery</Button>
        </>
      }
    >
      {advance && (
        <div className="space-y-4">
          <div className="rounded-lg bg-slate-50 p-3">
            <p className="text-sm text-slate-600">
              Outstanding balance: <span className="font-bold text-orange-600">{formatINR(maxAmount)}</span>
            </p>
          </div>
          <Field label="Recovery Amount (₹)" required error={error}>
            <Input
              type="number"
              min={1}
              max={maxAmount}
              value={amount || ''}
              onChange={(e) => { setAmount(Number(e.target.value)); setError(''); }}
              error={!!error}
              placeholder={String(maxAmount)}
            />
          </Field>
          <Field label="Notes" hint="Optional">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="How was this recovered?" />
          </Field>
        </div>
      )}
    </Modal>
  );
}
