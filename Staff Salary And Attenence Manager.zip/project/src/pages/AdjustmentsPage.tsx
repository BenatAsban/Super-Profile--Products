import { useMemo, useState } from 'react';
import {
  Receipt, Plus, Download, TrendingUp, TrendingDown, Trash2,
} from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Card, CardBody } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Modal } from '@/components/ui/Modal';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { EmptyState, PageHeader, ConfirmDialog } from '@/components/ui/Misc';
import { useToast } from '@/hooks/useToast';
import {
  formatINR, formatDate, currentMonthKey, monthLabel, monthKey, uid, todayISO,
} from '@/lib/format';
import { downloadCSV } from '@/lib/export';
import { outstandingAdvance } from '@/lib/salary';
import type { Adjustment, AdjustmentType } from '@/lib/types';

const TYPE_LABELS: Record<AdjustmentType, string> = {
  'advance-recovery': 'Advance Recovery',
  'other-deduction': 'Other Deduction',
  'bonus': 'Bonus',
  'additional-earning': 'Additional Earning',
};

const TYPE_COLORS: Record<AdjustmentType, 'emerald' | 'red' | 'orange' | 'blue'> = {
  'advance-recovery': 'red',
  'other-deduction': 'orange',
  'bonus': 'emerald',
  'additional-earning': 'emerald',
};

export function AdjustmentsPage() {
  const { data, addAdjustment, removeAdjustment } = useData();
  const { showToast } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Adjustment | null>(null);
  const [typeFilter, setTypeFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('all');

  const activeEmployees = data.employees.filter((e) => e.status === 'active');

  const filtered = useMemo(() => {
    return data.adjustments
      .filter((a) => {
        if (typeFilter !== 'all' && a.type !== typeFilter) return false;
        if (monthFilter !== 'all' && a.salaryMonth !== monthFilter) return false;
        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [data.adjustments, typeFilter, monthFilter]);

  const totalBonus = useMemo(
    () => filtered.filter((a) => a.type === 'bonus' || a.type === 'additional-earning').reduce((s, a) => s + a.amount, 0),
    [filtered]
  );
  const totalDeductions = useMemo(
    () => filtered.filter((a) => a.type === 'other-deduction' || a.type === 'advance-recovery').reduce((s, a) => s + a.amount, 0),
    [filtered]
  );

  const exportCSV = () => {
    const rows: (string | number)[][] = [
      ['Employee ID', 'Name', 'Date', 'Salary Month', 'Type', 'Amount', 'Reason', 'Status'],
    ];
    for (const a of filtered) {
      const emp = data.employees.find((e) => e.id === a.employeeId);
      rows.push([
        emp?.employeeId || '',
        emp?.fullName || 'Unknown',
        a.date,
        a.salaryMonth,
        TYPE_LABELS[a.type],
        a.amount,
        a.reason,
        a.status,
      ]);
    }
    downloadCSV('adjustments', rows);
    showToast('Adjustments exported');
  };

  const canDelete = (adj: Adjustment) => adj.status === 'pending';

  return (
    <div>
      <PageHeader
        title="Adjustments"
        subtitle="Bonuses, deductions, and additional earnings"
        action={
          <>
            <Button variant="outline" size="sm" onClick={exportCSV}><Download size={16} /> Export</Button>
            <Button size="sm" onClick={() => setFormOpen(true)}><Plus size={16} /> Add Adjustment</Button>
          </>
        }
      />

      <div className="grid sm:grid-cols-2 gap-3 mb-4">
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 flex items-center gap-3">
          <TrendingUp className="text-emerald-600" size={22} />
          <div>
            <p className="text-xs text-emerald-600 font-medium">Total Bonuses & Earnings</p>
            <p className="text-xl font-bold text-emerald-700">{formatINR(totalBonus)}</p>
          </div>
        </div>
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 flex items-center gap-3">
          <TrendingDown className="text-red-600" size={22} />
          <div>
            <p className="text-xs text-red-600 font-medium">Total Deductions</p>
            <p className="text-xl font-bold text-red-700">{formatINR(totalDeductions)}</p>
          </div>
        </div>
      </div>

      <Card className="mb-4">
        <CardBody className="!py-3 flex flex-col sm:flex-row gap-3">
          <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="sm:w-48">
            <option value="all">All Types</option>
            <option value="bonus">Bonus</option>
            <option value="additional-earning">Additional Earning</option>
            <option value="other-deduction">Other Deduction</option>
            <option value="advance-recovery">Advance Recovery</option>
          </Select>
          <Select value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)} className="sm:w-44">
            <option value="all">All Months</option>
            {Array.from(new Set(data.adjustments.map((a) => a.salaryMonth))).sort().reverse().map((m) => (
              <option key={m} value={m}>{monthLabel(m)}</option>
            ))}
          </Select>
        </CardBody>
      </Card>

      {data.adjustments.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Receipt size={32} />}
            title="No adjustments recorded"
            description="Add bonuses, additional earnings, or deductions for salary adjustments. Advance recoveries can also be recorded here."
            action={<Button onClick={() => setFormOpen(true)}><Plus size={16} /> Add Adjustment</Button>}
          />
        </Card>
      ) : filtered.length === 0 ? (
        <Card><EmptyState title="No adjustments found" description="Try adjusting filters." /></Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((adj) => {
            const emp = data.employees.find((e) => e.id === adj.employeeId);
            const isEarning = adj.type === 'bonus' || adj.type === 'additional-earning';
            return (
              <Card key={adj.id}>
                <CardBody className="!py-3">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                        isEarning ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                      }`}>
                        {isEarning ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-700 truncate">
                          {emp?.fullName || 'Unknown'}
                        </p>
                        <p className="text-xs text-slate-400">
                          {formatDate(adj.date)} · {monthLabel(adj.salaryMonth)} · {adj.reason}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-sm font-bold ${isEarning ? 'text-emerald-600' : 'text-red-600'}`}>
                        {isEarning ? '+' : '-'}{formatINR(adj.amount)}
                      </span>
                      <Badge color={TYPE_COLORS[adj.type]}>{TYPE_LABELS[adj.type]}</Badge>
                      <Badge color={adj.status === 'applied' ? 'blue' : 'slate'}>
                        {adj.status === 'applied' ? 'Applied' : 'Pending'}
                      </Badge>
                      {canDelete(adj) && (
                        <Button variant="ghost" size="sm" onClick={() => setDeleteTarget(adj)}>
                          <Trash2 size={14} className="text-red-500" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardBody>
              </Card>
            );
          })}
        </div>
      )}

      <AdjustmentForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        employees={activeEmployees}
        advances={data.advances}
        recoveries={data.recoveries}
        onSave={(adj) => {
          addAdjustment(adj);
          setFormOpen(false);
          showToast('Adjustment added');
        }}
      />

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (!deleteTarget) return;
          removeAdjustment(deleteTarget.id);
          showToast('Adjustment deleted', 'info');
        }}
        title="Delete Adjustment?"
        message="This will permanently remove the adjustment. This cannot be undone."
        confirmLabel="Delete"
      />
    </div>
  );
}

function AdjustmentForm({
  open, onClose, employees, advances, recoveries, onSave,
}: {
  open: boolean;
  onClose: () => void;
  employees: ReturnType<typeof useData>['data']['employees'];
  advances: ReturnType<typeof useData>['data']['advances'];
  recoveries: ReturnType<typeof useData>['data']['recoveries'];
  onSave: (a: Adjustment) => void;
}) {
  const [form, setForm] = useState<Partial<Adjustment>>({
    employeeId: '',
    date: todayISO(),
    salaryMonth: currentMonthKey(),
    type: 'bonus',
    amount: 0,
    reason: '',
    advanceId: undefined,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const employeeAdvances = useMemo(
    () => advances.filter(
      (a) => a.employeeId === form.employeeId && a.status === 'active' && outstandingAdvance(a, recoveries) > 0
    ),
    [advances, recoveries, form.employeeId]
  );

  const handleSave = () => {
    const e: Record<string, string> = {};
    if (!form.employeeId) e.employeeId = 'Select an employee';
    if (!form.amount || form.amount <= 0) e.amount = 'Amount must be greater than 0';
    if (!form.reason?.trim()) e.reason = 'Reason is required';
    if (!form.date) e.date = 'Date is required';
    if (form.type === 'advance-recovery' && !form.advanceId) e.advanceId = 'Select an outstanding advance';
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    onSave({
      id: uid('adj_'),
      employeeId: form.employeeId!,
      date: form.date!,
      salaryMonth: form.salaryMonth || currentMonthKey(),
      type: form.type as AdjustmentType,
      amount: Number(form.amount),
      reason: form.reason!.trim(),
      advanceId: form.advanceId || undefined,
      status: 'pending',
      createdAt: new Date().toISOString(),
    });
    setForm({ employeeId: '', date: todayISO(), salaryMonth: currentMonthKey(), type: 'bonus', amount: 0, reason: '' });
  };

  if (employees.length === 0) {
    return (
      <Modal open={open} onClose={onClose} title="Add Adjustment" footer={<Button variant="outline" onClick={onClose}>Close</Button>}>
        <EmptyState title="No active employees" description="Add employees first." />
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add Salary Adjustment"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Add Adjustment</Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label="Employee" required error={errors.employeeId}>
          <Select
            value={form.employeeId}
            onChange={(e) => setForm((f) => ({ ...f, employeeId: e.target.value, advanceId: undefined }))}
            error={!!errors.employeeId}
          >
            <option value="">Select employee...</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>{emp.fullName} ({emp.employeeId})</option>
            ))}
          </Select>
        </Field>

        <Field label="Adjustment Type" required>
          <Select
            value={form.type}
            onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as AdjustmentType, advanceId: undefined }))}
          >
            <option value="bonus">Bonus</option>
            <option value="additional-earning">Additional Earning</option>
            <option value="other-deduction">Other Deduction</option>
            <option value="advance-recovery">Advance Recovery</option>
          </Select>
        </Field>

        {form.type === 'advance-recovery' && (
          <Field label="Outstanding Advance" required error={errors.advanceId} hint="Link to an actual outstanding advance to prevent double recovery.">
            {employeeAdvances.length === 0 ? (
              <p className="text-sm text-slate-400 py-2">No outstanding advances for this employee.</p>
            ) : (
              <Select
                value={form.advanceId || ''}
                onChange={(e) => setForm((f) => ({ ...f, advanceId: e.target.value }))}
                error={!!errors.advanceId}
              >
                <option value="">Select advance...</option>
                {employeeAdvances.map((a) => (
                  <option key={a.id} value={a.id}>
                    {formatINR(outstandingAdvance(a, recoveries))} remaining (given {formatDate(a.advanceDate)})
                  </option>
                ))}
              </Select>
            )}
          </Field>
        )}

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Date" required error={errors.date}>
            <Input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} error={!!errors.date} />
          </Field>
          <Field label="Salary Month" required>
            <Input type="month" value={form.salaryMonth} onChange={(e) => setForm((f) => ({ ...f, salaryMonth: e.target.value }))} />
          </Field>
        </div>

        <Field label="Amount (₹)" required error={errors.amount}>
          <Input type="number" min={1} value={form.amount ?? ''} onChange={(e) => setForm((f) => ({ ...f, amount: Number(e.target.value) }))} error={!!errors.amount} placeholder="500" />
        </Field>

        <Field label="Reason / Description" required error={errors.reason}>
          <Textarea value={form.reason} onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} error={!!errors.reason} placeholder="Performance bonus, late penalty..." />
        </Field>

        <div className="rounded-lg bg-blue-50 border border-blue-200 p-3">
          <p className="text-xs text-blue-700">
            Pending adjustments are applied when payroll is finalized for the selected month. Applied adjustments cannot be deleted.
          </p>
        </div>
      </div>
    </Modal>
  );
}
