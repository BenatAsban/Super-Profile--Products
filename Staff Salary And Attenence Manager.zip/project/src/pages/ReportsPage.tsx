import { useMemo, useState } from 'react';
import {
  BarChart3, Download, CalendarCheck, IndianRupee, Wallet,
  Clock, Users, FileText,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Legend,
} from 'recharts';
import { useData } from '@/context/DataContext';
import { Card, CardBody } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Select, Input } from '@/components/ui/Field';
import { EmptyState, PageHeader } from '@/components/ui/Misc';
import { useToast } from '@/hooks/useToast';
import {
  formatINR, formatDate, currentMonthKey, monthKey, monthLabel,
  todayISO, datesInMonth, getStatusLabel, round2,
} from '@/lib/format';
import { downloadCSV } from '@/lib/export';
import { summarizeAttendance } from '@/lib/attendance';
import { calculateSalary, outstandingAdvance, getOutstandingSalary } from '@/lib/salary';

type ReportType =
  | 'daily-attendance'
  | 'monthly-attendance'
  | 'employee-attendance'
  | 'monthly-salary'
  | 'employee-salary'
  | 'advances'
  | 'outstanding-advances'
  | 'deductions-bonuses'
  | 'paid-unpaid-salary'
  | 'overtime';

const REPORT_OPTIONS: { value: ReportType; label: string; icon: typeof BarChart3 }[] = [
  { value: 'daily-attendance', label: 'Daily Attendance Report', icon: CalendarCheck },
  { value: 'monthly-attendance', label: 'Monthly Attendance Summary', icon: CalendarCheck },
  { value: 'employee-attendance', label: 'Employee-wise Attendance', icon: Users },
  { value: 'monthly-salary', label: 'Monthly Salary Expense', icon: IndianRupee },
  { value: 'employee-salary', label: 'Employee-wise Salary Statement', icon: IndianRupee },
  { value: 'advances', label: 'Advances Given', icon: Wallet },
  { value: 'outstanding-advances', label: 'Outstanding Advances', icon: Wallet },
  { value: 'deductions-bonuses', label: 'Deductions & Bonuses', icon: FileText },
  { value: 'paid-unpaid-salary', label: 'Paid & Unpaid Salary Summary', icon: IndianRupee },
  { value: 'overtime', label: 'Overtime Report', icon: Clock },
];

export function ReportsPage() {
  const { data } = useData();
  const { showToast } = useToast();
  const [reportType, setReportType] = useState<ReportType>('daily-attendance');
  const [selectedMonth, setSelectedMonth] = useState(currentMonthKey());
  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [empFilter, setEmpFilter] = useState('all');

  const activeEmployees = data.employees.filter((e) => e.status === 'active');
  void activeEmployees;

  const handleExport = () => {
    const rows = buildExportRows();
    if (!rows) return;
    downloadCSV(`report-${reportType}-${selectedMonth || selectedDate}`, rows);
    showToast('Report exported');
  };

  const buildExportRows = (): (string | number)[][] | null => {
    switch (reportType) {
      case 'daily-attendance': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Department', 'Status', 'Overtime Hours']];
        const dayAtt = data.attendance.filter((a) => a.date === selectedDate);
        for (const emp of data.employees) {
          const att = dayAtt.find((a) => a.employeeId === emp.id);
          rows.push([emp.employeeId, emp.fullName, emp.department, att ? getStatusLabel(att.status) : 'Not Marked', att?.overtimeHours || 0]);
        }
        return rows;
      }
      case 'monthly-attendance': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Present', 'Absent', 'Half Day', 'Paid Leave', 'Unpaid Leave', 'Weekly Off', 'Holiday', 'Payable Days', 'OT Hours']];
        for (const emp of data.employees) {
          const att = data.attendance.filter((a) => a.employeeId === emp.id && monthKey(a.date) === selectedMonth);
          const s = summarizeAttendance(att);
          rows.push([emp.employeeId, emp.fullName, s.present, s.absent, s.halfDay, s.paidLeave, s.unpaidLeave, s.weeklyOff, s.holiday, s.payableDays, s.overtimeHours]);
        }
        return rows;
      }
      case 'employee-attendance': {
        const emps = empFilter === 'all' ? data.employees : data.employees.filter((e) => e.id === empFilter);
        const monthDates = datesInMonth(selectedMonth);
        const rows: (string | number)[][] = [['Employee ID', 'Name', ...monthDates.map((d) => d.slice(8)), 'Payable Days']];
        for (const emp of emps) {
          const att = data.attendance.filter((a) => a.employeeId === emp.id && monthKey(a.date) === selectedMonth);
          const dayMap = new Map(att.map((a) => [a.date, a.status]));
          const s = summarizeAttendance(att);
          rows.push([emp.employeeId, emp.fullName, ...monthDates.map((d) => getStatusLabel(dayMap.get(d) || 'not-marked').charAt(0)), s.payableDays]);
        }
        return rows;
      }
      case 'monthly-salary': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Type', 'Base', 'OT Earnings', 'Bonus', 'Deductions', 'Net Payable']];
        for (const emp of data.employees) {
          const att = data.attendance.filter((a) => a.employeeId === emp.id && monthKey(a.date) === selectedMonth);
          const b = calculateSalary({ employee: emp, month: selectedMonth, attendanceRecords: att, adjustments: data.adjustments, settings: data.settings });
          rows.push([emp.employeeId, emp.fullName, emp.salaryType, b.proratedBase, b.overtimeEarnings, b.bonus, b.totalDeductions, b.netPayable]);
        }
        return rows;
      }
      case 'employee-salary': {
        const emps = empFilter === 'all' ? data.employees : data.employees.filter((e) => e.id === empFilter);
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Month', 'Base', 'OT', 'Bonus', 'Deductions', 'Net', 'Status', 'Paid', 'Outstanding']];
        for (const emp of emps) {
          const payrolls = data.payrolls.filter((p) => p.employeeId === emp.id).sort((a, b) => a.salaryMonth.localeCompare(b.salaryMonth));
          if (payrolls.length === 0) {
            rows.push([emp.employeeId, emp.fullName, selectedMonth, 0, 0, 0, 0, 0, 'draft', 0, 0]);
          }
          for (const p of payrolls) {
            rows.push([emp.employeeId, emp.fullName, p.salaryMonth, p.baseSalary, p.overtimeEarnings, p.bonus, p.advanceRecovery + p.otherDeductions, p.netPayable, p.status, p.paidAmount, getOutstandingSalary(p)]);
          }
        }
        return rows;
      }
      case 'advances': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Date', 'Amount', 'Method', 'Reference', 'Status']];
        const advances = data.advances.filter((a) => monthKey(a.advanceDate) === selectedMonth);
        for (const a of advances) {
          const emp = data.employees.find((e) => e.id === a.employeeId);
          rows.push([emp?.employeeId || '', emp?.fullName || 'Unknown', a.advanceDate, a.amount, a.paymentMethod, a.referenceNumber || '', a.status]);
        }
        return rows;
      }
      case 'outstanding-advances': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Advance Date', 'Original Amount', 'Recovered', 'Outstanding']];
        for (const a of data.advances.filter((a) => a.status === 'active')) {
          const emp = data.employees.find((e) => e.id === a.employeeId);
          const remaining = outstandingAdvance(a, data.recoveries);
          if (remaining > 0) {
            rows.push([emp?.employeeId || '', emp?.fullName || 'Unknown', a.advanceDate, a.amount, round2(a.amount - remaining), remaining]);
          }
        }
        return rows;
      }
      case 'deductions-bonuses': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Date', 'Type', 'Amount', 'Reason', 'Month', 'Status']];
        const adjs = data.adjustments.filter((a) => a.salaryMonth === selectedMonth);
        for (const a of adjs) {
          const emp = data.employees.find((e) => e.id === a.employeeId);
          rows.push([emp?.employeeId || '', emp?.fullName || 'Unknown', a.date, a.type, a.amount, a.reason, a.salaryMonth, a.status]);
        }
        return rows;
      }
      case 'paid-unpaid-salary': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Month', 'Net Payable', 'Paid', 'Outstanding', 'Status']];
        const payrolls = data.payrolls.filter((p) => p.salaryMonth === selectedMonth);
        for (const p of payrolls) {
          const emp = data.employees.find((e) => e.id === p.employeeId);
          rows.push([emp?.employeeId || '', emp?.fullName || 'Unknown', p.salaryMonth, p.netPayable, p.paidAmount, getOutstandingSalary(p), p.status]);
        }
        return rows;
      }
      case 'overtime': {
        const rows: (string | number)[][] = [['Employee ID', 'Name', 'Date', 'OT Hours', 'OT Rate', 'OT Earnings']];
        const att = data.attendance.filter((a) => monthKey(a.date) === selectedMonth && a.overtimeHours > 0);
        for (const a of att) {
          const emp = data.employees.find((e) => e.id === a.employeeId);
          const rate = emp?.overtimeRatePerHour || 0;
          rows.push([emp?.employeeId || '', emp?.fullName || 'Unknown', a.date, a.overtimeHours, rate, round2(a.overtimeHours * rate)]);
        }
        return rows;
      }
      default:
        return null;
    }
  };

  const reportContent = useMemo(() => buildReportContent(), [reportType, selectedMonth, selectedDate, empFilter, data]);

  return (
    <div>
      <PageHeader
        title="Reports"
        subtitle="View and export detailed reports"
        action={<Button variant="outline" size="sm" onClick={handleExport}><Download size={16} /> Export CSV</Button>}
      />

      <Card className="mb-4">
        <CardBody className="!py-3">
          <div className="flex flex-col gap-3">
            <Select value={reportType} onChange={(e) => setReportType(e.target.value as ReportType)}>
              {REPORT_OPTIONS.map((r) => (
                <option key={r.value} value={r.value}>{r.label}</option>
              ))}
            </Select>
            <div className="flex flex-wrap gap-3">
              {reportType === 'daily-attendance' ? (
                <Input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="sm:w-44" />
              ) : (
                <Input type="month" value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} className="sm:w-44" />
              )}
              {(reportType === 'employee-attendance' || reportType === 'employee-salary') && (
                <Select value={empFilter} onChange={(e) => setEmpFilter(e.target.value)} className="sm:w-48">
                  <option value="all">All Employees</option>
                  {data.employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>{emp.fullName}</option>
                  ))}
                </Select>
              )}
            </div>
          </div>
        </CardBody>
      </Card>

      {data.employees.length === 0 ? (
        <Card>
          <EmptyState icon={<BarChart3 size={32} />} title="No data to report" description="Add employees and mark attendance to generate reports." />
        </Card>
      ) : (
        reportContent
      )}
    </div>
  );

  function buildReportContent() {
    switch (reportType) {
      case 'daily-attendance':
        return <DailyAttendanceReport date={selectedDate} />;
      case 'monthly-attendance':
        return <MonthlyAttendanceReport month={selectedMonth} />;
      case 'employee-attendance':
        return <EmployeeAttendanceReport month={selectedMonth} empFilter={empFilter} />;
      case 'monthly-salary':
        return <MonthlySalaryReport month={selectedMonth} />;
      case 'employee-salary':
        return <EmployeeSalaryReport empFilter={empFilter} />;
      case 'advances':
        return <AdvancesReport month={selectedMonth} />;
      case 'outstanding-advances':
        return <OutstandingAdvancesReport />;
      case 'deductions-bonuses':
        return <DeductionsBonusesReport month={selectedMonth} />;
      case 'paid-unpaid-salary':
        return <PaidUnpaidReport month={selectedMonth} />;
      case 'overtime':
        return <OvertimeReport month={selectedMonth} />;
      default:
        return null;
    }
  }
}

function ReportTable({ headers, rows }: { headers: string[]; rows: (string | number)[][] }) {
  return (
    <Card>
      <CardBody className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                {headers.map((h, i) => (
                  <th key={i} className={`px-3 py-2.5 text-xs font-medium text-slate-500 ${typeof rows[0]?.[i] === 'number' ? 'text-right' : 'text-left'}`}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 ? (
                <tr><td colSpan={headers.length} className="px-3 py-8 text-center text-slate-400">No records found for this period</td></tr>
              ) : (
                rows.map((row, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    {row.map((cell, j) => (
                      <td key={j} className={`px-3 py-2.5 ${typeof cell === 'number' ? 'text-right text-slate-600' : 'text-left text-slate-700'}`}>{cell}</td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </CardBody>
    </Card>
  );
}

function DailyAttendanceReport({ date }: { date: string }) {
  const { data } = useData();
  const dayAtt = data.attendance.filter((a) => a.date === date);
  const rows: (string | number)[][] = data.employees.map((emp) => {
    const att = dayAtt.find((a) => a.employeeId === emp.id);
    return [emp.employeeId, emp.fullName, emp.department, att ? getStatusLabel(att.status) : 'Not Marked', att?.overtimeHours || 0];
  });
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Attendance for {formatDate(date)}</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Department', 'Status', 'OT Hours']} rows={rows} />
    </div>
  );
}

function MonthlyAttendanceReport({ month }: { month: string }) {
  const { data } = useData();
  const rows: (string | number)[][] = data.employees.map((emp) => {
    const att = data.attendance.filter((a) => a.employeeId === emp.id && monthKey(a.date) === month);
    const s = summarizeAttendance(att);
    return [emp.employeeId, emp.fullName, s.present, s.absent, s.halfDay, s.paidLeave, s.unpaidLeave, s.weeklyOff, s.holiday, s.payableDays, s.overtimeHours];
  });
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Monthly Attendance — {monthLabel(month)}</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Present', 'Absent', 'Half', 'Paid Leave', 'Unpaid', 'W. Off', 'Holiday', 'Payable', 'OT hrs']} rows={rows} />
    </div>
  );
}

function EmployeeAttendanceReport({ month, empFilter }: { month: string; empFilter: string }) {
  const { data } = useData();
  const emps = empFilter === 'all' ? data.employees : data.employees.filter((e) => e.id === empFilter);
  const monthDates = datesInMonth(month);
  const rows: (string | number)[][] = emps.map((emp) => {
    const att = data.attendance.filter((a) => a.employeeId === emp.id && monthKey(a.date) === month);
    const dayMap = new Map(att.map((a) => [a.date, a.status]));
    const s = summarizeAttendance(att);
    return [emp.employeeId, emp.fullName, ...monthDates.map((d) => getStatusLabel(dayMap.get(d) || 'not-marked').charAt(0)), s.payableDays];
  });
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Employee-wise Attendance — {monthLabel(month)}</h3>
      <div className="overflow-x-auto">
        <Card>
          <CardBody className="p-0">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-2 py-2 text-left text-xs font-medium text-slate-500 sticky left-0 bg-slate-50">Emp ID</th>
                  <th className="px-2 py-2 text-left text-xs font-medium text-slate-500 sticky left-12 bg-slate-50">Name</th>
                  {monthDates.map((d) => (
                    <th key={d} className="px-1 py-2 text-center text-xs font-medium text-slate-400 min-w-[20px]">{Number(d.slice(8))}</th>
                  ))}
                  <th className="px-2 py-2 text-right text-xs font-medium text-slate-500">Payable</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((row, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    {row.map((cell, j) => (
                      <td key={j} className={`px-1 py-1.5 ${j < 2 ? 'text-left text-slate-700 font-medium' : 'text-center text-slate-500'} ${j < 2 ? 'sticky' : ''} ${j === 0 ? 'left-0 bg-white' : ''} ${j === 1 ? 'left-12 bg-white' : ''} ${j === row.length - 1 ? 'text-right font-semibold text-slate-700' : ''}`}>{cell}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

function MonthlySalaryReport({ month }: { month: string }) {
  const { data } = useData();
  const rows: (string | number)[][] = data.employees.map((emp) => {
    const att = data.attendance.filter((a) => a.employeeId === emp.id && monthKey(a.date) === month);
    const b = calculateSalary({ employee: emp, month, attendanceRecords: att, adjustments: data.adjustments, settings: data.settings });
    return [emp.employeeId, emp.fullName, emp.salaryType, formatINR(b.proratedBase), formatINR(b.overtimeEarnings), formatINR(b.bonus), formatINR(b.totalDeductions), formatINR(b.netPayable)];
  });
  const total = rows.reduce((s, r) => s + (Number(String(r[7]).replace(/[₹,]/g, '')) || 0), 0);
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Monthly Salary Expense — {monthLabel(month)}</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Type', 'Base', 'OT', 'Bonus', 'Deductions', 'Net Payable']} rows={rows} />
      <div className="mt-3 rounded-lg bg-slate-800 text-white px-4 py-3 flex justify-between items-center">
        <span className="text-sm">Total Salary Expense</span>
        <span className="text-lg font-bold">{formatINR(total)}</span>
      </div>
    </div>
  );
}

function EmployeeSalaryReport({ empFilter }: { empFilter: string }) {
  const { data } = useData();
  const emps = empFilter === 'all' ? data.employees : data.employees.filter((e) => e.id === empFilter);
  const rows: (string | number)[][] = [];
  for (const emp of emps) {
    const payrolls = data.payrolls.filter((p) => p.employeeId === emp.id).sort((a, b) => a.salaryMonth.localeCompare(b.salaryMonth));
    if (payrolls.length === 0) {
      rows.push([emp.employeeId, emp.fullName, '-', formatINR(0), formatINR(0), formatINR(0), formatINR(0), formatINR(0), 'draft', formatINR(0), formatINR(0)]);
    }
    for (const p of payrolls) {
      rows.push([emp.employeeId, emp.fullName, p.salaryMonth, formatINR(p.baseSalary), formatINR(p.overtimeEarnings), formatINR(p.bonus), formatINR(p.advanceRecovery + p.otherDeductions), formatINR(p.netPayable), p.status, formatINR(p.paidAmount), formatINR(getOutstandingSalary(p))]);
    }
  }
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Employee-wise Salary Statement</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Month', 'Base', 'OT', 'Bonus', 'Deductions', 'Net', 'Status', 'Paid', 'Outstanding']} rows={rows} />
    </div>
  );
}

function AdvancesReport({ month }: { month: string }) {
  const { data } = useData();
  const advances = data.advances.filter((a) => monthKey(a.advanceDate) === month);
  const rows: (string | number)[][] = advances.map((a) => {
    const emp = data.employees.find((e) => e.id === a.employeeId);
    return [emp?.employeeId || '', emp?.fullName || 'Unknown', a.advanceDate, formatINR(a.amount), a.paymentMethod, a.referenceNumber || '', a.status];
  });
  const total = advances.reduce((s, a) => s + a.amount, 0);
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Advances Given — {monthLabel(month)}</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Date', 'Amount', 'Method', 'Reference', 'Status']} rows={rows} />
      <div className="mt-3 rounded-lg bg-orange-50 border border-orange-200 px-4 py-3 flex justify-between items-center">
        <span className="text-sm text-orange-700">Total Advances</span>
        <span className="text-lg font-bold text-orange-700">{formatINR(total)}</span>
      </div>
    </div>
  );
}

function OutstandingAdvancesReport() {
  const { data } = useData();
  const rows: (string | number)[][] = [];
  for (const a of data.advances.filter((a) => a.status === 'active')) {
    const remaining = outstandingAdvance(a, data.recoveries);
    if (remaining > 0) {
      const emp = data.employees.find((e) => e.id === a.employeeId);
      rows.push([emp?.employeeId || '', emp?.fullName || 'Unknown', a.advanceDate, formatINR(a.amount), formatINR(round2(a.amount - remaining)), formatINR(remaining)]);
    }
  }
  const total = rows.reduce((s, r) => s + (Number(String(r[5]).replace(/[₹,]/g, '')) || 0), 0);
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Outstanding Advances (All Time)</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Date', 'Original', 'Recovered', 'Outstanding']} rows={rows} />
      <div className="mt-3 rounded-lg bg-orange-50 border border-orange-200 px-4 py-3 flex justify-between items-center">
        <span className="text-sm text-orange-700">Total Outstanding</span>
        <span className="text-lg font-bold text-orange-700">{formatINR(total)}</span>
      </div>
    </div>
  );
}

function DeductionsBonusesReport({ month }: { month: string }) {
  const { data } = useData();
  const adjs = data.adjustments.filter((a) => a.salaryMonth === month);
  const rows: (string | number)[][] = adjs.map((a) => {
    const emp = data.employees.find((e) => e.id === a.employeeId);
    return [emp?.employeeId || '', emp?.fullName || 'Unknown', a.date, a.type, formatINR(a.amount), a.reason, a.status];
  });
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Deductions & Bonuses — {monthLabel(month)}</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Date', 'Type', 'Amount', 'Reason', 'Status']} rows={rows} />
    </div>
  );
}

function PaidUnpaidReport({ month }: { month: string }) {
  const { data } = useData();
  const payrolls = data.payrolls.filter((p) => p.salaryMonth === month);
  const rows: (string | number)[][] = payrolls.map((p) => {
    const emp = data.employees.find((e) => e.id === p.employeeId);
    return [emp?.employeeId || '', emp?.fullName || 'Unknown', p.salaryMonth, formatINR(p.netPayable), formatINR(p.paidAmount), formatINR(getOutstandingSalary(p)), p.status];
  });
  const totalNet = payrolls.reduce((s, p) => s + p.netPayable, 0);
  const totalPaid = payrolls.reduce((s, p) => s + p.paidAmount, 0);
  const totalOutstanding = round2(totalNet - totalPaid);
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Paid & Unpaid Salary — {monthLabel(month)}</h3>
      <ReportTable headers={['Emp ID', 'Name', 'Month', 'Net Payable', 'Paid', 'Outstanding', 'Status']} rows={rows} />
      <div className="mt-3 grid grid-cols-3 gap-3">
        <div className="rounded-lg bg-slate-50 border border-slate-200 px-4 py-3">
          <p className="text-xs text-slate-500">Total Net Payable</p>
          <p className="text-lg font-bold text-slate-800">{formatINR(totalNet)}</p>
        </div>
        <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-3">
          <p className="text-xs text-emerald-600">Total Paid</p>
          <p className="text-lg font-bold text-emerald-700">{formatINR(totalPaid)}</p>
        </div>
        <div className="rounded-lg bg-orange-50 border border-orange-200 px-4 py-3">
          <p className="text-xs text-orange-600">Total Outstanding</p>
          <p className="text-lg font-bold text-orange-700">{formatINR(totalOutstanding)}</p>
        </div>
      </div>
    </div>
  );
}

function OvertimeReport({ month }: { month: string }) {
  const { data } = useData();
  const att = data.attendance.filter((a) => monthKey(a.date) === month && a.overtimeHours > 0);
  const rows: (string | number)[][] = att.map((a) => {
    const emp = data.employees.find((e) => e.id === a.employeeId);
    const rate = emp?.overtimeRatePerHour || 0;
    return [emp?.employeeId || '', emp?.fullName || 'Unknown', a.date, a.overtimeHours, formatINR(rate), formatINR(round2(a.overtimeHours * rate))];
  });
  const totalHours = att.reduce((s, a) => s + a.overtimeHours, 0);
  const totalEarnings = att.reduce((s, a) => {
    const emp = data.employees.find((e) => e.id === a.employeeId);
    return s + round2(a.overtimeHours * (emp?.overtimeRatePerHour || 0));
  }, 0);

  // Per employee summary
  const empSummary = data.employees.map((emp) => {
    const empAtt = att.filter((a) => a.employeeId === emp.id);
    const hours = empAtt.reduce((s, a) => s + a.overtimeHours, 0);
    const earnings = round2(hours * (emp.overtimeRatePerHour || 0));
    return { name: emp.fullName, hours, earnings };
  }).filter((e) => e.hours > 0);

  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Overtime Report — {monthLabel(month)}</h3>
      <div className="grid sm:grid-cols-2 gap-3 mb-4">
        <div className="rounded-lg bg-slate-50 border border-slate-200 px-4 py-3">
          <p className="text-xs text-slate-500">Total OT Hours</p>
          <p className="text-lg font-bold text-slate-800">{totalHours} hrs</p>
        </div>
        <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-3">
          <p className="text-xs text-emerald-600">Total OT Earnings</p>
          <p className="text-lg font-bold text-emerald-700">{formatINR(totalEarnings)}</p>
        </div>
      </div>
      {empSummary.length > 0 && (
        <Card className="mb-4">
          <CardHeader><CardTitle>Employee-wise Overtime</CardTitle></CardHeader>
          <CardBody>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={empSummary}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="hours" fill="#0284c7" radius={[4, 4, 0, 0]} name="OT Hours" />
              </BarChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>
      )}
      <ReportTable headers={['Emp ID', 'Name', 'Date', 'OT Hours', 'OT Rate', 'OT Earnings']} rows={rows} />
    </div>
  );
}
