import { useRef, useState } from 'react';
import {
  Store, Download, Upload, Trash2, AlertCircle,
  Database, FlaskConical, Check, IndianRupee,
} from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Field, Input, Select, Textarea } from '@/components/ui/Field';
import { PageHeader, ConfirmDialog } from '@/components/ui/Misc';
import { useToast } from '@/hooks/useToast';
import { downloadJSON, readJSONFile } from '@/lib/export';
import { isValidDataShape } from '@/lib/storage';
import type { AppData, SalaryPolicy } from '@/lib/types';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export function SettingsPage() {
  const { data, updateSettings, loadDemoData, removeDemoData, importData, clearAllData } = useData();
  const { showToast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [clearOpen, setClearOpen] = useState(false);
  const [importPreview, setImportPreview] = useState<{ data: AppData; replace: boolean } | null>(null);
  const [removeDemoOpen, setRemoveDemoOpen] = useState(false);

  const s = data.settings;

  const handleSave = () => {
    showToast('Settings saved');
  };

  const handleExportJSON = () => {
    downloadJSON('staff-manager-data-export', data);
    showToast('Data exported to JSON');
  };

  const handleImportFile = async (file: File) => {
    try {
      const parsed = await readJSONFile<AppData>(file);
      if (!isValidDataShape(parsed)) {
        showToast('Invalid file format. Not a valid data backup.', 'error');
        return;
      }
      setImportPreview({ data: parsed, replace: false });
    } catch {
      showToast('Could not read the file. Make sure it is a valid JSON export.', 'error');
    }
  };

  const confirmImport = () => {
    if (!importPreview) return;
    const ok = importData(importPreview.data, importPreview.replace);
    if (ok) {
      showToast('Data imported successfully');
    } else {
      showToast('Import failed. Invalid data.', 'error');
    }
    setImportPreview(null);
  };

  const toggleWeeklyOff = (day: string) => {
    const current = s.defaultWeeklyOffDays;
    updateSettings({
      defaultWeeklyOffDays: current.includes(day)
        ? current.filter((d) => d !== day)
        : [...current, day],
    });
  };

  return (
    <div>
      <PageHeader title="Settings" subtitle="Configure your business and salary policies" />

      <div className="space-y-5 max-w-3xl">
        {/* Business Info */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Store size={18} className="text-emerald-600" />
              <CardTitle>Business Information</CardTitle>
            </div>
          </CardHeader>
          <CardBody className="space-y-4">
            <Field label="Business Name">
              <Input value={s.businessName} onChange={(e) => updateSettings({ businessName: e.target.value })} placeholder="Sharma General Store" />
            </Field>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Business Phone">
                <Input value={s.businessPhone} onChange={(e) => updateSettings({ businessPhone: e.target.value })} placeholder="9876543210" />
              </Field>
              <Field label="Currency">
                <Select value={s.currency} onChange={(e) => updateSettings({ currency: e.target.value })} disabled>
                  <option value="INR">INR (₹) — Indian Rupee</option>
                </Select>
              </Field>
            </div>
            <Field label="Business Address">
              <Textarea value={s.businessAddress} onChange={(e) => updateSettings({ businessAddress: e.target.value })} placeholder="123 Market Street, City, State - PIN" />
            </Field>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Language">
                <Select value={s.language} onChange={(e) => updateSettings({ language: e.target.value as 'english' | 'tamil' })}>
                  <option value="english">English</option>
                  <option value="tamil">Tamil (தமிழ்)</option>
                </Select>
              </Field>
              <Field label="Default Salary Payment Day" hint="Day of month salary is usually paid">
                <Input type="number" min={1} max={31} value={s.defaultPaymentDay} onChange={(e) => updateSettings({ defaultPaymentDay: Number(e.target.value) })} />
              </Field>
            </div>
          </CardBody>
        </Card>

        {/* Salary Policy */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <IndianRupee size={18} className="text-emerald-600" />
              <CardTitle>Salary Calculation Policy</CardTitle>
            </div>
          </CardHeader>
          <CardBody className="space-y-4">
            <Field label="Salary Calculation Method" hint="Controls how monthly salary is prorated based on attendance">
              <Select value={s.salaryPolicy} onChange={(e) => updateSettings({ salaryPolicy: e.target.value as SalaryPolicy })}>
                <option value="no-proration">No Proration (Full salary regardless of attendance)</option>
                <option value="prorate-salary-days">Prorate by Salary Days (e.g. 30 days/month)</option>
                <option value="prorate-calendar-days">Prorate by Calendar Days (actual days in month)</option>
              </Select>
            </Field>
            {s.salaryPolicy === 'prorate-salary-days' && (
              <Field label="Salary Days Per Month" hint="Standard working days used for proration">
                <Input type="number" min={1} max={31} value={s.salaryDaysPerMonth} onChange={(e) => updateSettings({ salaryDaysPerMonth: Number(e.target.value) })} />
              </Field>
            )}
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Default Working Hours Per Day">
                <Input type="number" min={1} max={24} value={s.defaultWorkingHours} onChange={(e) => updateSettings({ defaultWorkingHours: Number(e.target.value) })} />
              </Field>
              <Field label="Default Overtime Rate Per Hour (₹)">
                <Input type="number" min={0} value={s.defaultOvertimeRate} onChange={(e) => updateSettings({ defaultOvertimeRate: Number(e.target.value) })} />
              </Field>
            </div>
            <Field label="Default Weekly Off Days">
              <div className="flex flex-wrap gap-2">
                {DAYS.map((day) => (
                  <button
                    key={day}
                    type="button"
                    onClick={() => toggleWeeklyOff(day)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
                      s.defaultWeeklyOffDays.includes(day)
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {day.slice(0, 3)}
                  </button>
                ))}
              </div>
            </Field>
            <div className="rounded-lg bg-blue-50 border border-blue-200 p-3">
              <p className="text-xs text-blue-700">
                Configure salary policies according to your business's applicable rules. This tool does not automatically apply statutory deductions or tax rates. Make manual entries where required.
              </p>
            </div>
          </CardBody>
        </Card>

        {/* Demo Data */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <FlaskConical size={18} className="text-amber-600" />
              <CardTitle>Demo Data</CardTitle>
              {data.demoDataLoaded && <Badge color="amber">Demo data loaded</Badge>}
            </div>
          </CardHeader>
          <CardBody className="space-y-3">
            <p className="text-sm text-slate-500">
              Load sample employees, attendance, and advances to explore the app. Demo data is clearly labeled and can be safely removed without affecting your real records.
            </p>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={loadDemoData}>
                <FlaskConical size={14} /> Load Demo Data
              </Button>
              {data.demoDataLoaded && (
                <Button variant="outline" size="sm" onClick={() => setRemoveDemoOpen(true)}>
                  <Trash2 size={14} /> Remove Demo Data
                </Button>
              )}
            </div>
          </CardBody>
        </Card>

        {/* Data Management */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Database size={18} className="text-slate-600" />
              <CardTitle>Data Backup & Restore</CardTitle>
            </div>
          </CardHeader>
          <CardBody className="space-y-4">
            <div className="rounded-lg bg-amber-50 border border-amber-200 p-3">
              <p className="text-xs text-amber-700">
                <AlertCircle size={14} className="inline mr-1" />
                Your data is stored locally in this browser only. It may be lost if you clear browser data. Export regularly to keep a backup. This app does not offer cloud backup or cross-device sync.
              </p>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={handleExportJSON}>
                <Download size={14} /> Export All Data (JSON)
              </Button>
              <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                <Upload size={14} /> Import Data (JSON)
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept=".json,application/json"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleImportFile(file);
                  e.target.value = '';
                }}
              />
            </div>
            <div className="pt-3 border-t border-slate-100">
              <Button variant="danger" size="sm" onClick={() => setClearOpen(true)}>
                <Trash2 size={14} /> Clear All Data
              </Button>
              <p className="text-xs text-slate-400 mt-2">This permanently deletes all employees, attendance, advances, and payroll records from this browser.</p>
            </div>
          </CardBody>
        </Card>

        <div className="flex justify-end">
          <Button onClick={handleSave}><Check size={16} /> Save Settings</Button>
        </div>
      </div>

      <ConfirmDialog
        open={clearOpen}
        onClose={() => setClearOpen(false)}
        onConfirm={() => {
          clearAllData();
          showToast('All data cleared', 'info');
        }}
        title="Clear All Data?"
        message={
          <div>
            <p className="font-medium text-red-600">This will permanently delete ALL data:</p>
            <ul className="mt-2 text-sm text-slate-600 list-disc pl-5 space-y-0.5">
              <li>All employees</li>
              <li>All attendance records</li>
              <li>All advances and recoveries</li>
              <li>All adjustments</li>
              <li>All payroll and payment history</li>
              <li>All settings</li>
            </ul>
            <p className="mt-2 text-sm">This cannot be undone. Consider exporting a backup first.</p>
          </div>
        }
        confirmLabel="Yes, Delete Everything"
      />

      <ConfirmDialog
        open={!!importPreview}
        onClose={() => setImportPreview(null)}
        onConfirm={confirmImport}
        title="Import Data?"
        message={
          <div>
            <p>This will import data from the selected JSON file.</p>
            <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <div className="rounded bg-slate-50 p-2">
                <p className="text-slate-500">Employees</p>
                <p className="font-medium">{importPreview?.data.employees.length || 0}</p>
              </div>
              <div className="rounded bg-slate-50 p-2">
                <p className="text-slate-500">Attendance</p>
                <p className="font-medium">{importPreview?.data.attendance.length || 0}</p>
              </div>
              <div className="rounded bg-slate-50 p-2">
                <p className="text-slate-500">Advances</p>
                <p className="font-medium">{importPreview?.data.advances.length || 0}</p>
              </div>
              <div className="rounded bg-slate-50 p-2">
                <p className="text-slate-500">Payrolls</p>
                <p className="font-medium">{importPreview?.data.payrolls.length || 0}</p>
              </div>
            </div>
            <p className="mt-3 text-sm">Data will be <strong>merged</strong> with existing records. If you want to replace all data, cancel and use "Clear All Data" first.</p>
          </div>
        }
        confirmLabel="Import & Merge"
        variant="primary"
      />

      <ConfirmDialog
        open={removeDemoOpen}
        onClose={() => setRemoveDemoOpen(false)}
        onConfirm={() => {
          removeDemoData();
          showToast('Demo data removed', 'info');
        }}
        title="Remove Demo Data?"
        message="This will remove demo employees and their related records. Your real employee records will not be affected."
        confirmLabel="Remove Demo Data"
      />
    </div>
  );
}
