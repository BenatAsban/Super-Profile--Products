import { useMemo, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Phone, Mail, Building2, Calendar, IndianRupee, Clock,
  Pencil, UserX, UserCheck, Users,
} from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { EmptyState, ConfirmDialog } from '@/components/ui/Misc';
import { EmployeeForm } from '@/components/EmployeeForm';
import { useToast } from '@/hooks/useToast';
import {
  formatINR, formatDate, currentMonthKey, monthKey, monthLabel,
} from '@/lib/format';
import { summarizeAttendance } from '@/lib/attendance';
import { calculateSalary, totalOutstandingForEmployee } from '@/lib/salary';

export function EmployeeProfilePage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data, updateEmployee } = useData();
  const { showToast } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [deactivateOpen, setDeactivateOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(currentMonthKey());

  const employee = data.employees.find((e) => e.id === id);

  const empAttendance = useMemo(
    () => (employee ? data.attendance.filter((a) => a.employeeId === employee.id) : []),
    [data.attendance, employee]
  );

  const empAdvances = useMemo(
    () => (employee ? data.advances.filter((a) => a.employeeId === employee.id) : []),
    [data.advances, employee]
  );

  const empAdjustments = useMemo(
    () => (employee ? data.adjustments.filter((a) => a.employeeId === employee.id) : []),
    [data.adjustments, employee]
  );

  const empPayrolls = useMemo(
    () => (employee ? data.payrolls.filter((p) => p.employeeId === employee.id).sort((a, b) => b.salaryMonth.localeCompare(a.salaryMonth)) : []),
    [data.payrolls, employee]
  );

  const monthAttendance = useMemo(
    () => empAttendance.filter((a) => monthKey(a.date) === selectedMonth),
    [empAttendance, selectedMonth]
  );

  const monthSummary = useMemo(() => summarizeAttendance(monthAttendance), [monthAttendance]);

  const monthSalary = useMemo(() => {
    if (!employee) return null;
    return calculateSalary({
      employee,
      month: selectedMonth,
      attendanceRecords: monthAttendance,
      adjustments: data.adjustments,
      settings: data.settings,
    });
  }, [employee, monthAttendance, data.adjustments, data.settings, selectedMonth]);

  const outstanding = useMemo(
    () => (employee ? totalOutstandingForEmployee(employee.id, data.advances, data.recoveries) : 0),
    [employee, data.advances, data.recoveries]
  );

  if (!employee) {
    return (
      <div>
        <EmptyState
          icon={<Users size={32} />}
          title="Employee not found"
          description="This employee may have been removed."
          action={<Link to="/app/employees"><Button>Back to Employees</Button></Link>}
        />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <Link to="/app/employees" className="p-2 -ml-2 text-slate-500 hover:bg-slate-100 rounded-lg">
          <ArrowLeft size={20} />
        </Link>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-bold text-slate-800 truncate">{employee.fullName}</h1>
          <p className="text-sm text-slate-400">{employee.employeeId}</p>
        </div>
        <Badge color={employee.status === 'active' ? 'emerald' : 'slate'}>
          {employee.status === 'active' ? 'Active' : 'Inactive'}
        </Badge>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Info card */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Employee Details</CardTitle>
            </div>
          </CardHeader>
          <CardBody className="space-y-3">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="w-14 h-14 rounded-full bg-slate-200 flex items-center justify-center text-xl font-bold text-slate-600">
                {employee.fullName.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="font-semibold text-slate-800">{employee.fullName}</p>
                <p className="text-sm text-slate-400">{employee.department}</p>
              </div>
            </div>

            <InfoRow icon={Building2} label="Department" value={employee.department} />
            <InfoRow icon={Phone} label="Phone" value={employee.phone} />
            {employee.email && <InfoRow icon={Mail} label="Email" value={employee.email} />}
            <InfoRow icon={Calendar} label="Joining Date" value={formatDate(employee.joiningDate)} />
            <InfoRow
              icon={IndianRupee}
              label="Salary"
              value={employee.salaryType === 'monthly'
                ? `${formatINR(employee.monthlySalary || 0)} / month`
                : `${formatINR(employee.dailyWageRate || 0)} / day`}
            />
            <InfoRow icon={Clock} label="Working Hours" value={`${employee.standardHoursPerDay} hrs/day`} />
            <InfoRow icon={IndianRupee} label="Overtime Rate" value={`${formatINR(employee.overtimeRatePerHour)} / hr`} />
            <div className="pt-2">
              <p className="text-xs text-slate-400 mb-1">Weekly Offs</p>
              <div className="flex flex-wrap gap-1">
                {employee.weeklyOffDays.length > 0 ? (
                  employee.weeklyOffDays.map((d) => (
                    <Badge key={d} color="slate">{d.slice(0, 3)}</Badge>
                  ))
                ) : (
                  <span className="text-sm text-slate-400">No weekly offs set</span>
                )}
              </div>
            </div>
            {employee.notes && (
              <div className="pt-2">
                <p className="text-xs text-slate-400 mb-1">Notes</p>
                <p className="text-sm text-slate-600">{employee.notes}</p>
              </div>
            )}

            <div className="flex gap-2 pt-3 border-t border-slate-100">
              <Button variant="outline" size="sm" className="flex-1" onClick={() => setFormOpen(true)}>
                <Pencil size={14} /> Edit
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setDeactivateOpen(true)}
              >
                {employee.status === 'active' ? <UserX size={14} /> : <UserCheck size={14} />}
              </Button>
            </div>
          </CardBody>
        </Card>

        {/* Right column */}
        <div className="lg:col-span-2 space-y-5">
          {/* Month selector */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <CardTitle>Monthly Summary</CardTitle>
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="h-9 rounded-lg border border-slate-300 px-3 text-sm bg-white cursor-pointer"
                >
                  {Array.from(new Set(empAttendance.map((a) => monthKey(a.date))))
                    .sort()
                    .reverse()
                    .map((m) => (
                      <option key={m} value={m}>{monthLabel(m)}</option>
                    ))}
                  {!empAttendance.map((a) => monthKey(a.date)).includes(selectedMonth) && (
                    <option value={selectedMonth}>{monthLabel(selectedMonth)}</option>
                  )}
                </select>
              </div>
            </CardHeader>
            <CardBody>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                <MiniStat label="Present" value={monthSummary.present} color="text-emerald-600" />
                <MiniStat label="Absent" value={monthSummary.absent} color="text-red-600" />
                <MiniStat label="Half Day" value={monthSummary.halfDay} color="text-amber-600" />
                <MiniStat label="Paid Leave" value={monthSummary.paidLeave} color="text-blue-600" />
                <MiniStat label="Unpaid Leave" value={monthSummary.unpaidLeave} color="text-orange-600" />
                <MiniStat label="Weekly Off" value={monthSummary.weeklyOff} color="text-slate-600" />
                <MiniStat label="OT Hours" value={monthSummary.overtimeHours} color="text-slate-600" />
                <MiniStat label="Payable Days" value={monthSummary.payableDays} color="text-slate-800" />
              </div>

              {monthSalary && (
                <div className="rounded-lg bg-slate-50 p-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Base Salary</span>
                    <span className="font-medium text-slate-700">{formatINR(monthSalary.proratedBase)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Overtime ({monthSalary.overtimeHours}h)</span>
                    <span className="font-medium text-emerald-600">+{formatINR(monthSalary.overtimeEarnings)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Bonus</span>
                    <span className="font-medium text-emerald-600">+{formatINR(monthSalary.bonus)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Deductions</span>
                    <span className="font-medium text-red-600">-{formatINR(monthSalary.totalDeductions)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-200">
                    <span className="font-semibold text-slate-700">Net Payable</span>
                    <span className="font-bold text-slate-800">{formatINR(monthSalary.netPayable)}</span>
                  </div>
                </div>
              )}
            </CardBody>
          </Card>

          {/* Advances */}
          <Card>
            <CardHeader>
              <CardTitle>Advances ({empAdvances.length})</CardTitle>
            </CardHeader>
            <CardBody className="p-0">
              {empAdvances.length === 0 ? (
                <p className="text-sm text-slate-400 text-center py-6">No advances recorded</p>
              ) : (
                <div className="divide-y divide-slate-100">
                  {empAdvances.map((adv) => {
                    const recovered = data.recoveries
                      .filter((r) => r.advanceId === adv.id)
                      .reduce((s, r) => s + r.amount, 0);
                    const remaining = adv.amount - recovered;
                    return (
                      <div key={adv.id} className="px-5 py-3 flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-slate-700">{formatINR(adv.amount)}</p>
                          <p className="text-xs text-slate-400">{formatDate(adv.advanceDate)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-orange-600 font-medium">{formatINR(remaining)} left</p>
                          <p className="text-xs text-slate-400">{formatINR(recovered)} recovered</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              {outstanding > 0 && (
                <div className="px-5 py-3 bg-orange-50 border-t border-orange-100">
                  <p className="text-sm text-orange-700">
                    Total outstanding: <span className="font-semibold">{formatINR(outstanding)}</span>
                  </p>
                </div>
              )}
            </CardBody>
          </Card>

          {/* Salary history */}
          <Card>
            <CardHeader>
              <CardTitle>Salary History ({empPayrolls.length})</CardTitle>
            </CardHeader>
            <CardBody className="p-0">
              {empPayrolls.length === 0 ? (
                <p className="text-sm text-slate-400 text-center py-6">No payroll records yet</p>
              ) : (
                <div className="divide-y divide-slate-100">
                  {empPayrolls.map((p) => (
                    <div key={p.id} className="px-5 py-3 flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-slate-700">{monthLabel(p.salaryMonth)}</p>
                        <p className="text-xs text-slate-400">{formatINR(p.netPayable)}</p>
                      </div>
                      <Badge color={
                        p.status === 'paid' ? 'emerald' :
                        p.status === 'partially-paid' ? 'orange' :
                        p.status === 'approved' ? 'blue' : 'slate'
                      }>
                        {p.status.replace('-', ' ')}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>

      <EmployeeForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        onSave={(emp) => {
          updateEmployee(employee.id, emp);
          setFormOpen(false);
          showToast('Employee updated');
        }}
        existing={employee}
        settings={data.settings}
        existingIds={data.employees.map((e) => e.employeeId)}
      />

      <ConfirmDialog
        open={deactivateOpen}
        onClose={() => setDeactivateOpen(false)}
        onConfirm={() => {
          updateEmployee(employee.id, {
            status: employee.status === 'active' ? 'inactive' : 'active',
          });
          showToast(employee.status === 'active' ? 'Employee deactivated' : 'Employee reactivated');
        }}
        title={employee.status === 'active' ? 'Deactivate Employee?' : 'Reactivate Employee?'}
        message={employee.status === 'active'
          ? `${employee.fullName} will be marked inactive. No history will be deleted.`
          : `Reactivate ${employee.fullName}?`}
      />
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: typeof Phone; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <Icon size={16} className="text-slate-400 shrink-0" />
      <div className="min-w-0">
        <p className="text-xs text-slate-400">{label}</p>
        <p className="text-sm text-slate-700 truncate">{value}</p>
      </div>
    </div>
  );
}

function MiniStat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-lg bg-slate-50 p-3 text-center">
      <p className={`text-lg font-bold ${color}`}>{value}</p>
      <p className="text-xs text-slate-400">{label}</p>
    </div>
  );
}
