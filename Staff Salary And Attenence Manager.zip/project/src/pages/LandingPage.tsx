import { Link } from 'react-router-dom';
import {
  Store, Users, CalendarCheck, Wallet, FileText, BarChart3,
  Check, ArrowRight, Shield, Smartphone, IndianRupee,
  ChevronDown, Clock, AlertCircle,
} from 'lucide-react';
import { useState } from 'react';

export function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <Benefits />
      <Features />
      <DashboardPreview />
      <UsageGuide />
      <FAQ />
      <CTASection />
      <Footer />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white">
      <div className="absolute inset-0 opacity-20" style={{
        backgroundImage: 'radial-gradient(circle at 20% 20%, rgba(16,185,129,0.4) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(16,185,129,0.2) 0%, transparent 50%)'
      }} />
      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-16 pb-20 sm:pt-24 sm:pb-28">
        <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/20 border border-emerald-400/30 px-4 py-1.5 text-sm font-medium text-emerald-300 mb-6">
          <Store size={16} />
          Made for Indian Small Businesses
        </div>
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight max-w-3xl">
          Staff Salary & Attendance Manager
          <span className="block text-emerald-400 mt-1">India 2026</span>
        </h1>
        <p className="mt-5 text-lg sm:text-xl text-slate-300 max-w-2xl leading-relaxed">
          Track employee attendance, calculate salaries, manage advances, and generate
          professional payroll reports — all from your browser. No expensive payroll software required.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row gap-3">
          <Link
            to="/app/dashboard"
            className="inline-flex items-center justify-center gap-2 h-12 px-6 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-400 transition-colors shadow-lg shadow-emerald-500/20"
          >
            Start Tracking <ArrowRight size={20} />
          </Link>
          <Link
            to="/app/dashboard"
            className="inline-flex items-center justify-center gap-2 h-12 px-6 rounded-xl bg-white/10 border border-white/20 text-white font-semibold hover:bg-white/20 transition-colors backdrop-blur-sm"
          >
            Try Demo
          </Link>
        </div>
        <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-400">
          <span className="flex items-center gap-1.5"><Check size={16} className="text-emerald-400" /> No backend required</span>
          <span className="flex items-center gap-1.5"><Check size={16} className="text-emerald-400" /> Works offline</span>
          <span className="flex items-center gap-1.5"><Check size={16} className="text-emerald-400" /> Mobile friendly</span>
        </div>
      </div>
    </section>
  );
}

function Benefits() {
  const items = [
    { icon: Clock, title: 'Save Hours Every Month', text: 'Stop calculating salaries by hand. Automatic attendance and salary calculation in seconds.' },
    { icon: IndianRupee, title: 'Handle Advances Safely', text: 'Track every salary advance and recover the exact amount through payroll — no double deductions.' },
    { icon: Smartphone, title: 'Works On Your Phone', text: 'Mark attendance from your mobile. No app install needed — just open in your browser.' },
    { icon: Shield, title: 'Your Data Stays Private', text: 'Records are stored locally in your browser. Nothing is sent to any server.' },
  ];
  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6 bg-slate-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800">Built for Shop Owners, Not Accountants</h2>
          <p className="mt-3 text-slate-500 max-w-2xl mx-auto">Simple enough for a beginner. Powerful enough for a growing team.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {items.map((it) => {
            const Icon = it.icon;
            return (
              <div key={it.title} className="rounded-xl bg-white border border-slate-200 p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-11 h-11 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 mb-4">
                  <Icon size={22} />
                </div>
                <h3 className="font-semibold text-slate-800">{it.title}</h3>
                <p className="mt-2 text-sm text-slate-500 leading-relaxed">{it.text}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Features() {
  const features = [
    { icon: Users, title: 'Employee Management', text: 'Add employees, set salary type (monthly or daily wage), configure overtime rates, weekly offs, and departments.' },
    { icon: CalendarCheck, title: 'Daily Attendance', text: 'Mark Present, Absent, Half Day, Paid Leave, Unpaid Leave, Weekly Off, or Holiday. Filter by date and department.' },
    { icon: Wallet, title: 'Advance Tracking', text: 'Record salary advances with payment method and reference. Track outstanding balances and partial recoveries.' },
    { icon: FileText, title: 'Salary Calculation', text: 'Automatic salary computation with overtime, bonuses, deductions, and advance recovery. Clear breakdown shown.' },
    { icon: FileText, title: 'Payroll & Salary Slips', text: 'Generate monthly payroll, approve, record payments, and print professional salary slips.' },
    { icon: BarChart3, title: 'Reports & Export', text: 'Attendance, salary, advance, and overtime reports. Export to CSV for accounting or sharing.' },
  ];
  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800">Everything You Need to Run Payroll</h2>
          <p className="mt-3 text-slate-500">Six core modules, all connected to real stored data.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f) => {
            const Icon = f.icon;
            return (
              <div key={f.title} className="rounded-xl bg-white border border-slate-200 p-6 shadow-sm hover:border-emerald-300 transition-colors">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-slate-900 flex items-center justify-center text-white shrink-0">
                    <Icon size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">{f.title}</h3>
                    <p className="mt-1.5 text-sm text-slate-500 leading-relaxed">{f.text}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function DashboardPreview() {
  const cards = [
    { label: 'Total Employees', value: '8', color: 'text-slate-800', bg: 'bg-slate-50' },
    { label: 'Present Today', value: '6', color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Absent Today', value: '1', color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'On Leave', value: '1', color: 'text-orange-600', bg: 'bg-orange-50' },
  ];
  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6 bg-slate-900 text-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold">A Dashboard That Tells You Everything</h2>
          <p className="mt-3 text-slate-400">See your team's status and salary expenses at a glance.</p>
        </div>
        <div className="rounded-2xl bg-slate-800 border border-slate-700 p-5 sm:p-6 shadow-2xl">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
            {cards.map((c) => (
              <div key={c.label} className="rounded-xl bg-slate-750 border border-slate-700 p-4" style={{ backgroundColor: '#1e293b' }}>
                <p className="text-xs text-slate-400">{c.label}</p>
                <p className={`text-2xl sm:text-3xl font-bold mt-1 ${c.color}`}>{c.value}</p>
              </div>
            ))}
          </div>
          <div className="grid lg:grid-cols-2 gap-4">
            <div className="rounded-xl bg-slate-750 border border-slate-700 p-4 h-48 flex items-end justify-around" style={{ backgroundColor: '#1e293b' }}>
              {[40, 65, 50, 80, 70, 90, 75].map((h, i) => (
                <div key={i} className="w-8 rounded-t bg-emerald-500/70" style={{ height: `${h}%` }} />
              ))}
            </div>
            <div className="rounded-xl bg-slate-750 border border-slate-700 p-4 h-48 flex items-end justify-around" style={{ backgroundColor: '#1e293b' }}>
              {[55, 70, 60, 85, 80].map((h, i) => (
                <div key={i} className="w-10 rounded-t bg-blue-500/70" style={{ height: `${h}%` }} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function UsageGuide() {
  const steps = [
    { num: '1', title: 'Add Your Employees', text: 'Enter name, phone, department, salary type, and joining date.' },
    { num: '2', title: 'Mark Daily Attendance', text: 'Each day, select a status for each employee. Takes under a minute.' },
    { num: '3', title: 'Generate Monthly Payroll', text: 'Pick a month, review the breakdown, approve, and print salary slips.' },
  ];
  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6 bg-slate-50">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800">Get Started in 3 Steps</h2>
        </div>
        <div className="space-y-4">
          {steps.map((s) => (
            <div key={s.num} className="flex items-start gap-4 rounded-xl bg-white border border-slate-200 p-5 shadow-sm">
              <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0">
                {s.num}
              </div>
              <div>
                <h3 className="font-semibold text-slate-800">{s.title}</h3>
                <p className="mt-1 text-sm text-slate-500">{s.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const faqs = [
    {
      q: 'Does this app process actual salary payments?',
      a: 'No. This app manages attendance records and calculates salary amounts. It does not transfer money to employees. You need to pay salaries through your usual method (cash, UPI, bank transfer).',
    },
    {
      q: 'Is this compliant with Indian payroll laws?',
      a: 'This tool helps with recordkeeping and salary calculations. It does not guarantee legal or statutory payroll compliance. Configure salary policies according to your business rules and consult a professional for compliance.',
    },
    {
      q: 'Where is my data stored?',
      a: 'All data is stored locally in your browser using LocalStorage. Nothing is uploaded to any server. This means your data stays private, but it may be lost if you clear your browser data. Use the Export feature to back up regularly.',
    },
    {
      q: 'Can I use this on multiple devices?',
      a: 'Data is stored per browser. To move data between devices, use the Export to JSON option in Settings and Import on the other device.',
    },
    {
      q: 'Does it handle daily wage workers?',
      a: 'Yes. You can set each employee as Monthly Salary or Daily Wage. Daily wage salary is calculated based on payable attendance days multiplied by the daily rate.',
    },
    {
      q: 'Can I track overtime?',
      a: 'Yes. Each employee can have a configurable overtime rate per hour. Overtime hours are entered with attendance and added to the salary calculation.',
    },
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800">Frequently Asked Questions</h2>
        </div>
        <div className="space-y-3">
          {faqs.map((f, i) => (
            <div key={i} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-slate-50 transition-colors"
              >
                <span className="font-medium text-slate-800">{f.q}</span>
                <ChevronDown
                  size={20}
                  className={`text-slate-400 transition-transform shrink-0 ml-3 ${open === i ? 'rotate-180' : ''}`}
                />
              </button>
              {open === i && (
                <div className="px-5 pb-4 text-sm text-slate-600 leading-relaxed">{f.a}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="py-16 sm:py-20 px-4 sm:px-6 bg-gradient-to-br from-emerald-600 to-emerald-700 text-white">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-2xl sm:text-4xl font-bold">Start Managing Your Staff Today</h2>
        <p className="mt-4 text-emerald-50 text-lg">
          Simple attendance and salary tracking for Indian small businesses.
        </p>
        <div className="mt-6 inline-flex items-center gap-4 rounded-xl bg-white/10 border border-white/20 px-6 py-3 backdrop-blur-sm">
          <div className="text-center">
            <p className="text-xs text-emerald-100">Launch Price</p>
            <p className="text-2xl font-bold">₹199</p>
          </div>
          <div className="h-10 w-px bg-white/30" />
          <div className="text-center">
            <p className="text-xs text-emerald-100">Regular Price</p>
            <p className="text-2xl font-bold line-through opacity-70">₹399</p>
          </div>
        </div>
        <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            to="/app/dashboard"
            className="inline-flex items-center justify-center gap-2 h-12 px-8 rounded-xl bg-white text-emerald-700 font-semibold hover:bg-emerald-50 transition-colors shadow-lg"
          >
            Try Demo <ArrowRight size={20} />
          </Link>
          <Link
            to="/app/dashboard"
            className="inline-flex items-center justify-center gap-2 h-12 px-8 rounded-xl bg-emerald-800 border border-emerald-600 text-white font-semibold hover:bg-emerald-900 transition-colors"
          >
            Start Tracking
          </Link>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="py-10 px-4 sm:px-6 bg-slate-900 text-slate-400">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Store size={18} className="text-emerald-500" />
            <span className="font-semibold text-slate-300">Staff Salary & Attendance Manager India 2026</span>
          </div>
          <Link to="/app/dashboard" className="text-sm hover:text-white transition-colors">
            Open App →
          </Link>
        </div>
        <div className="mt-6 pt-6 border-t border-slate-800 text-xs space-y-2">
          <p className="flex items-center gap-1.5"><AlertCircle size={14} /> This app manages attendance and calculates salary records. It does not transfer salary payments.</p>
          <p className="flex items-center gap-1.5"><AlertCircle size={14} /> It does not guarantee legal or statutory payroll compliance. Configure policies per your business rules.</p>
          <p className="flex items-center gap-1.5"><AlertCircle size={14} /> Data is stored locally in your browser. Export regularly to avoid data loss.</p>
        </div>
      </div>
    </footer>
  );
}
