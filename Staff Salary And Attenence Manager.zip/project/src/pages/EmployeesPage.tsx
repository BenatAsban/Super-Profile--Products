import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Users, Search, Plus, Eye, Pencil, UserX, UserCheck, Phone,
  Building2, IndianRupee,
} from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Card, CardBody } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Input, Select } from '@/components/ui/Field';
import { EmptyState, PageHeader, ConfirmDialog } from '@/components/ui/Misc';
import { EmployeeForm } from '@/components/EmployeeForm';
import { useToast } from '@/hooks/useToast';
import { formatINR } from '@/lib/format';
import type { Employee } from '@/lib/types';

export function EmployeesPage() {
  const { data, addEmployee, updateEmployee } = useData();
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [deptFilter, setDeptFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [deactivateTarget, setDeactivateTarget] = useState<Employee | null>(null);

  const departments = useMemo(() => {
    const set = new Set(data.employees.map((e) => e.department).filter(Boolean));
    return Array.from(set);
  }, [data.employees]);

  const filtered = useMemo(() => {
    return data.employees.filter((e) => {
      if (statusFilter !== 'all' && e.status !== statusFilter) return false;
      if (deptFilter !== 'all' && e.department !== deptFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          e.fullName.toLowerCase().includes(q) ||
          e.employeeId.toLowerCase().includes(q) ||
          e.phone.includes(q) ||
          (e.email || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [data.employees, search, statusFilter, deptFilter]);

  const handleSave = (emp: Employee) => {
    if (editing) {
      updateEmployee(emp.id, emp);
      showToast('Employee updated successfully');
    } else {
      addEmployee(emp);
      showToast('Employee added successfully');
    }
    setFormOpen(false);
    setEditing(null);
  };

  const handleDeactivate = () => {
    if (!deactivateTarget) return;
    updateEmployee(deactivateTarget.id, {
      status: deactivateTarget.status === 'active' ? 'inactive' : 'active',
    });
    showToast(
      deactivateTarget.status === 'active'
        ? 'Employee deactivated'
        : 'Employee reactivated'
    );
  };

  const hasHistory = (empId: string) => {
    return (
      data.attendance.some((a) => a.employeeId === empId) ||
      data.advances.some((a) => a.employeeId === empId) ||
      data.payrolls.some((p) => p.employeeId === empId)
    );
  };

  if (data.employees.length === 0) {
    return (
      <div>
        <PageHeader
          title="Employees"
          subtitle="Manage your team members"
          action={<Button onClick={() => { setEditing(null); setFormOpen(true); }}><Plus size={16} /> Add Employee</Button>}
        />
        <Card>
          <EmptyState
            icon={<Users size={32} />}
            title="No employees yet"
            description="Add your first employee to start tracking attendance and calculating salaries."
            action={<Button onClick={() => { setEditing(null); setFormOpen(true); }}><Plus size={16} /> Add Your First Employee</Button>}
          />
        </Card>
        <EmployeeForm
          open={formOpen}
          onClose={() => setFormOpen(false)}
          onSave={handleSave}
          existing={editing}
          settings={data.settings}
          existingIds={data.employees.map((e) => e.employeeId)}
        />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Employees"
        subtitle={`${data.employees.length} total, ${data.employees.filter((e) => e.status === 'active').length} active`}
        action={<Button onClick={() => { setEditing(null); setFormOpen(true); }}><Plus size={16} /> Add Employee</Button>}
      />

      <Card className="mb-4">
        <CardBody className="!py-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, ID, phone..."
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:w-36">
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </Select>
            <Select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="sm:w-44">
              <option value="all">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </Select>
          </div>
        </CardBody>
      </Card>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState title="No employees found" description="Try adjusting your search or filters." />
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((emp) => (
            <Card key={emp.id} className="hover:shadow-md transition-shadow">
              <CardBody>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-slate-200 flex items-center justify-center text-sm font-bold text-slate-600">
                      {emp.fullName.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <Link to={`/app/employees/${emp.id}`} className="font-semibold text-slate-800 hover:text-emerald-600 block truncate">
                        {emp.fullName}
                      </Link>
                      <p className="text-xs text-slate-400">{emp.employeeId}</p>
                    </div>
                  </div>
                  <Badge color={emp.status === 'active' ? 'emerald' : 'slate'}>
                    {emp.status === 'active' ? 'Active' : 'Inactive'}
                  </Badge>
                </div>

                <div className="space-y-1.5 text-sm text-slate-500">
                  <p className="flex items-center gap-2 truncate">
                    <Building2 size={14} className="text-slate-400 shrink-0" />
                    {emp.department || 'No department'}
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone size={14} className="text-slate-400 shrink-0" />
                    {emp.phone}
                  </p>
                  <p className="flex items-center gap-2">
                    <IndianRupee size={14} className="text-slate-400 shrink-0" />
                    {emp.salaryType === 'monthly'
                      ? `${formatINR(emp.monthlySalary || 0)}/month`
                      : `${formatINR(emp.dailyWageRate || 0)}/day`}
                  </p>
                </div>

                <div className="mt-4 flex gap-2">
                  <Link to={`/app/employees/${emp.id}`} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full"><Eye size={14} /> View</Button>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => { setEditing(emp); setFormOpen(true); }}
                  >
                    <Pencil size={14} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setDeactivateTarget(emp)}
                    title={emp.status === 'active' ? 'Deactivate' : 'Reactivate'}
                  >
                    {emp.status === 'active' ? <UserX size={14} /> : <UserCheck size={14} />}
                  </Button>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <EmployeeForm
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        onSave={handleSave}
        existing={editing}
        settings={data.settings}
        existingIds={data.employees.map((e) => e.employeeId)}
      />

      <ConfirmDialog
        open={!!deactivateTarget}
        onClose={() => setDeactivateTarget(null)}
        onConfirm={handleDeactivate}
        title={deactivateTarget?.status === 'active' ? 'Deactivate Employee?' : 'Reactivate Employee?'}
        message={
          deactivateTarget?.status === 'active'
            ? hasHistory(deactivateTarget.id)
              ? `${deactivateTarget.fullName} has attendance, advance, or salary records. Deactivating will not delete any history. The employee will be marked as inactive and excluded from new attendance and payroll.`
              : `Deactivate ${deactivateTarget.fullName}? They will be excluded from new attendance and payroll.`
            : `Reactivate ${deactivateTarget?.fullName}?`
        }
        confirmLabel={deactivateTarget?.status === 'active' ? 'Deactivate' : 'Reactivate'}
      />
    </div>
  );
}
