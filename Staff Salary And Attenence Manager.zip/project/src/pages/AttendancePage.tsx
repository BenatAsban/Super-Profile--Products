import { useMemo, useState } from 'react';
import {
  CalendarCheck, Download, Users, ChevronLeft, ChevronRight,
  CheckCircle2, XCircle, Clock, Coffee, Plane, Ban, CalendarOff,
} from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Input, Select, Field } from '@/components/ui/Field';
import { EmptyState, PageHeader } from '@/components/ui/Misc';
import { useToast } from '@/hooks/useToast';
import {
  todayISO, formatDate, dayName, getStatusLabel, datesInMonth,
  currentMonthKey, monthLabel, monthKey,
} from '@/lib/format';
import { downloadCSV } from '@/lib/export';
import { uid } from '@/lib/format';
import type { AttendanceStatus, Attendance } from '@/lib/types';
import { summarizeAttendance } from '@/lib/attendance';

const STATUSES: { value: AttendanceStatus; label: string; icon: typeof CheckCircle2; color: string }[] = [
  { value: 'present', label: 'Present', icon: CheckCircle2, color: 'emerald' },
  { value: 'absent', label: 'Absent', icon: XCircle, color: 'red' },
  { value: 'half-day', label: 'Half Day', icon: Clock, color: 'amber' },
  { value: 'paid-leave', label: 'Paid Leave', icon: Plane, color: 'blue' },
  { value: 'unpaid-leave', label: 'Unpaid Leave', icon: Ban, color: 'orange' },
  { value: 'weekly-off', label: 'Weekly Off', icon: CalendarOff, color: 'slate' },
  { value: 'holiday', label: 'Holiday', icon: Coffee, color: 'slate' },
];

const statusColors: Record<AttendanceStatus, string> = {
  present: 'bg-emerald-500',
  absent: 'bg-red-500',
  'half-day': 'bg-amber-500',
  'paid-leave': 'bg-blue-500',
  'unpaid-leave': 'bg-orange-500',
  'weekly-off': 'bg-slate-400',
  holiday: 'bg-slate-300',
};

export function AttendancePage() {
  const { data, addAttendance, updateAttendance, removeAttendance } = useData();
  const { showToast } = useToast();
  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [deptFilter, setDeptFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'daily' | 'monthly'>('daily');
  const [calendarMonth, setCalendarMonth] = useState(currentMonthKey());

  const activeEmployees = data.employees.filter((e) => e.status === 'active');

  const departments = useMemo(() => {
    const set = new Set(activeEmployees.map((e) => e.department).filter(Boolean));
    return Array.from(set);
  }, [activeEmployees]);

  const filteredEmployees = useMemo(() => {
    if (deptFilter === 'all') return activeEmployees;
    return activeEmployees.filter((e) => e.department === deptFilter);
  }, [activeEmployees, deptFilter]);

  const dayAttendanceMap = useMemo(() => {
    const map = new Map<string, Attendance>();
    for (const a of data.attendance) {
      if (a.date === selectedDate) map.set(a.employeeId, a);
    }
    return map;
  }, [data.attendance, selectedDate]);

  const handleMark = (employeeId: string, status: AttendanceStatus) => {
    const existing = dayAttendanceMap.get(employeeId);
    if (existing) {
      if (existing.status === status) {
        removeAttendance(existing.id);
        showToast('Attendance removed', 'info');
      } else {
        updateAttendance(existing.id, { status });
        showToast(`${getStatusLabel(status)} marked`);
      }
    } else {
      addAttendance({
        id: uid('att_'),
        employeeId,
        date: selectedDate,
        status,
        overtimeHours: 0,
        createdAt: new Date().toISOString(),
      });
      showToast(`${getStatusLabel(status)} marked`);
    }
  };

  const handleOvertime = (employeeId: string, hours: number) => {
    const existing = dayAttendanceMap.get(employeeId);
    if (existing) {
      updateAttendance(existing.id, { overtimeHours: Math.max(0, hours) });
    }
  };

  const handleBulkMark = (status: AttendanceStatus) => {
    for (const emp of filteredEmployees) {
      const existing = dayAttendanceMap.get(emp.id);
      if (!existing) {
        addAttendance({
          id: uid('att_'),
          employeeId: emp.id,
          date: selectedDate,
          status,
          overtimeHours: 0,
          createdAt: new Date().toISOString(),
        });
      } else if (existing.status !== status) {
        updateAttendance(existing.id, { status });
      }
    }
    showToast(`All marked as ${getStatusLabel(status)}`);
  };

  const daySummary = useMemo(() => {
    const records = filteredEmployees
      .map((e) => dayAttendanceMap.get(e.id))
      .filter((a): a is Attendance => !!a);
    return summarizeAttendance(records);
  }, [filteredEmployees, dayAttendanceMap]);

  const exportDayCSV = () => {
    const rows: (string | number)[][] = [
      ['Employee ID', 'Name', 'Department', 'Date', 'Status', 'Overtime Hours'],
    ];
    for (const emp of filteredEmployees) {
      const att = dayAttendanceMap.get(emp.id);
      rows.push([
        emp.employeeId,
        emp.fullName,
        emp.department,
        selectedDate,
        att ? getStatusLabel(att.status) : 'Not Marked',
        att?.overtimeHours || 0,
      ]);
    }
    downloadCSV(`attendance-${selectedDate}`, rows);
    showToast('Attendance exported');
  };

  const exportMonthCSV = () => {
    const monthDates = datesInMonth(calendarMonth);
    const rows: (string | number)[][] = [
      ['Employee ID', 'Name', 'Department', ...monthDates.map((d) => d.slice(8)), 'Present', 'Absent', 'Half Day', 'Payable Days'],
    ];
    for (const emp of filteredEmployees) {
      const empMonthAtt = data.attendance.filter(
        (a) => a.employeeId === emp.id && monthKey(a.date) === calendarMonth
      );
      const dayMap = new Map(empMonthAtt.map((a) => [a.date, a]));
      const summary = summarizeAttendance(empMonthAtt);
      rows.push([
        emp.employeeId,
        emp.fullName,
        emp.department,
        ...monthDates.map((d) => {
          const a = dayMap.get(d);
          return a ? getStatusLabel(a.status).charAt(0) : '-';
        }),
        summary.present,
        summary.absent,
        summary.halfDay,
        summary.payableDays,
      ]);
    }
    downloadCSV(`attendance-${calendarMonth}`, rows);
    showToast('Monthly attendance exported');
  };

  if (activeEmployees.length === 0) {
    return (
      <div>
        <PageHeader title="Attendance" subtitle="Mark daily attendance for your team" />
        <Card>
          <EmptyState
            icon={<Users size={32} />}
            title="No active employees"
            description="Add employees first to mark attendance."
          />
        </Card>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Attendance"
        subtitle="Mark and review daily attendance"
        action={
          <Button variant="outline" size="sm" onClick={viewMode === 'daily' ? exportDayCSV : exportMonthCSV}>
            <Download size={16} /> Export CSV
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="inline-flex rounded-lg border border-slate-200 bg-white p-1">
          <button
            onClick={() => setViewMode('daily')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              viewMode === 'daily' ? 'bg-emerald-600 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Daily
          </button>
          <button
            onClick={() => setViewMode('monthly')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              viewMode === 'monthly' ? 'bg-emerald-600 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Monthly
          </button>
        </div>

        <Select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="sm:w-44">
          <option value="all">All Departments</option>
          {departments.map((d) => <option key={d} value={d}>{d}</option>)}
        </Select>

        {viewMode === 'daily' ? (
          <Field>
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="sm:w-44"
            />
          </Field>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCalendarMonth((m) => {
                const [y, mo] = m.split('-').map(Number);
                const d = new Date(y, mo - 2, 1);
                return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
              })}
              className="p-2 rounded-lg border border-slate-300 hover:bg-slate-50"
            >
              <ChevronLeft size={16} />
            </button>
            <span className="text-sm font-medium text-slate-700 min-w-[140px] text-center">
              {monthLabel(calendarMonth)}
            </span>
            <button
              onClick={() => setCalendarMonth((m) => {
                const [y, mo] = m.split('-').map(Number);
                const d = new Date(y, mo, 1);
                return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
              })}
              className="p-2 rounded-lg border border-slate-300 hover:bg-slate-50"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        )}
      </div>

      {viewMode === 'daily' ? (
        <DailyView
          employees={filteredEmployees}
          attendanceMap={dayAttendanceMap}
          onMark={handleMark}
          onOvertime={handleOvertime}
          onBulkMark={handleBulkMark}
          summary={daySummary}
          date={selectedDate}
        />
      ) : (
        <MonthlyView
          employees={filteredEmployees}
          allAttendance={data.attendance}
          month={calendarMonth}
        />
      )}
    </div>
  );
}

function DailyView({
  employees, attendanceMap, onMark, onOvertime, onBulkMark, summary, date,
}: {
  employees: ReturnType<typeof useData>['data']['employees'];
  attendanceMap: Map<string, Attendance>;
  onMark: (id: string, s: AttendanceStatus) => void;
  onOvertime: (id: string, h: number) => void;
  onBulkMark: (s: AttendanceStatus) => void;
  summary: ReturnType<typeof summarizeAttendance>;
  date: string;
}) {
  return (
    <div className="space-y-4">
      {/* Day summary */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
        <DayStat label="Present" value={summary.present} color="text-emerald-600 bg-emerald-50" />
        <DayStat label="Absent" value={summary.absent} color="text-red-600 bg-red-50" />
        <DayStat label="Half Day" value={summary.halfDay} color="text-amber-600 bg-amber-50" />
        <DayStat label="Paid Leave" value={summary.paidLeave} color="text-blue-600 bg-blue-50" />
        <DayStat label="Unpaid" value={summary.unpaidLeave} color="text-orange-600 bg-orange-50" />
        <DayStat label="Not Marked" value={employees.length - summary.totalMarked} color="text-slate-600 bg-slate-100" />
      </div>

      <Card className="mb-3">
        <CardBody className="!py-3 flex items-center gap-2 flex-wrap">
          <span className="text-sm text-slate-500 mr-2">Bulk mark all:</span>
          {STATUSES.slice(0, 5).map((s) => (
            <Button key={s.value} variant="outline" size="sm" onClick={() => onBulkMark(s.value)}>
              {s.label}
            </Button>
          ))}
        </CardBody>
      </Card>

      <p className="text-sm text-slate-500">
        {formatDate(date)} · {dayName(date)}
      </p>

      <div className="space-y-2">
        {employees.map((emp) => {
          const att = attendanceMap.get(emp.id);
          return (
            <Card key={emp.id}>
              <CardBody className="!py-3">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600 shrink-0">
                      {emp.fullName.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-700 truncate">{emp.fullName}</p>
                      <p className="text-xs text-slate-400">{emp.employeeId} · {emp.department}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {STATUSES.map((s) => {
                      const Icon = s.icon;
                      const isActive = att?.status === s.value;
                      return (
                        <button
                          key={s.value}
                          onClick={() => onMark(emp.id, s.value)}
                          className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium border transition-colors ${
                            isActive
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                          }`}
                          title={s.label}
                        >
                          <Icon size={13} />
                          <span className="hidden sm:inline">{s.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {att && att.status === 'present' && (
                  <div className="mt-3 flex items-center gap-2 pt-3 border-t border-slate-100">
                    <Clock size={14} className="text-slate-400" />
                    <span className="text-sm text-slate-500">Overtime:</span>
                    <Input
                      type="number"
                      min={0}
                      step={0.5}
                      value={att.overtimeHours || 0}
                      onChange={(e) => onOvertime(emp.id, Number(e.target.value))}
                      className="w-20 h-8"
                    />
                    <span className="text-sm text-slate-500">hours</span>
                  </div>
                )}
              </CardBody>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function MonthlyView({
  employees, allAttendance, month,
}: {
  employees: ReturnType<typeof useData>['data']['employees'];
  allAttendance: Attendance[];
  month: string;
}) {
  const monthDates = datesInMonth(month);

  const getCellColor = (status: AttendanceStatus | undefined): string => {
    if (!status) return '';
    return statusColors[status];
  };

  return (
    <Card className="overflow-x-auto">
      <CardHeader>
        <CardTitle>{monthLabel(month)} — Calendar View</CardTitle>
      </CardHeader>
      <CardBody className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="sticky left-0 bg-white px-3 py-2 text-left text-xs font-medium text-slate-500 min-w-[140px]">Employee</th>
                {monthDates.map((d) => (
                  <th key={d} className="px-1 py-2 text-center text-xs font-medium text-slate-400 min-w-[28px]">
                    {Number(d.slice(8))}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.map((emp) => {
                const empAtt = allAttendance.filter(
                  (a) => a.employeeId === emp.id && monthKey(a.date) === month
                );
                const dayMap = new Map(empAtt.map((a) => [a.date, a.status]));
                const summary = summarizeAttendance(empAtt);
                return (
                  <tr key={emp.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="sticky left-0 bg-white px-3 py-2">
                      <p className="text-xs font-medium text-slate-700 truncate max-w-[130px]">{emp.fullName}</p>
                      <p className="text-[10px] text-slate-400">{summary.payableDays} days</p>
                    </td>
                    {monthDates.map((d) => {
                      const status = dayMap.get(d);
                      return (
                        <td key={d} className="px-1 py-2 text-center">
                          {status && (
                            <div
                              className={`w-5 h-5 rounded ${getCellColor(status)} mx-auto`}
                              title={getStatusLabel(status)}
                            />
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="px-5 py-3 flex flex-wrap gap-3 border-t border-slate-100">
          {STATUSES.map((s) => (
            <div key={s.value} className="flex items-center gap-1.5">
              <div className={`w-3 h-3 rounded ${statusColors[s.value]}`} />
              <span className="text-xs text-slate-500">{s.label}</span>
            </div>
          ))}
        </div>
      </CardBody>
    </Card>
  );
}

function DayStat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className={`rounded-lg p-3 text-center ${color}`}>
      <p className="text-lg sm:text-xl font-bold">{value}</p>
      <p className="text-xs opacity-80">{label}</p>
    </div>
  );
}
