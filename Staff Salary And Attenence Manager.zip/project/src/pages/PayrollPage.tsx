import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  FileText, Download, Eye, CheckCircle2, Banknote, Printer,
  ChevronLeft, ChevronRight, AlertCircle,
} from 'lucide-react';
import { useData } from '@/context/DataContext';
import { Card, CardBody } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Modal } from '@/components/ui/Modal';
import { Field, Input, Select } from '@/components/ui/Field';
import { EmptyState, PageHeader, ConfirmDialog } from '@/components/ui/Misc';
import { useToast } from '@/hooks/useToast';
import {
  formatINR, monthLabel, currentMonthKey, uid, todayISO,
  monthKey, round2,
} from '@/lib/format';
import { downloadCSV } from '@/lib/export';
import { calculateSalary, getOutstandingSalary, isPayrollFinalized } from '@/lib/salary';
import type { PayrollRecord, PayrollStatus, SalaryPayment, PaymentMethod, Employee } from '@/lib/types';

export function PayrollPage() {
  const { data, upsertPayroll, updatePayroll, addRecovery, updateAdjustment, updateAdvance } = useData();
  const { showToast } = useToast();
  const [selectedMonth, setSelectedMonth] = useState(currentMonthKey());
  const [slipEmployee, setSlipEmployee] = useState<PayrollRecord | null>(null);
  const [paymentTarget, setPaymentTarget] = useState<PayrollRecord | null>(null);
  const [approveTarget, setApproveTarget] = useState<{ record: PayrollRecord | null; emp: Employee; breakdown: ReturnType<typeof calculateSalary> } | null>(null);

  const activeEmployees = data.employees.filter((e) => e.status === 'active');

  const payrollData = useMemo(() => {
    return activeEmployees.map((emp) => {
      const empAttendance = data.attendance.filter(
        (a) => a.employeeId === emp.id && monthKey(a.date) === selectedMonth
      );
      const breakdown = calculateSalary({
        employee: emp,
        month: selectedMonth,
        attendanceRecords: empAttendance,
        adjustments: data.adjustments,
        settings: data.settings,
      });
      const existing = data.payrolls.find(
        (p) => p.employeeId === emp.id && p.salaryMonth === selectedMonth
      );
      return { emp, breakdown, existing, empAttendance };
    });
  }, [activeEmployees, data, selectedMonth]);

  const totalNetPayable = useMemo(
    () => payrollData.reduce((s, p) => s + (p.existing?.netPayable ?? p.breakdown.netPayable), 0),
    [payrollData]
  );
  const totalPaid = useMemo(
    () => payrollData.reduce((s, p) => s + (p.existing?.paidAmount ?? 0), 0),
    [payrollData]
  );
  const totalOutstanding = round2(totalNetPayable - totalPaid);

  const handleApprove = (record: PayrollRecord | null, emp: Employee, breakdown: ReturnType<typeof calculateSalary>) => {
    if (record && isPayrollFinalized(record)) {
      showToast('This payroll is already finalized', 'info');
      return;
    }
    const payroll: PayrollRecord = record ? {
      ...record,
      salaryType: emp.salaryType,
      baseSalary: breakdown.baseSalary,
      payableDays: breakdown.payableDays,
      presentDays: breakdown.presentDays,
      halfDays: breakdown.halfDays,
      paidLeaveDays: breakdown.paidLeaveDays,
      unpaidLeaveDays: breakdown.unpaidLeaveDays,
      overtimeHours: breakdown.overtimeHours,
      overtimeEarnings: breakdown.overtimeEarnings,
      bonus: breakdown.bonus,
      advanceRecovery: breakdown.advanceRecovery,
      otherDeductions: breakdown.otherDeductions,
      grossEarnings: breakdown.grossEarnings,
      netPayable: breakdown.netPayable,
      status: 'approved',
      finalizedAt: new Date().toISOString(),
    } : {
      id: uid('pay_'),
      employeeId: emp.id,
      salaryMonth: selectedMonth,
      salaryType: emp.salaryType,
      baseSalary: breakdown.baseSalary,
      payableDays: breakdown.payableDays,
      presentDays: breakdown.presentDays,
      halfDays: breakdown.halfDays,
      paidLeaveDays: breakdown.paidLeaveDays,
      unpaidLeaveDays: breakdown.unpaidLeaveDays,
      overtimeHours: breakdown.overtimeHours,
      overtimeEarnings: breakdown.overtimeEarnings,
      bonus: breakdown.bonus,
      advanceRecovery: breakdown.advanceRecovery,
      otherDeductions: breakdown.otherDeductions,
      grossEarnings: breakdown.grossEarnings,
      netPayable: breakdown.netPayable,
      status: 'approved',
      paidAmount: 0,
      payments: [],
      adjustments: [],
      finalizedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    // Apply pending adjustments linked to this month
    const pendingAdjustments = data.adjustments.filter(
      (a) => a.employeeId === emp.id && a.salaryMonth === selectedMonth && a.status === 'pending'
    );
    payroll.adjustments = pendingAdjustments.map((a) => a.id);

    // Create recovery records for advance-recovery adjustments
    for (const adj of pendingAdjustments) {
      if (adj.type === 'advance-recovery' && adj.advanceId) {
        addRecovery({
          id: uid('rec_'),
          advanceId: adj.advanceId,
          employeeId: emp.id,
          amount: adj.amount,
          date: todayISO(),
          source: 'payroll',
          payrollId: payroll.id,
          createdAt: new Date().toISOString(),
        });
        const adv = data.advances.find((a) => a.id === adj.advanceId);
        if (adv) {
          const totalRec = data.recoveries.filter((r) => r.advanceId === adv.id).reduce((s, r) => s + r.amount, 0) + adj.amount;
          if (totalRec >= adv.amount) {
            updateAdvance(adv.id, { status: 'closed' });
          }
        }
      }
      updateAdjustment(adj.id, { status: 'applied', payrollId: payroll.id });
    }

    upsertPayroll(payroll);
    showToast('Payroll approved and finalized');
  };

  const handlePayment = (payroll: PayrollRecord, payment: SalaryPayment) => {
    const newPayments = [...(payroll.payments || []), payment];
    const newPaidAmount = round2(payroll.paidAmount + payment.amount);
    const newStatus: PayrollStatus = newPaidAmount >= payroll.netPayable ? 'paid' : 'partially-paid';
    updatePayroll(payroll.id, {
      payments: newPayments,
      paidAmount: newPaidAmount,
      status: newStatus,
    });
    showToast(`Payment of ${formatINR(payment.amount)} recorded`);
  };

  const exportCSV = () => {
    const rows: (string | number)[][] = [
      ['Employee ID', 'Name', 'Type', 'Base', 'Present', 'Half Day', 'Paid Leave', 'Unpaid Leave', 'OT Hours', 'OT Earnings', 'Bonus', 'Adv Recovery', 'Other Deductions', 'Gross', 'Net Payable', 'Paid', 'Outstanding', 'Status'],
    ];
    for (const { emp, breakdown, existing } of payrollData) {
      const net = existing?.netPayable ?? breakdown.netPayable;
      const paid = existing?.paidAmount ?? 0;
      rows.push([
        emp.employeeId, emp.fullName, emp.salaryType,
        breakdown.proratedBase, breakdown.presentDays, breakdown.halfDays,
        breakdown.paidLeaveDays, breakdown.unpaidLeaveDays,
        breakdown.overtimeHours, breakdown.overtimeEarnings,
        breakdown.bonus, breakdown.advanceRecovery, breakdown.otherDeductions,
        breakdown.grossEarnings, net, paid, round2(net - paid),
        existing?.status || 'draft',
      ]);
    }
    downloadCSV(`payroll-${selectedMonth}`, rows);
    showToast('Payroll exported');
  };

  if (activeEmployees.length === 0) {
    return (
      <div>
        <PageHeader title="Payroll" subtitle="Generate and manage monthly salary payments" />
        <Card>
          <EmptyState
            icon={<FileText size={32} />}
            title="No active employees"
            description="Add employees before generating payroll."
            action={<Link to="/app/employees"><Button>Add Employees</Button></Link>}
          />
        </Card>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Payroll"
        subtitle="Generate and manage monthly salary payments"
        action={
          <Button variant="outline" size="sm" onClick={exportCSV}><Download size={16} /> Export CSV</Button>
        }
      />

      {/* Month selector */}
      <div className="flex items-center gap-2 mb-4">
        <button
          onClick={() => {
            const [y, m] = selectedMonth.split('-').map(Number);
            const d = new Date(y, m - 2, 1);
            setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
          }}
          className="p-2 rounded-lg border border-slate-300 hover:bg-slate-50"
        >
          <ChevronLeft size={16} />
        </button>
        <span className="text-sm font-semibold text-slate-700 min-w-[140px] text-center">
          {monthLabel(selectedMonth)}
        </span>
        <button
          onClick={() => {
            const [y, m] = selectedMonth.split('-').map(Number);
            const d = new Date(y, m, 1);
            setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
          }}
          className="p-2 rounded-lg border border-slate-300 hover:bg-slate-50"
        >
          <ChevronRight size={16} />
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Total Net Payable</p>
          <p className="text-xl font-bold text-slate-800 mt-1">{formatINR(totalNetPayable)}</p>
        </div>
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4">
          <p className="text-xs text-emerald-600">Total Paid</p>
          <p className="text-xl font-bold text-emerald-700 mt-1">{formatINR(totalPaid)}</p>
        </div>
        <div className="rounded-xl border border-orange-200 bg-orange-50 p-4">
          <p className="text-xs text-orange-600">Outstanding</p>
          <p className="text-xl font-bold text-orange-700 mt-1">{formatINR(totalOutstanding)}</p>
        </div>
      </div>

      <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 mb-4">
        <p className="text-xs text-blue-700">
          <AlertCircle size={14} className="inline mr-1" />
          Review each employee's breakdown before approving. Once approved, the payroll record is finalized and will not change when employee settings are updated later.
        </p>
      </div>

      {/* Payroll table */}
      <Card className="overflow-x-auto">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5 text-left text-xs font-medium text-slate-500">Employee</th>
                  <th className="px-3 py-2.5 text-right text-xs font-medium text-slate-500">Base</th>
                  <th className="px-3 py-2.5 text-right text-xs font-medium text-slate-500">OT</th>
                  <th className="px-3 py-2.5 text-right text-xs font-medium text-slate-500">Bonus</th>
                  <th className="px-3 py-2.5 text-right text-xs font-medium text-slate-500">Deduct.</th>
                  <th className="px-3 py-2.5 text-right text-xs font-medium text-slate-500">Net Payable</th>
                  <th className="px-3 py-2.5 text-center text-xs font-medium text-slate-500">Status</th>
                  <th className="px-3 py-2.5 text-right text-xs font-medium text-slate-500">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {payrollData.map(({ emp, breakdown, existing }) => {
                  const finalized = existing && isPayrollFinalized(existing);
                  const outstanding = existing ? getOutstandingSalary(existing) : breakdown.netPayable;
                  const displayNet = existing?.netPayable ?? breakdown.netPayable;
                  return (
                    <tr key={emp.id} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5">
                        <p className="font-medium text-slate-700">{emp.fullName}</p>
                        <p className="text-xs text-slate-400">{emp.employeeId} · {emp.salaryType}</p>
                      </td>
                      <td className="px-3 py-2.5 text-right text-slate-600">{formatINR(existing?.baseSalary ?? breakdown.proratedBase)}</td>
                      <td className="px-3 py-2.5 text-right text-slate-600">{formatINR(existing?.overtimeEarnings ?? breakdown.overtimeEarnings)}</td>
                      <td className="px-3 py-2.5 text-right text-emerald-600">{formatINR(existing?.bonus ?? breakdown.bonus)}</td>
                      <td className="px-3 py-2.5 text-right text-red-600">{formatINR(existing ? existing.advanceRecovery + existing.otherDeductions : breakdown.totalDeductions)}</td>
                      <td className="px-3 py-2.5 text-right font-bold text-slate-800">{formatINR(displayNet)}</td>
                      <td className="px-3 py-2.5 text-center">
                        {existing ? (
                          <Badge color={
                            existing.status === 'paid' ? 'emerald' :
                            existing.status === 'partially-paid' ? 'orange' :
                            existing.status === 'approved' ? 'blue' : 'slate'
                          }>
                            {existing.status.replace('-', ' ')}
                          </Badge>
                        ) : (
                          <Badge color="slate">Draft</Badge>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-right">
                        <div className="flex justify-end gap-1">
                          {finalized ? (
                            <>
                              {outstanding > 0 && (
                                <Button size="sm" variant="outline" onClick={() => setPaymentTarget(existing!)}>
                                  <Banknote size={13} /> Pay
                                </Button>
                              )}
                              <Button size="sm" variant="ghost" onClick={() => setSlipEmployee(existing!)}>
                                <Printer size={14} />
                              </Button>
                            </>
                          ) : (
                            <Button size="sm" variant="outline" onClick={() => setApproveTarget({ record: existing ?? null, emp, breakdown })}>
                              <CheckCircle2 size={13} /> Approve
                            </Button>
                          )}
                          <Button size="sm" variant="ghost" onClick={() => setSlipEmployee(existing || buildPreview(emp, breakdown, selectedMonth))}>
                            <Eye size={14} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      <SalarySlipModal
        payroll={slipEmployee}
        data={data}
        onClose={() => setSlipEmployee(null)}
      />

      <PaymentModal
        payroll={paymentTarget}
        onClose={() => setPaymentTarget(null)}
        onConfirm={(payment) => {
          if (paymentTarget) handlePayment(paymentTarget, payment);
          setPaymentTarget(null);
        }}
      />

      <ConfirmDialog
        open={!!approveTarget}
        onClose={() => setApproveTarget(null)}
        onConfirm={() => {
          if (!approveTarget) return;
          handleApprove(approveTarget.record, approveTarget.emp, approveTarget.breakdown);
        }}
        title="Approve and Finalize Payroll?"
        message={
          <>
            <p>This will finalize the salary calculation for {approveTarget?.emp.fullName} for {monthLabel(selectedMonth)}.</p>
            <p className="mt-2">Net payable: <strong>{formatINR(approveTarget?.breakdown.netPayable ?? 0)}</strong></p>
            <p className="mt-2">Pending adjustments (bonuses, deductions, advance recoveries) will be applied. Once finalized, this record will not change even if employee settings are updated later.</p>
          </>
        }
        confirmLabel="Approve & Finalize"
        variant="primary"
      />
    </div>
  );

  function buildPreview(emp: Employee, breakdown: ReturnType<typeof calculateSalary>, month: string): PayrollRecord {
    return {
      id: 'preview',
      employeeId: emp.id,
      salaryMonth: month,
      salaryType: emp.salaryType,
      baseSalary: breakdown.baseSalary,
      payableDays: breakdown.payableDays,
      presentDays: breakdown.presentDays,
      halfDays: breakdown.halfDays,
      paidLeaveDays: breakdown.paidLeaveDays,
      unpaidLeaveDays: breakdown.unpaidLeaveDays,
      overtimeHours: breakdown.overtimeHours,
      overtimeEarnings: breakdown.overtimeEarnings,
      bonus: breakdown.bonus,
      advanceRecovery: breakdown.advanceRecovery,
      otherDeductions: breakdown.otherDeductions,
      grossEarnings: breakdown.grossEarnings,
      netPayable: breakdown.netPayable,
      status: 'draft',
      paidAmount: 0,
      payments: [],
      adjustments: [],
      createdAt: new Date().toISOString(),
    };
  }
}

function SalarySlipModal({
  payroll, data, onClose,
}: {
  payroll: PayrollRecord | null;
  data: ReturnType<typeof useData>['data'];
  onClose: () => void;
}) {
  if (!payroll) return null;
  const emp = data.employees.find((e) => e.id === payroll.employeeId);
  if (!emp) return null;
  const outstanding = getOutstandingSalary(payroll);

  return (
    <Modal
      open={!!payroll}
      onClose={onClose}
      title="Salary Slip"
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button onClick={() => window.print()}><Printer size={16} /> Print / PDF</Button>
        </>
      }
    >
      <div className="rounded-xl border border-slate-200 p-6 print:border-0 print:p-0" id="salary-slip">
        <div className="flex justify-between items-start mb-6 pb-4 border-b border-slate-200">
          <div>
            <h2 className="text-lg font-bold text-slate-800">{data.settings.businessName || 'Your Business'}</h2>
            {data.settings.businessPhone && <p className="text-xs text-slate-500">{data.settings.businessPhone}</p>}
            {data.settings.businessAddress && <p className="text-xs text-slate-500">{data.settings.businessAddress}</p>}
          </div>
          <div className="text-right">
            <p className="text-sm font-semibold text-slate-700">Salary Slip</p>
            <p className="text-xs text-slate-500">{monthLabel(payroll.salaryMonth)}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <p className="text-xs text-slate-400">Employee Name</p>
            <p className="text-sm font-medium text-slate-700">{emp.fullName}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Employee ID</p>
            <p className="text-sm font-medium text-slate-700">{emp.employeeId}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Department</p>
            <p className="text-sm font-medium text-slate-700">{emp.department}</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Salary Type</p>
            <p className="text-sm font-medium text-slate-700">{payroll.salaryType === 'monthly' ? 'Monthly Salary' : 'Daily Wage'}</p>
          </div>
        </div>

        <div className="mb-4">
          <h3 className="text-sm font-semibold text-slate-700 mb-2">Attendance Summary</h3>
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
            <SlipStat label="Present" value={payroll.presentDays} />
            <SlipStat label="Half Day" value={payroll.halfDays} />
            <SlipStat label="Paid Leave" value={payroll.paidLeaveDays} />
            <SlipStat label="Unpaid Leave" value={payroll.unpaidLeaveDays} />
            <SlipStat label="Payable Days" value={payroll.payableDays} />
            <SlipStat label="OT Hours" value={payroll.overtimeHours} />
            <SlipStat label="Status" value={payroll.status.replace('-', ' ')} />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          <div className="rounded-lg border border-emerald-100 bg-emerald-50/50 p-4">
            <h3 className="text-sm font-semibold text-emerald-700 mb-3">Earnings</h3>
            <div className="space-y-2 text-sm">
              <SlipRow label="Base Salary" value={formatINR(payroll.baseSalary)} />
              <SlipRow label="Overtime Earnings" value={formatINR(payroll.overtimeEarnings)} />
              <SlipRow label="Bonus" value={formatINR(payroll.bonus)} />
              <div className="flex justify-between pt-2 border-t border-emerald-200 font-semibold">
                <span className="text-emerald-700">Gross Earnings</span>
                <span className="text-emerald-700">{formatINR(payroll.grossEarnings)}</span>
              </div>
            </div>
          </div>
          <div className="rounded-lg border border-red-100 bg-red-50/50 p-4">
            <h3 className="text-sm font-semibold text-red-700 mb-3">Deductions</h3>
            <div className="space-y-2 text-sm">
              <SlipRow label="Advance Recovery" value={`- ${formatINR(payroll.advanceRecovery)}`} />
              <SlipRow label="Other Deductions" value={`- ${formatINR(payroll.otherDeductions)}`} />
              <div className="flex justify-between pt-2 border-t border-red-200 font-semibold">
                <span className="text-red-700">Total Deductions</span>
                <span className="text-red-700">- {formatINR(payroll.advanceRecovery + payroll.otherDeductions)}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-lg bg-slate-800 text-white p-4 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-slate-300">Net Payable Salary</p>
              <p className="text-xs text-slate-400">{monthLabel(payroll.salaryMonth)}</p>
            </div>
            <p className="text-2xl font-bold">{formatINR(payroll.netPayable)}</p>
          </div>
        </div>

        {payroll.payments && payroll.payments.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-slate-700 mb-2">Payment History</h3>
            <div className="space-y-1.5">
              {payroll.payments.map((p) => (
                <div key={p.id} className="flex justify-between text-sm bg-slate-50 rounded-lg px-3 py-2">
                  <span className="text-slate-600">{p.date} · {p.method}</span>
                  <span className="font-medium text-emerald-600">{formatINR(p.amount)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-between items-center text-sm">
          <div>
            <p className="text-slate-500">Paid: <span className="font-medium text-emerald-600">{formatINR(payroll.paidAmount)}</span></p>
            {outstanding > 0 && <p className="text-slate-500">Outstanding: <span className="font-medium text-orange-600">{formatINR(outstanding)}</span></p>}
          </div>
          <p className="text-xs text-slate-400">Generated on {todayISO()}</p>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-200 text-center">
          <p className="text-xs text-slate-400">
            This is a computer-generated salary slip for recordkeeping purposes. It does not constitute a legal payment document.
          </p>
        </div>
      </div>
    </Modal>
  );
}

function SlipStat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded bg-slate-50 p-2 text-center">
      <p className="text-sm font-semibold text-slate-700">{value}</p>
      <p className="text-[10px] text-slate-400">{label}</p>
    </div>
  );
}

function SlipRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-slate-600">{label}</span>
      <span className="font-medium text-slate-700">{value}</span>
    </div>
  );
}

function PaymentModal({
  payroll, onClose, onConfirm,
}: {
  payroll: PayrollRecord | null;
  onClose: () => void;
  onConfirm: (payment: SalaryPayment) => void;
}) {
  const outstanding = payroll ? getOutstandingSalary(payroll) : 0;
  const [amount, setAmount] = useState(0);
  const [date, setDate] = useState(todayISO());
  const [method, setMethod] = useState<PaymentMethod>('cash');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  const handleConfirm = () => {
    if (amount <= 0) { setError('Amount must be greater than 0'); return; }
    if (amount > outstanding) { setError(`Amount cannot exceed outstanding ${formatINR(outstanding)}`); return; }
    onConfirm({
      id: uid('pay_pmt_'),
      amount: round2(amount),
      date,
      method,
      reference: reference.trim() || undefined,
      notes: notes.trim() || undefined,
    });
    setAmount(0); setReference(''); setNotes(''); setError('');
  };

  return (
    <Modal
      open={!!payroll}
      onClose={onClose}
      title="Record Salary Payment"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleConfirm}><Banknote size={16} /> Record Payment</Button>
        </>
      }
    >
      {payroll && (
        <div className="space-y-4">
          <div className="rounded-lg bg-slate-50 p-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Net Payable</span>
              <span className="font-medium text-slate-700">{formatINR(payroll.netPayable)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Already Paid</span>
              <span className="font-medium text-emerald-600">{formatINR(payroll.paidAmount)}</span>
            </div>
            <div className="flex justify-between text-sm pt-2 border-t border-slate-200">
              <span className="text-slate-600 font-medium">Outstanding</span>
              <span className="font-bold text-orange-600">{formatINR(outstanding)}</span>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Payment Amount (₹)" required error={error}>
              <Input type="number" min={1} max={outstanding} value={amount || ''} onChange={(e) => { setAmount(Number(e.target.value)); setError(''); }} error={!!error} placeholder={String(outstanding)} />
            </Field>
            <Field label="Payment Date" required>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
          </div>
          <Field label="Payment Method">
            <Select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
              <option value="cash">Cash</option>
              <option value="upi">UPI</option>
              <option value="bank-transfer">Bank Transfer</option>
              <option value="other">Other</option>
            </Select>
          </Field>
          <Field label="Reference Number" hint="Optional">
            <Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="UTR, cheque no..." />
          </Field>
          <Field label="Notes" hint="Optional">
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Partial payment, full settlement..." />
          </Field>
        </div>
      )}
    </Modal>
  );
}
