import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Users, CalendarCheck, CalendarX, Clock, IndianRupee,
  Wallet, AlertCircle, UserPlus, CalendarPlus, Plus, FileText,
  TrendingUp, ArrowRight,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, CartesianGrid, Legend,
} from 'recharts';
import { useData } from '@/context/DataContext';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { EmptyState, PageHeader } from '@/components/ui/Misc';
import {
  todayISO, currentMonthKey, monthKey, monthLabel, lastNMonths,
  formatINR, formatDate, getStatusLabel, datesInMonth,
} from '@/lib/format';
import { summarizeAttendance } from '@/lib/attendance';
import {
  calculateSalary, totalOutstandingForEmployee, outstandingAdvance,
  getOutstandingSalary,
} from '@/lib/salary';
import type { Employee } from '@/lib/types';

export function DashboardPage() {
  const { data } = useData();
  const today = todayISO();
  const month = currentMonthKey();

  const employees = data.employees;
  const activeEmployees = employees.filter((e) => e.status === 'active');

  const todayAttendance = data.attendance.filter((a) => a.date === today);
  const todayByStatus = useMemo(() => {
    const map = new Map<string, number>();
    for (const a of todayAttendance) {
      map.set(a.status, (map.get(a.status) || 0) + 1);
    }
    return map;
  }, [todayAttendance]);

  const presentToday = todayByStatus.get('present') || 0;
  const absentToday = todayByStatus.get('absent') || 0;
  const onLeaveToday =
    (todayByStatus.get('paid-leave') || 0) + (todayByStatus.get('unpaid-leave') || 0);
  const markedToday = todayAttendance.length;
  const notMarked = activeEmployees.length - markedToday;

  const monthlySalaryEstimate = useMemo(() => {
    return activeEmployees.reduce((sum, emp) => {
      const empAttendance = data.attendance.filter(
        (a) => a.employeeId === emp.id && monthKey(a.date) === month
      );
      const breakdown = calculateSalary({
        employee: emp,
        month,
        attendanceRecords: empAttendance,
        adjustments: data.adjustments,
        settings: data.settings,
      });
      return sum + breakdown.netPayable;
    }, 0);
  }, [activeEmployees, data.attendance, data.adjustments, data.settings, month]);

  const advancesThisMonth = useMemo(() => {
    return data.advances
      .filter((a) => monthKey(a.advanceDate) === month)
      .reduce((sum, a) => sum + a.amount, 0);
  }, [data.advances, month]);

  const pendingSalary = useMemo(() => {
    return data.payrolls.reduce((sum, p) => {
      if (p.status === 'paid') return sum;
      return sum + getOutstandingSalary(p);
    }, 0);
  }, [data.payrolls]);

  const monthlyChart = useMemo(() => {
    const months = lastNMonths(6, month);
    return months.map((m) => {
      const present = data.attendance.filter(
        (a) => monthKey(a.date) === m && a.status === 'present'
      ).length;
      const absent = data.attendance.filter(
        (a) => monthKey(a.date) === m && a.status === 'absent'
      ).length;
      const halfDay = data.attendance.filter(
        (a) => monthKey(a.date) === m && a.status === 'half-day'
      ).length;
      return {
        month: m.slice(5) + '/' + m.slice(2, 4),
        Present: present,
        Absent: absent,
        'Half Day': halfDay,
      };
    });
  }, [data.attendance, month]);

  const salaryChart = useMemo(() => {
    const months = lastNMonths(6, month);
    return months.map((m) => {
      const total = data.employees
        .filter((e) => e.status === 'active')
        .reduce((sum, emp) => {
          const empAtt = data.attendance.filter(
            (a) => a.employeeId === emp.id && monthKey(a.date) === m
          );
          const b = calculateSalary({
            employee: emp,
            month: m,
            attendanceRecords: empAtt,
            adjustments: data.adjustments,
            settings: data.settings,
          });
          return sum + b.netPayable;
        }, 0);
      return { month: m.slice(5) + '/' + m.slice(2, 4), salary: Math.round(total) };
    });
  }, [data.employees, data.attendance, data.adjustments, data.settings, month]);

  const departmentSummary = useMemo(() => {
    const map = new Map<string, { count: number; salary: number }>();
    for (const emp of employees) {
      const dept = emp.department || 'Unassigned';
      const existing = map.get(dept) || { count: 0, salary: 0 };
      existing.count++;
      if (emp.salaryType === 'monthly') existing.salary += emp.monthlySalary || 0;
      else existing.salary += (emp.dailyWageRate || 0) * 30;
      map.set(dept, existing);
    }
    return Array.from(map.entries()).map(([name, v]) => ({
      name,
      value: v.count,
      salary: v.salary,
    }));
  }, [employees]);

  const recentAttendance = useMemo(() => {
    return [...data.attendance]
      .sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt))
      .slice(0, 8)
      .map((a) => {
        const emp = employees.find((e) => e.id === a.employeeId);
        return { ...a, employeeName: emp?.fullName || 'Unknown', empId: emp?.employeeId || '' };
      });
  }, [data.attendance, employees]);

  const upcomingReminders = useMemo(() => {
    const settings = data.settings;
    const payDay = settings.defaultPaymentDay || 7;
    const now = new Date();
    const thisMonth = currentMonthKey();
    const paymentDate = `${thisMonth}-${String(payDay).padStart(2, '0')}`;
    const reminders: { label: string; sub: string; urgent: boolean }[] = [];

    if (today <= paymentDate) {
      reminders.push({
        label: `Salary payment due ${formatDate(paymentDate)}`,
        sub: `${activeEmployees.length} employees to pay`,
        urgent: today === paymentDate,
      });
    }

    const outstandingAdvances = employees
      .map((e) => ({ emp: e, amt: totalOutstandingForEmployee(e.id, data.advances, data.recoveries) }))
      .filter((x) => x.amt > 0);

    if (outstandingAdvances.length > 0) {
      reminders.push({
        label: `${outstandingAdvances.length} employees have outstanding advances`,
        sub: formatINR(outstandingAdvances.reduce((s, x) => s + x.amt, 0)) + ' total pending recovery',
        urgent: false,
      });
    }

    const unpaidPayrolls = data.payrolls.filter((p) => p.status !== 'paid' && getOutstandingSalary(p) > 0);
    if (unpaidPayrolls.length > 0) {
      reminders.push({
        label: `${unpaidPayrolls.length} payroll records pending payment`,
        sub: formatINR(unpaidPayrolls.reduce((s, p) => s + getOutstandingSalary(p), 0)) + ' outstanding',
        urgent: false,
      });
    }

    return reminders;
  }, [data, today, activeEmployees.length]);

  if (employees.length === 0) {
    return (
      <div>
        <PageHeader title="Dashboard" subtitle="Welcome! Start by adding your first employee." />
        <Card>
          <EmptyState
            icon={<Users size={32} />}
            title="No employees yet"
            description="Add your first employee to start tracking attendance and managing salaries. You can also load demo data to explore the app."
            action={
              <div className="flex gap-2 flex-wrap justify-center">
                <Link to="/app/employees">
                  <Button><UserPlus size={16} /> Add Employee</Button>
                </Link>
              </div>
            }
          />
        </Card>
        <OnboardingChecklist />
      </div>
    );
  }

  const pieColors = ['#059669', '#0284c7', '#f59e0b', '#ef4444', '#8b5cf6', '#64748b'];

  return (
    <div>
      <PageHeader
        title="Dashboard"
        subtitle={data.settings.businessName ? data.settings.businessName : 'Overview of your team'}
        action={
          <Link to="/app/payroll">
            <Button variant="outline" size="sm"><FileText size={16} /> Generate Payroll</Button>
          </Link>
        }
      />

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 sm:gap-4 mb-6">
        <StatCard icon={Users} label="Total Employees" value={String(employees.length)} sub={`${activeEmployees.length} active`} color="slate" />
        <StatCard icon={CalendarCheck} label="Present Today" value={String(presentToday)} color="emerald" />
        <StatCard icon={CalendarX} label="Absent Today" value={String(absentToday)} color="red" />
        <StatCard icon={Clock} label="On Leave Today" value={String(onLeaveToday)} color="orange" />
        <StatCard icon={IndianRupee} label="Est. Monthly Salary" value={formatINR(monthlySalaryEstimate)} color="blue" />
        <StatCard icon={Wallet} label="Advances This Month" value={formatINR(advancesThisMonth)} color="orange" />
      </div>

      {pendingSalary > 0 && (
        <div className="mb-6 flex items-center gap-3 rounded-xl bg-orange-50 border border-orange-200 px-4 py-3">
          <AlertCircle className="text-orange-600 shrink-0" size={20} />
          <p className="text-sm text-orange-800">
            <span className="font-semibold">{formatINR(pendingSalary)}</span> in pending salary payments.
          </p>
          <Link to="/app/payroll" className="ml-auto text-sm font-medium text-orange-700 hover:underline">
            View Payroll →
          </Link>
        </div>
      )}

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-5 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Attendance (6 months)</CardTitle>
          </CardHeader>
          <CardBody>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={monthlyChart}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" allowDecimals={false} />
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="Present" fill="#059669" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Absent" fill="#ef4444" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Half Day" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly Salary Expense (6 months)</CardTitle>
          </CardHeader>
          <CardBody>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={salaryChart}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#94a3b8" />
                <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" tickFormatter={(v) => '₹' + (v >= 1000 ? (v / 1000) + 'k' : v)} />
                <Tooltip formatter={(v: number) => formatINR(v)} />
                <Bar dataKey="salary" fill="#0284c7" radius={[4, 4, 0, 0]} name="Salary" />
              </BarChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>
      </div>

      {/* Department + Quick actions */}
      <div className="grid lg:grid-cols-3 gap-5 mb-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Department Summary</CardTitle>
          </CardHeader>
          <CardBody>
            {departmentSummary.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={departmentSummary}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={(e: { name: string }) => e.name}
                    labelLine={false}
                  >
                    {departmentSummary.map((_, i) => (
                      <Cell key={i} fill={pieColors[i % pieColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-sm text-slate-400 text-center py-8">No departments set</p>
            )}
          </CardBody>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <QuickAction to="/app/employees" icon={UserPlus} label="Add Employee" />
              <QuickAction to="/app/attendance" icon={CalendarPlus} label="Mark Attendance" />
              <QuickAction to="/app/advances" icon={Plus} label="Add Advance" />
              <QuickAction to="/app/payroll" icon={FileText} label="Generate Report" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Recent activity + reminders */}
      <div className="grid lg:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Recent Attendance Activity</CardTitle>
          </CardHeader>
          <CardBody className="p-0">
            {recentAttendance.length === 0 ? (
              <EmptyState title="No attendance recorded" description="Mark attendance to see activity here." />
            ) : (
              <div className="divide-y divide-slate-100">
                {recentAttendance.map((a) => (
                  <div key={a.id} className="flex items-center gap-3 px-5 py-3">
                    <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-xs font-semibold text-slate-600 shrink-0">
                      {a.employeeName.charAt(0)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-slate-700 truncate">{a.employeeName}</p>
                      <p className="text-xs text-slate-400">{formatDate(a.date)}</p>
                    </div>
                    <AttendanceBadge status={a.status} />
                    {a.overtimeHours > 0 && (
                      <span className="text-xs text-slate-400">+{a.overtimeHours}h OT</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Reminders</CardTitle>
          </CardHeader>
          <CardBody>
            {upcomingReminders.length === 0 ? (
              <EmptyState icon={<TrendingUp size={28} />} title="All clear!" description="No pending salary payments or outstanding advances." />
            ) : (
              <div className="space-y-3">
                {upcomingReminders.map((r, i) => (
                  <div
                    key={i}
                    className={`flex items-start gap-3 rounded-lg p-3 ${
                      r.urgent ? 'bg-orange-50 border border-orange-200' : 'bg-slate-50 border border-slate-100'
                    }`}
                  >
                    <AlertCircle
                      size={18}
                      className={r.urgent ? 'text-orange-600 shrink-0' : 'text-slate-400 shrink-0'}
                    />
                    <div>
                      <p className="text-sm font-medium text-slate-700">{r.label}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{r.sub}</p>
                    </div>
                  </div>
                ))}
                <Link to="/app/payroll" className="block">
                  <Button variant="outline" size="sm" className="w-full">
                    Go to Payroll <ArrowRight size={14} />
                  </Button>
                </Link>
              </div>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

const cardColors = {
  slate: { bg: 'bg-slate-50', text: 'text-slate-700', icon: 'text-slate-500' },
  emerald: { bg: 'bg-emerald-50', text: 'text-emerald-700', icon: 'text-emerald-600' },
  red: { bg: 'bg-red-50', text: 'text-red-700', icon: 'text-red-600' },
  orange: { bg: 'bg-orange-50', text: 'text-orange-700', icon: 'text-orange-600' },
  blue: { bg: 'bg-blue-50', text: 'text-blue-700', icon: 'text-blue-600' },
};

function StatCard({
  icon: Icon, label, value, sub, color,
}: {
  icon: typeof Users; label: string; value: string; sub?: string;
  color: keyof typeof cardColors;
}) {
  const c = cardColors[color];
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-medium text-slate-500">{label}</p>
        <div className={`w-8 h-8 rounded-lg ${c.bg} flex items-center justify-center`}>
          <Icon size={16} className={c.icon} />
        </div>
      </div>
      <p className={`text-xl sm:text-2xl font-bold ${c.text}`}>{value}</p>
      {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
    </div>
  );
}

function QuickAction({ to, icon: Icon, label }: { to: string; icon: typeof Users; label: string }) {
  return (
    <Link
      to={to}
      className="flex flex-col items-center gap-2 rounded-xl border border-slate-200 p-4 hover:border-emerald-300 hover:bg-emerald-50/30 transition-colors text-center"
    >
      <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
        <Icon size={20} />
      </div>
      <span className="text-xs font-medium text-slate-700">{label}</span>
    </Link>
  );
}

function AttendanceBadge({ status }: { status: string }) {
  const map: Record<string, { color: 'emerald' | 'red' | 'orange' | 'slate' | 'blue' | 'amber' }> = {
    present: { color: 'emerald' },
    absent: { color: 'red' },
    'half-day': { color: 'amber' },
    'paid-leave': { color: 'blue' },
    'unpaid-leave': { color: 'orange' },
    'weekly-off': { color: 'slate' },
    holiday: { color: 'slate' },
  };
  const config = map[status] || { color: 'slate' as const };
  return <Badge color={config.color}>{getStatusLabel(status)}</Badge>;
}

function OnboardingChecklist() {
  const { data } = useData();
  const steps = [
    { done: data.employees.length > 0, label: 'Add your first employee', to: '/app/employees' },
    { done: data.employees.some((e) => e.monthlySalary || e.dailyWageRate), label: 'Configure salary details', to: '/app/employees' },
    { done: data.attendance.length > 0, label: 'Mark daily attendance', to: '/app/attendance' },
    { done: data.advances.length > 0 || data.adjustments.length > 0, label: 'Record an advance or deduction', to: '/app/advances' },
    { done: data.payrolls.length > 0, label: 'Generate monthly payroll', to: '/app/payroll' },
  ];
  const completed = steps.filter((s) => s.done).length;

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>Getting Started ({completed}/{steps.length})</CardTitle>
      </CardHeader>
      <CardBody>
        <div className="space-y-2">
          {steps.map((s, i) => (
            <Link
              key={i}
              to={s.to}
              className="flex items-center gap-3 rounded-lg p-3 hover:bg-slate-50 transition-colors"
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                s.done ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-400'
              }`}>
                {s.done ? '✓' : i + 1}
              </div>
              <span className={`text-sm ${s.done ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
                {s.label}
              </span>
              {!s.done && <ArrowRight size={14} className="ml-auto text-slate-300" />}
            </Link>
          ))}
        </div>
      </CardBody>
    </Card>
  );
}
