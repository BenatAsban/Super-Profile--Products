import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type {
  AppData,
  Employee,
  Attendance,
  Advance,
  AdvanceRecovery,
  Adjustment,
  PayrollRecord,
  Settings,
} from '@/lib/types';
import { loadData, saveData, clearStorage, emptyData, isValidDataShape } from '@/lib/storage';
import { generateDemoData } from '@/lib/seed';

interface DataContextValue {
  data: AppData;
  setData: React.Dispatch<React.SetStateAction<AppData>>;
  updateSettings: (s: Partial<Settings>) => void;
  addEmployee: (e: Employee) => void;
  updateEmployee: (id: string, e: Partial<Employee>) => void;
  addAttendance: (a: Attendance) => void;
  updateAttendance: (id: string, a: Partial<Attendance>) => void;
  removeAttendance: (id: string) => void;
  addAdvance: (a: Advance) => void;
  updateAdvance: (id: string, a: Partial<Advance>) => void;
  addRecovery: (r: AdvanceRecovery) => void;
  addAdjustment: (a: Adjustment) => void;
  updateAdjustment: (id: string, a: Partial<Adjustment>) => void;
  removeAdjustment: (id: string) => void;
  upsertPayroll: (p: PayrollRecord) => void;
  updatePayroll: (id: string, p: Partial<PayrollRecord>) => void;
  loadDemoData: () => void;
  removeDemoData: () => void;
  importData: (incoming: AppData, replace: boolean) => boolean;
  clearAllData: () => void;
  setOnboardingCompleted: (v: boolean) => void;
}

const DataContext = createContext<DataContextValue | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => loadData());

  useEffect(() => {
    saveData(data);
  }, [data]);

  const updateSettings = useCallback((s: Partial<Settings>) => {
    setData((prev) => ({ ...prev, settings: { ...prev.settings, ...s } }));
  }, []);

  const addEmployee = useCallback((e: Employee) => {
    setData((prev) => ({ ...prev, employees: [...prev.employees, e] }));
  }, []);

  const updateEmployee = useCallback((id: string, e: Partial<Employee>) => {
    setData((prev) => ({
      ...prev,
      employees: prev.employees.map((emp) => (emp.id === id ? { ...emp, ...e } : emp)),
    }));
  }, []);

  const addAttendance = useCallback((a: Attendance) => {
    setData((prev) => {
      const existing = prev.attendance.find(
        (x) => x.employeeId === a.employeeId && x.date === a.date
      );
      if (existing) {
        return {
          ...prev,
          attendance: prev.attendance.map((x) =>
            x.id === existing.id ? { ...x, ...a, id: existing.id } : x
          ),
        };
      }
      return { ...prev, attendance: [...prev.attendance, a] };
    });
  }, []);

  const updateAttendance = useCallback((id: string, a: Partial<Attendance>) => {
    setData((prev) => ({
      ...prev,
      attendance: prev.attendance.map((x) => (x.id === id ? { ...x, ...a } : x)),
    }));
  }, []);

  const removeAttendance = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      attendance: prev.attendance.filter((x) => x.id !== id),
    }));
  }, []);

  const addAdvance = useCallback((a: Advance) => {
    setData((prev) => ({ ...prev, advances: [...prev.advances, a] }));
  }, []);

  const updateAdvance = useCallback((id: string, a: Partial<Advance>) => {
    setData((prev) => ({
      ...prev,
      advances: prev.advances.map((x) => (x.id === id ? { ...x, ...a } : x)),
    }));
  }, []);

  const addRecovery = useCallback((r: AdvanceRecovery) => {
    setData((prev) => ({ ...prev, recoveries: [...prev.recoveries, r] }));
  }, []);

  const addAdjustment = useCallback((a: Adjustment) => {
    setData((prev) => ({ ...prev, adjustments: [...prev.adjustments, a] }));
  }, []);

  const updateAdjustment = useCallback((id: string, a: Partial<Adjustment>) => {
    setData((prev) => ({
      ...prev,
      adjustments: prev.adjustments.map((x) => (x.id === id ? { ...x, ...a } : x)),
    }));
  }, []);

  const removeAdjustment = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      adjustments: prev.adjustments.filter((x) => x.id !== id),
    }));
  }, []);

  const upsertPayroll = useCallback((p: PayrollRecord) => {
    setData((prev) => {
      const existing = prev.payrolls.find(
        (x) => x.employeeId === p.employeeId && x.salaryMonth === p.salaryMonth
      );
      if (existing) {
        return {
          ...prev,
          payrolls: prev.payrolls.map((x) => (x.id === existing.id ? { ...p, id: existing.id } : x)),
        };
      }
      return { ...prev, payrolls: [...prev.payrolls, p] };
    });
  }, []);

  const updatePayroll = useCallback((id: string, p: Partial<PayrollRecord>) => {
    setData((prev) => ({
      ...prev,
      payrolls: prev.payrolls.map((x) => (x.id === id ? { ...x, ...p } : x)),
    }));
  }, []);

  const loadDemoData = useCallback(() => {
    setData((prev) => {
      const demo = generateDemoData();
      return {
        ...demo,
        employees: [...prev.employees, ...demo.employees],
        attendance: [...prev.attendance, ...demo.attendance],
        advances: [...prev.advances, ...demo.advances],
        adjustments: [...prev.adjustments, ...demo.adjustments],
        recoveries: [...prev.recoveries, ...demo.recoveries],
        payrolls: [...prev.payrolls, ...demo.payrolls],
        settings: prev.settings.businessName ? prev.settings : demo.settings,
        onboardingCompleted: prev.onboardingCompleted,
        demoDataLoaded: true,
      };
    });
  }, []);

  const removeDemoData = useCallback(() => {
    setData((prev) => ({
      ...prev,
      employees: prev.employees.filter((e) => !e.id.startsWith('emp_') || !isDemoEmployee(e)),
      attendance: prev.attendance.filter((a) => {
        const emp = prev.employees.find((e) => e.id === a.employeeId);
        return emp ? !isDemoEmployee(emp) : true;
      }),
      advances: prev.advances.filter((a) => {
        const emp = prev.employees.find((e) => e.id === a.employeeId);
        return emp ? !isDemoEmployee(emp) : true;
      }),
      adjustments: prev.adjustments.filter((a) => {
        const emp = prev.employees.find((e) => e.id === a.employeeId);
        return emp ? !isDemoEmployee(emp) : true;
      }),
      recoveries: [],
      payrolls: [],
      demoDataLoaded: false,
    }));
  }, []);

  const importData = useCallback((incoming: AppData, replace: boolean): boolean => {
    if (!isValidDataShape(incoming)) return false;
    try {
      setData((prev) => {
        const base = replace ? emptyData() : prev;
        return {
          employees: replace ? incoming.employees : [...base.employees, ...incoming.employees],
          attendance: replace ? incoming.attendance : [...base.attendance, ...incoming.attendance],
          advances: replace ? incoming.advances : [...base.advances, ...incoming.advances],
          recoveries: replace ? incoming.recoveries : [...base.recoveries, ...incoming.recoveries],
          adjustments: replace ? incoming.adjustments : [...base.adjustments, ...incoming.adjustments],
          payrolls: replace ? incoming.payrolls : [...base.payrolls, ...incoming.payrolls],
          settings: { ...base.settings, ...incoming.settings },
          onboardingCompleted: incoming.onboardingCompleted ?? base.onboardingCompleted,
          demoDataLoaded: incoming.demoDataLoaded ?? base.demoDataLoaded,
        };
      });
      return true;
    } catch {
      return false;
    }
  }, []);

  const clearAllData = useCallback(() => {
    clearStorage();
    setData(emptyData());
  }, []);

  const setOnboardingCompleted = useCallback((v: boolean) => {
    setData((prev) => ({ ...prev, onboardingCompleted: v }));
  }, []);

  const value = useMemo<DataContextValue>(
    () => ({
      data,
      setData,
      updateSettings,
      addEmployee,
      updateEmployee,
      addAttendance,
      updateAttendance,
      removeAttendance,
      addAdvance,
      updateAdvance,
      addRecovery,
      addAdjustment,
      updateAdjustment,
      removeAdjustment,
      upsertPayroll,
      updatePayroll,
      loadDemoData,
      removeDemoData,
      importData,
      clearAllData,
      setOnboardingCompleted,
    }),
    [data, updateSettings, addEmployee, updateEmployee, addAttendance, updateAttendance, removeAttendance, addAdvance, updateAdvance, addRecovery, addAdjustment, updateAdjustment, removeAdjustment, upsertPayroll, updatePayroll, loadDemoData, removeDemoData, importData, clearAllData, setOnboardingCompleted]
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

function isDemoEmployee(e: Employee): boolean {
  return (
    e.id.startsWith('emp_') &&
    ['Ramesh Kumar', 'Priya Sharma', 'Arun Mahadevan', 'Suresh Reddy', 'Lakshmi Nair', 'Vikram Singh', 'Deepa Iyer', 'Karthik Raj'].includes(e.fullName)
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useData(): DataContextValue {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
