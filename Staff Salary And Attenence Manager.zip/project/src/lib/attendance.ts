import type {
  Attendance,
  AttendanceStatus,
  Employee,
  Settings,
} from './types';
import { daysInMonth, datesInMonth, monthKey } from './format';

export const PAYABLE_DAYS: Record<AttendanceStatus, number> = {
  present: 1,
  absent: 0,
  'half-day': 0.5,
  'paid-leave': 1,
  'unpaid-leave': 0,
  'weekly-off': 0,
  holiday: 0,
};

export function attendanceMap(
  records: Attendance[],
  month?: string
): Map<string, Map<string, Attendance>> {
  const map = new Map<string, Map<string, Attendance>>();
  for (const a of records) {
    if (month && monthKey(a.date) !== month) continue;
    let empMap = map.get(a.employeeId);
    if (!empMap) {
      empMap = new Map();
      map.set(a.employeeId, empMap);
    }
    empMap.set(a.date, a);
  }
  return map;
}

export function getEmployeeAttendance(
  records: Attendance[],
  employeeId: string,
  month: string
): Attendance[] {
  return records.filter(
    (a) => a.employeeId === employeeId && monthKey(a.date) === month
  );
}

export interface AttendanceSummary {
  present: number;
  absent: number;
  halfDay: number;
  paidLeave: number;
  unpaidLeave: number;
  weeklyOff: number;
  holiday: number;
  payableDays: number;
  overtimeHours: number;
  totalMarked: number;
}

export function summarizeAttendance(records: Attendance[]): AttendanceSummary {
  const s: AttendanceSummary = {
    present: 0,
    absent: 0,
    halfDay: 0,
    paidLeave: 0,
    unpaidLeave: 0,
    weeklyOff: 0,
    holiday: 0,
    payableDays: 0,
    overtimeHours: 0,
    totalMarked: records.length,
  };
  for (const r of records) {
    s.payableDays += PAYABLE_DAYS[r.status] || 0;
    s.overtimeHours += r.overtimeHours || 0;
    switch (r.status) {
      case 'present': s.present++; break;
      case 'absent': s.absent++; break;
      case 'half-day': s.halfDay++; break;
      case 'paid-leave': s.paidLeave++; break;
      case 'unpaid-leave': s.unpaidLeave++; break;
      case 'weekly-off': s.weeklyOff++; break;
      case 'holiday': s.holiday++; break;
    }
  }
  s.payableDays = Math.round(s.payableDays * 100) / 100;
  return s;
}

export function getPayableDays(
  summary: AttendanceSummary,
  employee: Employee,
  settings: Settings
): number {
  let payable = summary.present + summary.paidLeave + summary.halfDay * 0.5;
  if (settings.salaryPolicy === 'no-proration') {
    payable += summary.weeklyOff + summary.holiday;
  }
  return Math.round(payable * 100) / 100;
}

export function getUnpaidDeductionDays(
  summary: AttendanceSummary,
  employee: Employee,
  settings: Settings
): number {
  if (settings.salaryPolicy === 'no-proration') return 0;
  return summary.unpaidLeave + summary.absent;
}

export { daysInMonth, datesInMonth };
