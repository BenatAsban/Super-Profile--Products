import type {
  Adjustment,
  Advance,
  AdvanceRecovery,
  Attendance,
  Employee,
  PayrollBreakdown,
  PayrollRecord,
  Settings,
} from './types';
import {
  PAYABLE_DAYS,
  summarizeAttendance,
} from './attendance';
import { daysInMonth, round2 } from './format';

export function outstandingAdvance(
  advance: Advance,
  recoveries: AdvanceRecovery[]
): number {
  const totalRecovered = recoveries
    .filter((r) => r.advanceId === advance.id)
    .reduce((sum, r) => sum + r.amount, 0);
  return round2(advance.amount - totalRecovered);
}

export function totalOutstandingForEmployee(
  employeeId: string,
  advances: Advance[],
  recoveries: AdvanceRecovery[]
): number {
  return round2(
    advances
      .filter((a) => a.employeeId === employeeId && a.status === 'active')
      .reduce((sum, a) => sum + outstandingAdvance(a, recoveries), 0)
  );
}

export interface SalaryInput {
  employee: Employee;
  month: string;
  attendanceRecords: Attendance[];
  adjustments: Adjustment[];
  settings: Settings;
  manualOvertimeHours?: number;
  manualBonus?: number;
  manualOtherDeductions?: number;
  manualAdvanceRecovery?: number;
  advanceIdForRecovery?: string;
}

export function calculateSalary(input: SalaryInput): PayrollBreakdown {
  const { employee, month, attendanceRecords, adjustments, settings } = input;
  const summary = summarizeAttendance(attendanceRecords);
  const totalDays = daysInMonth(month);

  const presentDays = summary.present;
  const halfDays = summary.halfDay;
  const paidLeaveDays = summary.paidLeave;
  const unpaidLeaveDays = settings.salaryPolicy === 'no-proration' ? 0 : summary.absent + summary.unpaidLeave;
  const weeklyOffDays = summary.weeklyOff;
  const holidayDays = summary.holiday;

  let payableDays: number;
  let baseSalary: number;
  let proratedBase: number;
  let prorationFactor = 1;

  if (employee.salaryType === 'daily') {
    payableDays =
      summary.present + summary.paidLeave + summary.halfDay * 0.5;
    if (settings.salaryPolicy === 'no-proration') {
      payableDays += summary.weeklyOff + summary.holiday;
    }
    payableDays = round2(payableDays);
    const rate = employee.dailyWageRate || 0;
    baseSalary = rate * payableDays;
    proratedBase = baseSalary;
  } else {
    const monthlyBase = employee.monthlySalary || 0;
    baseSalary = monthlyBase;
    if (settings.salaryPolicy === 'no-proration') {
      payableDays =
        summary.present +
        summary.paidLeave +
        summary.halfDay * 0.5 +
        summary.weeklyOff +
        summary.holiday;
      payableDays = round2(payableDays);
      proratedBase = monthlyBase;
    } else {
      const actualPayable =
        summary.present + summary.paidLeave + summary.halfDay * 0.5;
      payableDays = round2(actualPayable);
      const divisor =
        settings.salaryPolicy === 'prorate-calendar-days'
          ? totalDays
          : settings.salaryDaysPerMonth || 30;
      prorationFactor = divisor > 0 ? actualPayable / divisor : 0;
      const deductionDays = summary.absent + summary.unpaidLeave;
      const dailyRate = divisor > 0 ? monthlyBase / divisor : 0;
      proratedBase = round2(monthlyBase - deductionDays * dailyRate);
      if (proratedBase < 0) proratedBase = 0;
    }
  }

  const overtimeHours = input.manualOvertimeHours ?? summary.overtimeHours;
  const overtimeEarnings = round2(overtimeHours * (employee.overtimeRatePerHour || 0));

  const monthAdjustments = adjustments.filter(
    (a) =>
      a.employeeId === employee.id &&
      a.salaryMonth === month &&
      a.status === 'applied'
  );
  const bonus = round2(
    input.manualBonus ??
      monthAdjustments
        .filter((a) => a.type === 'bonus' || a.type === 'additional-earning')
        .reduce((s, a) => s + a.amount, 0)
  );
  const otherDeductions = round2(
    input.manualOtherDeductions ??
      monthAdjustments
        .filter((a) => a.type === 'other-deduction')
        .reduce((s, a) => s + a.amount, 0)
  );
  const advanceRecovery = round2(
    input.manualAdvanceRecovery ??
      monthAdjustments
        .filter((a) => a.type === 'advance-recovery')
        .reduce((s, a) => s + a.amount, 0)
  );

  const grossEarnings = round2(proratedBase + overtimeEarnings + bonus);
  const totalDeductions = round2(advanceRecovery + otherDeductions);
  const netPayable = round2(grossEarnings - totalDeductions);

  return {
    baseSalary: round2(baseSalary),
    payableDays,
    prorationFactor: round2(prorationFactor),
    proratedBase,
    overtimeEarnings,
    bonus,
    grossEarnings,
    advanceRecovery,
    otherDeductions,
    totalDeductions,
    netPayable: netPayable > 0 ? netPayable : 0,
    presentDays,
    halfDays,
    paidLeaveDays,
    unpaidLeaveDays,
    weeklyOffDays,
    holidayDays,
    overtimeHours: round2(overtimeHours),
  };
}

export function getPayrollForMonth(
  employeeId: string,
  month: string,
  payrolls: PayrollRecord[]
): PayrollRecord | undefined {
  return payrolls.find((p) => p.employeeId === employeeId && p.salaryMonth === month);
}

export function isPayrollFinalized(
  payroll: PayrollRecord | undefined
): boolean {
  if (!payroll) return false;
  return payroll.status === 'approved' || payroll.status === 'paid' || payroll.status === 'partially-paid';
}

export function getOutstandingSalary(payroll: PayrollRecord): number {
  return round2(payroll.netPayable - payroll.paidAmount);
}
