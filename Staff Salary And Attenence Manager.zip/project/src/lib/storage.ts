import type { AppData, Settings } from './types';

const STORAGE_KEY = 'ssa-india-2026-v1';

export const defaultSettings: Settings = {
  businessName: '',
  businessPhone: '',
  businessAddress: '',
  currency: 'INR',
  defaultWorkingHours: 8,
  defaultOvertimeRate: 50,
  defaultWeeklyOffDays: ['Sunday'],
  salaryPolicy: 'no-proration',
  salaryDaysPerMonth: 30,
  defaultPaymentDay: 7,
  language: 'english',
};

export function emptyData(): AppData {
  return {
    employees: [],
    attendance: [],
    advances: [],
    recoveries: [],
    adjustments: [],
    payrolls: [],
    settings: { ...defaultSettings },
    onboardingCompleted: false,
    demoDataLoaded: false,
  };
}

export function loadData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyData();
    const parsed = JSON.parse(raw) as Partial<AppData>;
    const base = emptyData();
    const merged: AppData = {
      employees: parsed.employees ?? [],
      attendance: parsed.attendance ?? [],
      advances: parsed.advances ?? [],
      recoveries: parsed.recoveries ?? [],
      adjustments: parsed.adjustments ?? [],
      payrolls: parsed.payrolls ?? [],
      settings: { ...base.settings, ...(parsed.settings ?? {}) },
      onboardingCompleted: parsed.onboardingCompleted ?? false,
      demoDataLoaded: parsed.demoDataLoaded ?? false,
    };
    return merged;
  } catch {
    return emptyData();
  }
}

export function saveData(data: AppData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save data', e);
  }
}

export function clearStorage(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear', e);
  }
}

export function isValidDataShape(obj: unknown): obj is AppData {
  if (!obj || typeof obj !== 'object') return false;
  const o = obj as Record<string, unknown>;
  return (
    Array.isArray(o.employees) &&
    Array.isArray(o.attendance) &&
    Array.isArray(o.advances) &&
    Array.isArray(o.recoveries) &&
    Array.isArray(o.adjustments) &&
    Array.isArray(o.payrolls) &&
    typeof o.settings === 'object' &&
    o.settings !== null
  );
}
