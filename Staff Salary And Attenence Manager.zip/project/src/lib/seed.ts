import type { AppData, Employee, Attendance, Advance, Adjustment, AttendanceStatus } from './types';
import { emptyData } from './storage';
import { uid, todayISO, currentMonthKey, datesInMonth, dayName } from './format';

const DEPARTMENTS = ['Sales', 'Kitchen', 'Cleaning', 'Counter', 'Security'];
const NAMES = [
  'Ramesh Kumar', 'Priya Sharma', 'Arun Mahadevan', 'Suresh Reddy',
  'Lakshmi Nair', 'Vikram Singh', 'Deepa Iyer', 'Karthik Raj',
];

export function generateDemoData(): AppData {
  const data = emptyData();
  const month = currentMonthKey();
  const allDates = datesInMonth(month);
  const joiningBase = `${month}-01`;

  let empCounter = 1;
  for (const name of NAMES) {
    const salaryType = empCounter % 3 === 0 ? 'daily' : 'monthly';
    const weeklyOff = empCounter % 2 === 0 ? ['Sunday'] : ['Monday'];
    const emp: Employee = {
      id: uid('emp_'),
      employeeId: `EMP${String(empCounter).padStart(3, '0')}`,
      fullName: name,
      phone: `98${String(10000000 + empCounter * 111111).slice(0, 8)}`,
      email: `${name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      department: DEPARTMENTS[(empCounter - 1) % DEPARTMENTS.length],
      joiningDate: joiningBase,
      status: 'active',
      salaryType,
      monthlySalary: salaryType === 'monthly' ? 12000 + empCounter * 1500 : undefined,
      dailyWageRate: salaryType === 'daily' ? 450 + empCounter * 25 : undefined,
      standardHoursPerDay: 8,
      overtimeRatePerHour: 50 + empCounter * 5,
      weeklyOffDays: weeklyOff,
      notes: '',
      createdAt: new Date().toISOString(),
    };
    data.employees.push(emp);
    empCounter++;
  }

  const statuses: AttendanceStatus[] = ['present', 'present', 'present', 'present', 'half-day', 'paid-leave', 'absent'];

  for (const emp of data.employees) {
    for (const date of allDates) {
      if (new Date(date + 'T00:00:00') > new Date(todayISO() + 'T00:00:00')) continue;
      const dow = dayName(date);
      let status: AttendanceStatus;
      if (emp.weeklyOffDays.includes(dow)) {
        status = 'weekly-off';
      } else {
        const seed = (date.charCodeAt(8) + date.charCodeAt(9) + emp.fullName.length) % statuses.length;
        status = statuses[seed];
      }
      const ot = status === 'present' ? (emp.fullName.length % 3 === 0 ? 1.5 : 0) : 0;
      data.attendance.push({
        id: uid('att_'),
        employeeId: emp.id,
        date,
        status,
        overtimeHours: ot,
        createdAt: new Date().toISOString(),
      });
    }

    if (empCounter % 2 === 0 || emp.id.includes('1')) {
      const amt = 2000 + Math.floor(Math.random() * 3000);
      const advance: Advance = {
        id: uid('adv_'),
        employeeId: emp.id,
        advanceDate: `${month}-05`,
        amount: amt,
        paymentMethod: 'cash',
        notes: 'Festival advance',
        status: 'active',
        createdAt: new Date().toISOString(),
      };
      data.advances.push(advance);
    }

    if (emp.salaryType === 'monthly') {
      data.adjustments.push({
        id: uid('adj_'),
        employeeId: emp.id,
        date: `${month}-10`,
        salaryMonth: month,
        type: 'bonus',
        amount: 500,
        reason: 'Performance bonus',
        status: 'pending',
        createdAt: new Date().toISOString(),
      });
    }
  }

  data.settings.businessName = 'Demo Sharma Store';
  data.settings.businessPhone = '9876543210';
  data.settings.businessAddress = '12 Market Road, Chennai, Tamil Nadu';
  data.demoDataLoaded = true;
  data.onboardingCompleted = false;

  return data;
}
