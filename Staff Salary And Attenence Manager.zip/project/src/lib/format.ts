export function uid(prefix = ''): string {
  return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export function formatINR(amount: number): string {
  const value = Math.round((amount + Number.EPSILON) * 100) / 100;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(value || 0);
}

export function formatNumber(value: number, digits = 2): string {
  return new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: digits,
    minimumFractionDigits: 0,
  }).format(value || 0);
}

export function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function currentMonthKey(): string {
  return new Date().toISOString().slice(0, 7);
}

export function monthKey(date: string): string {
  return date.slice(0, 7);
}

export function monthLabel(month: string): string {
  const [y, m] = month.split('-');
  const d = new Date(Number(y), Number(m) - 1, 1);
  return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
}

export function formatDate(date: string): string {
  if (!date) return '';
  const d = new Date(date + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function daysInMonth(month: string): number {
  const [y, m] = month.split('-').map(Number);
  return new Date(y, m, 0).getDate();
}

export function datesInMonth(month: string): string[] {
  const total = daysInMonth(month);
  const [y, m] = month.split('-').map(Number);
  const out: string[] = [];
  for (let d = 1; d <= total; d++) {
    out.push(
      `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`
    );
  }
  return out;
}

export function dayName(date: string): string {
  const d = new Date(date + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'long' });
}

export function dayShort(date: string): string {
  const d = new Date(date + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'short' });
}

export function dateNumber(date: string): number {
  return Number(date.slice(8, 10));
}

export function addMonths(month: string, count: number): string {
  const [y, m] = month.split('-').map(Number);
  const d = new Date(y, m - 1 + count, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function lastNMonths(n: number, endMonth?: string): string[] {
  const end = endMonth || currentMonthKey();
  const out: string[] = [];
  for (let i = n - 1; i >= 0; i--) out.push(addMonths(end, -i));
  return out;
}

export function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    present: 'Present',
    absent: 'Absent',
    'half-day': 'Half Day',
    'paid-leave': 'Paid Leave',
    'unpaid-leave': 'Unpaid Leave',
    'weekly-off': 'Weekly Off',
    holiday: 'Holiday',
  };
  return map[status] || status;
}
