export type EmploymentStatus = 'active' | 'inactive';
export type SalaryType = 'monthly' | 'daily';
export type AttendanceStatus =
  | 'present'
  | 'absent'
  | 'half-day'
  | 'paid-leave'
  | 'unpaid-leave'
  | 'weekly-off'
  | 'holiday';

export type PaymentMethod = 'cash' | 'upi' | 'bank-transfer' | 'other';
export type AdjustmentType =
  | 'advance-recovery'
  | 'other-deduction'
  | 'bonus'
  | 'additional-earning';

export type PayrollStatus = 'draft' | 'approved' | 'paid' | 'partially-paid';

export type SalaryPolicy = 'no-proration' | 'prorate-salary-days' | 'prorate-calendar-days';

export interface Employee {
  id: string;
  employeeId: string;
  fullName: string;
  phone: string;
  email?: string;
  department: string;
  joiningDate: string;
  status: EmploymentStatus;
  salaryType: SalaryType;
  monthlySalary?: number;
  dailyWageRate?: number;
  standardHoursPerDay: number;
  overtimeRatePerHour: number;
  weeklyOffDays: string[];
  notes?: string;
  createdAt: string;
}

export interface Attendance {
  id: string;
  employeeId: string;
  date: string;
  status: AttendanceStatus;
  overtimeHours: number;
  notes?: string;
  createdAt: string;
}

export interface Advance {
  id: string;
  employeeId: string;
  advanceDate: string;
  amount: number;
  paymentMethod: PaymentMethod;
  referenceNumber?: string;
  notes?: string;
  status: 'active' | 'closed';
  createdAt: string;
}

export interface AdvanceRecovery {
  id: string;
  advanceId: string;
  employeeId: string;
  amount: number;
  date: string;
  source: 'manual' | 'payroll';
  payrollId?: string;
  notes?: string;
  createdAt: string;
}

export interface Adjustment {
  id: string;
  employeeId: string;
  date: string;
  salaryMonth: string;
  type: AdjustmentType;
  amount: number;
  reason: string;
  advanceId?: string;
  status: 'pending' | 'applied';
  payrollId?: string;
  createdAt: string;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  salaryMonth: string;
  salaryType: SalaryType;
  baseSalary: number;
  payableDays: number;
  presentDays: number;
  halfDays: number;
  paidLeaveDays: number;
  unpaidLeaveDays: number;
  overtimeHours: number;
  overtimeEarnings: number;
  bonus: number;
  advanceRecovery: number;
  otherDeductions: number;
  grossEarnings: number;
  netPayable: number;
  status: PayrollStatus;
  paidAmount: number;
  payments: SalaryPayment[];
  adjustments: string[];
  finalizedAt?: string;
  notes?: string;
  createdAt: string;
}

export interface SalaryPayment {
  id: string;
  amount: number;
  date: string;
  method: PaymentMethod;
  reference?: string;
  notes?: string;
}

export interface Settings {
  businessName: string;
  businessPhone: string;
  businessAddress: string;
  currency: string;
  defaultWorkingHours: number;
  defaultOvertimeRate: number;
  defaultWeeklyOffDays: string[];
  salaryPolicy: SalaryPolicy;
  salaryDaysPerMonth: number;
  defaultPaymentDay: number;
  language: 'english' | 'tamil';
}

export interface AppData {
  employees: Employee[];
  attendance: Attendance[];
  advances: Advance[];
  recoveries: AdvanceRecovery[];
  adjustments: Adjustment[];
  payrolls: PayrollRecord[];
  settings: Settings;
  onboardingCompleted: boolean;
  demoDataLoaded: boolean;
}

export interface PayrollBreakdown {
  baseSalary: number;
  payableDays: number;
  prorationFactor: number;
  proratedBase: number;
  overtimeEarnings: number;
  bonus: number;
  grossEarnings: number;
  advanceRecovery: number;
  otherDeductions: number;
  totalDeductions: number;
  netPayable: number;
  presentDays: number;
  halfDays: number;
  paidLeaveDays: number;
  unpaidLeaveDays: number;
  weeklyOffDays: number;
  holidayDays: number;
  overtimeHours: number;
}
