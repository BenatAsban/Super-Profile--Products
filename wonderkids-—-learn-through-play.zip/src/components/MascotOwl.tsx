import React from 'react';

interface MascotOwlProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  mood?: 'happy' | 'waving' | 'smart' | 'celebrate';
  speechBubble?: string;
}

export const MascotOwl: React.FC<MascotOwlProps> = ({
  className = '',
  size = 'md',
  mood = 'happy',
  speechBubble
}) => {
  const sizeMap = {
    sm: 'w-16 h-16',
    md: 'w-28 h-28',
    lg: 'w-40 h-40',
    xl: 'w-52 h-52'
  };

  return (
    <div className={`relative inline-flex items-center justify-center flex-col ${className}`}>
      {speechBubble && (
        <div className="mb-2 px-3 py-1.5 bg-white border-2 border-amber-300 rounded-2xl shadow-sm text-xs sm:text-sm font-semibold text-amber-900 relative animate-bounce-gentle max-w-xs text-center">
          {speechBubble}
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-amber-300" />
        </div>
      )}

      {/* SVG Mascot Professor Hoot */}
      <svg
        viewBox="0 0 200 200"
        className={`${sizeMap[size]} filter drop-shadow-md select-none transition-transform hover:scale-105 duration-300`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Professor Hoot the friendly owl mascot"
      >
        {/* Soft Shadow */}
        <ellipse cx="100" cy="188" rx="55" ry="10" fill="#E2E8F0" />

        {/* Feet / Talons */}
        <path d="M72 178C72 184 66 188 60 188C54 188 50 184 52 178L62 165H72L72 178Z" fill="#F59E0B" />
        <path d="M128 178C128 184 134 188 140 188C146 188 150 184 148 178L138 165H128L128 178Z" fill="#F59E0B" />

        {/* Body */}
        <path
          d="M100 45C55 45 42 85 42 125C42 165 65 178 100 178C135 178 158 165 158 125C158 85 145 45 100 45Z"
          fill="#8B5CF6"
        />

        {/* Belly Plaque */}
        <path
          d="M100 80C75 80 62 105 62 135C62 165 78 172 100 172C122 172 138 165 138 135C138 105 125 80 100 80Z"
          fill="#EDE9FE"
        />

        {/* Belly Feathers pattern */}
        <path d="M92 110C96 114 104 114 108 110" stroke="#C4B5FD" strokeWidth="3" strokeLinecap="round" />
        <path d="M84 128C88 132 96 132 100 128" stroke="#C4B5FD" strokeWidth="3" strokeLinecap="round" />
        <path d="M100 128C104 132 112 132 116 128" stroke="#C4B5FD" strokeWidth="3" strokeLinecap="round" />
        <path d="M92 145C96 149 104 149 108 145" stroke="#C4B5FD" strokeWidth="3" strokeLinecap="round" />

        {/* Left Wing */}
        {mood === 'waving' ? (
          <path
            d="M48 115C32 95 24 70 36 60C45 52 56 75 58 95"
            fill="#7C3AED"
            className="animate-bounce-gentle origin-bottom"
          />
        ) : (
          <path
            d="M44 95C30 115 32 145 46 155C52 145 56 125 52 100Z"
            fill="#7C3AED"
          />
        )}

        {/* Right Wing */}
        {mood === 'celebrate' ? (
          <path
            d="M152 115C168 95 176 70 164 60C155 52 144 75 142 95"
            fill="#7C3AED"
            className="animate-bounce-gentle origin-bottom"
          />
        ) : (
          <path
            d="M156 95C170 115 168 145 154 155C148 145 144 125 148 100Z"
            fill="#7C3AED"
          />
        )}

        {/* Big Curious Eyes Outer */}
        <circle cx="75" cy="85" r="24" fill="#FFFFFF" stroke="#DDD6FE" strokeWidth="2" />
        <circle cx="125" cy="85" r="24" fill="#FFFFFF" stroke="#DDD6FE" strokeWidth="2" />

        {/* Eye Irises */}
        <circle cx="78" cy="85" r="13" fill="#1E1B4B" />
        <circle cx="122" cy="85" r="13" fill="#1E1B4B" />

        {/* Eye Highlights */}
        <circle cx="74" cy="81" r="5" fill="#FFFFFF" />
        <circle cx="82" cy="88" r="2" fill="#FFFFFF" />
        <circle cx="118" cy="81" r="5" fill="#FFFFFF" />
        <circle cx="126" cy="88" r="2" fill="#FFFFFF" />

        {/* Rosy Cheeks */}
        <ellipse cx="60" cy="105" rx="8" ry="5" fill="#F472B6" opacity="0.75" />
        <ellipse cx="140" cy="105" rx="8" ry="5" fill="#F472B6" opacity="0.75" />

        {/* Cute Orange Beak */}
        <polygon points="95,94 105,94 100,108" fill="#F59E0B" />
        <polygon points="97,94 103,94 100,105" fill="#FBBF24" />

        {/* Graduation Cap / Academic Hat */}
        <polygon points="100,14 165,34 100,52 35,34" fill="#0F172A" />
        <polygon points="100,18 160,34 100,48 40,34" fill="#1E293B" />
        <rect x="75" y="44" width="50" height="15" rx="4" fill="#0F172A" />
        
        {/* Cap Golden Button & Tassel */}
        <circle cx="100" cy="33" r="4" fill="#FBBF24" />
        <path d="M100 33Q125 40 135 60" stroke="#F59E0B" strokeWidth="3" fill="none" strokeLinecap="round" />
        <rect x="131" y="60" width="8" height="14" rx="2" fill="#F59E0B" />

        {/* Smart Glasses if smart or happy */}
        <path
          d="M58 85A18 18 0 1 0 94 85A18 18 0 1 0 58 85M94 85L106 85M106 85A18 18 0 1 0 142 85A18 18 0 1 0 106 85"
          stroke="#F59E0B"
          strokeWidth="3.5"
          fill="none"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
};
