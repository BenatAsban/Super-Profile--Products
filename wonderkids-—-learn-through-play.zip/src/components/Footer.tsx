import React from 'react';
import { TabType } from '../types';
import { soundManager } from '../utils/audio';
import { Heart, ShieldCheck, Sparkles, BookOpen } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: TabType) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab }) => {
  const handleTab = (t: TabType) => {
    soundManager.playPop();
    onSelectTab(t);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-white border-t-4 border-amber-200 mt-20 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand info */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-3xl select-none" role="img" aria-label="Owl mascot">🦉</span>
              <span className="text-2xl font-black bg-gradient-to-r from-purple-700 to-amber-600 bg-clip-text text-transparent font-heading">
                WonderKids
              </span>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-3">
              Little minds, big discoveries! An interactive, colorful playground where kids aged 3–12 learn essential skills through play.
            </p>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200 w-fit">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              100% Ad-Free & Kid Safe
            </div>
          </div>

          {/* Learning Activities */}
          <div>
            <h4 className="font-extrabold text-slate-800 text-base mb-3 font-heading flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-purple-600" />
              Learning Adventures
            </h4>
            <ul className="space-y-2 text-sm text-slate-600 font-medium">
              <li>
                <button onClick={() => handleTab('alphabet')} className="hover:text-amber-600 transition-colors cursor-pointer">
                  🔤 Alphabet & Phonics
                </button>
              </li>
              <li>
                <button onClick={() => handleTab('math')} className="hover:text-amber-600 transition-colors cursor-pointer">
                  🔢 Math Adventures
                </button>
              </li>
              <li>
                <button onClick={() => handleTab('english')} className="hover:text-amber-600 transition-colors cursor-pointer">
                  📖 English Words & Sentences
                </button>
              </li>
              <li>
                <button onClick={() => handleTab('science')} className="hover:text-amber-600 transition-colors cursor-pointer">
                  🪐 Science Explorer
                </button>
              </li>
            </ul>
          </div>

          {/* Games & Art */}
          <div>
            <h4 className="font-extrabold text-slate-800 text-base mb-3 font-heading flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              Fun & Creativity
            </h4>
            <ul className="space-y-2 text-sm text-slate-600 font-medium">
              <li>
                <button onClick={() => handleTab('brain-games')} className="hover:text-amber-600 transition-colors cursor-pointer">
                  🧠 Brain Games & Puzzles
                </button>
              </li>
              <li>
                <button onClick={() => handleTab('creative')} className="hover:text-amber-600 transition-colors cursor-pointer">
                  🎨 Creative Art Studio
                </button>
              </li>
              <li>
                <button onClick={() => handleTab('parent-zone')} className="hover:text-amber-600 transition-colors cursor-pointer">
                  👨‍👩‍👧 Parent Zone & Tips
                </button>
              </li>
            </ul>
          </div>

          {/* Child Safety & LocalStorage Notice */}
          <div className="bg-amber-50/70 p-4 rounded-2xl border-2 border-amber-200">
            <h4 className="font-bold text-amber-950 text-sm mb-1 font-heading">
              Privacy & Offline Promise
            </h4>
            <p className="text-xs text-amber-900/80 leading-relaxed mb-2">
              All stars, drawings, and game progress remain inside this web browser. No accounts, cookies, or remote tracking are ever used.
            </p>
            <p className="text-[11px] text-slate-500 italic">
              Designed to support parents and early educators. Does not replace professional schooling.
            </p>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© {new Date().getFullYear()} WonderKids — Learn Through Play. Built with care for joyful young minds.</p>
          <div className="flex items-center gap-1 text-slate-400">
            <span>Made with</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>for curious kids everywhere</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
