import React, { useState } from 'react';
import { TabType } from '../types';
import { soundManager } from '../utils/audio';
import { 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Star, 
  Menu, 
  X, 
  Compass, 
  Palette, 
  BookOpen, 
  Calculator, 
  Languages, 
  Atom, 
  Gamepad2, 
  Users 
} from 'lucide-react';

interface NavbarProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
  stars: number;
  onOpenBadges: () => void;
  isSoundEnabled: boolean;
  onToggleSound: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  stars,
  onOpenBadges,
  isSoundEnabled,
  onToggleSound
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: TabType; label: string; icon: React.ReactNode; color: string }[] = [
    { id: 'home', label: 'Home', icon: <Compass className="w-4 h-4" />, color: 'text-amber-600' },
    { id: 'alphabet', label: 'Alphabet', icon: <BookOpen className="w-4 h-4" />, color: 'text-pink-600' },
    { id: 'math', label: 'Math', icon: <Calculator className="w-4 h-4" />, color: 'text-sky-600' },
    { id: 'english', label: 'English', icon: <Languages className="w-4 h-4" />, color: 'text-emerald-600' },
    { id: 'science', label: 'Science', icon: <Atom className="w-4 h-4" />, color: 'text-purple-600' },
    { id: 'brain-games', label: 'Brain Games', icon: <Gamepad2 className="w-4 h-4" />, color: 'text-indigo-600' },
    { id: 'creative', label: 'Creative', icon: <Palette className="w-4 h-4" />, color: 'text-rose-600' },
    { id: 'parent-zone', label: 'Parent Zone', icon: <Users className="w-4 h-4" />, color: 'text-teal-600' }
  ];

  const handleNavClick = (tab: TabType) => {
    soundManager.playPop();
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-amber-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 cursor-pointer group text-left"
            aria-label="WonderKids Home"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 via-orange-400 to-yellow-300 flex items-center justify-center shadow-md transform group-hover:scale-105 group-hover:rotate-3 transition-transform border-2 border-white">
              <span className="text-2xl select-none" role="img" aria-label="Owl mascot">🦉</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-black bg-gradient-to-r from-purple-700 via-pink-600 to-amber-600 bg-clip-text text-transparent font-heading tracking-tight">
                  WonderKids
                </span>
                <span className="hidden sm:inline-block text-[10px] uppercase font-black px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full border border-amber-300">
                  Play & Learn
                </span>
              </div>
              <div className="text-[11px] font-semibold text-slate-400 -mt-0.5 tracking-wider">
                Learn Through Play
              </div>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1">
            {navItems.map(item => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-2 rounded-xl text-sm font-bold font-heading transition-all flex items-center gap-1.5 cursor-pointer ${
                    isActive
                      ? 'bg-amber-100 text-amber-900 shadow-xs border-2 border-amber-300 scale-105'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 border-2 border-transparent'
                  }`}
                >
                  <span className={item.color}>{item.icon}</span>
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Sound Toggle */}
            <button
              onClick={() => {
                soundManager.playPop();
                onToggleSound();
              }}
              title={isSoundEnabled ? 'Sound is ON (Click to mute)' : 'Sound is OFF (Click to turn on)'}
              aria-label={isSoundEnabled ? 'Turn sound off' : 'Turn sound on'}
              className={`p-2.5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-center ${
                isSoundEnabled
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700 hover:bg-emerald-100 shadow-xs'
                  : 'bg-slate-100 border-slate-300 text-slate-400 hover:bg-slate-200'
              }`}
            >
              {isSoundEnabled ? <Volume2 className="w-5 h-5 animate-pulse-subtle" /> : <VolumeX className="w-5 h-5" />}
            </button>

            {/* Stars Button -> Badges */}
            <button
              onClick={() => {
                soundManager.playPop();
                onOpenBadges();
              }}
              aria-label="View stars and badges"
              className="flex items-center gap-2 px-3 sm:px-4 py-2 bg-gradient-to-r from-amber-300 to-yellow-400 hover:from-amber-400 hover:to-yellow-500 text-amber-950 font-black rounded-2xl border-2 border-amber-200 shadow-sm active:scale-95 transition-all cursor-pointer font-heading"
            >
              <div className="w-6 h-6 rounded-full bg-white/70 flex items-center justify-center shadow-xs">
                <Star className="w-4 h-4 fill-amber-500 text-amber-500 animate-bounce-gentle" />
              </div>
              <span className="text-base sm:text-lg">{stars}</span>
              <span className="hidden sm:inline text-xs font-bold text-amber-900/80 uppercase">Stars</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => {
                soundManager.playPop();
                setMobileMenuOpen(!mobileMenuOpen);
              }}
              className="xl:hidden p-2.5 rounded-2xl border-2 border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 cursor-pointer"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b-2 border-amber-200 px-4 pt-2 pb-6 shadow-xl animate-fadeIn">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
            {navItems.map(item => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`p-3 rounded-2xl text-left font-bold font-heading text-sm transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                    isActive
                      ? 'bg-amber-100 text-amber-950 border-2 border-amber-300 shadow-xs'
                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-2 border-slate-100'
                  }`}
                >
                  <div className={`p-2 rounded-xl bg-white shadow-xs ${item.color}`}>
                    {item.icon}
                  </div>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-500">
            <span>WonderKids Safe Play</span>
            <button
              onClick={() => {
                soundManager.playPop();
                onOpenBadges();
                setMobileMenuOpen(false);
              }}
              className="text-amber-700 font-bold flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Open Trophy Room ({stars} ⭐)
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
