import React, { useState } from 'react';
import { ALL_BADGES } from '../utils/storage';
import { soundManager } from '../utils/audio';
import { Trophy, Star, X, RotateCcw, AlertTriangle, Sparkles } from 'lucide-react';

interface BadgesModalProps {
  isOpen: boolean;
  onClose: () => void;
  stars: number;
  unlockedBadgeIds: string[];
  onResetProgress: () => void;
}

export const BadgesModal: React.FC<BadgesModalProps> = ({
  isOpen,
  onClose,
  stars,
  unlockedBadgeIds,
  onResetProgress
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border-4 border-amber-200 max-h-[90vh] overflow-y-auto relative">
        {/* Close Button */}
        <button
          onClick={() => {
            soundManager.playPop();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors cursor-pointer"
          aria-label="Close badges window"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-200 shadow-md mb-3 border-2 border-amber-300">
            <Trophy className="w-8 h-8 text-amber-900 animate-bounce-gentle" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-800 font-heading">
            Trophy Room & Badges
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-1">
            Keep playing games and quizzes to collect all glowing badges!
          </p>
        </div>

        {/* Star Summary Card */}
        <div className="bg-amber-50 rounded-2xl p-4 border-2 border-amber-200 flex items-center justify-between mb-6 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-400 flex items-center justify-center shadow-inner">
              <Star className="w-7 h-7 text-white fill-white" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-700 uppercase tracking-wide">Total Stars</div>
              <div className="text-2xl font-black text-amber-950 font-heading">{stars} Stars Earned</div>
            </div>
          </div>
          <div className="text-right">
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-200 text-amber-900 rounded-full text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              {unlockedBadgeIds.length} / {ALL_BADGES.length} Badges
            </span>
          </div>
        </div>

        {/* Badge Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          {ALL_BADGES.map(badge => {
            const isUnlocked = unlockedBadgeIds.includes(badge.id) || stars >= badge.requiredStars;
            return (
              <div
                key={badge.id}
                className={`p-3.5 rounded-2xl border-2 transition-all flex items-start gap-3 ${
                  isUnlocked
                    ? 'bg-gradient-to-br from-yellow-50 to-amber-50 border-amber-300 shadow-xs'
                    : 'bg-slate-50 border-slate-200 opacity-60'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 shadow-xs ${
                    isUnlocked ? 'bg-amber-100 border border-amber-300 ring-2 ring-amber-200/50' : 'bg-slate-200'
                  }`}
                >
                  {isUnlocked ? badge.icon : '🔒'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-800 text-sm truncate font-heading">{badge.title}</h3>
                    {isUnlocked && (
                      <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                        Unlocked!
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5 leading-snug line-clamp-2">{badge.description}</p>
                  {!isUnlocked && (
                    <div className="text-[11px] font-semibold text-amber-600 mt-1 flex items-center gap-1">
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                      Needs {badge.requiredStars} stars ({badge.requiredStars - stars} more)
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Browser storage note */}
        <div className="p-3 bg-sky-50 rounded-xl border border-sky-200 text-sky-800 text-xs mb-6 flex items-start gap-2">
          <span className="text-base">💾</span>
          <div>
            <strong>Private & Browser-Safe:</strong> Your stars and badges are stored only in this browser (LocalStorage). No sign-in or personal accounts needed!
          </div>
        </div>

        {/* Reset Confirmation or Reset Trigger */}
        {showConfirmReset ? (
          <div className="p-4 bg-rose-50 border-2 border-rose-200 rounded-2xl">
            <div className="flex items-center gap-2 text-rose-800 font-bold text-sm mb-1">
              <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0" />
              Reset all stars and badges?
            </div>
            <p className="text-xs text-rose-700 mb-3">
              This will reset stars back to 5 so you can enjoy earning them all over again.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  soundManager.playPop();
                  onResetProgress();
                  setShowConfirmReset(false);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Yes, Reset My Stars
              </button>
              <button
                onClick={() => {
                  soundManager.playPop();
                  setShowConfirmReset(false);
                }}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="flex justify-between items-center pt-2 border-t border-slate-100">
            <button
              onClick={() => {
                soundManager.playPop();
                setShowConfirmReset(true);
              }}
              className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Learning Progress
            </button>
            <button
              onClick={() => {
                soundManager.playPop();
                onClose();
              }}
              className="px-5 py-2.5 bg-amber-400 hover:bg-amber-500 text-amber-950 font-bold rounded-xl text-sm transition-all shadow-sm active:scale-95 cursor-pointer font-heading"
            >
              Keep Playing!
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
