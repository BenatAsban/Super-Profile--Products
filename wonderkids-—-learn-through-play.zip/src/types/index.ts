export type TabType = 
  | 'home'
  | 'alphabet'
  | 'math'
  | 'english'
  | 'science'
  | 'brain-games'
  | 'creative'
  | 'parent-zone';

export interface ProgressState {
  stars: number;
  completedActivities: string[];
  badges: string[];
  dailyChallengeCompletedDate: string | null;
  activityHistory: Record<string, number>; // activityId -> score or times played
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  requiredStars: number;
  category: string;
}

export interface AlphabetLetter {
  letter: string;
  phonetic: string;
  word: string;
  category: string;
  emoji: string;
  soundDescription: string;
  exampleSentence: string;
}

export interface EnglishWord {
  id: string;
  word: string;
  category: 'animals' | 'fruits' | 'colors' | 'shapes' | 'family' | 'home' | 'actions';
  emoji: string;
  meaning: string;
  sentence: string;
}

export interface ScienceTopic {
  id: string;
  title: string;
  badgeEmoji: string;
  category: string;
  summary: string;
  explanation: string;
  keyFacts: string[];
  quiz: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }[];
}

export interface DailyChallenge {
  id: string;
  title: string;
  description: string;
  targetTab: TabType;
  rewardStars: number;
  icon: string;
}
