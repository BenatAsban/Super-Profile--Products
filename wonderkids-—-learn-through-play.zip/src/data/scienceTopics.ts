import { ScienceTopic } from '../types';

export const SCIENCE_TOPICS: ScienceTopic[] = [
  {
    id: 'solar_system',
    title: 'The Solar System & Planets',
    badgeEmoji: '🪐',
    category: 'Space Science',
    summary: 'Our cosmic neighborhood with 8 exciting planets traveling around one giant star!',
    explanation: 'The solar system is made of the Sun at the center and eight planets orbiting around it. The four inner rocky planets are Mercury, Venus, Earth, and Mars. The four outer gas and ice giants are Jupiter, Saturn, Uranus, and Neptune. Earth is the only known planet with liquid oceans and living creatures!',
    keyFacts: [
      'The Sun is so huge that over 1 million Earths could fit inside it!',
      'Jupiter is the biggest planet and has a giant storm called the Great Red Spot.',
      'Saturn has magnificent sparkling rings made mostly of ice chunks and dust.'
    ],
    quiz: [
      {
        question: 'Which planet do we live on?',
        options: ['Mars', 'Earth', 'Jupiter', 'Venus'],
        correctIndex: 1,
        explanation: 'Earth is our beautiful home planet with blue oceans and fresh air!'
      },
      {
        question: 'What is at the very center of our solar system?',
        options: ['The Moon', 'The Sun', 'Saturn', 'A Comet'],
        correctIndex: 1,
        explanation: 'The Sun is the giant glowing star that holds the planets in orbit with gravity.'
      },
      {
        question: 'Which planet is famous for its stunning visible rings?',
        options: ['Saturn', 'Mercury', 'Mars', 'Earth'],
        correctIndex: 0,
        explanation: 'Saturn has the most famous and dazzling rings made of ice and rock!'
      }
    ]
  },
  {
    id: 'animals_habitats',
    title: 'Animals & Their Habitats',
    badgeEmoji: '🐾',
    category: 'Biology',
    summary: 'Discover where wild animals sleep, hunt, build nests, and stay safe!',
    explanation: 'A habitat is a natural home where an animal finds food, fresh water, shelter, and space to grow. Frogs and fish thrive in freshwater wetlands and rivers. Polar bears have thick blubber and fur for icy polar tundras. Monkeys and colorful birds love leafy rainforest canopies, while camels have special humps to store energy in dry deserts.',
    keyFacts: [
      'Camels can survive weeks without water in hot deserts thanks to fat stored in their humps!',
      'Polar bears actually have black skin under their clear, hollow white fur to absorb warmth.',
      'Over half of all animal and plant species in the world live in tropical rainforests.'
    ],
    quiz: [
      {
        question: 'Where would you find a polar bear living naturally?',
        options: ['Hot Desert', 'Snowy Arctic', 'Tropical Jungle', 'Deep Cave'],
        correctIndex: 1,
        explanation: 'Polar bears are specially adapted for the frozen ice and snow of the Arctic.'
      },
      {
        question: 'What is a natural home of an animal called?',
        options: ['A Habitat', 'A Laboratory', 'A Runway', 'A Backpack'],
        correctIndex: 0,
        explanation: 'A habitat provides food, water, and shelter for living animals!'
      },
      {
        question: 'Which habitat is home to monkeys, toucans, and tall trees?',
        options: ['Ocean Floor', 'Rainforest', 'Desert Dunes', 'Ice Cap'],
        correctIndex: 1,
        explanation: 'Rainforests are warm, rainy, and filled with tall trees for climbing creatures!'
      }
    ]
  },
  {
    id: 'plants_growth',
    title: 'Plants & How They Grow',
    badgeEmoji: '🌱',
    category: 'Botany',
    summary: 'From tiny seeds to tall leafy trees: how plants make food from sunlight!',
    explanation: 'Plants are green powerhouses! With sunlight, water, air (carbon dioxide), and soil minerals, plants perform photosynthesis to create their own sugary food and release fresh oxygen for us to breathe. Roots drink water from the soil, the stem carries nutrients up, and green leaves soak in warm sunshine.',
    keyFacts: [
      'Leaves have a green pigment called chlorophyll that captures sunlight energy.',
      'The tallest trees on Earth, California Redwoods, can grow higher than a 30-story skyscraper!',
      'Some flowers, like sunflowers, track and turn towards the sun across the sky each day.'
    ],
    quiz: [
      {
        question: 'What do plants need to grow healthy and strong?',
        options: ['Ice cream and soda', 'Sunlight, water, and soil', 'Darkness only', 'Plastic toys'],
        correctIndex: 1,
        explanation: 'Plants thrive when they have warm sunshine, fresh water, and nutrient-rich soil.'
      },
      {
        question: 'What do plants give off into the air that animals and humans breathe?',
        options: ['Oxygen', 'Steam', 'Sand', 'Helium'],
        correctIndex: 0,
        explanation: 'Plants produce clean oxygen, which is essential for all of us to breathe!'
      },
      {
        question: 'Which part of a plant drinks water underground?',
        options: ['Petals', 'Roots', 'Bark', 'Thorns'],
        correctIndex: 1,
        explanation: 'Roots branch underground like little straws to pull up moisture and minerals.'
      }
    ]
  },
  {
    id: 'weather_wonders',
    title: 'Weather & Seasons',
    badgeEmoji: '⛅',
    category: 'Earth Science',
    summary: 'Sunshine, clouds, raindrops, snow, and winds that shape our daily adventures!',
    explanation: 'Weather describes what the air outside is like every day. Is it sunny, cloudy, windy, or rainy? As Earth tilts on its axis while orbiting the Sun, we experience four seasons: Spring (fresh blossoms), Summer (warm and long days), Autumn (crunchy falling leaves), and Winter (chilly snow and cozy mittens).',
    keyFacts: [
      'No two snowflakes in the sky have the exact same shape under a microscope!',
      'Wind is simply air moving from high pressure areas to low pressure areas.',
      'Rainbows form when sunlight beams bounce and bend through floating raindrops.'
    ],
    quiz: [
      {
        question: 'Which season has cold temperatures and sometimes snow?',
        options: ['Summer', 'Winter', 'Spring', 'Autumn'],
        correctIndex: 1,
        explanation: 'Winter brings cold weather, warm hats, and sometimes soft snowflakes!'
      },
      {
        question: 'What causes a rainbow in the sky?',
        options: ['Sunlight shining through raindrops', 'Moonlight hitting clouds', 'Stars twinkling', 'Lightning'],
        correctIndex: 0,
        explanation: 'Raindrops act like tiny glass prisms that split white sunlight into 7 colors!'
      },
      {
        question: 'What tool measures how hot or cold the day is?',
        options: ['A Ruler', 'A Thermometer', 'A Telescope', 'A Compass'],
        correctIndex: 1,
        explanation: 'A thermometer measures degrees of air temperature!'
      }
    ]
  },
  {
    id: 'water_cycle',
    title: 'The Wonderful Water Cycle',
    badgeEmoji: '💧',
    category: 'Earth Science',
    summary: 'The endless journey of water from oceans to fluffy clouds and back down as rain!',
    explanation: 'Water on Earth is always moving in a cycle. When the sun warms lakes and oceans, liquid water turns into invisible vapor in a process called evaporation. High in the cold sky, vapor chills and bunches into clouds (condensation). When clouds grow heavy, water drops down as rain, sleet, or snow (precipitation)!',
    keyFacts: [
      'The water coming out of your kitchen tap today could be the same water a dinosaur drank millions of years ago!',
      'Clouds look light and fluffy, but an average cumulus cloud weighs as much as 100 elephants!',
      'Most of Earth’s fresh water is frozen inside polar glaciers and icecaps.'
    ],
    quiz: [
      {
        question: 'What is it called when warm water turns into invisible sky vapor?',
        options: ['Freezing', 'Evaporation', 'Digestion', 'Melting'],
        correctIndex: 1,
        explanation: 'Evaporation happens when warm heat changes liquid water into rising water vapor.'
      },
      {
        question: 'When clouds get too heavy with droplets, what happens?',
        options: ['Precipitation (Rain or Snow)', 'They vanish instantly', 'They catch fire', 'They turn green'],
        correctIndex: 0,
        explanation: 'Precipitation falls down as rain, hail, or snow to refill streams and rivers.'
      },
      {
        question: 'What brings vapor together to form clouds in the sky?',
        options: ['Condensation', 'Explosion', 'Windmills', 'Mirrors'],
        correctIndex: 0,
        explanation: 'Condensation happens when chilled water vapor gathers into tiny cloud droplets.'
      }
    ]
  },
  {
    id: 'human_body',
    title: 'Human Body Basics',
    badgeEmoji: '🫀',
    category: 'Anatomy',
    summary: 'Your fantastic body: bones, heart, muscles, and brain working as a great team!',
    explanation: 'Your body is an incredible biological machine! Your skeleton has 206 bones that protect organs and help you stand tall. Muscles contract to help you run, jump, and smile. Your heart pumps blood carrying oxygen to every cell, and your brain is the master computer directing your thoughts and feelings.',
    keyFacts: [
      'Your beating heart pumps about 2,000 gallons of blood throughout your body every single day!',
      'Your brain produces enough tiny electrical signals to light a small low-wattage LED bulb!',
      'Kids have about 300 bones at birth; as you grow, some join together so adults have 206.'
    ],
    quiz: [
      {
        question: 'Which organ pumps blood throughout your whole body?',
        options: ['Lungs', 'Heart', 'Stomach', 'Elbow'],
        correctIndex: 1,
        explanation: 'Your heart is a tireless muscle that beats steady rhythm to pump oxygenated blood.'
      },
      {
        question: 'What hard structure protects your brain inside your head?',
        options: ['The Skull bone', 'The Ribcage', 'The Spine', 'The Kneecap'],
        correctIndex: 0,
        explanation: 'The skull is a strong bone helmet that keeps your brain safe!'
      },
      {
        question: 'What gives your body energy to play, run, and learn?',
        options: ['Healthy food, water, and restful sleep', 'Sitting still all day', 'Eating only candy', 'Never drinking water'],
        correctIndex: 0,
        explanation: 'Nutritious meals, fresh water, and deep sleep recharge your wonderful body!'
      }
    ]
  },
  {
    id: 'five_senses',
    title: 'The Five Senses',
    badgeEmoji: '👀',
    category: 'Biology',
    summary: 'Sight, sound, smell, taste, and touch: how you explore the amazing world around you!',
    explanation: 'Our five senses help us gather information and stay safe every second. Eyes let us see vibrant colors and shapes. Ears pick up soft music and birdsong. Your nose sniffs fresh flowers and warm soup. Your tongue tastes sweet, salty, sour, and savory flavors. Your skin feels soft puppy fur, smooth stones, and warm blankets.',
    keyFacts: [
      'Your nose and tastebuds work together — when your nose is stuffed, food tastes much milder!',
      'Ears do more than hear: special fluid in your inner ear also helps you keep your balance!',
      'Fingertips are packed with thousands of sensitive nerve endings for detailed touch.'
    ],
    quiz: [
      {
        question: 'Which organ do we use to listen to birds singing?',
        options: ['Eyes', 'Ears', 'Nose', 'Tongue'],
        correctIndex: 1,
        explanation: 'Our ears collect sound waves and send signals to the brain!'
      },
      {
        question: 'Which sense helps you know if an apple is sweet?',
        options: ['Touch', 'Taste', 'Hearing', 'Balance'],
        correctIndex: 1,
        explanation: 'Taste buds on your tongue detect sweetness!'
      },
      {
        question: 'What organ covers your entire body to give you the sense of touch?',
        options: ['Bones', 'Skin', 'Hair', 'Muscles'],
        correctIndex: 1,
        explanation: 'Skin is our largest organ and lets us feel warmth, coolness, and textures.'
      }
    ]
  },
  {
    id: 'day_and_night',
    title: 'Day and Night',
    badgeEmoji: '🌓',
    category: 'Astronomy',
    summary: 'Why does the sun rise and set? How the spinning Earth brings morning and bedtime!',
    explanation: 'Day and night happen because planet Earth is constantly spinning like a giant, gentle top! It takes Earth 24 hours to make one full spin. When the side of Earth you live on faces towards the Sun, it is bright daytime. As Earth spins away into shadow, the stars appear and it becomes bedtime night.',
    keyFacts: [
      'The Moon does not make its own light; it shines by reflecting sunlight like a cosmic mirror!',
      'Earth spins around at over 1,000 miles per hour at the equator, but we don’t feel it because everything moves smoothly together.',
      'Some nocturnal animals, like owls and fireflies, are wide awake and active at night!'
    ],
    quiz: [
      {
        question: 'Why does morning turn into night on Earth?',
        options: ['The Sun turns off like a lightbulb', 'Earth spins around every 24 hours', 'Clouds block the sky permanently', 'The Moon covers the Sun'],
        correctIndex: 1,
        explanation: 'Earth spins steadily; when your side faces the sun, it is day; when turned away, it is night!'
      },
      {
        question: 'How long does Earth take to make one full spin?',
        options: ['1 hour', '12 hours', '24 hours (one day)', '1 whole year'],
        correctIndex: 2,
        explanation: '24 hours makes up one day and one night!'
      },
      {
        question: 'Which bird is famous for staying awake during the starry night?',
        options: ['Rooster', 'Owl', 'Penguin', 'Robin'],
        correctIndex: 1,
        explanation: 'Owls are nocturnal birds with keen night vision!'
      }
    ]
  },
  {
    id: 'caring_planet',
    title: 'Caring for Our Earth',
    badgeEmoji: '🌍',
    category: 'Ecology',
    summary: 'Simple, powerful ways kids and families can protect nature, clean oceans, and green trees!',
    explanation: 'Our planet gives us fresh air to breathe, sparkling water to drink, and fertile soil for food. We can all be Earth Guardians by practicing the three Rs: Reduce (use less waste), Reuse (give toys and bags a second life), and Recycle (turn paper, aluminum, and plastic into new things). Planting trees and turning off lights also help keep Earth healthy!',
    keyFacts: [
      'Recycling just one aluminum can saves enough electric energy to power a TV for three hours!',
      'A single mature leafy tree provides enough fresh oxygen for four people each day.',
      'Turning off the tap while brushing your teeth can save up to 8 gallons of clean water daily.'
    ],
    quiz: [
      {
        question: 'What are the famous three Rs for helping the Earth?',
        options: ['Run, Read, Rest', 'Reduce, Reuse, Recycle', 'Rain, River, Rock', 'Red, Rose, Ruby'],
        correctIndex: 1,
        explanation: 'Reduce what we waste, Reuse what we can, and Recycle materials into new items!'
      },
      {
        question: 'What is an easy habit to save clean water at home?',
        options: ['Leaving the tap running', 'Turning off the tap while brushing teeth', 'Pouring juice on the lawn', 'Taking 2-hour showers'],
        correctIndex: 1,
        explanation: 'Turning off the faucet while brushing teeth saves buckets of clean water!'
      },
      {
        question: 'How do green trees help the air we breathe?',
        options: ['They blow cold wind', 'They clean the air and produce oxygen', 'They paint the clouds', 'They make rain salty'],
        correctIndex: 1,
        explanation: 'Trees absorb carbon dioxide and release fresh, clean oxygen for everyone!'
      }
    ]
  },
  {
    id: 'ocean_mysteries',
    title: 'Ocean Mysteries',
    badgeEmoji: '🌊',
    category: 'Marine Biology',
    summary: 'Dive deep beneath blue waves to meet playful dolphins, coral reefs, and gentle sea turtles!',
    explanation: 'Oceans cover more than 70% of Earth’s surface! They are home to millions of amazing marine creatures, from microscopic plankton to giant blue whales. Colorful coral reefs act like bustling underwater cities where clownfish, sea stars, and baby turtles find safety and food.',
    keyFacts: [
      'The blue whale is the largest animal ever known to live on Earth — even bigger than any dinosaur!',
      'Octopuses have three hearts and blue blood, and can change their color in a split second to hide!',
      'Coral reefs look like colorful rocks, but they are actually colonies of tiny soft living animals.'
    ],
    quiz: [
      {
        question: 'How much of Earth’s surface is covered by oceans?',
        options: ['About 10%', 'About 70%', 'Only 5%', 'None'],
        correctIndex: 1,
        explanation: 'Over 70% of our blue planet is covered by vast, shimmering oceans!'
      },
      {
        question: 'Which sea creature has three hearts and can camouflage?',
        options: ['Octopus', 'Goldfish', 'Clownfish', 'Starfish'],
        correctIndex: 0,
        explanation: 'The octopus has three hearts and is a master of camouflage!'
      },
      {
        question: 'What is the largest animal to ever live on planet Earth?',
        options: ['T-Rex dinosaur', 'Blue Whale', 'Elephant', 'Great White Shark'],
        correctIndex: 1,
        explanation: 'The blue whale can grow up to 100 feet long!'
      }
    ]
  }
];
