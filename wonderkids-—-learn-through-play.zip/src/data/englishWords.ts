import { EnglishWord } from '../types';

export const ENGLISH_WORDS: EnglishWord[] = [
  // Animals
  { id: 'w1', word: 'Puppy', category: 'animals', emoji: '🐶', meaning: 'A playful baby dog', sentence: 'The puppy wags its tail happily.' },
  { id: 'w2', word: 'Kitten', category: 'animals', emoji: '🐱', meaning: 'A tiny sweet baby cat', sentence: 'The kitten drinks warm milk.' },
  { id: 'w3', word: 'Bunny', category: 'animals', emoji: '🐰', meaning: 'A fluffy rabbit with long ears', sentence: 'The bunny hops over the clover.' },
  { id: 'w4', word: 'Panda', category: 'animals', emoji: '🐼', meaning: 'A cuddly bear that munches bamboo', sentence: 'The panda rolls on the soft grass.' },
  { id: 'w5', word: 'Dolphin', category: 'animals', emoji: '🐬', meaning: 'A smart and friendly sea creature', sentence: 'The dolphin leaps high through the ocean waves.' },
  
  // Fruits & Veggies
  { id: 'w6', word: 'Strawberry', category: 'fruits', emoji: '🍓', meaning: 'A sweet red berry with tiny seeds', sentence: 'Strawberries are delicious in smoothies.' },
  { id: 'w7', word: 'Banana', category: 'fruits', emoji: '🍌', meaning: 'A long yellow fruit with a peel', sentence: 'Peel the ripe banana for snack time.' },
  { id: 'w8', word: 'Carrot', category: 'fruits', emoji: '🥕', meaning: 'A crunchy orange root vegetable', sentence: 'Bunnies love to munch fresh carrots.' },
  { id: 'w9', word: 'Watermelon', category: 'fruits', emoji: '🍉', meaning: 'A big juicy green and red summer melon', sentence: 'We eat cold watermelon on sunny picnic days.' },
  { id: 'w10', word: 'Broccoli', category: 'fruits', emoji: '🥦', meaning: 'A healthy green vegetable that looks like tiny trees', sentence: 'Broccoli gives us energy to run and play.' },

  // Colors
  { id: 'w11', word: 'Blue', category: 'colors', emoji: '🟦', meaning: 'The calm color of the sky and sea', sentence: 'The blue ocean sparkles in daylight.' },
  { id: 'w12', word: 'Yellow', category: 'colors', emoji: '🟨', meaning: 'The cheerful color of sunshine and lemons', sentence: 'Dandelions bloom with bright yellow petals.' },
  { id: 'w13', word: 'Green', category: 'colors', emoji: '🟩', meaning: 'The fresh color of spring leaves and grass', sentence: 'Spring turns the hilltops emerald green.' },
  { id: 'w14', word: 'Purple', category: 'colors', emoji: '🟪', meaning: 'A royal color made by mixing red and blue', sentence: 'Sweet grapes hang in purple bunches.' },
  { id: 'w15', word: 'Orange', category: 'colors', emoji: '🟧', meaning: 'A warm color like pumpkins and tigers', sentence: 'The sunset painted the clouds orange.' },

  // Shapes
  { id: 'w16', word: 'Circle', category: 'shapes', emoji: '⭕', meaning: 'A round shape with no corners', sentence: 'A clock and a coin are round circles.' },
  { id: 'w17', word: 'Square', category: 'shapes', emoji: '⏹️', meaning: 'A shape with four equal straight sides', sentence: 'The picture frame is shaped like a square.' },
  { id: 'w18', word: 'Triangle', category: 'shapes', emoji: '🔺', meaning: 'A shape with three points and three sides', sentence: 'A slice of pizza looks like a triangle.' },
  { id: 'w19', word: 'Star', category: 'shapes', emoji: '⭐', meaning: 'A twinkling shape with five or more points', sentence: 'Draw a shining star on top of your drawing.' },
  { id: 'w20', word: 'Heart', category: 'shapes', emoji: '❤️', meaning: 'A shape that represents love and kindness', sentence: 'Give a handmade heart card to your friend.' },

  // Family
  { id: 'w21', word: 'Mother', category: 'family', emoji: '👩', meaning: 'A loving female parent', sentence: 'Mother reads a bedtime story tonight.' },
  { id: 'w22', word: 'Father', category: 'family', emoji: '👨', meaning: 'A caring male parent', sentence: 'Father helps tie my shoelaces.' },
  { id: 'w23', word: 'Baby', category: 'family', emoji: '👶', meaning: 'A very young child', sentence: 'The smiling baby giggles and claps.' },
  { id: 'w24', word: 'Grandma', category: 'family', emoji: '👵', meaning: 'The mother of your parent', sentence: 'Grandma bakes warm cinnamon cookies.' },
  { id: 'w25', word: 'Friend', category: 'family', emoji: '🧑‍🤝‍🧑', meaning: 'Someone you like playing and sharing with', sentence: 'Good friends share their toys and laughs.' },

  // Home Objects
  { id: 'w26', word: 'Bed', category: 'home', emoji: '🛏️', meaning: 'A cozy place to sleep and dream', sentence: 'I snuggle under my blanket in bed.' },
  { id: 'w27', word: 'Chair', category: 'home', emoji: '🪑', meaning: 'Furniture made for sitting comfortably', sentence: 'Pull up a wooden chair to the table.' },
  { id: 'w28', word: 'Book', category: 'home', emoji: '📖', meaning: 'Pages with stories and exciting pictures', sentence: 'Opening a book begins a grand adventure.' },
  { id: 'w29', word: 'Clock', category: 'home', emoji: '⏰', meaning: 'A tool that tells us what time it is', sentence: 'The clock ticks steadily on the wall.' },
  { id: 'w30', word: 'Lamp', category: 'home', emoji: '💡', meaning: 'A light that brightens up a room', sentence: 'Turn on the desk lamp to do homework.' },

  // Actions
  { id: 'w31', word: 'Jump', category: 'actions', emoji: '🦘', meaning: 'Pushing off the ground with both feet', sentence: 'We jump over puddles after the rain.' },
  { id: 'w32', word: 'Sing', category: 'actions', emoji: '🎤', meaning: 'Making musical sounds with your voice', sentence: 'The birds sing melodies in the morning.' },
  { id: 'w33', word: 'Dance', category: 'actions', emoji: '💃', meaning: 'Moving your body joyfully to music', sentence: 'Kids dance together to the playful beat.' },
  { id: 'w34', word: 'Read', category: 'actions', emoji: '📚', meaning: 'Looking at words and understanding them', sentence: 'We read fairy tales before going to sleep.' },
  { id: 'w35', word: 'Smile', category: 'actions', emoji: '😊', meaning: 'Making a happy curve with your mouth', sentence: 'A warm smile brightens everyone\'s day.' }
];

export interface SentencePuzzle {
  id: string;
  targetSentence: string;
  words: string[];
  hint: string;
  emoji: string;
}

export const SENTENCE_PUZZLES: SentencePuzzle[] = [
  {
    id: 's1',
    targetSentence: 'Birds can fly high.',
    words: ['fly', 'Birds', 'high.', 'can'],
    hint: 'Think about feathered friends in the blue sky!',
    emoji: '🕊️'
  },
  {
    id: 's2',
    targetSentence: 'The sun is bright.',
    words: ['is', 'bright.', 'The', 'sun'],
    hint: 'What shines and warms us during daytime?',
    emoji: '☀️'
  },
  {
    id: 's3',
    targetSentence: 'I love reading books.',
    words: ['books.', 'love', 'I', 'reading'],
    hint: 'Tell about your favorite peaceful hobby!',
    emoji: '📚'
  },
  {
    id: 's4',
    targetSentence: 'Fish swim in water.',
    words: ['swim', 'in', 'Fish', 'water.'],
    hint: 'Where do our underwater friends live?',
    emoji: '🐠'
  },
  {
    id: 's5',
    targetSentence: 'Apples grow on trees.',
    words: ['on', 'grow', 'Apples', 'trees.'],
    hint: 'Where do delicious red fruits come from?',
    emoji: '🍎'
  },
  {
    id: 's6',
    targetSentence: 'Dogs like to play.',
    words: ['to', 'Dogs', 'play.', 'like'],
    hint: 'What do happy puppies enjoy doing at the park?',
    emoji: '🐕'
  }
];
