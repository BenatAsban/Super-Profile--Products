import { AlphabetLetter } from '../types';

export const ALPHABET_DATA: AlphabetLetter[] = [
  {
    letter: 'A',
    phonetic: '/æ/',
    word: 'Apple',
    category: 'Fruit',
    emoji: '🍎',
    soundDescription: 'A makes the sound "ah" as in Apple!',
    exampleSentence: 'A juicy red apple is sweet and yummy.'
  },
  {
    letter: 'B',
    phonetic: '/b/',
    word: 'Ball',
    category: 'Toy',
    emoji: '⚽',
    soundDescription: 'B makes the bouncy "buh" sound like Ball!',
    exampleSentence: 'Bounce the round ball high into the air.'
  },
  {
    letter: 'C',
    phonetic: '/k/',
    word: 'Cat',
    category: 'Animal',
    emoji: '🐱',
    soundDescription: 'C makes the crisp "kuh" sound like Cat!',
    exampleSentence: 'The fluffy cat purrs and chases a yarn ball.'
  },
  {
    letter: 'D',
    phonetic: '/d/',
    word: 'Duck',
    category: 'Animal',
    emoji: '🦆',
    soundDescription: 'D makes the tap "duh" sound like Duck!',
    exampleSentence: 'The yellow duck says quack in the pond.'
  },
  {
    letter: 'E',
    phonetic: '/e/',
    word: 'Elephant',
    category: 'Animal',
    emoji: '🐘',
    soundDescription: 'E makes the friendly "eh" sound like Elephant!',
    exampleSentence: 'The gentle elephant waves its long trunk.'
  },
  {
    letter: 'F',
    phonetic: '/f/',
    word: 'Fish',
    category: 'Animal',
    emoji: '🐟',
    soundDescription: 'F makes the soft "fff" breeze sound like Fish!',
    exampleSentence: 'The shiny little fish swims through the blue water.'
  },
  {
    letter: 'G',
    phonetic: '/ɡ/',
    word: 'Giraffe',
    category: 'Animal',
    emoji: '🦒',
    soundDescription: 'G makes the "guh" and "juh" sounds like Giraffe!',
    exampleSentence: 'The tall giraffe reaches green leaves high in trees.'
  },
  {
    letter: 'H',
    phonetic: '/h/',
    word: 'House',
    category: 'Home',
    emoji: '🏠',
    soundDescription: 'H makes a warm breathy "huh" sound like House!',
    exampleSentence: 'Our warm house has cozy beds and family love.'
  },
  {
    letter: 'I',
    phonetic: '/ɪ/',
    word: 'Igloo',
    category: 'Place',
    emoji: '🛖',
    soundDescription: 'I makes the short "ih" sound like Igloo!',
    exampleSentence: 'An igloo is a cool dome built with snowy ice blocks.'
  },
  {
    letter: 'J',
    phonetic: '/dʒ/',
    word: 'Jellyfish',
    category: 'Sea Animal',
    emoji: '🪼',
    soundDescription: 'J makes the jolly "juh" sound like Jellyfish!',
    exampleSentence: 'The glowing jellyfish floats gently like a parachute.'
  },
  {
    letter: 'K',
    phonetic: '/k/',
    word: 'Kite',
    category: 'Toy',
    emoji: '🪁',
    soundDescription: 'K makes the sharp "kuh" sound like Kite!',
    exampleSentence: 'The colorful kite dances in the sunny wind.'
  },
  {
    letter: 'L',
    phonetic: '/l/',
    word: 'Lion',
    category: 'Animal',
    emoji: '🦁',
    soundDescription: 'L makes the cheerful "lll" sound like Lion!',
    exampleSentence: 'The brave lion has a golden mane and a loud roar.'
  },
  {
    letter: 'M',
    phonetic: '/m/',
    word: 'Monkey',
    category: 'Animal',
    emoji: '🐵',
    soundDescription: 'M makes the sweet "mmm" humming sound like Monkey!',
    exampleSentence: 'The playful monkey swings from vine to vine.'
  },
  {
    letter: 'N',
    phonetic: '/n/',
    word: 'Nest',
    category: 'Nature',
    emoji: '🪺',
    soundDescription: 'N makes the nose "nnn" sound like Nest!',
    exampleSentence: 'A robin mother tucks her blue eggs safely in a nest.'
  },
  {
    letter: 'O',
    phonetic: '/ɒ/',
    word: 'Owl',
    category: 'Bird',
    emoji: '🦉',
    soundDescription: 'O makes the round "ah" and "oh" sounds like Owl!',
    exampleSentence: 'The wise owl watches over the quiet starry night.'
  },
  {
    letter: 'P',
    phonetic: '/p/',
    word: 'Penguin',
    category: 'Bird',
    emoji: '🐧',
    soundDescription: 'P makes the popping "puh" sound like Penguin!',
    exampleSentence: 'The tuxedo penguin waddles and slides across the ice.'
  },
  {
    letter: 'Q',
    phonetic: '/kw/',
    word: 'Queen',
    category: 'Person',
    emoji: '👑',
    soundDescription: 'Q teams up with U to say "kwuh" like Queen!',
    exampleSentence: 'The kind queen wears a sparkling golden crown.'
  },
  {
    letter: 'R',
    phonetic: '/r/',
    word: 'Rainbow',
    category: 'Nature',
    emoji: '🌈',
    soundDescription: 'R makes the rolling "rrr" sound like Rainbow!',
    exampleSentence: 'A rainbow paints seven bright colors across the sky.'
  },
  {
    letter: 'S',
    phonetic: '/s/',
    word: 'Sun',
    category: 'Space',
    emoji: '☀️',
    soundDescription: 'S makes the sunny snake "sss" sound like Sun!',
    exampleSentence: 'The bright sun warms our cheeks every morning.'
  },
  {
    letter: 'T',
    phonetic: '/t/',
    word: 'Turtle',
    category: 'Animal',
    emoji: '🐢',
    soundDescription: 'T makes the ticking "tuh" sound like Turtle!',
    exampleSentence: 'The patient turtle carries its sturdy shell on its back.'
  },
  {
    letter: 'U',
    phonetic: '/ʌ/',
    word: 'Umbrella',
    category: 'Item',
    emoji: '☂️',
    soundDescription: 'U makes the "uh" sound like Umbrella!',
    exampleSentence: 'Pop open the umbrella when raindrop showers fall.'
  },
  {
    letter: 'V',
    phonetic: '/v/',
    word: 'Violin',
    category: 'Music',
    emoji: '🎻',
    soundDescription: 'V makes the buzzing "vvv" sound like Violin!',
    exampleSentence: 'The wooden violin plays sweet and dreamy melodies.'
  },
  {
    letter: 'W',
    phonetic: '/w/',
    word: 'Whale',
    category: 'Sea Animal',
    emoji: '🐳',
    soundDescription: 'W makes the whimsical "wuh" sound like Whale!',
    exampleSentence: 'The gentle blue whale spouts misty water into the air.'
  },
  {
    letter: 'X',
    phonetic: '/ks/',
    word: 'Xylophone',
    category: 'Music',
    emoji: '🎼',
    soundDescription: 'X makes the exciting "zyl" or "ks" sound like Xylophone!',
    exampleSentence: 'Tap the rainbow bars of the xylophone to make bells sing.'
  },
  {
    letter: 'Y',
    phonetic: '/j/',
    word: 'Yo-yo',
    category: 'Toy',
    emoji: '🪀',
    soundDescription: 'Y makes the bouncy "yuh" sound like Yo-yo!',
    exampleSentence: 'The speedy yo-yo spins down on its string and snaps up.'
  },
  {
    letter: 'Z',
    phonetic: '/z/',
    word: 'Zebra',
    category: 'Animal',
    emoji: '🦓',
    soundDescription: 'Z makes the zippy "zzz" sound like Zebra!',
    exampleSentence: 'The zebra sports stylish black and white stripes.'
  }
];
