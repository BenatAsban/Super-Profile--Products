export interface AgeGuide {
  ageGroup: string;
  stage: string;
  icon: string;
  focusAreas: string[];
  recommendedSections: string[];
  parentCoachingTip: string;
}

export const AGE_GUIDES: AgeGuide[] = [
  {
    ageGroup: 'Ages 3–5',
    stage: 'Little Explorers (Preschool & Kindergarten)',
    icon: '🐣',
    focusAreas: [
      'Letter recognition and sound matching (phonemic awareness)',
      'Counting objects 1 to 10 with tactile and visual aids',
      'Basic shape & primary color identification',
      'Fine motor hand-eye coordination with drawing canvas'
    ],
    recommendedSections: ['Alphabet & Phonics', 'Math Adventure (Beginner)', 'Creative Corner'],
    parentCoachingTip: 'Sit together and explore aloud! When touching a letter card, repeat the letter sound together and search for items in your room that start with that sound.'
  },
  {
    ageGroup: 'Ages 6–8',
    stage: 'Curious Discoverers (Early Elementary)',
    icon: '🚀',
    focusAreas: [
      'Sight words, everyday vocabulary, and simple sentence formation',
      'Addition and subtraction within 20, greater/less than comparisons',
      'Observation of nature: weather, water cycle, animal habitats',
      'Short-term visual memory and pattern recognition'
    ],
    recommendedSections: ['English Words & Sentence Builder', 'Math Adventure (Intermediate)', 'Science Explorer', 'Brain Games'],
    parentCoachingTip: 'Celebrate effort over perfection. Ask open-ended questions like "Why do you think the clouds turn gray before rain?" or "How did you spot that pattern?"'
  },
  {
    ageGroup: 'Ages 9–12',
    stage: 'Junior Innovators (Upper Elementary)',
    icon: '🌟',
    focusAreas: [
      'Multiplication foundations, mental math division, and number logic',
      'Deeper science topics: planetary systems, ecological sustainability, anatomy',
      'Analytical brain puzzles and multi-step deduction games',
      'Digital illustration and creative expression'
    ],
    recommendedSections: ['Math Adventure (Advanced)', 'Brain Games (Picture Puzzle & Pattern Detective)', 'Science Explorer (Full Quizzes)', 'Creative Canvas'],
    parentCoachingTip: 'Encourage kids to explain concepts back to you like a teacher! Teaching someone else reinforces conceptual understanding and builds confidence.'
  }
];

export const PARENTING_TIPS = {
  reading: [
    {
      title: 'Make Reading a Daily Ritual',
      text: 'Even 15 minutes of bedtime reading fosters a lifelong love for language, expands vocabulary, and calms bedtime routines.'
    },
    {
      title: 'Point to Words as You Read',
      text: 'Running your finger under words helps emerging readers connect spoken sounds to written text and understand left-to-right flow.'
    },
    {
      title: 'Ask "What Happens Next?"',
      text: 'Pausing before turning a page encourages predictive thinking, narrative comprehension, and active storytelling participation.'
    }
  ],
  math: [
    {
      title: 'Count Objects in the Kitchen',
      text: 'Count fruit slices on snack plates, spoons in the drawer, or stairs climbed. Concrete tactile counting makes abstract numbers real.'
    },
    {
      title: 'Play With Patterns Everywhere',
      text: 'Look for patterns on tiles, clothing stripes, or rhythms clapped with hands. Pattern recognition is the foundation of algebraic thinking.'
    },
    {
      title: 'Normalize Making Mistakes',
      text: 'Mistakes are simply puzzle clues! Use phrases like "That is an interesting guess, let’s count them together and verify."'
    }
  ],
  screenTime: [
    {
      title: 'Co-Engagement Over Passive Watching',
      text: 'Interactive learning with parental conversation produces vastly higher retention than passive video streaming.'
    },
    {
      title: 'The 20-20-20 Rule for Eye Comfort',
      text: 'Every 20 minutes of screen activity, look at an object 20 feet away for 20 seconds to relax developing eye muscles.'
    },
    {
      title: 'Screen-Free Zones Before Bedtime',
      text: 'Turn off screens at least 45 minutes before sleep to let natural melatonin flow and ensure deep, restorative rest.'
    }
  ]
};
