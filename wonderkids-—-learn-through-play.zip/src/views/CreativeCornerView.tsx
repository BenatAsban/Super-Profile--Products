import React, { useRef, useState, useEffect } from 'react';
import { soundManager } from '../utils/audio';
import { 
  Palette, 
  Download, 
  Trash2, 
  RotateCcw, 
  Sparkles, 
  Star, 
  Paintbrush, 
  Eraser, 
  Stamp, 
  Heart, 
  Smile 
} from 'lucide-react';

interface CreativeCornerViewProps {
  onEarnStars: (amount: number, activityId: string) => void;
}

const COLOR_PALETTE = [
  '#ef4444', // Red
  '#f97316', // Orange
  '#f59e0b', // Amber
  '#eab308', // Yellow
  '#84cc16', // Lime
  '#10b981', // Emerald
  '#06b6d4', // Cyan
  '#3b82f6', // Blue
  '#8b5cf6', // Purple
  '#ec4899', // Pink
  '#78350f', // Brown
  '#0f172a'  // Slate / Black
];

const TEMPLATES = [
  { id: 'blank', label: 'Blank Page', icon: '📄' },
  { id: 'sun', label: 'Smiling Sun', icon: '☀️' },
  { id: 'dino', label: 'Baby Dinosaur', icon: '🦕' },
  { id: 'rocket', label: 'Space Rocket', icon: '🚀' },
  { id: 'butterfly', label: 'Spring Butterfly', icon: '🦋' }
];

export const CreativeCornerView: React.FC<CreativeCornerViewProps> = ({ onEarnStars }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<'brush' | 'eraser' | 'stamp'>('brush');
  const [selectedColor, setSelectedColor] = useState<string>('#ef4444');
  const [brushSize, setBrushSize] = useState<number>(8);
  const [selectedStamp, setSelectedStamp] = useState<string>('⭐');
  const [currentTemplate, setCurrentTemplate] = useState<string>('blank');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);

  // Initialize canvas with white background
  useEffect(() => {
    initCanvas();
  }, []);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill white
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // If template selected, draw outline
    if (currentTemplate !== 'blank') {
      drawTemplateOutline(ctx, currentTemplate, canvas.width, canvas.height);
    }
  };

  const drawTemplateOutline = (ctx: CanvasRenderingContext2D, templateId: string, w: number, h: number) => {
    ctx.save();
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const cx = w / 2;
    const cy = h / 2;

    if (templateId === 'sun') {
      // Big Sun circle
      ctx.beginPath();
      ctx.arc(cx, cy, 70, 0, Math.PI * 2);
      ctx.stroke();

      // Rays
      for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 6) {
        const x1 = cx + Math.cos(angle) * 85;
        const y1 = cy + Math.sin(angle) * 85;
        const x2 = cx + Math.cos(angle) * 115;
        const y2 = cy + Math.sin(angle) * 115;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }

      // Friendly smile face
      ctx.beginPath();
      ctx.arc(cx - 25, cy - 15, 6, 0, Math.PI * 2);
      ctx.arc(cx + 25, cy - 15, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#64748b';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(cx, cy + 10, 30, 0.2, Math.PI - 0.2);
      ctx.stroke();
    } else if (templateId === 'dino') {
      // Baby Dinosaur outline
      ctx.beginPath();
      // Body
      ctx.ellipse(cx, cy + 20, 90, 60, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Neck and head
      ctx.beginPath();
      ctx.moveTo(cx - 60, cy);
      ctx.quadraticCurveTo(cx - 80, cy - 60, cx - 60, cy - 90);
      ctx.quadraticCurveTo(cx - 20, cy - 100, cx - 10, cy - 70);
      ctx.quadraticCurveTo(cx - 30, cy - 50, cx - 30, cy);
      ctx.stroke();

      // Eye
      ctx.beginPath();
      ctx.arc(cx - 45, cy - 80, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#64748b';
      ctx.fill();

      // Feet
      ctx.beginPath();
      ctx.rect(cx - 40, cy + 70, 25, 35);
      ctx.rect(cx + 20, cy + 70, 25, 35);
      ctx.stroke();

      // Tail
      ctx.beginPath();
      ctx.moveTo(cx + 80, cy);
      ctx.quadraticCurveTo(cx + 140, cy - 20, cx + 150, cy - 60);
      ctx.quadraticCurveTo(cx + 120, cy + 10, cx + 70, cy + 30);
      ctx.stroke();
    } else if (templateId === 'rocket') {
      // Space Rocket
      ctx.beginPath();
      // Rocket Body
      ctx.moveTo(cx, cy - 120);
      ctx.quadraticCurveTo(cx + 45, cy - 30, cx + 45, cy + 60);
      ctx.lineTo(cx - 45, cy + 60);
      ctx.quadraticCurveTo(cx - 45, cy - 30, cx, cy - 120);
      ctx.stroke();

      // Window
      ctx.beginPath();
      ctx.arc(cx, cy - 30, 24, 0, Math.PI * 2);
      ctx.stroke();

      // Fins
      ctx.beginPath();
      ctx.moveTo(cx - 45, cy + 20);
      ctx.lineTo(cx - 85, cy + 70);
      ctx.lineTo(cx - 45, cy + 60);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(cx + 45, cy + 20);
      ctx.lineTo(cx + 85, cy + 70);
      ctx.lineTo(cx + 45, cy + 60);
      ctx.stroke();

      // Booster flame
      ctx.beginPath();
      ctx.moveTo(cx - 25, cy + 60);
      ctx.lineTo(cx, cy + 110);
      ctx.lineTo(cx + 25, cy + 60);
      ctx.stroke();
    } else if (templateId === 'butterfly') {
      // Butterfly
      ctx.beginPath();
      // Wings left
      ctx.ellipse(cx - 60, cy - 30, 50, 40, -Math.PI / 6, 0, Math.PI * 2);
      ctx.ellipse(cx - 50, cy + 40, 40, 30, Math.PI / 6, 0, Math.PI * 2);
      // Wings right
      ctx.ellipse(cx + 60, cy - 30, 50, 40, Math.PI / 6, 0, Math.PI * 2);
      ctx.ellipse(cx + 50, cy + 40, 40, 30, -Math.PI / 6, 0, Math.PI * 2);
      ctx.stroke();

      // Body
      ctx.beginPath();
      ctx.ellipse(cx, cy, 14, 60, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#cbd5e1';
      ctx.fill();
      ctx.stroke();

      // Antennae
      ctx.beginPath();
      ctx.moveTo(cx - 5, cy - 50);
      ctx.quadraticCurveTo(cx - 25, cy - 80, cx - 20, cy - 90);
      ctx.moveTo(cx + 5, cy - 50);
      ctx.quadraticCurveTo(cx + 25, cy - 80, cx + 20, cy - 90);
      ctx.stroke();
    }

    ctx.restore();
  };

  // Get pointer coordinates relative to canvas
  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    let clientX = 0;
    let clientY = 0;

    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);

    if (tool === 'stamp') {
      soundManager.playPop();
      ctx.font = `${brushSize * 4 + 20}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(selectedStamp, x, y);
      setHasDrawn(true);
      return;
    }

    setIsDrawing(true);
    setHasDrawn(true);

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = tool === 'eraser' ? '#FFFFFF' : selectedColor;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.closePath();
    }
  };

  const handleSelectTemplate = (templateId: string) => {
    soundManager.playPop();
    setCurrentTemplate(templateId);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (templateId !== 'blank') {
      drawTemplateOutline(ctx, templateId, canvas.width, canvas.height);
    }
  };

  const handleClearCanvas = () => {
    soundManager.playPop();
    handleSelectTemplate(currentTemplate);
    setShowClearConfirm(false);
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    soundManager.playTrophy();

    const link = document.createElement('a');
    link.download = `WonderKids_Art_${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();

    onEarnStars(3, 'creative_artwork_download');
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-rose-100 via-pink-50 to-amber-100 rounded-3xl p-6 sm:p-8 border-3 border-rose-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-200 text-rose-900 rounded-full text-xs font-bold font-heading mb-2">
            <Palette className="w-3.5 h-3.5" />
            Creative Art Studio
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-800 font-heading">
            Draw, Paint & Stamp!
          </h1>
          <p className="text-sm sm:text-base text-slate-600 font-medium max-w-xl mt-1">
            Pick cheerful colors, adjust brush size, color in original animal outlines, and save your masterpiece to your computer!
          </p>
        </div>

        <button
          onClick={handleDownload}
          className="px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-black rounded-2xl shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer font-heading text-sm"
        >
          <Download className="w-5 h-5" />
          <span>Save Masterpiece PNG</span>
        </button>
      </div>

      {/* Main Studio Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Toolbar */}
        <div className="lg:col-span-1 space-y-5">
          {/* Tool Picker */}
          <div className="bg-white rounded-3xl p-5 border-3 border-rose-200 shadow-xs space-y-3">
            <h3 className="font-extrabold text-slate-800 text-sm font-heading">
              Select Tool
            </h3>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  soundManager.playPop();
                  setTool('brush');
                }}
                className={`p-3 rounded-2xl border-2 flex flex-col items-center gap-1 transition-all cursor-pointer font-heading text-xs font-bold ${
                  tool === 'brush'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-rose-50 text-slate-700 border-slate-200'
                }`}
              >
                <Paintbrush className="w-5 h-5" />
                <span>Brush</span>
              </button>

              <button
                onClick={() => {
                  soundManager.playPop();
                  setTool('eraser');
                }}
                className={`p-3 rounded-2xl border-2 flex flex-col items-center gap-1 transition-all cursor-pointer font-heading text-xs font-bold ${
                  tool === 'eraser'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-rose-50 text-slate-700 border-slate-200'
                }`}
              >
                <Eraser className="w-5 h-5" />
                <span>Eraser</span>
              </button>

              <button
                onClick={() => {
                  soundManager.playPop();
                  setTool('stamp');
                }}
                className={`p-3 rounded-2xl border-2 flex flex-col items-center gap-1 transition-all cursor-pointer font-heading text-xs font-bold ${
                  tool === 'stamp'
                    ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 hover:bg-rose-50 text-slate-700 border-slate-200'
                }`}
              >
                <Stamp className="w-5 h-5" />
                <span>Stamp</span>
              </button>
            </div>

            {/* Brush Size Slider / Buttons */}
            <div className="pt-2">
              <div className="flex justify-between text-xs font-bold text-slate-600 mb-1.5 font-heading">
                <span>Brush Size</span>
                <span>{brushSize}px</span>
              </div>
              <div className="flex gap-2">
                {[4, 8, 16, 28].map(size => (
                  <button
                    key={size}
                    onClick={() => {
                      soundManager.playPop();
                      setBrushSize(size);
                    }}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border-2 transition-all cursor-pointer ${
                      brushSize === size
                        ? 'bg-amber-400 text-amber-950 border-amber-500'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {size <= 4 ? 'Fine' : size <= 8 ? 'Med' : size <= 16 ? 'Thick' : 'Jumbo'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Color Palette or Stamp Palette */}
          {tool === 'stamp' ? (
            <div className="bg-white rounded-3xl p-5 border-3 border-rose-200 shadow-xs space-y-3">
              <h3 className="font-extrabold text-slate-800 text-sm font-heading">
                Pick a Fun Stamp
              </h3>
              <div className="grid grid-cols-4 gap-2">
                {['⭐', '💖', '🌈', '🦕', '🚀', '🦋', '🌸', '🍎'].map(s => (
                  <button
                    key={s}
                    onClick={() => {
                      soundManager.playPop();
                      setSelectedStamp(s);
                    }}
                    className={`aspect-square rounded-2xl border-2 text-2xl flex items-center justify-center transition-all cursor-pointer ${
                      selectedStamp === s
                        ? 'bg-amber-100 border-amber-400 scale-105 ring-2 ring-amber-300'
                        : 'bg-slate-50 border-slate-200 hover:bg-amber-50'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl p-5 border-3 border-rose-200 shadow-xs space-y-3">
              <h3 className="font-extrabold text-slate-800 text-sm font-heading">
                Vibrant Colors
              </h3>
              <div className="grid grid-cols-4 gap-2.5">
                {COLOR_PALETTE.map(color => (
                  <button
                    key={color}
                    onClick={() => {
                      soundManager.playPop();
                      setSelectedColor(color);
                      if (tool === 'eraser') setTool('brush');
                    }}
                    style={{ backgroundColor: color }}
                    className={`w-full aspect-square rounded-2xl transition-all cursor-pointer shadow-xs ${
                      selectedColor === color && tool !== 'eraser'
                        ? 'ring-4 ring-offset-2 ring-rose-400 scale-110'
                        : 'hover:scale-105'
                    }`}
                    aria-label={`Select color ${color}`}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Outline Template selector */}
          <div className="bg-white rounded-3xl p-5 border-3 border-rose-200 shadow-xs space-y-2">
            <h3 className="font-extrabold text-slate-800 text-sm font-heading">
              Coloring Pages
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {TEMPLATES.map(tmpl => (
                <button
                  key={tmpl.id}
                  onClick={() => handleSelectTemplate(tmpl.id)}
                  className={`p-2 rounded-xl border-2 text-xs font-bold font-heading flex items-center gap-1.5 transition-all cursor-pointer ${
                    currentTemplate === tmpl.id
                      ? 'bg-rose-100 text-rose-900 border-rose-300'
                      : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                  }`}
                >
                  <span>{tmpl.icon}</span>
                  <span className="truncate">{tmpl.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Clear Canvas */}
          {showClearConfirm ? (
            <div className="p-3 bg-rose-50 border-2 border-rose-300 rounded-2xl text-xs space-y-2">
              <p className="font-bold text-rose-900">Erase whole page and start fresh?</p>
              <div className="flex gap-2">
                <button
                  onClick={handleClearCanvas}
                  className="px-3 py-1.5 bg-rose-600 text-white font-bold rounded-xl cursor-pointer"
                >
                  Yes, Clear
                </button>
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-3 py-1.5 bg-slate-200 text-slate-700 font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => {
                soundManager.playPop();
                setShowClearConfirm(true);
              }}
              className="w-full py-2.5 bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 rounded-2xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear Drawing Canvas</span>
            </button>
          )}
        </div>

        {/* Right Canvas Area */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-3xl p-4 sm:p-6 border-3 border-rose-200 shadow-md flex flex-col items-center">
            <div className="w-full flex items-center justify-between mb-3 text-xs text-slate-500">
              <span className="font-bold flex items-center gap-1 text-rose-700">
                <Sparkles className="w-4 h-4" />
                Touch or drag anywhere on the paper to draw!
              </span>
              <span className="hidden sm:inline">Canvas: 700 × 520 px</span>
            </div>

            {/* Real HTML5 Drawing Canvas */}
            <div className="w-full max-w-2xl bg-white rounded-2xl overflow-hidden border-4 border-dashed border-amber-300 shadow-inner touch-none relative">
              <canvas
                ref={canvasRef}
                width={700}
                height={520}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="w-full h-auto cursor-crosshair block select-none bg-white"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
