import React, { useState } from 'react';
import { ENGLISH_WORDS, SENTENCE_PUZZLES, SentencePuzzle } from '../data/englishWords';
import { EnglishWord } from '../types';
import { soundManager } from '../utils/audio';
import { 
  Languages, 
  Volume2, 
  Sparkles, 
  RotateCcw, 
  CheckCircle, 
  Layers, 
  HelpCircle, 
  Star, 
  ArrowRight 
} from 'lucide-react';

interface EnglishViewProps {
  onEarnStars: (amount: number, activityId: string) => void;
}

export const EnglishView: React.FC<EnglishViewProps> = ({ onEarnStars }) => {
  const [subTab, setSubTab] = useState<'vocab' | 'matching' | 'sentence'>('vocab');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Matching game state
  const [matchPairs, setMatchPairs] = useState(() => generateMatchGame());
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  const [selectedPicture, setSelectedPicture] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);

  // Sentence Builder state
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const currentPuzzle: SentencePuzzle = SENTENCE_PUZZLES[puzzleIndex];
  const [assembledWords, setAssembledWords] = useState<string[]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>(() => [...currentPuzzle.words]);
  const [sentenceFeedback, setSentenceFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);

  function generateMatchGame() {
    const subset = [...ENGLISH_WORDS].sort(() => Math.random() - 0.5).slice(0, 4);
    const wordsList = subset.map(w => ({ id: w.id, text: w.word })).sort(() => Math.random() - 0.5);
    const picsList = subset.map(w => ({ id: w.id, emoji: w.emoji, word: w.word })).sort(() => Math.random() - 0.5);
    return { words: wordsList, pics: picsList };
  }

  const filteredWords = selectedCategory === 'all'
    ? ENGLISH_WORDS
    : ENGLISH_WORDS.filter(w => w.category === selectedCategory);

  const handleSpeakWord = (w: EnglishWord) => {
    soundManager.playPop();
    soundManager.speakText(`${w.word}. ${w.sentence}`);
  };

  // Word-to-Picture match logic
  const handleWordSelect = (id: string) => {
    soundManager.playPop();
    if (selectedPicture) {
      checkMatch(id, selectedPicture);
    } else {
      setSelectedWord(id);
    }
  };

  const handlePicSelect = (id: string) => {
    soundManager.playPop();
    if (selectedWord) {
      checkMatch(selectedWord, id);
    } else {
      setSelectedPicture(id);
    }
  };

  const checkMatch = (wordId: string, picId: string) => {
    if (wordId === picId) {
      soundManager.playSuccess();
      const updated = [...matchedIds, wordId];
      setMatchedIds(updated);
      setSelectedWord(null);
      setSelectedPicture(null);

      if (updated.length === 4) {
        onEarnStars(3, 'english_vocab_match_won');
      }
    } else {
      soundManager.playGentleWrong();
      setSelectedWord(null);
      setSelectedPicture(null);
    }
  };

  const handleResetMatch = () => {
    soundManager.playPop();
    setMatchPairs(generateMatchGame());
    setMatchedIds([]);
    setSelectedWord(null);
    setSelectedPicture(null);
  };

  // Sentence Builder logic
  const handleAddWordToSentence = (word: string, indexInAvailable: number) => {
    soundManager.playPop();
    setAssembledWords(prev => [...prev, word]);
    setAvailableWords(prev => prev.filter((_, idx) => idx !== indexInAvailable));
    setSentenceFeedback(null);
  };

  const handleRemoveWordFromSentence = (word: string, indexInAssembled: number) => {
    soundManager.playPop();
    setAssembledWords(prev => prev.filter((_, idx) => idx !== indexInAssembled));
    setAvailableWords(prev => [...prev, word]);
    setSentenceFeedback(null);
  };

  const handleCheckSentence = () => {
    const formed = assembledWords.join(' ');
    if (formed.trim() === currentPuzzle.targetSentence.trim()) {
      soundManager.playSuccess();
      setSentenceFeedback({
        isCorrect: true,
        message: `Hooray! "${currentPuzzle.targetSentence}" is correct! ⭐`
      });
      soundManager.speakText(currentPuzzle.targetSentence);
      onEarnStars(2, `english_sentence_${currentPuzzle.id}`);
    } else {
      soundManager.playGentleWrong();
      setSentenceFeedback({
        isCorrect: false,
        message: 'Almost there! Check the order of words and try again.'
      });
      soundManager.speakText('Nice attempt! Try rearranging the words.');
    }
  };

  const handleNextSentence = () => {
    soundManager.playPop();
    const next = (puzzleIndex + 1) % SENTENCE_PUZZLES.length;
    setPuzzleIndex(next);
    const nextPuzzle = SENTENCE_PUZZLES[next];
    setAssembledWords([]);
    setAvailableWords([...nextPuzzle.words]);
    setSentenceFeedback(null);
  };

  const handleResetSentence = () => {
    soundManager.playPop();
    setAssembledWords([]);
    setAvailableWords([...currentPuzzle.words]);
    setSentenceFeedback(null);
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-100 via-teal-50 to-sky-100 rounded-3xl p-6 sm:p-8 border-3 border-emerald-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-200 text-emerald-900 rounded-full text-xs font-bold font-heading mb-2">
            <Languages className="w-3.5 h-3.5" />
            English Learning & Vocabulary
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-800 font-heading">
            Words & Sentence Fun
          </h1>
          <p className="text-sm sm:text-base text-slate-600 font-medium max-w-xl mt-1">
            Build everyday vocabulary, match words with colorful pictures, and assemble fun sentence puzzles!
          </p>
        </div>

        {/* Sub-Tab Navigation */}
        <div className="flex bg-white/90 p-1.5 rounded-2xl border-2 border-emerald-200 shadow-xs">
          <button
            onClick={() => {
              soundManager.playPop();
              setSubTab('vocab');
            }}
            className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              subTab === 'vocab'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-emerald-600'
            }`}
          >
            📚 Word Cards
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setSubTab('matching');
            }}
            className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              subTab === 'matching'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-emerald-600'
            }`}
          >
            🧩 Match Game
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setSubTab('sentence');
            }}
            className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              subTab === 'sentence'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-emerald-600'
            }`}
          >
            ✍️ Sentence Builder
          </button>
        </div>
      </div>

      {/* TAB 1: VOCABULARY EXPLORER */}
      {subTab === 'vocab' && (
        <div className="space-y-6">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: 'All Words' },
              { id: 'animals', label: '🐾 Animals' },
              { id: 'fruits', label: '🍓 Fruits & Food' },
              { id: 'colors', label: '🎨 Colors' },
              { id: 'shapes', label: '📐 Shapes' },
              { id: 'family', label: '👨‍👩‍👧 Family' },
              { id: 'home', label: '🏠 Home' },
              { id: 'actions', label: '🏃 Action Words' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  soundManager.playPop();
                  setSelectedCategory(cat.id);
                }}
                className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-600 text-white shadow-xs scale-105'
                    : 'bg-white hover:bg-emerald-50 text-slate-700 border-2 border-slate-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredWords.map(item => (
              <div
                key={item.id}
                className="bg-white rounded-3xl p-5 border-3 border-emerald-100 hover:border-emerald-300 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                      {item.emoji}
                    </div>
                    <button
                      onClick={() => handleSpeakWord(item)}
                      className="p-2.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl transition-colors cursor-pointer"
                      title="Listen to word and sentence"
                      aria-label={`Pronounce ${item.word}`}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>

                  <h3 className="text-xl font-black text-slate-800 font-heading">
                    {item.word}
                  </h3>
                  <p className="text-xs text-emerald-800 font-semibold mb-2">
                    {item.meaning}
                  </p>
                  <p className="text-xs sm:text-sm text-slate-600 italic bg-amber-50/60 p-2.5 rounded-xl border border-amber-200/60">
                    "{item.sentence}"
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: WORD TO PICTURE MATCHING */}
      {subTab === 'matching' && (
        <div className="max-w-2xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-emerald-200 shadow-md">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-800 font-heading">
                Match the Word to Its Picture
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Tap a word on the left, then tap the matching picture on the right!
              </p>
            </div>
            <button
              onClick={handleResetMatch}
              className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors cursor-pointer"
              title="Restart"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:gap-6 mb-6">
            {/* Words column */}
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider font-heading">Words</span>
              {matchPairs.words.map(w => {
                const isMatched = matchedIds.includes(w.id);
                const isSelected = selectedWord === w.id;
                return (
                  <button
                    key={w.id}
                    onClick={() => handleWordSelect(w.id)}
                    disabled={isMatched}
                    className={`w-full py-4 px-4 rounded-2xl border-3 text-base sm:text-lg font-black font-heading transition-all cursor-pointer shadow-xs text-center ${
                      isMatched
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 opacity-60'
                        : isSelected
                        ? 'bg-emerald-500 text-white border-emerald-600 scale-102 ring-2 ring-emerald-300'
                        : 'bg-slate-50 hover:bg-emerald-50 border-slate-200 hover:border-emerald-300 text-slate-800'
                    }`}
                  >
                    {w.text}
                  </button>
                );
              })}
            </div>

            {/* Pictures column */}
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider font-heading">Pictures</span>
              {matchPairs.pics.map(p => {
                const isMatched = matchedIds.includes(p.id);
                const isSelected = selectedPicture === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => handlePicSelect(p.id)}
                    disabled={isMatched}
                    className={`w-full py-3.5 px-4 rounded-2xl border-3 text-3xl font-heading transition-all cursor-pointer shadow-xs text-center flex items-center justify-center ${
                      isMatched
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 opacity-60'
                        : isSelected
                        ? 'bg-amber-300 border-amber-500 scale-102 ring-2 ring-amber-300'
                        : 'bg-slate-50 hover:bg-amber-50 border-slate-200 hover:border-amber-300'
                    }`}
                  >
                    {p.emoji}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between bg-emerald-50 p-4 rounded-2xl border border-emerald-200">
            <div className="text-sm font-bold text-emerald-900 font-heading">
              Matched: {matchedIds.length} / 4
            </div>
            {matchedIds.length === 4 && (
              <div className="text-emerald-700 font-black text-sm flex items-center gap-1.5 animate-bounce-gentle">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                All matched! +3 Stars!
              </div>
            )}
            <button
              onClick={handleResetMatch}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all font-heading cursor-pointer"
            >
              Play Another Set
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: SENTENCE BUILDER */}
      {subTab === 'sentence' && (
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-emerald-200 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider font-heading">
              Sentence Puzzle {puzzleIndex + 1} of {SENTENCE_PUZZLES.length}
            </span>
            <button
              onClick={handleResetSentence}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              title="Reset current sentence"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Hint and emoji */}
          <div className="text-center mb-6">
            <div className="w-20 h-20 mx-auto rounded-2xl bg-amber-100 border-2 border-amber-300 flex items-center justify-center text-4xl mb-3 shadow-inner">
              {currentPuzzle.emoji}
            </div>
            <div className="inline-block px-3 py-1 bg-sky-50 text-sky-800 rounded-full text-xs font-bold border border-sky-200">
              💡 Hint: {currentPuzzle.hint}
            </div>
          </div>

          {/* Sentence Assembly Slot */}
          <div className="min-h-20 p-4 bg-slate-50 border-3 border-dashed border-slate-300 rounded-2xl flex flex-wrap items-center justify-center gap-2 mb-6">
            {assembledWords.length === 0 ? (
              <span className="text-xs sm:text-sm text-slate-400 font-semibold italic">
                Tap words below to arrange your sentence here!
              </span>
            ) : (
              assembledWords.map((word, idx) => (
                <button
                  key={idx}
                  onClick={() => handleRemoveWordFromSentence(word, idx)}
                  className="px-4 py-2 bg-emerald-500 hover:bg-rose-500 text-white font-black text-sm rounded-xl shadow-xs transition-colors cursor-pointer font-heading"
                  title="Click to remove"
                >
                  {word}
                </button>
              ))
            )}
          </div>

          {/* Available Word Bank */}
          <div className="flex flex-wrap justify-center gap-2 mb-6">
            {availableWords.map((word, idx) => (
              <button
                key={idx}
                onClick={() => handleAddWordToSentence(word, idx)}
                className="px-4 py-2.5 bg-amber-100 hover:bg-amber-200 text-amber-950 font-black text-sm rounded-xl border-2 border-amber-300 shadow-xs active:scale-95 transition-all cursor-pointer font-heading"
              >
                {word}
              </button>
            ))}
          </div>

          {/* Feedback */}
          {sentenceFeedback && (
            <div
              className={`p-3.5 rounded-2xl border-2 text-center text-sm font-bold mb-6 animate-fadeIn ${
                sentenceFeedback.isCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-rose-50 border-rose-300 text-rose-800'
              }`}
            >
              {sentenceFeedback.message}
            </div>
          )}

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleCheckSentence}
              disabled={assembledWords.length === 0}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black rounded-2xl shadow-md transition-all font-heading text-sm cursor-pointer"
            >
              Check My Sentence ⭐
            </button>

            {sentenceFeedback?.isCorrect && (
              <button
                onClick={handleNextSentence}
                className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-black rounded-2xl shadow-md transition-all font-heading text-sm cursor-pointer flex items-center gap-1"
              >
                <span>Next</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
