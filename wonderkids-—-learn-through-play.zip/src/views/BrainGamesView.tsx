import React, { useState } from 'react';
import { soundManager } from '../utils/audio';
import { 
  Gamepad2, 
  RotateCcw, 
  Sparkles, 
  Trophy, 
  Star, 
  HelpCircle, 
  CheckCircle2, 
  ArrowRight 
} from 'lucide-react';

interface BrainGamesViewProps {
  onEarnStars: (amount: number, activityId: string) => void;
}

type BrainGameMode = 'memory' | 'odd-one' | 'pattern' | 'puzzle' | 'quick-quiz';

// Memory match cards
const MEMORY_EMOJIS = ['🐶', '🐱', '🐼', '🦁', '🐰', '🦊'];

// Odd one out questions
const ODD_ONE_DATA = [
  {
    items: ['🍎', '🍌', '🥕', '🍓'],
    oddIndex: 2,
    explanation: 'The carrot is a crunchy vegetable that grows underground, while apple, banana, and strawberry are sweet fruits that grow on plants or trees!'
  },
  {
    items: ['🚗', '🚌', '✈️', '🚲'],
    oddIndex: 2,
    explanation: 'The airplane flies high through the clouds in the sky, while the car, bus, and bicycle travel on the ground!'
  },
  {
    items: ['🐶', '🐱', '🦁', '🐠'],
    oddIndex: 3,
    explanation: 'The fish lives and swims underwater with gills, while the puppy, kitten, and lion are mammals living on land!'
  },
  {
    items: ['☀️', '⭐', '🌧️', '🪐'],
    oddIndex: 2,
    explanation: 'Rain is weather that happens in Earth’s atmosphere, while the Sun, stars, and planets are celestial bodies out in space!'
  }
];

// Pattern questions
const PATTERN_DATA = [
  {
    sequence: ['🟡', '🟦', '🟡', '🟦'],
    options: ['🟡', '🟦', '🔺', '🟩'],
    correct: '🟡',
    explanation: 'The pattern alternates: Yellow circle, Blue square, Yellow circle, Blue square, so next is Yellow circle!'
  },
  {
    sequence: ['🍎', '🍎', '🍌', '🍎', '🍎'],
    options: ['🍌', '🍎', '🍓', '🥕'],
    correct: '🍌',
    explanation: 'Two apples, then one banana! So after two apples comes another banana!'
  },
  {
    sequence: ['2', '4', '6', '8'],
    options: ['9', '10', '12', '14'],
    correct: '10',
    explanation: 'Counting by twos: 2, 4, 6, 8, 10! You add 2 each time!'
  },
  {
    sequence: ['⭐', '💖', '⭐', '💖'],
    options: ['⭐', '💖', '🌸', '🎈'],
    correct: '⭐',
    explanation: 'Star, Heart, Star, Heart... the next one is Star!'
  }
];

// Quick quiz bank
const QUICK_QUIZ_BANK = [
  {
    question: 'How many days are in one week?',
    options: ['5 days', '7 days', '10 days', '12 days'],
    correct: 1,
    explanation: 'There are 7 days: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, and Sunday!'
  },
  {
    question: 'What do bees make that tastes sweet and golden?',
    options: ['Honey', 'Milk', 'Juice', 'Chocolate'],
    correct: 0,
    explanation: 'Busy bees gather nectar from flowers to make delicious honey!'
  },
  {
    question: 'Which shape has exactly 3 sides and 3 corners?',
    options: ['Square', 'Circle', 'Triangle', 'Rectangle'],
    correct: 2,
    explanation: 'A triangle always has 3 sides and 3 corners!'
  },
  {
    question: 'What color do you get when you mix blue and yellow paint?',
    options: ['Red', 'Green', 'Purple', 'Orange'],
    correct: 1,
    explanation: 'Mixing blue and yellow makes fresh vibrant green!'
  },
  {
    question: 'Which giant planet has colorful rings of ice around it?',
    options: ['Mars', 'Saturn', 'Earth', 'Venus'],
    correct: 1,
    explanation: 'Saturn is surrounded by magnificent rings made of icy particles!'
  }
];

export const BrainGamesView: React.FC<BrainGamesViewProps> = ({ onEarnStars }) => {
  const [activeGame, setActiveGame] = useState<BrainGameMode>('memory');

  // GAME A: Memory Match State
  const [memoryCards, setMemoryCards] = useState(() => initMemoryCards());
  const [memoryFlipped, setMemoryFlipped] = useState<number[]>([]);
  const [memoryMoves, setMemoryMoves] = useState(0);
  const [memoryPairsFound, setMemoryPairsFound] = useState(0);

  function initMemoryCards() {
    const deck = [...MEMORY_EMOJIS, ...MEMORY_EMOJIS]
      .sort(() => Math.random() - 0.5)
      .map((emoji, idx) => ({ id: idx, emoji, isFlipped: false, isMatched: false }));
    return deck;
  }

  const handleMemoryFlip = (idx: number) => {
    if (memoryFlipped.length === 2 || memoryCards[idx].isMatched || memoryCards[idx].isFlipped) {
      return;
    }
    soundManager.playPop();

    const newCards = [...memoryCards];
    newCards[idx].isFlipped = true;
    setMemoryCards(newCards);

    const newFlipped = [...memoryFlipped, idx];
    setMemoryFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setMemoryMoves(prev => prev + 1);
      const [firstIdx, secondIdx] = newFlipped;
      if (newCards[firstIdx].emoji === newCards[secondIdx].emoji) {
        // Matched!
        setTimeout(() => {
          soundManager.playSuccess();
          newCards[firstIdx].isMatched = true;
          newCards[secondIdx].isMatched = true;
          setMemoryCards([...newCards]);
          setMemoryFlipped([]);
          const newPairs = memoryPairsFound + 1;
          setMemoryPairsFound(newPairs);
          if (newPairs === MEMORY_EMOJIS.length) {
            onEarnStars(5, 'brain_memory_win');
          }
        }, 400);
      } else {
        // Not matched
        setTimeout(() => {
          soundManager.playGentleWrong();
          newCards[firstIdx].isFlipped = false;
          newCards[secondIdx].isFlipped = false;
          setMemoryCards([...newCards]);
          setMemoryFlipped([]);
        }, 900);
      }
    }
  };

  const handleResetMemory = () => {
    soundManager.playPop();
    setMemoryCards(initMemoryCards());
    setMemoryFlipped([]);
    setMemoryMoves(0);
    setMemoryPairsFound(0);
  };

  // GAME B: Odd One Out State
  const [oddIdx, setOddIdx] = useState(0);
  const [oddSelected, setOddSelected] = useState<number | null>(null);
  const [oddFeedback, setOddFeedback] = useState<{ isCorrect: boolean; text: string } | null>(null);

  const currentOdd = ODD_ONE_DATA[oddIdx];

  const handleOddPick = (itemIndex: number) => {
    if (oddFeedback !== null) return;
    setOddSelected(itemIndex);
    const isCorrect = itemIndex === currentOdd.oddIndex;
    if (isCorrect) {
      soundManager.playSuccess();
      setOddFeedback({
        isCorrect: true,
        text: `Spot on! ${currentOdd.explanation} ⭐`
      });
      soundManager.speakText(`Great job! ${currentOdd.explanation}`);
      onEarnStars(2, `brain_odd_${oddIdx}`);
    } else {
      soundManager.playGentleWrong();
      setOddFeedback({
        isCorrect: false,
        text: `Not quite! ${currentOdd.explanation}`
      });
      soundManager.speakText(`Good try! ${currentOdd.explanation}`);
    }
  };

  const handleNextOdd = () => {
    soundManager.playPop();
    setOddIdx((prev) => (prev + 1) % ODD_ONE_DATA.length);
    setOddSelected(null);
    setOddFeedback(null);
  };

  // GAME C: Pattern Detective State
  const [patternIdx, setPatternIdx] = useState(0);
  const [patternChoice, setPatternChoice] = useState<string | null>(null);
  const [patternFeedback, setPatternFeedback] = useState<{ isCorrect: boolean; text: string } | null>(null);

  const currentPattern = PATTERN_DATA[patternIdx];

  const handlePatternSelect = (opt: string) => {
    if (patternFeedback !== null) return;
    setPatternChoice(opt);
    const isCorrect = opt === currentPattern.correct;
    if (isCorrect) {
      soundManager.playSuccess();
      setPatternFeedback({
        isCorrect: true,
        text: `Brilliant detective work! ${currentPattern.explanation} ⭐`
      });
      soundManager.speakText(`Correct! ${currentPattern.explanation}`);
      onEarnStars(2, `brain_pattern_${patternIdx}`);
    } else {
      soundManager.playGentleWrong();
      setPatternFeedback({
        isCorrect: false,
        text: `Almost! ${currentPattern.explanation}`
      });
      soundManager.speakText(`Nice try! ${currentPattern.explanation}`);
    }
  };

  const handleNextPattern = () => {
    soundManager.playPop();
    setPatternIdx((prev) => (prev + 1) % PATTERN_DATA.length);
    setPatternChoice(null);
    setPatternFeedback(null);
  };

  // GAME D: Picture Puzzle (3x3 grid tile swap puzzle)
  // Target: [1,2,3,4,5,6,7,8,9]
  const TARGET_TILES = ['🦁', '🐯', '🐻', '🐼', '🐨', '🦊', '🐰', '🐸', '🐵'];
  const [puzzleTiles, setPuzzleTiles] = useState<string[]>(() => {
    return [...TARGET_TILES].sort(() => Math.random() - 0.5);
  });
  const [puzzleSelectedIdx, setPuzzleSelectedIdx] = useState<number | null>(null);
  const [puzzleWon, setPuzzleWon] = useState(false);

  const handleTileClick = (idx: number) => {
    if (puzzleWon) return;
    soundManager.playPop();
    if (puzzleSelectedIdx === null) {
      setPuzzleSelectedIdx(idx);
    } else {
      // Swap tiles
      const nextTiles = [...puzzleTiles];
      const temp = nextTiles[puzzleSelectedIdx];
      nextTiles[puzzleSelectedIdx] = nextTiles[idx];
      nextTiles[idx] = temp;
      setPuzzleTiles(nextTiles);
      setPuzzleSelectedIdx(null);

      // Check win
      const isComplete = nextTiles.every((t, i) => t === TARGET_TILES[i]);
      if (isComplete) {
        soundManager.playTrophy();
        setPuzzleWon(true);
        onEarnStars(5, 'brain_puzzle_solved');
      }
    }
  };

  const handleResetPuzzle = () => {
    soundManager.playPop();
    setPuzzleTiles([...TARGET_TILES].sort(() => Math.random() - 0.5));
    setPuzzleSelectedIdx(null);
    setPuzzleWon(false);
  };

  // GAME E: Quick Quiz State
  const [qqIdx, setQqIdx] = useState(0);
  const [qqAnswers, setQqAnswers] = useState<Record<number, number>>({});
  const [qqFeedback, setQqFeedback] = useState<string | null>(null);
  const [qqScore, setQqScore] = useState(0);

  const currentQq = QUICK_QUIZ_BANK[qqIdx];

  const handleQqAnswer = (optIdx: number) => {
    if (qqFeedback !== null) return;
    const isCorrect = optIdx === currentQq.correct;
    setQqAnswers(prev => ({ ...prev, [qqIdx]: optIdx }));

    if (isCorrect) {
      soundManager.playSuccess();
      setQqScore(prev => prev + 1);
      setQqFeedback(`Spot on! ${currentQq.explanation} ⭐`);
      onEarnStars(1, `quick_quiz_q${qqIdx}`);
    } else {
      soundManager.playGentleWrong();
      setQqFeedback(`Good try! ${currentQq.explanation}`);
    }
  };

  const handleNextQq = () => {
    soundManager.playPop();
    setQqFeedback(null);
    if (qqIdx < QUICK_QUIZ_BANK.length - 1) {
      setQqIdx(prev => prev + 1);
    }
  };

  const handleResetQq = () => {
    soundManager.playPop();
    setQqIdx(0);
    setQqAnswers({});
    setQqScore(0);
    setQqFeedback(null);
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-100 via-orange-50 to-yellow-100 rounded-3xl p-6 sm:p-8 border-3 border-amber-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-200 text-amber-950 rounded-full text-xs font-bold font-heading mb-2">
            <Gamepad2 className="w-3.5 h-3.5" />
            Brain Gym & Logic Games
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-800 font-heading">
            Play & Train Your Mind!
          </h1>
          <p className="text-sm sm:text-base text-slate-600 font-medium max-w-xl mt-1">
            Enjoy 5 real, interactive games: Memory Match, Odd One Out, Pattern Detective, Picture Puzzle, and Quick Quiz!
          </p>
        </div>
      </div>

      {/* Game Selector Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {[
          { id: 'memory', label: '🃏 Memory Match' },
          { id: 'odd-one', label: '🔍 Odd One Out' },
          { id: 'pattern', label: '🧩 Pattern Detective' },
          { id: 'puzzle', label: '🖼️ Picture Puzzle' },
          { id: 'quick-quiz', label: '⚡ Quick Quiz' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => {
              soundManager.playPop();
              setActiveGame(tab.id as BrainGameMode);
            }}
            className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold font-heading transition-all whitespace-nowrap cursor-pointer flex-shrink-0 ${
              activeGame === tab.id
                ? 'bg-amber-500 text-amber-950 border-2 border-amber-600 shadow-sm scale-102 font-black'
                : 'bg-white hover:bg-amber-50 text-slate-700 border-2 border-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* GAME 1: MEMORY MATCH */}
      {activeGame === 'memory' && (
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-amber-200 shadow-md">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-800 font-heading">
                Card Memory Match
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Flip two cards at a time to find all 6 animal twins!
              </p>
            </div>
            <button
              onClick={handleResetMemory}
              className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors cursor-pointer"
              title="Restart game"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          {/* Cards Grid: 3x4 = 12 cards */}
          <div className="grid grid-cols-4 gap-3 mb-6">
            {memoryCards.map((card, idx) => {
              const isVisible = card.isFlipped || card.isMatched;
              return (
                <button
                  key={card.id}
                  onClick={() => handleMemoryFlip(idx)}
                  disabled={card.isMatched}
                  className={`aspect-square rounded-2xl border-3 text-3xl sm:text-4xl font-heading flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                    card.isMatched
                      ? 'bg-emerald-100 border-emerald-300 text-emerald-800 opacity-70'
                      : isVisible
                      ? 'bg-amber-100 border-amber-400 rotate-y-180 scale-102'
                      : 'bg-gradient-to-br from-indigo-300 to-purple-400 border-indigo-400 text-white hover:scale-102'
                  }`}
                >
                  {isVisible ? card.emoji : '🌟'}
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between bg-amber-50 p-4 rounded-2xl border border-amber-200 text-xs sm:text-sm">
            <span className="font-bold text-amber-900">Moves: {memoryMoves}</span>
            <span className="font-black text-amber-950 font-heading">
              Pairs: {memoryPairsFound} / {MEMORY_EMOJIS.length}
            </span>
            {memoryPairsFound === MEMORY_EMOJIS.length && (
              <span className="text-emerald-700 font-black animate-bounce-gentle">
                🎉 All Found! +5 Stars!
              </span>
            )}
          </div>
        </div>
      )}

      {/* GAME 2: ODD ONE OUT */}
      {activeGame === 'odd-one' && (
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-amber-200 shadow-md text-center">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider font-heading">
              Puzzle {oddIdx + 1} of {ODD_ONE_DATA.length}
            </span>
            <button
              onClick={handleNextOdd}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
            >
              <span>Skip / Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-slate-800 font-heading mb-2">
            Spot the Odd One Out!
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-6">
            One of these four items is different from the rest. Can you find it?
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
            {currentOdd.items.map((emoji, idx) => {
              const isSelected = oddSelected === idx;
              const isCorrect = idx === currentOdd.oddIndex;

              let style = 'bg-slate-50 hover:bg-amber-50 border-slate-200 hover:border-amber-300';
              if (oddFeedback !== null) {
                if (isCorrect) {
                  style = 'bg-emerald-500 text-white border-emerald-600 scale-105';
                } else if (isSelected && !isCorrect) {
                  style = 'bg-rose-100 border-rose-300 text-rose-800';
                } else {
                  style = 'bg-slate-50 border-slate-200 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleOddPick(idx)}
                  disabled={oddFeedback !== null}
                  className={`aspect-square rounded-2xl border-3 text-4xl sm:text-5xl flex items-center justify-center transition-all cursor-pointer shadow-xs active:scale-95 ${style}`}
                >
                  {emoji}
                </button>
              );
            })}
          </div>

          {oddFeedback && (
            <div
              className={`p-4 rounded-2xl border-2 mb-6 text-xs sm:text-sm font-bold text-left animate-fadeIn ${
                oddFeedback.isCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-amber-50 border-amber-300 text-amber-900'
              }`}
            >
              {oddFeedback.text}
            </div>
          )}

          {oddFeedback && (
            <button
              onClick={handleNextOdd}
              className="px-8 py-3 bg-amber-500 hover:bg-amber-600 text-amber-950 font-black text-sm rounded-2xl shadow-md transition-all font-heading cursor-pointer"
            >
              Try Next Puzzle →
            </button>
          )}
        </div>
      )}

      {/* GAME 3: PATTERN DETECTIVE */}
      {activeGame === 'pattern' && (
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-amber-200 shadow-md text-center">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider font-heading">
              Pattern {patternIdx + 1} of {PATTERN_DATA.length}
            </span>
            <button
              onClick={handleNextPattern}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-slate-800 font-heading mb-2">
            What Comes Next in the Pattern?
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mb-6">
            Study the sequence carefully and choose the missing piece!
          </p>

          {/* Sequence Display */}
          <div className="flex items-center justify-center gap-3 p-4 bg-amber-50/70 rounded-2xl border-2 border-amber-200 mb-6 flex-wrap">
            {currentPattern.sequence.map((item, idx) => (
              <div
                key={idx}
                className="w-14 h-14 rounded-2xl bg-white border-2 border-amber-300 flex items-center justify-center text-3xl font-black font-heading shadow-xs"
              >
                {item}
              </div>
            ))}
            <div className="w-14 h-14 rounded-2xl bg-amber-200 border-2 border-dashed border-amber-400 flex items-center justify-center text-2xl font-black font-heading text-amber-900 animate-pulse-subtle">
              ?
            </div>
          </div>

          {/* Options */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            {currentPattern.options.map((opt, idx) => {
              const isChosen = patternChoice === opt;
              const isCorrect = opt === currentPattern.correct;

              let style = 'bg-slate-50 hover:bg-amber-50 border-slate-200 hover:border-amber-300 text-slate-800';
              if (patternFeedback !== null) {
                if (isCorrect) {
                  style = 'bg-emerald-500 text-white border-emerald-600 scale-105';
                } else if (isChosen && !isCorrect) {
                  style = 'bg-rose-100 border-rose-300 text-rose-800';
                } else {
                  style = 'bg-slate-50 border-slate-200 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handlePatternSelect(opt)}
                  disabled={patternFeedback !== null}
                  className={`py-3.5 rounded-2xl border-3 text-3xl font-black font-heading flex items-center justify-center transition-all cursor-pointer shadow-xs active:scale-95 ${style}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>

          {patternFeedback && (
            <div
              className={`p-4 rounded-2xl border-2 mb-6 text-xs sm:text-sm font-bold text-left animate-fadeIn ${
                patternFeedback.isCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-amber-50 border-amber-300 text-amber-900'
              }`}
            >
              {patternFeedback.text}
            </div>
          )}

          {patternFeedback && (
            <button
              onClick={handleNextPattern}
              className="px-8 py-3 bg-amber-500 hover:bg-amber-600 text-amber-950 font-black text-sm rounded-2xl shadow-md transition-all font-heading cursor-pointer"
            >
              Next Pattern Detective →
            </button>
          )}
        </div>
      )}

      {/* GAME 4: PICTURE PUZZLE */}
      {activeGame === 'puzzle' && (
        <div className="max-w-md mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-amber-200 shadow-md text-center">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
            <div>
              <h2 className="text-xl font-black text-slate-800 font-heading">
                Animal Safari Tile Puzzle
              </h2>
              <p className="text-xs text-slate-500">
                Tap one animal tile, then tap another to swap them into the right picture!
              </p>
            </div>
            <button
              onClick={handleResetPuzzle}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              title="Shuffle tiles"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          {/* 3x3 Tile Grid */}
          <div className="grid grid-cols-3 gap-3 p-4 bg-amber-50/70 rounded-3xl border-2 border-amber-200 mb-6">
            {puzzleTiles.map((tile, idx) => {
              const isSelected = puzzleSelectedIdx === idx;
              const isInPlace = tile === TARGET_TILES[idx];
              return (
                <button
                  key={idx}
                  onClick={() => handleTileClick(idx)}
                  className={`aspect-square rounded-2xl border-3 text-4xl flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                    isSelected
                      ? 'bg-amber-300 border-amber-500 scale-105 ring-4 ring-amber-300'
                      : isInPlace
                      ? 'bg-emerald-50 border-emerald-300'
                      : 'bg-white hover:bg-amber-100 border-slate-200'
                  }`}
                >
                  {tile}
                </button>
              );
            })}
          </div>

          {/* Target Hint Row */}
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 mb-4">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide block mb-1">
              Target Safari Order:
            </span>
            <div className="flex justify-center gap-1.5 text-lg">
              {TARGET_TILES.map((t, i) => (
                <span key={i}>{t}</span>
              ))}
            </div>
          </div>

          {puzzleWon ? (
            <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-2xl text-emerald-800 font-black text-sm animate-bounce-gentle">
              🏆 Masterpiece Puzzle Solved! You earned +5 Stars!
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic">
              Tiles in the correct position show a subtle green border!
            </p>
          )}
        </div>
      )}

      {/* GAME 5: QUICK QUIZ */}
      {activeGame === 'quick-quiz' && (
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-amber-200 shadow-md text-center">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider font-heading">
              Quick Quiz {qqIdx + 1} of {QUICK_QUIZ_BANK.length}
            </span>
            <span className="px-3 py-1 bg-amber-100 text-amber-900 rounded-full text-xs font-bold flex items-center gap-1 font-heading">
              <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              Score: {qqScore}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-slate-800 font-heading mb-6">
            {currentQq.question}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {currentQq.options.map((opt, idx) => {
              const isChosen = qqAnswers[qqIdx] === idx;
              const isCorrect = idx === currentQq.correct;

              let style = 'bg-slate-50 hover:bg-amber-50 border-slate-200 hover:border-amber-300 text-slate-800';
              if (qqFeedback !== null) {
                if (isCorrect) {
                  style = 'bg-emerald-500 text-white border-emerald-600 scale-102';
                } else if (isChosen && !isCorrect) {
                  style = 'bg-rose-100 border-rose-300 text-rose-800';
                } else {
                  style = 'bg-slate-50 border-slate-200 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleQqAnswer(idx)}
                  disabled={qqFeedback !== null}
                  className={`p-4 rounded-2xl border-3 text-base font-bold font-heading transition-all cursor-pointer shadow-xs active:scale-95 text-center ${style}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>

          {qqFeedback && (
            <div
              className={`p-3.5 rounded-2xl border-2 mb-6 text-xs sm:text-sm font-bold text-left animate-fadeIn ${
                qqAnswers[qqIdx] === currentQq.correct
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-amber-50 border-amber-300 text-amber-900'
              }`}
            >
              {qqFeedback}
            </div>
          )}

          {qqFeedback && (
            qqIdx < QUICK_QUIZ_BANK.length - 1 ? (
              <button
                onClick={handleNextQq}
                className="px-8 py-3 bg-amber-500 hover:bg-amber-600 text-amber-950 font-black text-sm rounded-2xl shadow-md transition-all font-heading cursor-pointer"
              >
                Next Quiz Question →
              </button>
            ) : (
              <div className="space-y-3">
                <div className="text-base font-black text-slate-800 font-heading">
                  Quiz Finished! You scored {qqScore} / {QUICK_QUIZ_BANK.length}! 🏆
                </div>
                <button
                  onClick={handleResetQq}
                  className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-amber-950 font-bold rounded-2xl transition-all font-heading cursor-pointer"
                >
                  Play Quiz Again
                </button>
              </div>
            )
          )}
        </div>
      )}
    </div>
  );
};
