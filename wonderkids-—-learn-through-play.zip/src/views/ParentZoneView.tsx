import React, { useState } from 'react';
import { AGE_GUIDES, PARENTING_TIPS } from '../data/parentTips';
import { soundManager } from '../utils/audio';
import { 
  Users, 
  ShieldCheck, 
  BookOpen, 
  Calculator, 
  Monitor, 
  Heart, 
  RotateCcw, 
  AlertTriangle, 
  CheckCircle2, 
  Info 
} from 'lucide-react';

interface ParentZoneViewProps {
  onResetProgress: () => void;
}

export const ParentZoneView: React.FC<ParentZoneViewProps> = ({ onResetProgress }) => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetSuccessMessage, setResetSuccessMessage] = useState(false);

  const handleConfirmReset = () => {
    soundManager.playPop();
    onResetProgress();
    setShowResetConfirm(false);
    setResetSuccessMessage(true);
    setTimeout(() => setResetSuccessMessage(false), 4000);
  };

  return (
    <div className="space-y-10 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-100 via-sky-50 to-emerald-100 rounded-3xl p-6 sm:p-8 border-3 border-teal-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-teal-200 text-teal-900 rounded-full text-xs font-bold font-heading mb-2">
            <Users className="w-3.5 h-3.5" />
            Caregiver & Educator Guide
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-800 font-heading">
            Parent Zone & Learning Insights
          </h1>
          <p className="text-sm sm:text-base text-slate-600 font-medium max-w-2xl mt-1">
            Practical pedagogical advice, screen-time balance strategies, and developmental milestones to empower your child's learning journey at home.
          </p>
        </div>

        <div className="flex items-center gap-2 p-3 bg-white/90 rounded-2xl border-2 border-teal-200 shadow-xs text-xs font-bold text-teal-900">
          <ShieldCheck className="w-5 h-5 text-teal-600 flex-shrink-0" />
          <span>No Ads • No Trackers • Browser Offline</span>
        </div>
      </div>

      {/* Section 1: Learning Stages by Age Group */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🌱</span>
          <h2 className="text-2xl font-black text-slate-800 font-heading">
            Recommended Pathways by Age Group
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {AGE_GUIDES.map(guide => (
            <div
              key={guide.ageGroup}
              className="bg-white rounded-3xl p-6 border-3 border-slate-200 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-3xl">{guide.icon}</span>
                  <span className="text-xs font-black px-3 py-1 rounded-full bg-teal-100 text-teal-800 font-heading">
                    {guide.ageGroup}
                  </span>
                </div>

                <h3 className="text-lg font-black text-slate-800 font-heading mb-3">
                  {guide.stage}
                </h3>

                <div className="space-y-1.5 mb-4">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide">Key Focus Areas:</span>
                  <ul className="space-y-1 text-xs text-slate-600">
                    {guide.focusAreas.map((f, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-teal-600 font-bold">•</span>
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 bg-teal-50/70 rounded-2xl border border-teal-100 text-xs text-teal-950 mb-4">
                  <strong>Coaching Tip:</strong> {guide.parentCoachingTip}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500">
                <strong>Best sections:</strong> {guide.recommendedSections.join(', ')}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Section 2: Practical Tips (Reading, Math, Screen Time) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Early Reading */}
        <div className="bg-white rounded-3xl p-6 border-3 border-pink-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-pink-600" />
            <h3 className="text-lg font-black text-slate-800 font-heading">
              Early Reading Habits
            </h3>
          </div>
          <div className="space-y-3">
            {PARENTING_TIPS.reading.map((tip, idx) => (
              <div key={idx} className="p-3 bg-pink-50/60 rounded-xl border border-pink-100">
                <h4 className="text-xs font-bold text-pink-900 font-heading mb-1">{tip.title}</h4>
                <p className="text-xs text-slate-600 leading-relaxed">{tip.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Math Mindset */}
        <div className="bg-white rounded-3xl p-6 border-3 border-sky-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-sky-600" />
            <h3 className="text-lg font-black text-slate-800 font-heading">
              Fun Math at Home
            </h3>
          </div>
          <div className="space-y-3">
            {PARENTING_TIPS.math.map((tip, idx) => (
              <div key={idx} className="p-3 bg-sky-50/60 rounded-xl border border-sky-100">
                <h4 className="text-xs font-bold text-sky-900 font-heading mb-1">{tip.title}</h4>
                <p className="text-xs text-slate-600 leading-relaxed">{tip.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Screen Time Guidelines */}
        <div className="bg-white rounded-3xl p-6 border-3 border-purple-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Monitor className="w-5 h-5 text-purple-600" />
            <h3 className="text-lg font-black text-slate-800 font-heading">
              Healthy Screen Habits
            </h3>
          </div>
          <div className="space-y-3">
            {PARENTING_TIPS.screenTime.map((tip, idx) => (
              <div key={idx} className="p-3 bg-purple-50/60 rounded-xl border border-purple-100">
                <h4 className="text-xs font-bold text-purple-900 font-heading mb-1">{tip.title}</h4>
                <p className="text-xs text-slate-600 leading-relaxed">{tip.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 3: Privacy, Data Safety & Educational Scope */}
      <section className="bg-amber-50/80 rounded-3xl p-6 sm:p-8 border-3 border-amber-200 space-y-4">
        <div className="flex items-start gap-3">
          <Info className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="space-y-2">
            <h3 className="text-lg font-black text-amber-950 font-heading">
              WonderKids Child Safety & Privacy Architecture
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              WonderKids does not request or collect any personal details such as children's names, emails, camera feeds, microphones, or location coordinates. All stars, unlocked trophies, and drawings are processed exclusively within this local web browser instance via HTML5 LocalStorage. Clearing browser data will reset stored game stars.
            </p>
            <p className="text-xs text-slate-500 italic">
              Notice: WonderKids is built to complement family play and early cognitive engagement. It is not an accredited school curriculum, nor does it replace professional educational assessments or parental care.
            </p>
          </div>
        </div>
      </section>

      {/* Section 4: Data Management & Reset Progress */}
      <section className="bg-white rounded-3xl p-6 border-3 border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-800 font-heading">
            Manage Local Learning Data
          </h3>
          <p className="text-xs text-slate-500">
            Reset star counter and activity records back to default so another sibling can start fresh.
          </p>
        </div>

        {resetSuccessMessage && (
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            Learning progress has been safely reset!
          </div>
        )}

        {showResetConfirm ? (
          <div className="flex items-center gap-2">
            <button
              onClick={handleConfirmReset}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Confirm Reset
            </button>
            <button
              onClick={() => setShowResetConfirm(false)}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            onClick={() => {
              soundManager.playPop();
              setShowResetConfirm(true);
            }}
            className="px-4 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 rounded-xl text-xs font-bold border border-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Local Progress</span>
          </button>
        )}
      </section>
    </div>
  );
};
