import React, { useState } from 'react';
import { SCIENCE_TOPICS } from '../data/scienceTopics';
import { ScienceTopic } from '../types';
import { soundManager } from '../utils/audio';
import { 
  Atom, 
  Sparkles, 
  Star, 
  Lightbulb, 
  CheckCircle, 
  RotateCcw, 
  Volume2, 
  HelpCircle, 
  Compass, 
  ArrowRight 
} from 'lucide-react';

interface ScienceViewProps {
  onEarnStars: (amount: number, activityId: string) => void;
}

export const ScienceView: React.FC<ScienceViewProps> = ({ onEarnStars }) => {
  const [selectedTopic, setSelectedTopic] = useState<ScienceTopic>(SCIENCE_TOPICS[0]);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  const handleSelectTopic = (topic: ScienceTopic) => {
    soundManager.playPop();
    setSelectedTopic(topic);
    setQuizAnswers({});
    setQuizSubmitted(false);
    setQuizScore(0);
  };

  const handleSpeakTopic = () => {
    soundManager.speakText(`${selectedTopic.title}. ${selectedTopic.explanation}`);
  };

  const handleAnswerSelect = (qIdx: number, optIdx: number) => {
    if (quizSubmitted) return;
    soundManager.playPop();
    setQuizAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
  };

  const handleSubmitQuiz = () => {
    let score = 0;
    selectedTopic.quiz.forEach((q, idx) => {
      if (quizAnswers[idx] === q.correctIndex) {
        score++;
      }
    });

    setQuizScore(score);
    setQuizSubmitted(true);

    if (score >= 2) {
      soundManager.playSuccess();
      onEarnStars(score, `science_quiz_${selectedTopic.id}`);
    } else {
      soundManager.playGentleWrong();
    }
  };

  const handleResetQuiz = () => {
    soundManager.playPop();
    setQuizAnswers({});
    setQuizSubmitted(false);
    setQuizScore(0);
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-100 via-indigo-50 to-pink-50 rounded-3xl p-6 sm:p-8 border-3 border-purple-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-200 text-purple-900 rounded-full text-xs font-bold font-heading mb-2">
            <Atom className="w-3.5 h-3.5" />
            Science Explorer
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-800 font-heading">
            Discover the World & Universe
          </h1>
          <p className="text-sm sm:text-base text-slate-600 font-medium max-w-xl mt-1">
            Explore 10 fascinating science topics: planets, nature, water cycle, weather, senses, and our blue Earth!
          </p>
        </div>

        {/* Listen to overview */}
        <button
          onClick={handleSpeakTopic}
          className="px-5 py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-2xl shadow-sm active:scale-95 transition-all flex items-center gap-2 cursor-pointer font-heading text-sm"
        >
          <Volume2 className="w-4 h-4" />
          <span>Read Aloud</span>
        </button>
      </div>

      {/* Topics Selector Carousel / Grid */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {SCIENCE_TOPICS.map(topic => {
          const isSelected = topic.id === selectedTopic.id;
          return (
            <button
              key={topic.id}
              onClick={() => handleSelectTopic(topic)}
              className={`px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold font-heading transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer flex-shrink-0 ${
                isSelected
                  ? 'bg-purple-600 text-white shadow-sm border-2 border-purple-700 scale-102'
                  : 'bg-white hover:bg-purple-50 text-slate-700 border-2 border-slate-200'
              }`}
            >
              <span className="text-lg">{topic.badgeEmoji}</span>
              <span>{topic.title}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Topic Explanation & Fun Facts */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border-3 border-purple-200 shadow-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-16 h-16 rounded-2xl bg-purple-100 border-2 border-purple-300 flex items-center justify-center text-3xl shadow-inner">
                {selectedTopic.badgeEmoji}
              </div>
              <div>
                <span className="text-xs font-bold text-purple-600 uppercase tracking-wider font-heading">
                  {selectedTopic.category}
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-heading">
                  {selectedTopic.title}
                </h2>
              </div>
            </div>

            <p className="text-base sm:text-lg text-slate-700 font-medium leading-relaxed mb-6 bg-purple-50/50 p-4 rounded-2xl border border-purple-100">
              {selectedTopic.explanation}
            </p>

            {/* 3 Fun Facts */}
            <div>
              <h3 className="text-lg font-black text-slate-800 font-heading mb-3 flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-amber-500" />
                3 Fascinating Facts!
              </h3>
              <div className="space-y-3">
                {selectedTopic.keyFacts.map((fact, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200 flex items-start gap-3"
                  >
                    <span className="w-6 h-6 rounded-full bg-amber-200 text-amber-900 font-black text-xs flex items-center justify-center flex-shrink-0 mt-0.5 font-heading">
                      {idx + 1}
                    </span>
                    <p className="text-xs sm:text-sm text-slate-700 font-semibold leading-relaxed">
                      {fact}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Interactive 3-Question Mini Quiz */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-3xl p-6 border-3 border-purple-200 shadow-md">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-800 text-base font-heading flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                Science Check-Up
              </h3>
              {quizSubmitted && (
                <button
                  onClick={handleResetQuiz}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
                  title="Try quiz again"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Quiz Questions */}
            <div className="space-y-6">
              {selectedTopic.quiz.map((q, qIdx) => (
                <div key={qIdx} className="space-y-2">
                  <p className="text-xs sm:text-sm font-bold text-slate-800 font-heading">
                    {qIdx + 1}. {q.question}
                  </p>
                  <div className="space-y-1.5">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = quizAnswers[qIdx] === optIdx;
                      const isCorrect = optIdx === q.correctIndex;

                      let style = 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-purple-50';
                      if (quizSubmitted) {
                        if (isCorrect) {
                          style = 'bg-emerald-100 border-emerald-400 text-emerald-900 font-bold';
                        } else if (isSelected && !isCorrect) {
                          style = 'bg-rose-100 border-rose-300 text-rose-800';
                        } else {
                          style = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                        }
                      } else if (isSelected) {
                        style = 'bg-purple-600 text-white border-purple-700 font-bold';
                      }

                      return (
                        <button
                          key={optIdx}
                          onClick={() => handleAnswerSelect(qIdx, optIdx)}
                          disabled={quizSubmitted}
                          className={`w-full text-left p-2.5 rounded-xl border-2 text-xs font-semibold transition-all cursor-pointer ${style}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>

                  {quizSubmitted && (
                    <p className="text-[11px] text-slate-500 italic mt-1 bg-slate-50 p-2 rounded-lg">
                      💡 {q.explanation}
                    </p>
                  )}
                </div>
              ))}
            </div>

            {/* Submit / Score */}
            <div className="mt-6 pt-4 border-t border-slate-100">
              {!quizSubmitted ? (
                <button
                  onClick={handleSubmitQuiz}
                  disabled={Object.keys(quizAnswers).length < selectedTopic.quiz.length}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white font-black rounded-2xl shadow-sm transition-all font-heading text-sm cursor-pointer"
                >
                  Check Answers ⭐
                </button>
              ) : (
                <div className="text-center space-y-3">
                  <div className="p-3 bg-purple-50 rounded-2xl border border-purple-200">
                    <span className="text-base font-black text-purple-900 font-heading">
                      You scored {quizScore} / {selectedTopic.quiz.length}!
                    </span>
                    <p className="text-xs text-purple-700 mt-0.5">
                      {quizScore === 3 ? 'Outstanding young scientist!' : 'Great exploration! Keep learning!'}
                    </p>
                  </div>
                  <button
                    onClick={handleResetQuiz}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer font-heading"
                  >
                    Retake Quiz
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
