import React from 'react';
import { TabType, DailyChallenge } from '../types';
import { MascotOwl } from '../components/MascotOwl';
import { soundManager } from '../utils/audio';
import { 
  BookOpen, 
  Calculator, 
  Languages, 
  Atom, 
  Gamepad2, 
  Palette, 
  Star, 
  Trophy, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Volume2
} from 'lucide-react';

interface HomeViewProps {
  onSelectTab: (tab: TabType) => void;
  stars: number;
  badgesCount: number;
  completedActivitiesCount: number;
  dailyChallengeCompleted: boolean;
  onCompleteDailyChallenge: (starsReward: number) => void;
  onOpenBadges: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectTab,
  stars,
  badgesCount,
  completedActivitiesCount,
  dailyChallengeCompleted,
  onCompleteDailyChallenge,
  onOpenBadges
}) => {
  // Deterministic daily challenge based on today's date
  const challenges: DailyChallenge[] = [
    {
      id: 'daily_letters',
      title: 'Alphabet Master: Explore 5 Letters',
      description: 'Visit the Alphabet room, tap letters, and hear their phonetic sounds!',
      targetTab: 'alphabet',
      rewardStars: 5,
      icon: '🔤'
    },
    {
      id: 'daily_math',
      title: 'Number Hero: Count & Solve 3 Math Problems',
      description: 'Hop into Math Adventure and solve fun counting or addition puzzles!',
      targetTab: 'math',
      rewardStars: 5,
      icon: '🔢'
    },
    {
      id: 'daily_science',
      title: 'Cosmic Wonder: Discover Solar System Planets',
      description: 'Explore the Science room and take a quick cosmic discovery quiz!',
      targetTab: 'science',
      rewardStars: 5,
      icon: '🪐'
    },
    {
      id: 'daily_memory',
      title: 'Memory Whiz: Match Card Pairs',
      description: 'Play Memory Match in Brain Games and find all animal pairs!',
      targetTab: 'brain-games',
      rewardStars: 5,
      icon: '🧠'
    },
    {
      id: 'daily_art',
      title: 'Little Picasso: Color a Fun Picture',
      description: 'Head to Creative Corner and draw or color with rainbow brushes!',
      targetTab: 'creative',
      rewardStars: 5,
      icon: '🎨'
    }
  ];

  // Rotate challenge by day of year
  const dayIndex = new Date().getDate() % challenges.length;
  const currentDailyChallenge = challenges[dayIndex];

  const categories = [
    {
      id: 'alphabet' as TabType,
      title: 'Alphabet & Phonics',
      age: 'Ages 3–6',
      desc: 'All 26 letters with phonetic sounds, cute words, audio pronunciation, and letter matching games.',
      icon: <BookOpen className="w-8 h-8 text-pink-600" />,
      bgGradient: 'from-pink-100 to-rose-50 border-pink-300',
      badgeBg: 'bg-pink-100 text-pink-800',
      buttonBg: 'bg-pink-500 hover:bg-pink-600 text-white',
      accentEmoji: '🔤'
    },
    {
      id: 'math' as TabType,
      title: 'Math Adventure',
      age: 'Ages 4–12',
      desc: 'Interactive levels: number counting 1-20, shapes, addition, subtraction, and multiplication puzzles.',
      icon: <Calculator className="w-8 h-8 text-sky-600" />,
      bgGradient: 'from-sky-100 to-blue-50 border-sky-300',
      badgeBg: 'bg-sky-100 text-sky-800',
      buttonBg: 'bg-sky-500 hover:bg-sky-600 text-white',
      accentEmoji: '🔢'
    },
    {
      id: 'english' as TabType,
      title: 'English Words',
      age: 'Ages 4–9',
      desc: 'Everyday vocabulary, animals, foods, colors, audio speech, and interactive sentence building.',
      icon: <Languages className="w-8 h-8 text-emerald-600" />,
      bgGradient: 'from-emerald-100 to-teal-50 border-emerald-300',
      badgeBg: 'bg-emerald-100 text-emerald-800',
      buttonBg: 'bg-emerald-500 hover:bg-emerald-600 text-white',
      accentEmoji: '📖'
    },
    {
      id: 'science' as TabType,
      title: 'Science Explorer',
      age: 'Ages 5–12',
      desc: 'Planets, animal habitats, weather, the water cycle, human senses, and exciting mini quizzes.',
      icon: <Atom className="w-8 h-8 text-purple-600" />,
      bgGradient: 'from-purple-100 to-indigo-50 border-purple-300',
      badgeBg: 'bg-purple-100 text-purple-800',
      buttonBg: 'bg-purple-600 hover:bg-purple-700 text-white',
      accentEmoji: '🪐'
    },
    {
      id: 'brain-games' as TabType,
      title: 'Brain Games',
      age: 'Ages 4–12',
      desc: 'Card memory match, odd-one-out detective, pattern completion, and picture rearrangement puzzles.',
      icon: <Gamepad2 className="w-8 h-8 text-indigo-600" />,
      bgGradient: 'from-amber-100 to-yellow-50 border-amber-300',
      badgeBg: 'bg-amber-100 text-amber-800',
      buttonBg: 'bg-amber-500 hover:bg-amber-600 text-amber-950 font-black',
      accentEmoji: '🧠'
    },
    {
      id: 'creative' as TabType,
      title: 'Creative Corner',
      age: 'All Ages',
      desc: 'Digital drawing canvas with vibrant colors, pencil, eraser, fun outline coloring templates & stamps.',
      icon: <Palette className="w-8 h-8 text-rose-600" />,
      bgGradient: 'from-rose-100 to-pink-50 border-rose-300',
      badgeBg: 'bg-rose-100 text-rose-800',
      buttonBg: 'bg-rose-500 hover:bg-rose-600 text-white',
      accentEmoji: '🎨'
    }
  ];

  const handleHeroSpeech = () => {
    soundManager.speakText("Welcome to WonderKids! Little minds, big discoveries! Choose an adventure below to start playing!");
  };

  return (
    <div className="space-y-12 pb-8">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-100 via-yellow-50 to-sky-100 border-4 border-amber-200 p-6 sm:p-10 lg:p-12 shadow-md">
        {/* Decorative Floating Elements */}
        <div className="absolute top-4 right-8 text-4xl select-none opacity-40 animate-float-slow">✨</div>
        <div className="absolute bottom-6 left-8 text-4xl select-none opacity-30 animate-pulse-subtle">🎈</div>
        <div className="absolute top-1/2 right-1/4 text-3xl select-none opacity-30 animate-bounce-gentle">⭐</div>

        <div className="relative z-10 flex flex-col-reverse lg:flex-row items-center justify-between gap-8">
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/80 border border-amber-300 text-amber-900 text-xs sm:text-sm font-bold shadow-xs mb-4">
              <Sparkles className="w-4 h-4 text-amber-500" />
              Fun, Safe & Interactive Learning for Kids 3–12
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-800 font-heading tracking-tight leading-tight mb-4">
              Little Minds, <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-amber-600 bg-clip-text text-transparent">
                Big Discoveries!
              </span>
            </h1>

            <p className="text-base sm:text-xl text-slate-600 font-medium max-w-xl mb-8 leading-relaxed">
              Explore, play, and learn something amazing every day. Games, sounds, colors, and friendly challenges designed to ignite curious minds!
            </p>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4">
              <button
                onClick={() => {
                  soundManager.playPop();
                  onSelectTab('alphabet');
                }}
                className="px-6 sm:px-8 py-3.5 sm:py-4 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-extrabold text-base sm:text-lg rounded-2xl shadow-md hover:shadow-lg active:scale-95 transition-all flex items-center gap-2 cursor-pointer font-heading"
              >
                <span>Start Learning</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                onClick={() => {
                  soundManager.playPop();
                  onSelectTab('brain-games');
                }}
                className="px-6 sm:px-8 py-3.5 sm:py-4 bg-white hover:bg-amber-50 text-amber-900 font-extrabold text-base sm:text-lg rounded-2xl border-2 border-amber-300 shadow-sm hover:shadow-md active:scale-95 transition-all flex items-center gap-2 cursor-pointer font-heading"
              >
                <Gamepad2 className="w-5 h-5 text-amber-600" />
                <span>Play Brain Games</span>
              </button>

              {/* Speak Welcome button */}
              <button
                onClick={handleHeroSpeech}
                title="Hear Professor Hoot speak"
                className="p-3.5 bg-amber-200/80 hover:bg-amber-300 text-amber-950 rounded-2xl border border-amber-400 transition-all cursor-pointer flex items-center justify-center"
                aria-label="Listen to welcome message"
              >
                <Volume2 className="w-6 h-6 text-amber-900" />
              </button>
            </div>
          </div>

          {/* Owl Mascot Card */}
          <div className="flex-shrink-0 flex flex-col items-center">
            <MascotOwl 
              size="lg" 
              mood="waving" 
              speechBubble="Hoot hoot! I am Professor Hoot! Are you ready for an adventure?" 
            />
          </div>
        </div>
      </section>

      {/* Daily Challenge & Learning Progress Banner */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Challenge Card */}
        <div className="lg:col-span-2 bg-gradient-to-r from-sky-50 via-teal-50 to-emerald-50 rounded-3xl p-6 border-3 border-sky-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white border-2 border-sky-300 flex items-center justify-center text-3xl shadow-sm flex-shrink-0">
              {currentDailyChallenge.icon}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 bg-sky-200 text-sky-900 text-xs font-black rounded-full uppercase font-heading tracking-wide">
                  Daily Challenge
                </span>
                <span className="text-xs font-bold text-amber-700 flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  +{currentDailyChallenge.rewardStars} Bonus Stars
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-slate-800 font-heading">
                {currentDailyChallenge.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                {currentDailyChallenge.description}
              </p>
            </div>
          </div>

          <div className="flex sm:flex-col gap-2 w-full sm:w-auto">
            {dailyChallengeCompleted ? (
              <div className="flex items-center gap-2 px-5 py-3 bg-emerald-100 border-2 border-emerald-300 text-emerald-800 font-bold rounded-2xl text-sm justify-center">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                Completed Today!
              </div>
            ) : (
              <>
                <button
                  onClick={() => {
                    soundManager.playPop();
                    onSelectTab(currentDailyChallenge.targetTab);
                  }}
                  className="flex-1 sm:flex-none px-5 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-2xl text-sm transition-all shadow-xs cursor-pointer font-heading text-center"
                >
                  Start Challenge
                </button>
                <button
                  onClick={() => {
                    onCompleteDailyChallenge(currentDailyChallenge.rewardStars);
                  }}
                  className="px-4 py-2 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold rounded-2xl text-xs transition-all cursor-pointer"
                  title="Claim your bonus stars after trying the activity"
                >
                  Claim Bonus ⭐
                </button>
              </>
            )}
          </div>
        </div>

        {/* Learning Stats Card */}
        <div className="bg-white rounded-3xl p-6 border-3 border-amber-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-extrabold text-slate-800 text-base font-heading flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-500" />
              Your Progress
            </h3>
            <button
              onClick={() => {
                soundManager.playPop();
                onOpenBadges();
              }}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 underline cursor-pointer"
            >
              View Badges
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-center">
              <div className="text-2xl font-black text-amber-900 font-heading flex items-center justify-center gap-1">
                <Star className="w-5 h-5 fill-amber-500 text-amber-500" />
                {stars}
              </div>
              <div className="text-[11px] font-bold text-amber-700 uppercase mt-0.5">Stars Earned</div>
            </div>

            <div className="bg-purple-50 p-3 rounded-2xl border border-purple-200 text-center">
              <div className="text-2xl font-black text-purple-900 font-heading">
                {badgesCount}
              </div>
              <div className="text-[11px] font-bold text-purple-700 uppercase mt-0.5">Badges Won</div>
            </div>
          </div>

          <div className="text-xs text-slate-500 flex items-center justify-between pt-2 border-t border-slate-100">
            <span>Activities played:</span>
            <span className="font-bold text-slate-700">{completedActivitiesCount}</span>
          </div>
        </div>
      </section>

      {/* Category Cards Section */}
      <section>
        <div className="text-center max-w-2xl mx-auto mb-8">
          <span className="text-xs uppercase font-extrabold px-3 py-1 bg-amber-100 text-amber-800 rounded-full font-heading">
            Choose Your Adventure
          </span>
          <h2 className="text-2xl sm:text-4xl font-black text-slate-800 font-heading mt-2">
            What Would You Like to Learn Today?
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-2">
            Click any colorful card below to jump straight into working games, audio pronunciation, and interactive quizzes!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map(cat => (
            <div
              key={cat.id}
              className={`rounded-3xl p-6 bg-gradient-to-br ${cat.bgGradient} border-3 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group hover:-translate-y-1`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-14 h-14 rounded-2xl bg-white border-2 border-white shadow-xs flex items-center justify-center group-hover:scale-110 transition-transform">
                    {cat.icon}
                  </div>
                  <span className={`text-xs font-black px-3 py-1 rounded-full font-heading ${cat.badgeBg}`}>
                    {cat.age}
                  </span>
                </div>

                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xl">{cat.accentEmoji}</span>
                  <h3 className="text-xl font-black text-slate-800 font-heading">
                    {cat.title}
                  </h3>
                </div>

                <p className="text-slate-600 text-sm leading-relaxed mb-6">
                  {cat.desc}
                </p>
              </div>

              <button
                onClick={() => {
                  soundManager.playPop();
                  onSelectTab(cat.id);
                }}
                className={`w-full py-3 px-4 rounded-2xl font-bold font-heading text-sm transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 ${cat.buttonBg}`}
              >
                <span>Open {cat.title}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
