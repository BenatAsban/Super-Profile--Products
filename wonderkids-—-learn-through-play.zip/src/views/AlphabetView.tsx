import React, { useState } from 'react';
import { ALPHABET_DATA } from '../data/alphabet';
import { AlphabetLetter } from '../types';
import { soundManager } from '../utils/audio';
import { 
  Volume2, 
  RotateCcw, 
  Sparkles, 
  CheckCircle, 
  HelpCircle, 
  Star, 
  BookOpen, 
  Layers, 
  Lightbulb 
} from 'lucide-react';

interface AlphabetViewProps {
  onEarnStars: (amount: number, activityId: string) => void;
}

export const AlphabetView: React.FC<AlphabetViewProps> = ({ onEarnStars }) => {
  const [activeTab, setActiveTab] = useState<'explore' | 'matching' | 'quiz'>('explore');
  const [selectedLetter, setSelectedLetter] = useState<AlphabetLetter>(ALPHABET_DATA[0]);

  // Matching game state
  // 6 pairs of uppercase & lowercase
  const [matchingCards, setMatchingCards] = useState<{ id: string; letter: string; type: 'upper' | 'lower'; matched: boolean; pairKey: string }[]>(() => generateMatchingCards());
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchesWon, setMatchesWon] = useState(0);

  // Picture quiz state
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [quizQuestions] = useState(() => {
    // Pick 5 random letters for quiz
    return [...ALPHABET_DATA].sort(() => Math.random() - 0.5).slice(0, 5);
  });

  function generateMatchingCards() {
    const subset = [...ALPHABET_DATA].sort(() => Math.random() - 0.5).slice(0, 4);
    const upper = subset.map((item, idx) => ({
      id: `u-${idx}`,
      letter: item.letter,
      type: 'upper' as const,
      matched: false,
      pairKey: item.letter
    }));
    const lower = subset.map((item, idx) => ({
      id: `l-${idx}`,
      letter: item.letter.toLowerCase(),
      type: 'lower' as const,
      matched: false,
      pairKey: item.letter
    }));
    return [...upper, ...lower].sort(() => Math.random() - 0.5);
  }

  const handleSelectLetter = (letter: AlphabetLetter) => {
    soundManager.playPop();
    setSelectedLetter(letter);
    soundManager.speakText(`${letter.letter}! ${letter.word}!`);
  };

  const handleSpeakSelected = () => {
    soundManager.speakText(`${selectedLetter.letter}. ${selectedLetter.word}. ${selectedLetter.exampleSentence}`);
  };

  // Card Matching Game Logic
  const handleCardClick = (index: number) => {
    if (flippedCards.length === 2 || matchingCards[index].matched || flippedCards.includes(index)) {
      return;
    }
    soundManager.playPop();
    const newFlipped = [...flippedCards, index];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      const first = matchingCards[newFlipped[0]];
      const second = matchingCards[newFlipped[1]];

      if (first.pairKey === second.pairKey && first.type !== second.type) {
        // Matched!
        setTimeout(() => {
          soundManager.playSuccess();
          setMatchingCards(prev =>
            prev.map((c, i) => (i === newFlipped[0] || i === newFlipped[1] ? { ...c, matched: true } : c))
          );
          setFlippedCards([]);
          const newMatches = matchesWon + 1;
          setMatchesWon(newMatches);
          if (newMatches === 4) {
            onEarnStars(3, 'alphabet_match_won');
          }
        }, 500);
      } else {
        // Not a match
        setTimeout(() => {
          soundManager.playGentleWrong();
          setFlippedCards([]);
        }, 900);
      }
    }
  };

  const resetMatchingGame = () => {
    soundManager.playPop();
    setMatchingCards(generateMatchingCards());
    setFlippedCards([]);
    setMatchesWon(0);
  };

  // Quiz logic
  const currentQuizItem = quizQuestions[quizIndex];
  // Generate 4 options (correct letter + 3 random distinct ones)
  const [quizOptions, setQuizOptions] = useState<string[]>(() => generateQuizOptions(currentQuizItem.letter));

  function generateQuizOptions(correct: string) {
    const distractors = ALPHABET_DATA.filter(l => l.letter !== correct)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map(l => l.letter);
    return [correct, ...distractors].sort(() => Math.random() - 0.5);
  }

  const handleQuizAnswer = (letterChoice: string) => {
    if (feedback !== null) return;
    const isCorrect = letterChoice === currentQuizItem.letter;
    if (isCorrect) {
      soundManager.playSuccess();
      setQuizScore(prev => prev + 1);
      setFeedback({
        isCorrect: true,
        message: `Super job! "${currentQuizItem.word}" starts with ${currentQuizItem.letter}! ⭐`
      });
      soundManager.speakText(`Correct! ${currentQuizItem.word} starts with ${currentQuizItem.letter}!`);
      onEarnStars(1, `alphabet_quiz_${currentQuizItem.letter}`);
    } else {
      soundManager.playGentleWrong();
      setFeedback({
        isCorrect: false,
        message: `Good try! Look closely: "${currentQuizItem.word}" starts with ${currentQuizItem.letter}.`
      });
      soundManager.speakText(`Nice try! Look closely at ${currentQuizItem.word}. It starts with ${currentQuizItem.letter}!`);
    }
  };

  const handleNextQuizQuestion = () => {
    soundManager.playPop();
    setFeedback(null);
    if (quizIndex < quizQuestions.length - 1) {
      const nextIdx = quizIndex + 1;
      setQuizIndex(nextIdx);
      setQuizOptions(generateQuizOptions(quizQuestions[nextIdx].letter));
    }
  };

  const resetQuiz = () => {
    soundManager.playPop();
    setQuizIndex(0);
    setQuizScore(0);
    setFeedback(null);
    setQuizOptions(generateQuizOptions(quizQuestions[0].letter));
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-pink-100 via-rose-50 to-amber-100 rounded-3xl p-6 sm:p-8 border-3 border-pink-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-pink-200 text-pink-900 rounded-full text-xs font-bold font-heading mb-2">
            <BookOpen className="w-3.5 h-3.5" />
            Alphabet Phonics Fun
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-800 font-heading">
            Learn Letters A to Z
          </h1>
          <p className="text-sm sm:text-base text-slate-600 font-medium max-w-xl mt-1">
            Explore big and small letters, listen to phonetic sounds, play the uppercase-lowercase memory match, and test your skills with picture quizzes!
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex bg-white/90 p-1.5 rounded-2xl border-2 border-pink-200 shadow-xs">
          <button
            onClick={() => {
              soundManager.playPop();
              setActiveTab('explore');
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              activeTab === 'explore'
                ? 'bg-pink-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-pink-600'
            }`}
          >
            🔤 Explore A–Z
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setActiveTab('matching');
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              activeTab === 'matching'
                ? 'bg-pink-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-pink-600'
            }`}
          >
            🃏 Match Cards
          </button>
          <button
            onClick={() => {
              soundManager.playPop();
              setActiveTab('quiz');
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              activeTab === 'quiz'
                ? 'bg-pink-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-pink-600'
            }`}
          >
            ❓ Picture Quiz
          </button>
        </div>
      </div>

      {/* TAB 1: EXPLORE ALL 26 LETTERS */}
      {activeTab === 'explore' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Detailed Active Letter Showcase */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border-3 border-pink-200 shadow-md sticky top-24 text-center">
              <div className="inline-block px-3 py-1 bg-pink-100 text-pink-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2 font-heading">
                Phonetic Sound: {selectedLetter.phonetic}
              </div>

              {/* Big letter & emoji */}
              <div className="my-4 relative">
                <div className="w-32 h-32 mx-auto rounded-3xl bg-gradient-to-tr from-pink-100 to-amber-100 border-4 border-pink-300 flex items-center justify-center text-6xl shadow-inner animate-bounce-gentle select-none">
                  {selectedLetter.emoji}
                </div>
              </div>

              <div className="text-5xl font-black text-slate-800 font-heading mb-1">
                {selectedLetter.letter}{selectedLetter.letter.toLowerCase()}
              </div>

              <div className="text-2xl font-black text-pink-600 font-heading mb-2">
                {selectedLetter.word}
              </div>

              <p className="text-xs sm:text-sm text-slate-500 font-semibold mb-3">
                {selectedLetter.soundDescription}
              </p>

              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-slate-700 text-xs sm:text-sm italic mb-6">
                "{selectedLetter.exampleSentence}"
              </div>

              <button
                onClick={handleSpeakSelected}
                className="w-full py-3.5 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-extrabold rounded-2xl shadow-md active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer font-heading text-base"
              >
                <Volume2 className="w-5 h-5 animate-pulse-subtle" />
                <span>Hear Pronunciation</span>
              </button>
            </div>
          </div>

          {/* Letter Grid A to Z */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl p-6 border-3 border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-extrabold text-slate-800 text-lg font-heading">
                  Touch Any Letter
                </h3>
                <span className="text-xs text-slate-500 font-semibold">26 Letters</span>
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-7 gap-2.5 sm:gap-3">
                {ALPHABET_DATA.map(item => {
                  const isSelected = selectedLetter.letter === item.letter;
                  return (
                    <button
                      key={item.letter}
                      onClick={() => handleSelectLetter(item)}
                      className={`p-2.5 sm:p-3 rounded-2xl border-2 transition-all cursor-pointer flex flex-col items-center justify-center text-center group active:scale-90 ${
                        isSelected
                          ? 'bg-pink-500 text-white border-pink-600 shadow-md scale-105 ring-2 ring-pink-300'
                          : 'bg-pink-50/60 hover:bg-pink-100 border-pink-200 text-slate-800'
                      }`}
                      aria-label={`Letter ${item.letter} for ${item.word}`}
                    >
                      <span className="text-xl sm:text-2xl mb-1 select-none group-hover:scale-125 transition-transform">
                        {item.emoji}
                      </span>
                      <span className="text-lg sm:text-xl font-black font-heading leading-tight">
                        {item.letter}
                      </span>
                      <span className={`text-[10px] font-bold truncate max-w-full ${isSelected ? 'text-pink-100' : 'text-slate-500'}`}>
                        {item.word}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: LETTER MATCHING GAME */}
      {activeTab === 'matching' && (
        <div className="max-w-2xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-pink-200 shadow-md">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-800 font-heading">
                Match Big & Small Letters
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                Flip two cards to pair the uppercase letter (A) with its lowercase letter (a)!
              </p>
            </div>
            <button
              onClick={resetMatchingGame}
              className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors cursor-pointer"
              title="Restart game"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          {/* Grid of 8 cards */}
          <div className="grid grid-cols-4 gap-3 sm:gap-4 mb-6">
            {matchingCards.map((card, idx) => {
              const isFlipped = flippedCards.includes(idx) || card.matched;
              return (
                <button
                  key={card.id}
                  onClick={() => handleCardClick(idx)}
                  disabled={card.matched}
                  className={`aspect-square rounded-2xl border-3 text-3xl sm:text-4xl font-black font-heading flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                    card.matched
                      ? 'bg-emerald-100 border-emerald-300 text-emerald-800 opacity-80'
                      : isFlipped
                      ? 'bg-pink-100 border-pink-400 text-pink-700 rotate-y-180 scale-105'
                      : 'bg-gradient-to-br from-amber-200 to-yellow-300 border-amber-300 text-amber-800 hover:scale-102'
                  }`}
                >
                  {isFlipped ? card.letter : '⭐'}
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between bg-pink-50 p-4 rounded-2xl border border-pink-200">
            <div className="text-sm font-bold text-pink-900 font-heading">
              Pairs matched: {matchesWon} / 4
            </div>
            {matchesWon === 4 && (
              <div className="flex items-center gap-2 text-emerald-700 font-extrabold text-sm animate-bounce-gentle">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                You Won! +3 Stars!
              </div>
            )}
            <button
              onClick={resetMatchingGame}
              className="px-4 py-2 bg-pink-500 hover:bg-pink-600 text-white rounded-xl text-xs font-bold transition-all font-heading cursor-pointer"
            >
              Play Again
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: PICTURE QUIZ */}
      {activeTab === 'quiz' && (
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border-3 border-pink-200 shadow-md text-center">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider font-heading">
              Question {quizIndex + 1} of {quizQuestions.length}
            </span>
            <span className="px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-bold flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              Score: {quizScore}
            </span>
          </div>

          {/* Current picture */}
          <div className="w-28 h-28 mx-auto rounded-3xl bg-pink-50 border-3 border-pink-200 flex items-center justify-center text-6xl shadow-inner mb-4 animate-bounce-gentle">
            {currentQuizItem.emoji}
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-slate-800 font-heading mb-1">
            What letter does "{currentQuizItem.word}" start with?
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mb-6">
            Tap the correct letter below to reveal the answer!
          </p>

          {/* Choice cards */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            {quizOptions.map(choice => (
              <button
                key={choice}
                onClick={() => handleQuizAnswer(choice)}
                disabled={feedback !== null}
                className={`py-4 rounded-2xl border-3 text-2xl sm:text-3xl font-black font-heading transition-all cursor-pointer shadow-xs ${
                  feedback !== null && choice === currentQuizItem.letter
                    ? 'bg-emerald-500 text-white border-emerald-600 scale-105'
                    : 'bg-slate-50 hover:bg-pink-50 border-slate-200 hover:border-pink-300 text-slate-700 active:scale-95'
                }`}
              >
                {choice}
              </button>
            ))}
          </div>

          {/* Encouraging Feedback */}
          {feedback && (
            <div
              className={`p-4 rounded-2xl border-2 mb-6 text-sm font-bold animate-fadeIn ${
                feedback.isCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-amber-50 border-amber-300 text-amber-900'
              }`}
            >
              {feedback.message}
            </div>
          )}

          {/* Next button */}
          {feedback && (
            quizIndex < quizQuestions.length - 1 ? (
              <button
                onClick={handleNextQuizQuestion}
                className="w-full py-3.5 bg-pink-500 hover:bg-pink-600 text-white font-extrabold rounded-2xl shadow-md transition-all font-heading text-base cursor-pointer"
              >
                Next Question →
              </button>
            ) : (
              <div className="space-y-3">
                <div className="text-base font-black text-slate-800 font-heading">
                  Quiz Complete! You scored {quizScore} out of {quizQuestions.length}! 🎉
                </div>
                <button
                  onClick={resetQuiz}
                  className="px-6 py-3 bg-pink-500 hover:bg-pink-600 text-white font-bold rounded-2xl transition-all font-heading cursor-pointer"
                >
                  Play Quiz Again
                </button>
              </div>
            )
          )}
        </div>
      )}
    </div>
  );
};
