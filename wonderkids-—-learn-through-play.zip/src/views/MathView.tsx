import React, { useState, useEffect } from 'react';
import { soundManager } from '../utils/audio';
import { 
  Calculator, 
  Star, 
  RotateCcw, 
  CheckCircle2, 
  Sparkles, 
  Circle, 
  Square, 
  Triangle, 
  HelpCircle 
} from 'lucide-react';

interface MathViewProps {
  onEarnStars: (amount: number, activityId: string) => void;
}

type Difficulty = 'beginner' | 'intermediate' | 'advanced';

interface MathProblem {
  id: string;
  question: string;
  visualItems?: { emoji: string; count: number }[];
  options: (number | string)[];
  correctAnswer: number | string;
  explanation: string;
  hint?: string;
}

export const MathView: React.FC<MathViewProps> = ({ onEarnStars }) => {
  const [level, setLevel] = useState<Difficulty>('beginner');
  const [problemIndex, setProblemIndex] = useState(0);
  const [roundScore, setRoundScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | string | null>(null);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; text: string } | null>(null);
  const [currentProblem, setCurrentProblem] = useState<MathProblem>(() => generateProblem('beginner'));
  const [roundLength] = useState(5);

  function generateProblem(diff: Difficulty): MathProblem {
    const emojis = ['🍎', '⭐', '🎈', '🐠', '🍪', '🐱', '🚀'];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];

    if (diff === 'beginner') {
      const mode = Math.random();
      if (mode < 0.45) {
        // Counting objects 1 to 10
        const count = Math.floor(Math.random() * 8) + 2; // 2 to 9
        const distractors = [count - 1, count + 1, count + 2].filter(n => n > 0 && n !== count);
        const options = [count, ...distractors.slice(0, 3)].sort(() => Math.random() - 0.5);
        return {
          id: `count-${Date.now()}`,
          question: `How many ${randomEmoji} can you count?`,
          visualItems: [{ emoji: randomEmoji, count }],
          options,
          correctAnswer: count,
          explanation: `There are ${count} ${randomEmoji}! Counting one by one gives ${count}.`,
          hint: 'Touch each item slowly and count out loud!'
        };
      } else if (mode < 0.75) {
        // Shapes recognition
        const shapes = [
          { name: 'Circle', emoji: '⭕', hint: 'Round like a cookie with no sharp corners' },
          { name: 'Square', emoji: '🟦', hint: 'Has 4 equal straight sides' },
          { name: 'Triangle', emoji: '🔺', hint: 'Has 3 sharp corners and 3 sides' },
          { name: 'Star', emoji: '⭐', hint: 'Twinkles with 5 magical points' }
        ];
        const chosen = shapes[Math.floor(Math.random() * shapes.length)];
        const otherNames = shapes.filter(s => s.name !== chosen.name).map(s => s.name);
        const options = [chosen.name, ...otherNames.slice(0, 3)].sort(() => Math.random() - 0.5);
        return {
          id: `shape-${Date.now()}`,
          question: `Which shape is shown here?`,
          visualItems: [{ emoji: chosen.emoji, count: 1 }],
          options,
          correctAnswer: chosen.name,
          explanation: `That is a ${chosen.name}! ${chosen.hint}.`,
          hint: chosen.hint
        };
      } else {
        // Number recognition 1-20
        const n = Math.floor(Math.random() * 15) + 1;
        const next = n + 1;
        const options = [next, next + 1, next - 2 > 0 ? next - 2 : next + 3, next + 2].sort(() => Math.random() - 0.5);
        return {
          id: `num-${Date.now()}`,
          question: `What number comes right after ${n}?`,
          options,
          correctAnswer: next,
          explanation: `When counting up, ${next} comes right after ${n}!`,
          hint: `Count up: ..., ${n}, ?`
        };
      }
    } else if (diff === 'intermediate') {
      const mode = Math.random();
      if (mode < 0.4) {
        // Addition within 20
        const a = Math.floor(Math.random() * 8) + 2;
        const b = Math.floor(Math.random() * 8) + 1;
        const sum = a + b;
        const options = [sum, sum + 1, sum - 1, sum + 2].sort(() => Math.random() - 0.5);
        return {
          id: `add-${Date.now()}`,
          question: `What is ${a} + ${b}?`,
          visualItems: [
            { emoji: '🟦', count: a },
            { emoji: '🟨', count: b }
          ],
          options,
          correctAnswer: sum,
          explanation: `${a} + ${b} = ${sum}. If you take ${a} blocks and add ${b} more, you have ${sum} in total!`,
          hint: `Start at ${a} and count forward ${b} steps.`
        };
      } else if (mode < 0.7) {
        // Subtraction
        const a = Math.floor(Math.random() * 8) + 5;
        const b = Math.floor(Math.random() * (a - 1)) + 1;
        const diffAns = a - b;
        const options = [diffAns, diffAns + 1, diffAns - 1 > 0 ? diffAns - 1 : diffAns + 3, diffAns + 2].sort(() => Math.random() - 0.5);
        return {
          id: `sub-${Date.now()}`,
          question: `What is ${a} - ${b}?`,
          options,
          correctAnswer: diffAns,
          explanation: `${a} - ${b} = ${diffAns}. Starting with ${a} and taking away ${b} leaves ${diffAns}.`,
          hint: `Count backward from ${a} by ${b}.`
        };
      } else {
        // Compare > , < , =
        const a = Math.floor(Math.random() * 15) + 1;
        const b = Math.floor(Math.random() * 15) + 1;
        const correct = a > b ? '>' : a < b ? '<' : '=';
        return {
          id: `cmp-${Date.now()}`,
          question: `Which symbol fits between ${a} and ${b}?`,
          options: ['>', '<', '='],
          correctAnswer: correct,
          explanation: a === b ? `${a} is equal to ${b}.` : a > b ? `${a} is greater than ${b} (the open alligator mouth faces the bigger number!).` : `${a} is less than ${b}.`,
          hint: 'The crocodile always wants to eat the bigger number!'
        };
      }
    } else {
      // Advanced
      const mode = Math.random();
      if (mode < 0.5) {
        // Multiplication basics (2x to 9x)
        const a = Math.floor(Math.random() * 6) + 2;
        const b = Math.floor(Math.random() * 6) + 2;
        const prod = a * b;
        const options = [prod, prod + a, prod - b, prod + 2].sort(() => Math.random() - 0.5);
        return {
          id: `mult-${Date.now()}`,
          question: `What is ${a} × ${b}?`,
          options,
          correctAnswer: prod,
          explanation: `${a} × ${b} = ${prod}. That means ${a} groups of ${b} items!`,
          hint: `Add ${b} to itself ${a} times.`
        };
      } else {
        // Simple division
        const b = Math.floor(Math.random() * 4) + 2; // divisor 2-5
        const ans = Math.floor(Math.random() * 6) + 2; // quotient 2-7
        const a = b * ans; // dividend
        const options = [ans, ans + 1, ans - 1, ans + 2].sort(() => Math.random() - 0.5);
        return {
          id: `div-${Date.now()}`,
          question: `What is ${a} ÷ ${b}?`,
          options,
          correctAnswer: ans,
          explanation: `${a} ÷ ${b} = ${ans}. If you share ${a} cookies equally between ${b} friends, each friend gets ${ans}!`,
          hint: `How many times does ${b} fit into ${a}?`
        };
      }
    }
  }

  const handleLevelChange = (lvl: Difficulty) => {
    soundManager.playPop();
    setLevel(lvl);
    setProblemIndex(0);
    setRoundScore(0);
    setSelectedAnswer(null);
    setFeedback(null);
    setCurrentProblem(generateProblem(lvl));
  };

  const handleSelectAnswer = (ans: number | string) => {
    if (feedback !== null) return;
    setSelectedAnswer(ans);

    const isCorrect = ans === currentProblem.correctAnswer;
    if (isCorrect) {
      soundManager.playSuccess();
      setRoundScore(prev => prev + 1);
      setFeedback({
        isCorrect: true,
        text: `Awesome job! ${currentProblem.explanation} ⭐`
      });
      soundManager.speakText(`Correct! ${currentProblem.explanation}`);
      onEarnStars(1, `math_${level}_question`);
    } else {
      soundManager.playGentleWrong();
      setFeedback({
        isCorrect: false,
        text: `Good try! ${currentProblem.explanation}`
      });
      soundManager.speakText(`Nice try! ${currentProblem.explanation}`);
    }
  };

  const handleNext = () => {
    soundManager.playPop();
    if (problemIndex < roundLength - 1) {
      setProblemIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setFeedback(null);
      setCurrentProblem(generateProblem(level));
    }
  };

  const handleRestartRound = () => {
    soundManager.playPop();
    setProblemIndex(0);
    setRoundScore(0);
    setSelectedAnswer(null);
    setFeedback(null);
    setCurrentProblem(generateProblem(level));
  };

  const isRoundComplete = feedback !== null && problemIndex === roundLength - 1;

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      {/* Level Selection Pill Bar */}
      <div className="bg-gradient-to-r from-sky-100 via-blue-50 to-indigo-50 rounded-3xl p-6 sm:p-8 border-3 border-sky-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-200 text-sky-900 rounded-full text-xs font-bold font-heading mb-2">
            <Calculator className="w-3.5 h-3.5" />
            Math Adventure
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-800 font-heading">
            Fun Math Explorer
          </h1>
          <p className="text-sm sm:text-base text-slate-600 font-medium max-w-xl mt-1">
            Count colorful objects, master shapes, practice additions, and solve number puzzles!
          </p>
        </div>

        {/* Difficulty Tabs */}
        <div className="flex bg-white/90 p-1.5 rounded-2xl border-2 border-sky-200 shadow-xs">
          <button
            onClick={() => handleLevelChange('beginner')}
            className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              level === 'beginner'
                ? 'bg-sky-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-sky-600'
            }`}
          >
            🐣 Beginner (3–6)
          </button>
          <button
            onClick={() => handleLevelChange('intermediate')}
            className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              level === 'intermediate'
                ? 'bg-sky-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-sky-600'
            }`}
          >
            🚀 Medium (6–8)
          </button>
          <button
            onClick={() => handleLevelChange('advanced')}
            className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-heading transition-all cursor-pointer ${
              level === 'advanced'
                ? 'bg-sky-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-sky-600'
            }`}
          >
            🌟 Advanced (9–12)
          </button>
        </div>
      </div>

      {/* Main Question Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border-3 border-sky-200 shadow-md">
        {/* Progress & Score header */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
          <span className="text-xs sm:text-sm font-extrabold text-slate-400 font-heading uppercase">
            Question {problemIndex + 1} of {roundLength}
          </span>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-amber-100 text-amber-900 rounded-full text-xs font-bold flex items-center gap-1 font-heading">
              <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              Round Score: {roundScore}
            </span>
            <button
              onClick={handleRestartRound}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              title="Restart Round"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Question Text */}
        <div className="text-center mb-8">
          <h2 className="text-2xl sm:text-4xl font-black text-slate-800 font-heading mb-4">
            {currentProblem.question}
          </h2>

          {/* Visual representations (counting emojis / shapes / math blocks) */}
          {currentProblem.visualItems && (
            <div className="flex flex-wrap items-center justify-center gap-3 p-4 bg-sky-50/70 rounded-2xl border border-sky-100 max-w-lg mx-auto mb-4">
              {currentProblem.visualItems.map((item, itemIdx) => (
                <div key={itemIdx} className="flex flex-wrap justify-center gap-2">
                  {Array.from({ length: item.count }).map((_, i) => (
                    <span
                      key={i}
                      className="text-3xl sm:text-4xl transform hover:scale-125 transition-transform select-none animate-bounce-gentle"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    >
                      {item.emoji}
                    </span>
                  ))}
                </div>
              ))}
            </div>
          )}

          {currentProblem.hint && !feedback && (
            <div className="inline-flex items-center gap-1 text-xs text-sky-700 font-bold bg-sky-50 px-3 py-1 rounded-full border border-sky-200">
              <HelpCircle className="w-3.5 h-3.5" />
              Hint: {currentProblem.hint}
            </div>
          )}
        </div>

        {/* Options grid */}
        <div className="grid grid-cols-2 gap-3 sm:gap-4 max-w-md mx-auto mb-6">
          {currentProblem.options.map((opt, idx) => {
            const isChosen = selectedAnswer === opt;
            const isCorrect = opt === currentProblem.correctAnswer;
            let btnStyle = 'bg-slate-50 hover:bg-sky-50 border-slate-200 hover:border-sky-300 text-slate-800';

            if (feedback !== null) {
              if (isCorrect) {
                btnStyle = 'bg-emerald-500 text-white border-emerald-600 shadow-md scale-102';
              } else if (isChosen && !isCorrect) {
                btnStyle = 'bg-rose-100 text-rose-800 border-rose-300';
              } else {
                btnStyle = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                onClick={() => handleSelectAnswer(opt)}
                disabled={feedback !== null}
                className={`py-4 sm:py-5 px-4 rounded-2xl border-3 text-2xl sm:text-3xl font-black font-heading transition-all shadow-xs cursor-pointer active:scale-95 flex items-center justify-center ${btnStyle}`}
              >
                {opt}
              </button>
            );
          })}
        </div>

        {/* Friendly Explanation Banner */}
        {feedback && (
          <div
            className={`p-4 rounded-2xl border-2 mb-6 text-center text-sm font-bold animate-fadeIn max-w-lg mx-auto ${
              feedback.isCorrect
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-amber-50 border-amber-300 text-amber-900'
            }`}
          >
            {feedback.text}
          </div>
        )}

        {/* Next / Completion CTA */}
        {feedback && (
          <div className="text-center">
            {!isRoundComplete ? (
              <button
                onClick={handleNext}
                className="px-8 py-3.5 bg-sky-500 hover:bg-sky-600 text-white font-black text-base rounded-2xl shadow-md transition-all font-heading cursor-pointer active:scale-95"
              >
                Next Math Question →
              </button>
            ) : (
              <div className="space-y-4">
                <div className="text-xl font-black text-slate-800 font-heading">
                  🎉 Round Complete! You scored {roundScore} out of {roundLength}!
                </div>
                <button
                  onClick={handleRestartRound}
                  className="px-8 py-3.5 bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-600 hover:to-indigo-600 text-white font-black text-base rounded-2xl shadow-md transition-all font-heading cursor-pointer"
                >
                  Play Another Math Round
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
