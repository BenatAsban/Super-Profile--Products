import { ProgressState, Badge } from '../types';
import confetti from 'canvas-confetti';
import { soundManager } from './audio';

const STORAGE_KEY = 'wonderkids_progress_v1';

export const ALL_BADGES: Badge[] = [
  {
    id: 'badge_alphabet',
    title: 'Alphabet Explorer',
    description: 'Explored letters and practiced phonics sounds!',
    icon: '🔤',
    requiredStars: 10,
    category: 'Alphabet'
  },
  {
    id: 'badge_math',
    title: 'Math Star',
    description: 'Solved counting, addition, or number puzzles!',
    icon: '⭐',
    requiredStars: 20,
    category: 'Math'
  },
  {
    id: 'badge_words',
    title: 'Word Wizard',
    description: 'Matched words and built amazing sentences!',
    icon: '🧙‍♂️',
    requiredStars: 30,
    category: 'English'
  },
  {
    id: 'badge_science',
    title: 'Science Explorer',
    description: 'Discovered solar planets, animals, and weather!',
    icon: '🔬',
    requiredStars: 40,
    category: 'Science'
  },
  {
    id: 'badge_brain',
    title: 'Brain Game Champion',
    description: 'Matched memory cards and solved clever patterns!',
    icon: '🏆',
    requiredStars: 50,
    category: 'Games'
  },
  {
    id: 'badge_artist',
    title: 'Little Artist',
    description: 'Created and colored a digital masterpiece!',
    icon: '🎨',
    requiredStars: 15,
    category: 'Creative'
  },
  {
    id: 'badge_super',
    title: 'Superstar Scholar',
    description: 'Earned 75 stars across all adventures!',
    icon: '👑',
    requiredStars: 75,
    category: 'All'
  }
];

export const INITIAL_PROGRESS: ProgressState = {
  stars: 5, // Give kids an immediate welcoming 5 stars to start!
  completedActivities: ['welcome_starter'],
  badges: [],
  dailyChallengeCompletedDate: null,
  activityHistory: {}
};

export const storageHelper = {
  getProgress(): ProgressState {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        this.saveProgress(INITIAL_PROGRESS);
        return INITIAL_PROGRESS;
      }
      return JSON.parse(stored) as ProgressState;
    } catch {
      return INITIAL_PROGRESS;
    }
  },

  saveProgress(state: ProgressState) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // safe fallback
    }
  },

  addStars(amount: number, activityId?: string): { newStars: number; newBadges: Badge[] } {
    const current = this.getProgress();
    const newStars = current.stars + Math.max(0, amount);
    const completed = new Set(current.completedActivities);
    if (activityId) {
      completed.add(activityId);
    }

    const currentBadges = new Set(current.badges);
    const newlyUnlocked: Badge[] = [];

    ALL_BADGES.forEach(badge => {
      if (!currentBadges.has(badge.id) && newStars >= badge.requiredStars) {
        currentBadges.add(badge.id);
        newlyUnlocked.push(badge);
      }
    });

    const updated: ProgressState = {
      ...current,
      stars: newStars,
      completedActivities: Array.from(completed),
      badges: Array.from(currentBadges),
      activityHistory: {
        ...current.activityHistory,
        ...(activityId ? { [activityId]: (current.activityHistory[activityId] || 0) + 1 } : {})
      }
    };

    this.saveProgress(updated);

    if (newlyUnlocked.length > 0) {
      soundManager.playTrophy();
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // safe
      }
    } else {
      soundManager.playSuccess();
    }

    return { newStars, newBadges: newlyUnlocked };
  },

  resetProgress(): ProgressState {
    this.saveProgress(INITIAL_PROGRESS);
    return INITIAL_PROGRESS;
  }
};
