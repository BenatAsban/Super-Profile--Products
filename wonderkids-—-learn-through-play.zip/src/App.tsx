/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TabType, ProgressState } from './types';
import { storageHelper, ALL_BADGES } from './utils/storage';
import { soundManager } from './utils/audio';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { BadgesModal } from './components/BadgesModal';
import { HomeView } from './views/HomeView';
import { AlphabetView } from './views/AlphabetView';
import { MathView } from './views/MathView';
import { EnglishView } from './views/EnglishView';
import { ScienceView } from './views/ScienceView';
import { BrainGamesView } from './views/BrainGamesView';
import { CreativeCornerView } from './views/CreativeCornerView';
import { ParentZoneView } from './views/ParentZoneView';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [progress, setProgress] = useState<ProgressState>(() => storageHelper.getProgress());
  const [isBadgesOpen, setIsBadgesOpen] = useState(false);
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);

  // Initialize sound settings on load
  useEffect(() => {
    soundManager.initSound();
    setIsSoundEnabled(soundManager.isSoundEnabled);
  }, []);

  const handleToggleSound = () => {
    const updated = soundManager.toggleSound();
    setIsSoundEnabled(updated);
  };

  const handleEarnStars = (amount: number, activityId: string) => {
    const result = storageHelper.addStars(amount, activityId);
    setProgress(storageHelper.getProgress());
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const isDailyCompleted = progress.dailyChallengeCompletedDate === todayStr;

  const handleCompleteDailyChallenge = (bonusStars: number) => {
    if (isDailyCompleted) return;
    const current = storageHelper.getProgress();
    const updated: ProgressState = {
      ...current,
      stars: current.stars + bonusStars,
      dailyChallengeCompletedDate: todayStr,
      completedActivities: [...new Set([...current.completedActivities, `daily_${todayStr}`])]
    };
    storageHelper.saveProgress(updated);
    setProgress(updated);
    soundManager.playTrophy();
  };

  const handleResetProgress = () => {
    const fresh = storageHelper.resetProgress();
    setProgress(fresh);
  };

  return (
    <div className="min-h-screen flex flex-col bg-amber-50/30 text-slate-800">
      {/* Navigation Header */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        stars={progress.stars}
        onOpenBadges={() => setIsBadgesOpen(true)}
        isSoundEnabled={isSoundEnabled}
        onToggleSound={handleToggleSound}
      />

      {/* Main Content View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {currentTab === 'home' && (
          <HomeView
            onSelectTab={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            stars={progress.stars}
            badgesCount={progress.badges.length}
            completedActivitiesCount={progress.completedActivities.length}
            dailyChallengeCompleted={isDailyCompleted}
            onCompleteDailyChallenge={handleCompleteDailyChallenge}
            onOpenBadges={() => setIsBadgesOpen(true)}
          />
        )}

        {currentTab === 'alphabet' && (
          <AlphabetView onEarnStars={handleEarnStars} />
        )}

        {currentTab === 'math' && (
          <MathView onEarnStars={handleEarnStars} />
        )}

        {currentTab === 'english' && (
          <EnglishView onEarnStars={handleEarnStars} />
        )}

        {currentTab === 'science' && (
          <ScienceView onEarnStars={handleEarnStars} />
        )}

        {currentTab === 'brain-games' && (
          <BrainGamesView onEarnStars={handleEarnStars} />
        )}

        {currentTab === 'creative' && (
          <CreativeCornerView onEarnStars={handleEarnStars} />
        )}

        {currentTab === 'parent-zone' && (
          <ParentZoneView onResetProgress={handleResetProgress} />
        )}
      </main>

      {/* Badges / Trophy Room Modal */}
      <BadgesModal
        isOpen={isBadgesOpen}
        onClose={() => setIsBadgesOpen(false)}
        stars={progress.stars}
        unlockedBadgeIds={progress.badges}
        onResetProgress={handleResetProgress}
      />

      {/* Footer */}
      <Footer onSelectTab={(tab) => {
        setCurrentTab(tab);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }} />
    </div>
  );
}
