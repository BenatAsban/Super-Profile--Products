/* ============================================= */
/* ===== Apex Digital — Custom JavaScript ===== */
/* ============================================= */
/* All interactive features for the agency site  */
/* are organized into clear sections. Edit the    */
/* CONFIG object at the top to customize key      */
/* settings.                                     */
/* ============================================= */

/* --- Configuration: edit these values to customize --- */
const CONFIG = {
  // WhatsApp number in international format (no + or spaces)
  whatsappNumber: "15551234567",
  // Agency email — used in the contact form note
  agencyEmail: "hello@apexdigital.com",
  // Scroll offset for sticky nav (px)
  scrollOffset: 80,
};

/* =============================================
   1. STICKY NAVIGATION — adds shadow on scroll
   ============================================= */
function initStickyNav() {
  const navbar = document.getElementById("mainNav");
  if (!navbar) return;

  function handleScroll() {
    if (window.scrollY > 50) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  }

  window.addEventListener("scroll", handleScroll, { passive: true });
  handleScroll();
}

/* =============================================
   2. SMOOTH SCROLLING — animated scroll to anchors
   ============================================= */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href");
      if (!targetId || targetId === "#") return;

      const target = document.querySelector(targetId);
      if (!target) return;

      e.preventDefault();
      const offsetTop =
        target.getBoundingClientRect().top + window.scrollY - CONFIG.scrollOffset;

      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      });
    });
  });
}

/* =============================================
   3. SCROLL-TRIGGERED ANIMATIONS
   Uses IntersectionObserver to add .is-visible
   ============================================= */
function initScrollAnimations() {
  const animatedElements = document.querySelectorAll("[data-animate]");
  if (!animatedElements.length) return;

  // Fallback: if IntersectionObserver isn't supported, show everything
  if (!("IntersectionObserver" in window)) {
    animatedElements.forEach((el) => el.classList.add("is-visible"));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const delay = parseInt(entry.target.dataset.delay || "0", 10);
          setTimeout(() => {
            entry.target.classList.add("is-visible");
          }, delay);
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12,
      rootMargin: "0px 0px -60px 0px",
    }
  );

  animatedElements.forEach((el) => observer.observe(el));
}

/* =============================================
   4. ACTIVE NAV LINK HIGHLIGHTING
   Highlights the current section in the navbar
   ============================================= */
function initActiveNav() {
  const sections = document.querySelectorAll("section[id], header[id]");
  const navLinks = document.querySelectorAll(".navbar-nav .nav-link, .offcanvas .nav-link");

  if (!sections.length || !navLinks.length) return;

  function updateActive() {
    const scrollPos = window.scrollY + CONFIG.scrollOffset + 20;
    let currentId = "";

    sections.forEach((section) => {
      if (scrollPos >= section.offsetTop) {
        currentId = section.getAttribute("id");
      }
    });

    navLinks.forEach((link) => {
      const href = link.getAttribute("href");
      if (href === `#${currentId}`) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });
  }

  window.addEventListener("scroll", updateActive, { passive: true });
  updateActive();
}

/* =============================================
   5. ANIMATED COUNTERS — counts up when visible
   ============================================= */
function initCounters() {
  const counters = document.querySelectorAll("[data-count]");
  if (!counters.length) return;

  if (!("IntersectionObserver" in window)) {
    counters.forEach((el) => {
      el.textContent = el.getAttribute("data-count");
    });
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.5 }
  );

  counters.forEach((el) => observer.observe(el));
}

function animateCounter(el) {
  const target = parseInt(el.getAttribute("data-count"), 10);
  const suffix = el.textContent.replace(/[0-9]/g, "").trim();
  const duration = 1800;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // Ease-out cubic for a natural deceleration
    const eased = 1 - Math.pow(1 - progress, 3);
    const value = Math.floor(eased * target);

    el.textContent = value + suffix;

    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      el.textContent = target + suffix;
    }
  }

  requestAnimationFrame(update);
}

/* =============================================
   6. CONTACT FORM VALIDATION
   Client-side validation with clear feedback
   ============================================= */
function initContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;

  const submitBtn = document.getElementById("submitBtn");
  const btnText = submitBtn.querySelector(".btn-text");
  const btnSpinner = submitBtn.querySelector(".btn-spinner");
  const successMsg = form.querySelector(".form-feedback-success");
  const errorMsg = form.querySelector(".form-feedback-error");

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    e.stopPropagation();

    // Hide previous feedback
    successMsg.classList.add("d-none");
    errorMsg.classList.add("d-none");

    // Validate all fields with constraints
    let isValid = true;

    // Name — required, min 2 chars
    const name = form.querySelector("#name");
    if (!name.value.trim() || name.value.trim().length < 2) {
      name.classList.add("is-invalid");
      isValid = false;
    } else {
      name.classList.remove("is-invalid");
    }

    // Email — required, regex check
    const email = form.querySelector("#email");
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.value.trim() || !emailRegex.test(email.value.trim())) {
      email.classList.add("is-invalid");
      isValid = false;
    } else {
      email.classList.remove("is-invalid");
    }

    // Phone — optional, but if provided must be valid
    const phone = form.querySelector("#phone");
    if (phone.value.trim()) {
      const phoneRegex = /^[+\d\s()\-]{7,}$/;
      if (!phoneRegex.test(phone.value.trim())) {
        phone.classList.add("is-invalid");
        isValid = false;
      } else {
        phone.classList.remove("is-invalid");
      }
    } else {
      phone.classList.remove("is-invalid");
    }

    // Message — required, min 10 chars
    const message = form.querySelector("#message");
    if (!message.value.trim() || message.value.trim().length < 10) {
      message.classList.add("is-invalid");
      isValid = false;
    } else {
      message.classList.remove("is-invalid");
    }

    if (!isValid) {
      form.classList.add("was-validated");
      return;
    }

    // Simulate form submission
    // NOTE: No backend is connected. To enable real delivery, integrate
    // a form service (Formspree, EmailJS, Supabase, etc.) — see README.
    submitBtn.disabled = true;
    btnText.classList.add("d-none");
    btnSpinner.classList.remove("d-none");

    setTimeout(() => {
      submitBtn.disabled = false;
      btnText.classList.remove("d-none");
      btnSpinner.classList.add("d-none");

      // Show success message (no actual submission occurred)
      successMsg.classList.remove("d-none");
      form.reset();
      form.classList.remove("was-validated");

      // Scroll to the success message
      successMsg.scrollIntoView({ behavior: "smooth", block: "center" });

      // Auto-hide success after 6 seconds
      setTimeout(() => {
        successMsg.classList.add("d-none");
      }, 6000);
    }, 1500);
  });

  // Clear invalid state on input
  form.querySelectorAll(".form-control").forEach((input) => {
    input.addEventListener("input", () => {
      input.classList.remove("is-invalid");
    });
  });
}

/* =============================================
   7. BACK TO TOP BUTTON
   ============================================= */
function initBackToTop() {
  const btn = document.getElementById("backToTop");
  if (!btn) return;

  window.addEventListener(
    "scroll",
    () => {
      if (window.scrollY > 500) {
        btn.classList.add("visible");
      } else {
        btn.classList.remove("visible");
      }
    },
    { passive: true }
  );

  btn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

/* =============================================
   8. DARK / LIGHT MODE TOGGLE
   Saves preference to localStorage
   ============================================= */
function initThemeToggle() {
  const toggle = document.getElementById("themeToggle");
  const iconDark = toggle.querySelector(".theme-icon-dark");
  const iconLight = toggle.querySelector(".theme-icon-light");
  const html = document.documentElement;

  // Load saved preference
  const savedTheme = localStorage.getItem("apex-theme");
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const theme = savedTheme || (prefersDark ? "dark" : "light");

  applyTheme(theme);

  toggle.addEventListener("click", () => {
    const current = html.getAttribute("data-bs-theme");
    const next = current === "dark" ? "light" : "dark";
    applyTheme(next);
    localStorage.setItem("apex-theme", next);
  });

  function applyTheme(themeName) {
    html.setAttribute("data-bs-theme", themeName);
    if (themeName === "dark") {
      iconDark.classList.add("d-none");
      iconLight.classList.remove("d-none");
    } else {
      iconDark.classList.remove("d-none");
      iconLight.classList.add("d-none");
    }
  }
}

/* =============================================
   9. FOOTER — DYNAMIC COPYRIGHT YEAR
   ============================================= */
function initCopyrightYear() {
  const yearEl = document.getElementById("currentYear");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

/* =============================================
   10. KEYBOARD ACCESSIBILITY ENHANCEMENTS
   Ensures offcanvas closes on Escape
   ============================================= */
function initKeyboardA11y() {
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      const offcanvasEl = document.querySelector(".offcanvas.show");
      if (offcanvasEl) {
        const instance = bootstrap.Offcanvas.getInstance(offcanvasEl);
        if (instance) instance.hide();
      }
    }
  });
}

/* =============================================
   INIT — run all features on DOM ready
   ============================================= */
document.addEventListener("DOMContentLoaded", () => {
  initStickyNav();
  initSmoothScroll();
  initScrollAnimations();
  initActiveNav();
  initCounters();
  initContactForm();
  initBackToTop();
  initThemeToggle();
  initCopyrightYear();
  initKeyboardA11y();
});
