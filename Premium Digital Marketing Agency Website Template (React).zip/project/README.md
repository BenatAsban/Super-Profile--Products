# Apex Digital — Premium Digital Marketing Agency Website

A polished, production-ready single-page website for a digital marketing agency. Built with HTML5, CSS3, Bootstrap 5, and vanilla JavaScript. Fully responsive, accessible, and easy to customize.

## Table of Contents

- [Quick Start](#quick-start)
- [Project Structure](#project-structure)
- [Customization Guide](#customization-guide)
  - [Agency Name & Logo](#agency-name--logo)
  - [Colors & Theme](#colors--theme)
  - [Typography](#typography)
  - [Hero Section](#hero-section)
  - [Services](#services)
  - [About Section](#about-section)
  - [Portfolio / Case Studies](#portfolio--case-studies)
  - [Statistics](#statistics)
  - [Testimonials](#testimonials)
  - [Contact Information](#contact-information)
  - [WhatsApp Button](#whatsapp-button)
  - [Social Media Links](#social-media-links)
  - [Footer](#footer)
  - [Images](#images)
- [Contact Form Setup](#contact-form-setup)
- [Dark / Light Mode](#dark--light-mode)
- [Browser Support](#browser-support)
- [License](#license)

---

## Quick Start

### Option 1: Vite (Development)

```bash
npm install
npm run dev
```

The site will be available at `http://localhost:5173`.

To build for production:

```bash
npm run build
npm run preview
```

The built files will be in the `dist/` folder.

### Option 2: Static Hosting

Since this is a static website, you can also:

1. Upload `index.html` and the `src/` folder (containing `style.css` and `script.js`) to any web host.
2. Or build with Vite and upload the `dist/` folder.

> **Note:** Bootstrap 5 and Bootstrap Icons are loaded via CDN, so an internet connection is required for the styling and icons to display correctly.

---

## Project Structure

```
├── index.html          # Main HTML file with all 11 sections
├── src/
│   ├── style.css       # All custom styles (design tokens, components, responsive)
│   └── script.js       # All interactive JavaScript (nav, animations, form, theme)
├── vite.config.ts      # Vite configuration
├── package.json        # Project dependencies and scripts
└── README.md           # This file
```

---

## Customization Guide

### Agency Name & Logo

**File:** `index.html`

- Search for `Apex` and replace with your agency name (appears in the navbar, footer, mobile menu, and browser tab title).
- The logo icon uses a Bootstrap Icon (`bi-graph-up-arrow`). To change it, find `brand-mark` in the HTML and swap the `<i class="bi bi-graph-up-arrow"></i>` for any [Bootstrap Icon](https://icons.getbootstrap.com/).

### Colors & Theme

**File:** `src/style.css`

All colors are defined as CSS custom properties at the top of the file in the `:root` block:

```css
:root {
  --color-primary: #0a1f44;       /* Deep navy blue — main brand color */
  --color-accent: #00b8a9;        /* Teal — accent / CTA color */
  --color-gold: #f5b041;          /* Gold — used for star ratings */
  /* ...and more */
}
```

Change these values and the entire site updates automatically. Dark theme colors are in the `[data-bs-theme="dark"]` block directly below.

### Typography

**File:** `src/style.css`

The site uses two Google Fonts:
- **Plus Jakarta Sans** — headings and buttons
- **Inter** — body text

To change fonts:
1. Update the `<link>` tag in `index.html` (in the `<head>`) with your new font.
2. Update the `--font-heading` and `--font-body` variables in `src/style.css`.

### Hero Section

**File:** `index.html` — look for `<!-- 2. HERO SECTION -->`

- **Headline:** Find the `<h1 class="hero-title">` element and edit the text.
- **Subheadline:** Find the `<p class="hero-subtitle">` element.
- **CTA buttons:** Edit the text inside the `<a class="btn btn-primary-lg">` and `<a class="btn btn-outline-lg">` elements.
- **Trust indicators (500+, 98%, 12+):** Find `data-count` attributes on `trust-number` spans and change the values.
- **Dashboard mockup:** The animated dashboard is built with HTML/CSS (not an image), so all numbers and bars are editable directly in the HTML.

### Services

**File:** `index.html` — look for `<!-- 3. SERVICES SECTION -->`

Each service is a `<article class="service-card">` block. To modify:
- **Icon:** Change the Bootstrap Icon class (e.g., `bi-search` to another icon).
- **Title:** Edit the `<h3 class="service-title">` text.
- **Description:** Edit the `<p class="service-desc">` text.

To add a 7th service, copy one of the `<div class="col-md-6 col-lg-4">` blocks and paste it after the last one.

### About Section

**File:** `index.html` — look for `<!-- 4. ABOUT SECTION -->`

- Edit the heading, paragraphs, and the benefits list (`about-benefits`).
- The "12+ Years" badge is editable — find `about-badge-number` and `about-badge-text`.
- The image is a Pexels stock photo. Replace the `src` URL with your own team photo.

### Portfolio / Case Studies

**File:** `index.html` — look for `<!-- 6. PORTFOLIO SECTION -->`

Each project is a `<article class="portfolio-card">` block. Edit:
- **Image:** Replace the `<img src="...">` URL.
- **Tag & service:** Edit `portfolio-tag` and `portfolio-service` text.
- **Project title:** Edit `portfolio-title`.
- **Industry:** Edit `portfolio-industry`.
- **Metrics:** Edit `metric-value` and `metric-label` spans.
- **Sample note:** The "Sample metrics for illustration" text (`portfolio-sample-note`) should be removed once you add real data.

### Statistics

**File:** `index.html` — look for `<!-- 7. RESULTS & STATISTICS -->`

Each stat is a `<div class="stat-card">` block. Edit:
- **Icon:** Change the Bootstrap Icon class on `stat-icon`.
- **Number:** Change the `data-count` attribute (this drives the count-up animation) and the displayed text.
- **Label:** Edit the `stat-label` text.

### Testimonials

**File:** `index.html` — look for `<!-- 8. TESTIMONIALS -->`

Each testimonial is a `<article class="testimonial-card">` block. Edit:
- **Quote:** Edit the `testimonial-quote` text.
- **Avatar initials:** Change the text inside `testimonial-avatar` (currently "SR", "MK", "EP").
- **Avatar color:** Change the `style="background: var(--gradient-X)"` to use a different gradient.
- **Name & role:** Edit `testimonial-name` and `testimonial-role`.
- **Placeholder note:** Remove the `testimonial-placeholder-note` text once you add real testimonials.

### Contact Information

**File:** `index.html` — look for `<!-- 10. CONTACT SECTION -->`

Update the following with your real details:
- **Email:** Find `hello@apexdigital.com` and replace everywhere it appears (contact card, footer).
- **Phone:** Find `+1 (555) 123-4567` and replace everywhere (contact card, footer).
- **Address:** Find the `contact-info-value` text under the Office label and the footer address.

### WhatsApp Button

**File:** `src/script.js` — top of file in the `CONFIG` object:

```javascript
const CONFIG = {
  whatsappNumber: "15551234567",  // Your WhatsApp number (international format, no +)
  // ...
};
```

**Also in `index.html`:** Find the WhatsApp button (`btn-whatsapp`) and update the `href` attribute:

```html
<a href="https://wa.me/15551234567" ...>
```

Use international format without the `+` sign or spaces (e.g., `15551234567` for US, `447123456789` for UK).

### Social Media Links

**File:** `index.html` — in the footer, find the `footer-social` section. Replace each `href="#"` with your actual social media profile URLs.

### Footer

**File:** `index.html` — look for `<!-- 11. FOOTER -->`

- **Description:** Edit the `footer-desc` text.
- **Links:** The quick links and service links point to sections on the same page. Update if you add new pages.
- **Copyright:** The year is auto-generated by JavaScript, so it always shows the current year.
- **Legal links:** Replace the `Privacy Policy`, `Terms of Service`, and `Cookies` `href="#"` with real pages.

### Images

The site uses stock photos from [Pexels](https://www.pexels.com) (free to use). To replace:

1. **About section image:** Find `about-img` in `index.html` and replace the `src` URL.
2. **Portfolio images:** Find each `portfolio-img` and replace the `src` URL.
3. Use properly sized images (recommended width: 700–900px for portfolio, 900px+ for about).
4. Always update the `alt` text to describe the image for accessibility.

---

## Contact Form Setup

The contact form includes full client-side validation (name, email, phone, message) but **does not send emails by default** — a backend or form service is required.

### Option 1: Formspree (Easiest)

1. Create a free account at [Formspree](https://formspree.io).
2. Get your form endpoint URL (e.g., `https://formspree.io/f/your-id`).
3. In `index.html`, find `<form id="contactForm" novalidate>` and add the `action` and `method` attributes:

```html
<form id="contactForm" novalidate action="https://formspree.io/f/your-id" method="POST">
```

4. In `src/script.js`, inside the `initContactForm` function, replace the simulated submission (the `setTimeout` block) with a real `fetch` call:

```javascript
fetch(form.action, {
  method: "POST",
  body: new FormData(form),
  headers: { Accept: "application/json" },
})
  .then((response) => {
    if (response.ok) {
      // Show success message
      successMsg.classList.remove("d-none");
      form.reset();
    } else {
      // Show error message
      errorMsg.classList.remove("d-none");
    }
  })
  .catch(() => {
    errorMsg.classList.remove("d-none");
  })
  .finally(() => {
    submitBtn.disabled = false;
    btnText.classList.remove("d-none");
    btnSpinner.classList.add("d-none");
  });
```

### Option 2: EmailJS

1. Sign up at [EmailJS](https://www.emailjs.com) and connect your email service.
2. Add the EmailJS SDK in `index.html` before `script.js`.
3. Follow the [EmailJS docs](https://www.emailjs.com/docs/) to send form data.

### Option 3: Supabase

If you have a Supabase project, you can store form submissions in a database table. Add the Supabase client library and insert the form data on submit.

### Option 4: Netlify Forms

If hosting on Netlify, add `data-netlify="true"` to the form tag and Netlify will handle submissions automatically.

---

## Dark / Light Mode

The site includes a dark/light mode toggle (bottom-right corner). The user's preference is saved in `localStorage` and persists across visits.

- The toggle respects the user's system preference on first visit.
- Dark theme colors are defined in `[data-bs-theme="dark"]` in `src/style.css`.
- Customize dark theme colors by editing the variables in that block.

---

## Browser Support

- Chrome, Firefox, Safari, Edge (latest 2 versions)
- Mobile Safari (iOS 14+)
- Chrome for Android
- Graceful degradation for older browsers (animations fall back to static display)

---

## License

This template is free to use and modify for personal and commercial projects. The stock photos from Pexels are licensed under the Pexels License (free to use, no attribution required).

---

**Built with care for digital marketing agencies that want to stand out.**
