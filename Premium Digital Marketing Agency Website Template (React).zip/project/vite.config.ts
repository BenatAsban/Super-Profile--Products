import { defineConfig } from 'vite';

// https://vitejs.dev/config/
export default defineConfig({
  // index.html is the entry point; Vite serves it directly
  // and bundles /src/style.css and /src/script.js
});
