// Navbar scroll effect
const nav = document.querySelector('.custom-nav');
if (nav) {
  const onScroll = () => {
    if (window.scrollY > 40) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

// Close mobile menu on link click
document.addEventListener('click', (e) => {
  const target = e.target as HTMLElement;
  const link = target.closest('.navbar-collapse .nav-link, .navbar-collapse .btn');
  if (!link) return;
  const collapse = document.getElementById('navMenu');
  if (collapse && collapse.classList.contains('show')) {
    collapse.classList.remove('show');
  }
});
