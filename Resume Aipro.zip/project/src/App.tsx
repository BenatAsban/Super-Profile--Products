import { useState, useRef, useEffect } from 'react';

type TabKey = 'resume' | 'cover' | 'linkedin';

interface GeneratedContent {
  resume: string;
  cover: string;
  linkedin: string;
}

const features = [
  { icon: 'bi-file-earmark-text', title: 'AI Resume Generator', desc: 'Craft polished, job-specific resumes in seconds with AI that highlights your strongest achievements.' },
  { icon: 'bi-envelope-paper', title: 'Matching Cover Letter', desc: 'Generate a tailored cover letter that aligns perfectly with your resume and the target role.' },
  { icon: 'bi-linkedin', title: 'LinkedIn Profile Summary', desc: 'Get a compelling LinkedIn summary that boosts your profile visibility and recruiter interest.' },
  { icon: 'bi-file-check', title: 'ATS-Friendly Templates', desc: 'Every template is optimized to pass Applicant Tracking Systems so your resume reaches recruiters.' },
  { icon: 'bi-download', title: 'One-Click PDF Download', desc: 'Export your resume and cover letter as a clean, professional PDF with a single click.' },
  { icon: 'bi-briefcase', title: 'Multiple Job Role Support', desc: 'Switch between job roles and industries — the AI adapts tone, keywords, and structure instantly.' },
];

const steps = [
  { icon: 'bi-pencil-square', title: 'Enter your details', desc: 'Share your name, target job role, years of experience, and key skills.' },
  { icon: 'bi-cpu', title: 'AI generates your docs', desc: 'Get a resume, cover letter, and LinkedIn summary tailored to the role.' },
  { icon: 'bi-download', title: 'Download instantly', desc: 'Export everything as a polished PDF — ready to send to recruiters.' },
];

const plans = [
  { name: 'Free', price: '₹0', period: 'one-time', highlight: false, features: ['1 AI resume', '1 cover letter', '1 LinkedIn summary', 'PDF download', 'ATS-friendly template'] },
  { name: 'Pro', price: '₹149', period: '7 days', highlight: true, features: ['Unlimited resumes', 'Unlimited cover letters', 'Unlimited LinkedIn summaries', 'All premium templates', 'Priority AI generation', 'Email support'] },
  { name: 'Lifetime', price: '₹499', period: 'forever', highlight: false, features: ['Everything in Pro', 'Lifetime access', 'Future template updates', 'Priority support', 'No renewal ever'] },
];

const testimonials = [
  { name: 'Aarav Sharma', role: 'Software Engineer', text: 'ResumeAI Pro helped me land interviews at three top tech companies within a week. The AI-generated resume was spot-on and ATS-friendly.' },
  { name: 'Priya Nair', role: 'Marketing Manager', text: 'The cover letter feature is incredible. It captured my voice perfectly and matched the job description better than I could have written myself.' },
  { name: 'Rohan Verma', role: 'Data Analyst', text: 'I went from zero callbacks to five interview invites after using this tool. The LinkedIn summary alone was worth it. Highly recommended!' },
];

const faqs = [
  { q: 'Is this really free?', a: 'Yes! The Free plan lets you generate one complete resume, cover letter, and LinkedIn summary at no cost. No credit card or sign-up required for the free plan.' },
  { q: 'Are the resumes ATS-friendly?', a: 'Absolutely. Every template is structured and formatted to pass Applicant Tracking Systems (ATS), ensuring your resume reaches human recruiters without being filtered out.' },
  { q: 'Can I edit the generated content?', a: 'Yes. After the AI generates your documents, you can review and customize every section before downloading. You are always in control of the final output.' },
  { q: 'Do I need to create an account?', a: 'No account is needed for the Free plan. For Pro and Lifetime plans, a simple email sign-up is required to manage your subscription and access unlimited generations.' },
  { q: 'How does the AI work?', a: 'Our AI analyzes your input — job role, experience, skills — and uses proven resume-writing frameworks to generate tailored, keyword-optimized content that matches what recruiters and ATS systems look for.' },
];

function App() {
  const [activeTab, setActiveTab] = useState<TabKey>('resume');
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState<GeneratedContent | null>(null);
  const [formError, setFormError] = useState('');
  const generatorRef = useRef<HTMLDivElement>(null);

  // Smooth scroll for anchor links
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a[href^="#"]');
      if (!anchor) return;
      const href = anchor.getAttribute('href');
      if (!href || href === '#') return;
      e.preventDefault();
      const el = document.querySelector(href);
      if (el) {
        const navbar = document.querySelector('.navbar');
        const offset = navbar ? navbar.getBoundingClientRect().height + 10 : 0;
        const top = el.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    };
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  // Entrance animation observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('reveal-visible');
          }
        });
      },
      { threshold: 0.12 }
    );
    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const handleGenerate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const name = (form.elements.namedItem('fullName') as HTMLInputElement).value.trim();
    const role = (form.elements.namedItem('jobRole') as HTMLInputElement).value.trim();
    const years = (form.elements.namedItem('years') as HTMLInputElement).value.trim();
    const skills = (form.elements.namedItem('skills') as HTMLTextAreaElement).value.trim();

    if (!name || !role || !years || !skills) {
      setFormError('Please fill in all required fields.');
      return;
    }
    setFormError('');
    setLoading(true);
    setGenerated(null);

    setTimeout(() => {
      const skillList = skills.split(',').map((s) => s.trim()).filter(Boolean);
      const topSkills = skillList.slice(0, 6).join(', ');
      const content: GeneratedContent = {
        resume: `${name}
${role} | ${years} years of experience

PROFESSIONAL SUMMARY
Dedicated ${role} with ${years} years of experience leveraging ${topSkills} to drive measurable results. Proven track record of delivering high-impact solutions, optimizing processes, and collaborating across teams to achieve business objectives.

CORE SKILLS
${skillList.slice(0, 8).map((s) => `• ${s}`).join('\n')}

EXPERIENCE
${role} — ${years} years
• Spearheaded key initiatives that improved efficiency and output quality
• Collaborated with cross-functional teams to deliver projects on time
• Applied ${topSkills} to solve complex challenges and drive innovation

EDUCATION
• Bachelor's Degree — Relevant to ${role} field`,
        cover: `Dear Hiring Manager,

I am writing to express my strong interest in the ${role} position. With ${years} years of experience and expertise in ${topSkills}, I am confident in my ability to make an immediate impact on your team.

Throughout my career, I have consistently delivered results by combining technical proficiency with a collaborative mindset. My experience has equipped me with the skills to tackle complex challenges and contribute meaningfully to organizational goals.

I am excited about the opportunity to bring my passion and expertise to your organization. Thank you for considering my application — I look forward to discussing how I can contribute to your team.

Sincerely,
${name}`,
        linkedin: `${name} | ${role}

${role} with ${years} years of experience specializing in ${topSkills}. Passionate about driving results, solving complex problems, and collaborating with teams to deliver impactful solutions.

Always eager to learn, grow, and take on new challenges. Open to opportunities where I can leverage my skills to make a meaningful difference.

Let's connect!`,
      };
      setGenerated(content);
      setLoading(false);
    }, 1800);
  };

  const scrollToGenerator = () => {
    if (generatorRef.current) {
      const navbar = document.querySelector('.navbar');
      const offset = navbar ? navbar.getBoundingClientRect().height + 10 : 0;
      const top = generatorRef.current.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* ===== Navigation ===== */}
      <nav className="navbar navbar-expand-lg fixed-top custom-nav">
        <div className="container">
          <a className="navbar-brand d-flex align-items-center gap-2" href="#home">
            <span className="brand-logo">
              <i className="bi bi-file-earmark-ruled"></i>
            </span>
            <span className="brand-name">ResumeAI <span className="brand-accent">Pro</span></span>
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navMenu"
            aria-controls="navMenu"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navMenu">
            <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
              <li className="nav-item"><a className="nav-link" href="#home">Home</a></li>
              <li className="nav-item"><a className="nav-link" href="#features">Features</a></li>
              <li className="nav-item"><a className="nav-link" href="#how">How it Works</a></li>
              <li className="nav-item"><a className="nav-link" href="#pricing">Pricing</a></li>
              <li className="nav-item"><a className="nav-link" href="#faq">FAQ</a></li>
            </ul>
            <a className="btn btn-nav-cta" href="#generator" onClick={(e) => { e.preventDefault(); scrollToGenerator(); }}>
              Create Resume Free
            </a>
          </div>
        </div>
      </nav>

      {/* ===== Hero ===== */}
      <section id="home" className="hero-section">
        <div className="hero-bg-glow"></div>
        <div className="container">
          <div className="row align-items-center g-5">
            <div className="col-lg-6">
              <span className="hero-badge">
                <i className="bi bi-stars"></i> AI-Powered Resume Builder
              </span>
              <h1 className="hero-title">
                Create a Job-Winning Resume<br />in <span className="text-accent">Minutes</span> with AI
              </h1>
              <p className="hero-subtitle">
                Instantly generate ATS-friendly resumes, matching cover letters, and LinkedIn summaries tailored to any job role.
              </p>
              <div className="d-flex flex-wrap gap-3 mt-4">
                <a href="#generator" className="btn btn-primary-cta" onClick={(e) => { e.preventDefault(); scrollToGenerator(); }}>
                  <i className="bi bi-rocket-takeoff me-2"></i>Create My Resume Free
                </a>
                <a href="#how" className="btn btn-secondary-cta">
                  See How It Works
                </a>
              </div>
              <div className="hero-trust d-flex flex-wrap gap-4 mt-4">
                <span><i className="bi bi-shield-check"></i> ATS Optimized</span>
                <span><i className="bi bi-lightning-charge"></i> Instant Download</span>
                <span><i className="bi bi-person-check"></i> No Sign-up Needed</span>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="hero-visual">
                <div className="hero-card-float hero-card-1">
                  <div className="hc-line hc-w60"></div>
                  <div className="hc-line hc-w40"></div>
                  <div className="hc-line hc-w80"></div>
                  <div className="hc-line hc-w50"></div>
                  <div className="hc-line hc-w70"></div>
                </div>
                <div className="hero-card-float hero-card-2">
                  <div className="hc-avatar"></div>
                  <div className="hc-line hc-w50"></div>
                  <div className="hc-line hc-w70"></div>
                  <div className="hc-line hc-w40"></div>
                </div>
                <div className="hero-ai-orb">
                  <i className="bi bi-cpu"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Features ===== */}
      <section id="features" className="section-padding">
        <div className="container">
          <div className="text-center mb-5 reveal">
            <span className="section-eyebrow">Features</span>
            <h2 className="section-title">Everything You Need to Land Your Dream Job</h2>
            <p className="section-subtitle">Powerful AI tools designed to give you an edge in every job application.</p>
          </div>
          <div className="row g-4">
            {features.map((f, i) => (
              <div className="col-md-6 col-lg-4 reveal" key={i} style={{ transitionDelay: `${i * 80}ms` }}>
                <div className="feature-card">
                  <div className="feature-icon">
                    <i className={`bi ${f.icon}`}></i>
                  </div>
                  <h3 className="feature-title">{f.title}</h3>
                  <p className="feature-desc">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== How It Works ===== */}
      <section id="how" className="section-padding section-alt">
        <div className="container">
          <div className="text-center mb-5 reveal">
            <span className="section-eyebrow">How It Works</span>
            <h2 className="section-title">Create Your Perfect Resume in 3 Simple Steps</h2>
          </div>
          <div className="row g-4 align-items-stretch">
            {steps.map((s, i) => (
              <div className="col-lg-4 reveal" key={i} style={{ transitionDelay: `${i * 120}ms` }}>
                <div className="step-card">
                  <div className="step-number">{i + 1}</div>
                  <div className="step-icon"><i className={`bi ${s.icon}`}></i></div>
                  <h3 className="step-title">{s.title}</h3>
                  <p className="step-desc">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Live Demo / Generator ===== */}
      <section id="generator" className="section-padding" ref={generatorRef}>
        <div className="container">
          <div className="text-center mb-5 reveal">
            <span className="section-eyebrow">Live Demo</span>
            <h2 className="section-title">Try It Now — Free</h2>
            <p className="section-subtitle">Fill in your details and watch the AI generate your documents instantly.</p>
          </div>
          <div className="row g-4 justify-content-center">
            <div className="col-lg-5 reveal">
              <div className="generator-form-wrap">
                <form onSubmit={handleGenerate} noValidate>
                  <div className="mb-3">
                    <label className="form-label">Full Name <span className="req">*</span></label>
                    <input type="text" className="form-control" name="fullName" placeholder="e.g. John Doe" />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Target Job Role <span className="req">*</span></label>
                    <input type="text" className="form-control" name="jobRole" placeholder="e.g. Software Engineer" />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Years of Experience <span className="req">*</span></label>
                    <input type="number" className="form-control" name="years" placeholder="e.g. 5" min="0" />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Key Skills <span className="req">*</span></label>
                    <textarea className="form-control" name="skills" rows={2} placeholder="e.g. Python, SQL, React, Project Management"></textarea>
                    <small className="form-hint">Comma separated</small>
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Previous Experience <span className="text-muted">(optional)</span></label>
                    <textarea className="form-control" name="experience" rows={3} placeholder="Briefly describe your past roles and achievements..."></textarea>
                  </div>
                  {formError && <div className="form-error">{formError}</div>}
                  <button type="submit" className="btn btn-primary-cta w-100" disabled={loading}>
                    {loading ? (
                      <><span className="spinner-border spinner-border-sm me-2"></span>Generating with AI...</>
                    ) : (
                      <><i className="bi bi-cpu me-2"></i>Generate with AI</>
                    )}
                  </button>
                </form>
              </div>
            </div>

            <div className="col-lg-7 reveal">
              <div className="generator-output">
                {!generated && !loading && (
                  <div className="output-placeholder">
                    <i className="bi bi-file-earmark-text"></i>
                    <p>Your AI-generated resume, cover letter, and LinkedIn summary will appear here.</p>
                  </div>
                )}
                {loading && (
                  <div className="output-loading">
                    <div className="ai-pulse"></div>
                    <p>AI is crafting your documents...</p>
                    <span className="loading-sub">Analyzing your details and generating tailored content</span>
                  </div>
                )}
                {generated && (
                  <>
                    <ul className="nav custom-tabs">
                      <li>
                        <button className={activeTab === 'resume' ? 'active' : ''} onClick={() => setActiveTab('resume')}>
                          <i className="bi bi-file-earmark-text me-1"></i>Resume
                        </button>
                      </li>
                      <li>
                        <button className={activeTab === 'cover' ? 'active' : ''} onClick={() => setActiveTab('cover')}>
                          <i className="bi bi-envelope-paper me-1"></i>Cover Letter
                        </button>
                      </li>
                      <li>
                        <button className={activeTab === 'linkedin' ? 'active' : ''} onClick={() => setActiveTab('linkedin')}>
                          <i className="bi bi-linkedin me-1"></i>LinkedIn Summary
                        </button>
                      </li>
                    </ul>
                    <div className="tab-content-custom">
                      <pre className="generated-text">{generated[activeTab]}</pre>
                    </div>
                    <div className="output-actions">
                      <button className="btn btn-download" onClick={() => window.print()}>
                        <i className="bi bi-download me-2"></i>Download PDF
                      </button>
                      <button className="btn btn-outline-ghost" onClick={() => { navigator.clipboard?.writeText(generated[activeTab]); }}>
                        <i className="bi bi-clipboard me-2"></i>Copy Text
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Pricing ===== */}
      <section id="pricing" className="section-padding section-alt">
        <div className="container">
          <div className="text-center mb-5 reveal">
            <span className="section-eyebrow">Pricing</span>
            <h2 className="section-title">Simple & Transparent Pricing</h2>
            <p className="section-subtitle">Start free. Upgrade when you need more. All prices are illustrative.</p>
          </div>
          <div className="row g-4 justify-content-center">
            {plans.map((p, i) => (
              <div className="col-md-6 col-lg-4 reveal" key={i}>
                <div className={`pricing-card ${p.highlight ? 'pricing-highlight' : ''}`}>
                  {p.highlight && <span className="pricing-badge">Most Popular</span>}
                  <h3 className="pricing-name">{p.name}</h3>
                  <div className="pricing-price">
                    <span className="price-amount">{p.price}</span>
                    <span className="price-period">/ {p.period}</span>
                  </div>
                  <ul className="pricing-features">
                    {p.features.map((feat, j) => (
                      <li key={j}><i className="bi bi-check-circle-fill"></i>{feat}</li>
                    ))}
                  </ul>
                  <a href="#generator" className={`btn ${p.highlight ? 'btn-primary-cta' : 'btn-outline-ghost'} w-100`} onClick={(e) => { e.preventDefault(); scrollToGenerator(); }}>
                    {p.name === 'Free' ? 'Start Free' : `Get ${p.name}`}
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Testimonials ===== */}
      <section className="section-padding">
        <div className="container">
          <div className="text-center mb-5 reveal">
            <span className="section-eyebrow">Testimonials</span>
            <h2 className="section-title">Loved by Job Seekers</h2>
            <p className="section-subtitle">Real stories from users who transformed their job search. Demo content.</p>
          </div>
          <div className="row g-4">
            {testimonials.map((t, i) => (
              <div className="col-md-4 reveal" key={i} style={{ transitionDelay: `${i * 100}ms` }}>
                <div className="testimonial-card">
                  <div className="testimonial-stars">
                    <i className="bi bi-star-fill"></i><i className="bi bi-star-fill"></i><i className="bi bi-star-fill"></i><i className="bi bi-star-fill"></i><i className="bi bi-star-fill"></i>
                  </div>
                  <p className="testimonial-text">"{t.text}"</p>
                  <div className="testimonial-author">
                    <div className="ta-avatar">{t.name.charAt(0)}</div>
                    <div>
                      <div className="ta-name">{t.name}</div>
                      <div className="ta-role">{t.role}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FAQ ===== */}
      <section id="faq" className="section-padding section-alt">
        <div className="container">
          <div className="text-center mb-5 reveal">
            <span className="section-eyebrow">FAQ</span>
            <h2 className="section-title">Frequently Asked Questions</h2>
          </div>
          <div className="row justify-content-center">
            <div className="col-lg-8 reveal">
              <div className="accordion custom-accordion" id="faqAccordion">
                {faqs.map((f, i) => (
                  <div className="accordion-item" key={i}>
                    <h2 className="accordion-header">
                      <button
                        className={`accordion-button ${i !== 0 ? 'collapsed' : ''}`}
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target={`#faq${i}`}
                        aria-expanded={i === 0}
                        aria-controls={`faq${i}`}
                      >
                        {f.q}
                      </button>
                    </h2>
                    <div id={`faq${i}`} className={`accordion-collapse collapse ${i === 0 ? 'show' : ''}`} data-bs-parent="#faqAccordion">
                      <div className="accordion-body">{f.a}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Final CTA ===== */}
      <section className="final-cta-section">
        <div className="container">
          <div className="final-cta-box reveal">
            <h2>Ready to Land More Interviews?</h2>
            <p>Join thousands of job seekers who are creating better resumes with AI. It's free to start.</p>
            <a href="#generator" className="btn btn-primary-cta btn-lg" onClick={(e) => { e.preventDefault(); scrollToGenerator(); }}>
              <i className="bi bi-rocket-takeoff me-2"></i>Create My Resume Now
            </a>
          </div>
        </div>
      </section>

      {/* ===== Footer ===== */}
      <footer className="footer-section">
        <div className="container">
          <div className="row g-4">
            <div className="col-lg-4">
              <a className="navbar-brand d-flex align-items-center gap-2 mb-3" href="#home">
                <span className="brand-logo">
                  <i className="bi bi-file-earmark-ruled"></i>
                </span>
                <span className="brand-name">ResumeAI <span className="brand-accent">Pro</span></span>
              </a>
              <p className="footer-desc">
                AI-powered resume and cover letter builder. Create ATS-friendly, job-winning documents in minutes.
              </p>
            </div>
            <div className="col-lg-2 col-6">
              <h4 className="footer-heading">Quick Links</h4>
              <ul className="footer-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#features">Features</a></li>
                <li><a href="#how">How it Works</a></li>
                <li><a href="#pricing">Pricing</a></li>
                <li><a href="#faq">FAQ</a></li>
              </ul>
            </div>
            <div className="col-lg-3 col-6">
              <h4 className="footer-heading">Legal</h4>
              <ul className="footer-links">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Service</a></li>
                <li><a href="#">Cookie Policy</a></li>
              </ul>
            </div>
            <div className="col-lg-3">
              <h4 className="footer-heading">Contact</h4>
              <p className="footer-contact">
                <i className="bi bi-envelope me-2"></i>
                <a href="mailto:hello@resumeaipro.com">hello@resumeaipro.com</a>
              </p>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2026 ResumeAI Pro. All rights reserved. Prices shown are illustrative.</p>
          </div>
        </div>
      </footer>
    </>
  );
}

export default App;
