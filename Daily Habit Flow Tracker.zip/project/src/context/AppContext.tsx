import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react';
import type {
  AppData,
  Habit,
  HabitLog,
  Task,
  Goal,
  Challenge,
  ThemeMode,
} from '@/types';
import { uid } from '@/utils/id';
import { todayKey } from '@/utils/date';

const STORAGE_KEY = 'habitflow-data-v1';
const THEME_KEY = 'habitflow-theme-v1';

const emptyData: AppData = {
  habits: [],
  habitLogs: [],
  tasks: [],
  goals: [],
  challenges: [],
};

function loadData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyData;
    const parsed = JSON.parse(raw);
    return {
      habits: parsed.habits ?? [],
      habitLogs: parsed.habitLogs ?? [],
      tasks: parsed.tasks ?? [],
      goals: parsed.goals ?? [],
      challenges: parsed.challenges ?? [],
    };
  } catch {
    return emptyData;
  }
}

function loadTheme(): ThemeMode {
  try {
    const stored = localStorage.getItem(THEME_KEY);
    if (stored === 'light' || stored === 'dark') return stored;
  } catch {
    // ignore
  }
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    return 'dark';
  }
  return 'light';
}

interface AppContextValue {
  data: AppData;
  theme: ThemeMode;
  toggleTheme: () => void;
  setTheme: (mode: ThemeMode) => void;

  // Habits
  addHabit: (habit: Omit<Habit, 'id' | 'createdAt' | 'archived'>) => void;
  updateHabit: (id: string, updates: Partial<Habit>) => void;
  deleteHabit: (id: string) => void;
  toggleHabit: (habitId: string, dateKey: string, targetCount: number) => void;
  setHabitCount: (habitId: string, dateKey: string, count: number) => void;

  // Tasks
  addTask: (title: string, priority: Task['priority'], dateKey: string) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;

  // Goals
  addGoal: (goal: Omit<Goal, 'id' | 'createdAt' | 'current' | 'completed'>) => void;
  updateGoal: (id: string, updates: Partial<Goal>) => void;
  deleteGoal: (id: string) => void;

  // Challenges
  addChallenge: (challenge: Omit<Challenge, 'id' | 'createdAt' | 'status' | 'progress'>) => void;
  updateChallenge: (id: string, updates: Partial<Challenge>) => void;
  deleteChallenge: (id: string) => void;

  // Data management
  clearAllData: () => void;
  exportData: () => string;
  importData: (json: string) => boolean;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => loadData());
  const [theme, setThemeState] = useState<ThemeMode>(() => loadTheme());

  // Persist data to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // ignore quota errors
    }
  }, [data]);

  // Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  const setTheme = useCallback((mode: ThemeMode) => {
    setThemeState(mode);
  }, []);

  // ---- Habits ----
  const addHabit = useCallback((habit: Omit<Habit, 'id' | 'createdAt' | 'archived'>) => {
    const newHabit: Habit = {
      ...habit,
      id: uid(),
      createdAt: new Date().toISOString(),
      archived: false,
    };
    setData((prev) => ({ ...prev, habits: [...prev.habits, newHabit] }));
  }, []);

  const updateHabit = useCallback((id: string, updates: Partial<Habit>) => {
    setData((prev) => ({
      ...prev,
      habits: prev.habits.map((h) => (h.id === id ? { ...h, ...updates } : h)),
    }));
  }, []);

  const deleteHabit = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      habits: prev.habits.filter((h) => h.id !== id),
      habitLogs: prev.habitLogs.filter((l) => l.habitId !== id),
    }));
  }, []);

  const setHabitCount = useCallback((habitId: string, dateKey: string, count: number) => {
    setData((prev) => {
      const existing = prev.habitLogs.find(
        (l) => l.habitId === habitId && l.date === dateKey
      );
      if (existing) {
        if (count <= 0) {
          return {
            ...prev,
            habitLogs: prev.habitLogs.filter((l) => l.id !== existing.id),
          };
        }
        return {
          ...prev,
          habitLogs: prev.habitLogs.map((l) =>
            l.id === existing.id ? { ...l, count } : l
          ),
        };
      }
      if (count <= 0) return prev;
      const newLog: HabitLog = {
        id: uid(),
        habitId,
        date: dateKey,
        count,
        completedAt: new Date().toISOString(),
      };
      return { ...prev, habitLogs: [...prev.habitLogs, newLog] };
    });
  }, []);

  const toggleHabit = useCallback(
    (habitId: string, dateKey: string, targetCount: number) => {
      setData((prev) => {
        const existing = prev.habitLogs.find(
          (l) => l.habitId === habitId && l.date === dateKey
        );
        if (existing) {
          if (existing.count >= targetCount) {
            // Remove the log (un-complete)
            return {
              ...prev,
              habitLogs: prev.habitLogs.filter((l) => l.id !== existing.id),
            };
          }
          // Already has a partial count, bump to target
          return {
            ...prev,
            habitLogs: prev.habitLogs.map((l) =>
              l.id === existing.id ? { ...l, count: targetCount } : l
            ),
          };
        }
        // No existing log — create one at target count
        const newLog: HabitLog = {
          id: uid(),
          habitId,
          date: dateKey,
          count: targetCount,
          completedAt: new Date().toISOString(),
        };
        return { ...prev, habitLogs: [...prev.habitLogs, newLog] };
      });
    },
    []
  );

  // ---- Tasks ----
  const addTask = useCallback(
    (title: string, priority: Task['priority'], dateKey: string) => {
      const newTask: Task = {
        id: uid(),
        title,
        priority,
        completed: false,
        date: dateKey,
        createdAt: new Date().toISOString(),
      };
      setData((prev) => ({ ...prev, tasks: [...prev.tasks, newTask] }));
    },
    []
  );

  const updateTask = useCallback((id: string, updates: Partial<Task>) => {
    setData((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    }));
  }, []);

  const toggleTask = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) =>
        t.id === id ? { ...t, completed: !t.completed } : t
      ),
    }));
  }, []);

  const deleteTask = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => t.id !== id),
    }));
  }, []);

  // ---- Goals ----
  const addGoal = useCallback(
    (goal: Omit<Goal, 'id' | 'createdAt' | 'current' | 'completed'>) => {
      const newGoal: Goal = {
        ...goal,
        id: uid(),
        current: 0,
        completed: false,
        createdAt: new Date().toISOString(),
      };
      setData((prev) => ({ ...prev, goals: [...prev.goals, newGoal] }));
    },
    []
  );

  const updateGoal = useCallback((id: string, updates: Partial<Goal>) => {
    setData((prev) => ({
      ...prev,
      goals: prev.goals.map((g) => (g.id === id ? { ...g, ...updates } : g)),
    }));
  }, []);

  const deleteGoal = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      goals: prev.goals.filter((g) => g.id !== id),
    }));
  }, []);

  // ---- Challenges ----
  const addChallenge = useCallback(
    (challenge: Omit<Challenge, 'id' | 'createdAt' | 'status' | 'progress'>) => {
      const newChallenge: Challenge = {
        ...challenge,
        id: uid(),
        status: 'active',
        progress: 0,
        createdAt: new Date().toISOString(),
      };
      setData((prev) => ({ ...prev, challenges: [...prev.challenges, newChallenge] }));
    },
    []
  );

  const updateChallenge = useCallback((id: string, updates: Partial<Challenge>) => {
    setData((prev) => ({
      ...prev,
      challenges: prev.challenges.map((c) =>
        c.id === id ? { ...c, ...updates } : c
      ),
    }));
  }, []);

  const deleteChallenge = useCallback((id: string) => {
    setData((prev) => ({
      ...prev,
      challenges: prev.challenges.filter((c) => c.id !== id),
    }));
  }, []);

  // ---- Data management ----
  const clearAllData = useCallback(() => {
    setData(emptyData);
  }, []);

  const exportData = useCallback(() => JSON.stringify(data, null, 2), [data]);

  const importData = useCallback((json: string) => {
    try {
      const parsed = JSON.parse(json);
      setData({
        habits: parsed.habits ?? [],
        habitLogs: parsed.habitLogs ?? [],
        tasks: parsed.tasks ?? [],
        goals: parsed.goals ?? [],
        challenges: parsed.challenges ?? [],
      });
      return true;
    } catch {
      return false;
    }
  }, []);

  const value: AppContextValue = {
    data,
    theme,
    toggleTheme,
    setTheme,
    addHabit,
    updateHabit,
    deleteHabit,
    toggleHabit,
    setHabitCount,
    addTask,
    updateTask,
    toggleTask,
    deleteTask,
    addGoal,
    updateGoal,
    deleteGoal,
    addChallenge,
    updateChallenge,
    deleteChallenge,
    clearAllData,
    exportData,
    importData,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
