import { Menu, Flame } from 'lucide-react';
import type { ViewName } from '@/types';

interface MobileHeaderProps {
  onMenuClick: () => void;
  view: ViewName;
}

const TITLES: Record<ViewName, string> = {
  dashboard: 'Dashboard',
  habits: 'Habits',
  tasks: 'Tasks',
  calendar: 'Calendar',
  goals: 'Goals & Challenges',
  analytics: 'Analytics',
  settings: 'Settings',
};

export default function MobileHeader({ onMenuClick, view }: MobileHeaderProps) {
  return (
    <header className="lg:hidden sticky top-0 z-20 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700 px-4 py-3 flex items-center justify-between">
      <button
        onClick={onMenuClick}
        className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
        aria-label="Open menu"
      >
        <Menu size={22} />
      </button>
      <div className="flex items-center gap-2">
        <Flame className="text-primary-500" size={20} />
        <span className="font-semibold text-slate-800 dark:text-white">
          {TITLES[view]}
        </span>
      </div>
      <div className="w-10" />
    </header>
  );
}
