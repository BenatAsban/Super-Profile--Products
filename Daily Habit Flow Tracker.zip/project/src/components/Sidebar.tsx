import type { ViewName } from '@/types';
import { useApp } from '@/context/AppContext';
import {
  LayoutDashboard,
  CheckCircle2,
  ListTodo,
  Calendar,
  Target,
  BarChart3,
  Settings,
  Moon,
  Sun,
  Flame,
  CheckSquare,
} from 'lucide-react';
import { todayKey } from '@/utils/date';
import { isHabitCompleted } from '@/utils/habit';

interface SidebarProps {
  currentView: ViewName;
  onNavigate: (view: ViewName) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: { view: ViewName; label: string; icon: typeof LayoutDashboard }[] = [
  { view: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { view: 'habits', label: 'Habits', icon: CheckCircle2 },
  { view: 'tasks', label: 'Tasks', icon: ListTodo },
  { view: 'calendar', label: 'Calendar', icon: Calendar },
  { view: 'goals', label: 'Goals', icon: Target },
  { view: 'analytics', label: 'Analytics', icon: BarChart3 },
  { view: 'settings', label: 'Settings', icon: Settings },
];

export default function Sidebar({
  currentView,
  onNavigate,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const { data, theme, toggleTheme } = useApp();
  const today = todayKey();

  const activeHabits = data.habits.filter((h) => !h.archived);
  const completedToday = activeHabits.filter((h) =>
    isHabitCompleted(h, today, data.habitLogs)
  ).length;
  const tasksToday = data.tasks.filter((t) => t.date === today);
  const tasksDone = tasksToday.filter((t) => t.completed).length;

  const sidebarContent = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-lg shadow-primary-500/30">
          <Flame className="text-white" size={22} />
        </div>
        <div>
          <h1 className="text-lg font-bold text-slate-800 dark:text-white leading-tight">
            HabitFlow
          </h1>
          <p className="text-xs text-slate-400 dark:text-slate-500">
            Daily Habit Tracker
          </p>
        </div>
      </div>

      {/* Quick stats */}
      <div className="px-4 mb-4">
        <div className="card p-4 space-y-2.5">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
              <CheckCircle2 size={15} className="text-primary-500" />
              Habits
            </span>
            <span className="font-semibold text-slate-700 dark:text-slate-200">
              {completedToday}/{activeHabits.length}
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
              <CheckSquare size={15} className="text-accent-500" />
              Tasks
            </span>
            <span className="font-semibold text-slate-700 dark:text-slate-200">
              {tasksDone}/{tasksToday.length}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = currentView === item.view;
          return (
            <button
              key={item.view}
              onClick={() => {
                onNavigate(item.view);
                onCloseMobile();
              }}
              className={`nav-item w-full ${active ? 'nav-item-active' : ''}`}
            >
              <Icon size={20} />
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Theme toggle */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-700">
        <button
          onClick={toggleTheme}
          className="nav-item w-full"
        >
          {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex fixed left-0 top-0 h-screen w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 z-30">
        {sidebarContent}
      </aside>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <>
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 lg:hidden animate-fade-in"
            onClick={onCloseMobile}
          />
          <aside className="fixed left-0 top-0 h-screen w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 z-50 lg:hidden animate-slide-up">
            {sidebarContent}
          </aside>
        </>
      )}
    </>
  );
}
