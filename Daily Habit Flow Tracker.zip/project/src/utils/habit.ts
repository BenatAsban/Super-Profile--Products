import type { Habit, HabitLog } from '@/types';
import { todayKey, addDays, formatDateKey, parseDateKey } from './date';

/**
 * Calculate the current streak for a habit based on its logs.
 */
export function calculateStreak(habit: Habit, logs: HabitLog[]): number {
  const habitLogs = logs
    .filter((l) => l.habitId === habit.id && l.count >= habit.targetCount)
    .map((l) => l.date)
    .sort((a, b) => b.localeCompare(a));

  if (habitLogs.length === 0) return 0;

  // Check if the most recent completed day is today or yesterday
  const today = todayKey();
  const yesterday = formatDateKey(addDays(new Date(), -1));

  if (habitLogs[0] !== today && habitLogs[0] !== yesterday) {
    return 0;
  }

  let streak = 0;
  let expected = habitLogs[0] === today ? today : yesterday;

  for (const logDate of habitLogs) {
    if (logDate === expected) {
      streak++;
      expected = formatDateKey(addDays(parseDateKey(expected), -1));
    } else if (logDate < expected) {
      break;
    }
  }

  return streak;
}

/**
 * Get the longest streak for a habit.
 */
export function calculateLongestStreak(habit: Habit, logs: HabitLog[]): number {
  const habitLogs = logs
    .filter((l) => l.habitId === habit.id && l.count >= habit.targetCount)
    .map((l) => l.date)
    .sort();

  if (habitLogs.length === 0) return 0;

  let longest = 1;
  let current = 1;

  for (let i = 1; i < habitLogs.length; i++) {
    const prev = parseDateKey(habitLogs[i - 1]);
    const curr = parseDateKey(habitLogs[i]);
    const diff = Math.round((curr.getTime() - prev.getTime()) / 86400000);

    if (diff === 1) {
      current++;
      longest = Math.max(longest, current);
    } else {
      current = 1;
    }
  }

  return longest;
}

/**
 * Get the completion count for a habit on a specific date.
 */
export function getHabitCountOnDate(
  habitId: string,
  dateKey: string,
  logs: HabitLog[]
): number {
  const log = logs.find(
    (l) => l.habitId === habitId && l.date === dateKey
  );
  return log?.count ?? 0;
}

/**
 * Check if a habit is completed on a given date.
 */
export function isHabitCompleted(
  habit: Habit,
  dateKey: string,
  logs: HabitLog[]
): boolean {
  return getHabitCountOnDate(habit.id, dateKey, logs) >= habit.targetCount;
}

/**
 * Get completion rate for a date range.
 */
export function getCompletionRate(
  habits: Habit[],
  logs: HabitLog[],
  dateKeys: string[]
): number {
  const activeHabits = habits.filter((h) => !h.archived);
  if (activeHabits.length === 0 || dateKeys.length === 0) return 0;

  let total = 0;
  let completed = 0;

  for (const habit of activeHabits) {
    for (const dateKey of dateKeys) {
      total++;
      if (isHabitCompleted(habit, dateKey, logs)) {
        completed++;
      }
    }
  }

  return total > 0 ? Math.round((completed / total) * 100) : 0;
}

/**
 * Get the last N days as date keys.
 */
export function getLastNDays(n: number): string[] {
  const days: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    days.push(formatDateKey(addDays(new Date(), -i)));
  }
  return days;
}

/**
 * Get total completions for a habit.
 */
export function getTotalCompletions(habit: Habit, logs: HabitLog[]): number {
  return logs.filter(
    (l) => l.habitId === habit.id && l.count >= habit.targetCount
  ).length;
}
