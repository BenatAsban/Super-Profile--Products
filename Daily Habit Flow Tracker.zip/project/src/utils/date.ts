export function formatDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseDateKey(key: string): Date {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function todayKey(): string {
  return formatDateKey(new Date());
}

export function isSameDay(a: Date, b: Date): boolean {
  return formatDateKey(a) === formatDateKey(b);
}

export function isToday(key: string): boolean {
  return key === todayKey();
}

export function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

export function startOfWeek(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  d.setDate(d.getDate() - day);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function endOfWeek(date: Date): Date {
  return addDays(startOfWeek(date), 6);
}

export function startOfMonth(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

export function endOfMonth(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0);
}

export function getWeekDays(date: Date): Date[] {
  const start = startOfWeek(date);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

export function getMonthDays(date: Date): Date[] {
  const start = startOfMonth(date);
  const startDay = start.getDay();
  const days: Date[] = [];
  // Leading days from previous month
  for (let i = 0; i < startDay; i++) {
    days.unshift(addDays(start, -i - 1));
  }
  // All days of current month
  const end = endOfMonth(date);
  let current = start;
  while (current <= end) {
    days.push(current);
    current = addDays(current, 1);
  }
  // Trailing days to fill the grid (6 rows)
  while (days.length < 42) {
    const last = days[days.length - 1];
    days.push(addDays(last, 1));
  }
  return days;
}

export function formatDateLong(date: Date): string {
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function formatDateShort(date: Date): string {
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
}

export function formatWeekday(date: Date): string {
  return date.toLocaleDateString('en-US', { weekday: 'short' });
}

export function formatMonth(date: Date): string {
  return date.toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });
}

export function relativeDay(key: string): string {
  const today = todayKey();
  const yesterday = formatDateKey(addDays(new Date(), -1));
  const tomorrow = formatDateKey(addDays(new Date(), 1));
  if (key === today) return 'Today';
  if (key === yesterday) return 'Yesterday';
  if (key === tomorrow) return 'Tomorrow';
  return formatDateShort(parseDateKey(key));
}

export function daysBetween(a: string, b: string): number {
  const d1 = parseDateKey(a);
  const d2 = parseDateKey(b);
  return Math.round((d2.getTime() - d1.getTime()) / 86400000);
}
