import { useState } from 'react';
import { AppProvider } from '@/context/AppContext';
import Sidebar from '@/components/Sidebar';
import MobileHeader from '@/components/MobileHeader';
import Dashboard from '@/views/Dashboard';
import Habits from '@/views/Habits';
import Tasks from '@/views/Tasks';
import CalendarView from '@/views/CalendarView';
import Goals from '@/views/Goals';
import Analytics from '@/views/Analytics';
import Settings from '@/views/Settings';
import type { ViewName } from '@/types';

function AppContent() {
  const [view, setView] = useState<ViewName>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  function renderView() {
    switch (view) {
      case 'dashboard':
        return <Dashboard onNavigate={setView} />;
      case 'habits':
        return <Habits />;
      case 'tasks':
        return <Tasks />;
      case 'calendar':
        return <CalendarView />;
      case 'goals':
        return <Goals />;
      case 'analytics':
        return <Analytics />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard onNavigate={setView} />;
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-200">
      <Sidebar
        currentView={view}
        onNavigate={setView}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />
      <MobileHeader onMenuClick={() => setMobileMenuOpen(true)} view={view} />
      <main className="lg:ml-64 min-h-screen">
        <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto">
          {renderView()}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
