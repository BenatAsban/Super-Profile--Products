export type HabitFrequency = 'daily' | 'weekly';

export type HabitColor =
  | 'blue'
  | 'green'
  | 'amber'
  | 'red'
  | 'teal'
  | 'purple'
  | 'pink';

export interface Habit {
  id: string;
  name: string;
  icon: string;
  color: HabitColor;
  frequency: HabitFrequency;
  targetCount: number;
  createdAt: string;
  archived: boolean;
}

export interface HabitLog {
  id: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  count: number;
  completedAt: string;
}

export type TaskPriority = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  title: string;
  priority: TaskPriority;
  completed: boolean;
  date: string; // YYYY-MM-DD
  createdAt: string;
}

export type GoalType = 'habit-streak' | 'completion-count' | 'task-count';

export interface Goal {
  id: string;
  title: string;
  description: string;
  type: GoalType;
  target: number;
  current: number;
  deadline: string;
  completed: boolean;
  createdAt: string;
}

export type ChallengeStatus = 'active' | 'completed' | 'abandoned';

export interface Challenge {
  id: string;
  title: string;
  description: string;
  durationDays: number;
  startDate: string;
  status: ChallengeStatus;
  progress: number;
  createdAt: string;
}

export type ThemeMode = 'light' | 'dark';

export type ViewName =
  | 'dashboard'
  | 'habits'
  | 'tasks'
  | 'calendar'
  | 'goals'
  | 'analytics'
  | 'settings';

export interface AppData {
  habits: Habit[];
  habitLogs: HabitLog[];
  tasks: Task[];
  goals: Goal[];
  challenges: Challenge[];
}

export const HABIT_COLORS: Record<
  HabitColor,
  { bg: string; text: string; ring: string; dot: string; gradient: string }
> = {
  blue: {
    bg: 'bg-blue-50 dark:bg-blue-900/20',
    text: 'text-blue-600 dark:text-blue-400',
    ring: 'stroke-blue-500',
    dot: 'bg-blue-500',
    gradient: 'from-blue-400 to-blue-600',
  },
  green: {
    bg: 'bg-green-50 dark:bg-green-900/20',
    text: 'text-green-600 dark:text-green-400',
    ring: 'stroke-green-500',
    dot: 'bg-green-500',
    gradient: 'from-green-400 to-green-600',
  },
  amber: {
    bg: 'bg-amber-50 dark:bg-amber-900/20',
    text: 'text-amber-600 dark:text-amber-400',
    ring: 'stroke-amber-500',
    dot: 'bg-amber-500',
    gradient: 'from-amber-400 to-amber-600',
  },
  red: {
    bg: 'bg-red-50 dark:bg-red-900/20',
    text: 'text-red-600 dark:text-red-400',
    ring: 'stroke-red-500',
    dot: 'bg-red-500',
    gradient: 'from-red-400 to-red-600',
  },
  teal: {
    bg: 'bg-teal-50 dark:bg-teal-900/20',
    text: 'text-teal-600 dark:text-teal-400',
    ring: 'stroke-teal-500',
    dot: 'bg-teal-500',
    gradient: 'from-teal-400 to-teal-600',
  },
  purple: {
    bg: 'bg-purple-50 dark:bg-purple-900/20',
    text: 'text-purple-600 dark:text-purple-400',
    ring: 'stroke-purple-500',
    dot: 'bg-purple-500',
    gradient: 'from-purple-400 to-purple-600',
  },
  pink: {
    bg: 'bg-pink-50 dark:bg-pink-900/20',
    text: 'text-pink-600 dark:text-pink-400',
    ring: 'stroke-pink-500',
    dot: 'bg-pink-500',
    gradient: 'from-pink-400 to-pink-600',
  },
};
