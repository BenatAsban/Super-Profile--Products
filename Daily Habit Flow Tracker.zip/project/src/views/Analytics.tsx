import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { HABIT_COLORS } from '@/types';
import {
  formatDateKey,
  addDays,
  parseDateKey,
  formatWeekday,
  startOfWeek,
} from '@/utils/date';
import {
  isHabitCompleted,
  calculateStreak,
  calculateLongestStreak,
  getTotalCompletions,
  getCompletionRate,
  getLastNDays,
} from '@/utils/habit';
import {
  BarChart3,
  TrendingUp,
  Flame,
  Trophy,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import EmptyState from '@/components/EmptyState';

type Period = 'week' | 'month';

export default function Analytics() {
  const { data } = useApp();
  const [period, setPeriod] = useState<Period>('week');
  const activeHabits = data.habits.filter((h) => !h.archived);

  // Weekly data (last 7 days)
  const last7 = getLastNDays(7);
  const weeklyData = last7.map((dateKey) => {
    const completed = activeHabits.filter((h) =>
      isHabitCompleted(h, dateKey, data.habitLogs)
    ).length;
    return {
      dateKey,
      day: formatWeekday(parseDateKey(dateKey)),
      completed,
      total: activeHabits.length,
    };
  });
  const weeklyRate = getCompletionRate(activeHabits, data.habitLogs, last7);

  // Monthly data (last 30 days as 4-5 weeks)
  const last30 = getLastNDays(30);
  const monthlyRate = getCompletionRate(activeHabits, data.habitLogs, last30);

  // Group monthly data by week
  const weeklyGroups: { label: string; completed: number; total: number }[] = [];
  const sw = startOfWeek(new Date());
  for (let i = 4; i >= 0; i--) {
    const weekStart = addDays(sw, -7 * i);
    const weekEnd = addDays(weekStart, 6);
    const startKey = formatDateKey(weekStart);
    const endKey = formatDateKey(weekEnd);
    const weekDays = last30.filter((d) => d >= startKey && d <= endKey);
    if (weekDays.length === 0) continue;
    const completed = activeHabits.reduce((sum, h) => {
      return sum + weekDays.filter((d) => isHabitCompleted(h, d, data.habitLogs)).length;
    }, 0);
    weeklyGroups.push({
      label: `${formatWeekday(weekStart)} ${weekStart.getDate()}`,
      completed,
      total: activeHabits.length * weekDays.length,
    });
  }

  const chartData = period === 'week' ? weeklyData : weeklyGroups;
  const maxVal = Math.max(1, ...chartData.map((d) => 'total' in d ? d.completed : (d as typeof weeklyData[0]).completed));

  // Per-habit stats
  const habitStats = activeHabits
    .map((h) => ({
      habit: h,
      streak: calculateStreak(h, data.habitLogs),
      longest: calculateLongestStreak(h, data.habitLogs),
      total: getTotalCompletions(h, data.habitLogs),
      last7: last7.filter((d) => isHabitCompleted(h, d, data.habitLogs)).length,
      last30: last30.filter((d) => isHabitCompleted(h, d, data.habitLogs)).length,
    }))
    .sort((a, b) => b.total - a.total);

  // Overall stats
  const totalCompletions = data.habitLogs.length;
  const bestStreak = Math.max(0, ...habitStats.map((s) => s.longest));
  const currentBestStreak = Math.max(0, ...habitStats.map((s) => s.streak));

  if (activeHabits.length === 0) {
    return (
      <div className="space-y-6 animate-fade-in">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Analytics</h1>
        <div className="card">
          <EmptyState
            icon={<BarChart3 size={28} />}
            title="No data to analyze yet"
            description="Create habits and start tracking them to see your analytics, streaks, and progress over time."
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Analytics</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Track your progress and identify trends
          </p>
        </div>
        {/* Period toggle */}
        <div className="flex bg-slate-100 dark:bg-slate-700 rounded-xl p-1">
          {(['week', 'month'] as Period[]).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                period === p
                  ? 'bg-white dark:bg-slate-800 text-primary-600 dark:text-primary-400 shadow-sm'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {p === 'week' ? 'This Week' : 'This Month'}
            </button>
          ))}
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-primary-50 dark:bg-primary-900/20 flex items-center justify-center">
              <TrendingUp className="text-primary-600 dark:text-primary-400" size={20} />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-800 dark:text-white">
            {period === 'week' ? weeklyRate : monthlyRate}%
          </p>
          <p className="text-xs text-slate-400 mt-1">
            {period === 'week' ? 'Weekly completion' : 'Monthly completion'}
          </p>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-orange-50 dark:bg-orange-900/20 flex items-center justify-center">
              <Flame className="text-orange-500" size={20} />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-800 dark:text-white">
            {currentBestStreak}
          </p>
          <p className="text-xs text-slate-400 mt-1">Current best streak</p>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-900/20 flex items-center justify-center">
              <Trophy className="text-amber-500" size={20} />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-800 dark:text-white">
            {bestStreak}
          </p>
          <p className="text-xs text-slate-400 mt-1">Longest streak ever</p>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-success-50 dark:bg-success-900/20 flex items-center justify-center">
              <CheckCircle2 className="text-success-500" size={20} />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-800 dark:text-white">
            {totalCompletions}
          </p>
          <p className="text-xs text-slate-400 mt-1">Total completions</p>
        </div>
      </div>

      {/* Chart */}
      <div className="card p-6">
        <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-4">
          {period === 'week' ? 'Daily Completions' : 'Weekly Completions'}
        </h2>
        <div className="flex items-end justify-between gap-2 sm:gap-4 h-48">
          {chartData.map((d, i) => {
            const completed = d.completed;
            const heightPct = (completed / maxVal) * 100;
            const label = period === 'week'
              ? (d as typeof weeklyData[0]).day
              : (d as typeof weeklyGroups[0]).label;
            return (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {completed}
                </span>
                <div className="w-full flex-1 flex items-end">
                  <div
                    className="w-full rounded-t-lg bg-gradient-to-t from-primary-600 to-primary-400 transition-all duration-700 ease-out hover:from-primary-700 hover:to-primary-500"
                    style={{ height: `${Math.max(2, heightPct)}%` }}
                  />
                </div>
                <span className="text-xs text-slate-400 dark:text-slate-500 truncate w-full text-center">
                  {label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Per-habit breakdown */}
      <div className="card p-6">
        <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-4">
          Habit Breakdown
        </h2>
        <div className="space-y-4">
          {habitStats.map(({ habit, streak, longest, total, last7, last30 }) => {
            const colors = HABIT_COLORS[habit.color];
            const last7Rate = activeHabits.length > 0 ? Math.round((last7 / 7) * 100) : 0;
            return (
              <div key={habit.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{habit.icon}</span>
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-200">
                      {habit.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="flex items-center gap-1 text-orange-500 font-medium">
                      <Flame size={12} /> {streak}
                    </span>
                    <span className="flex items-center gap-1 text-amber-500 font-medium">
                      <Trophy size={12} /> {longest}
                    </span>
                    <span className="flex items-center gap-1 text-primary-500 font-medium">
                      <CheckCircle2 size={12} /> {total}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${colors.dot} transition-all duration-500`}
                      style={{ width: `${last7Rate}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-400 w-20 text-right">
                    {last7}/7 this week
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 30-day heatmap */}
      <div className="card p-6">
        <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
          <Calendar size={18} className="text-primary-500" />
          30-Day Activity
        </h2>
        <div className="grid grid-cols-10 gap-1.5 sm:grid-cols-15">
          {last30.map((dateKey) => {
            const completed = activeHabits.filter((h) =>
              isHabitCompleted(h, dateKey, data.habitLogs)
            ).length;
            const rate = activeHabits.length > 0 ? completed / activeHabits.length : 0;
            const opacity = rate === 0 ? 0.15 : Math.max(0.3, rate);
            return (
              <div
                key={dateKey}
                className="aspect-square rounded-md transition-all hover:scale-110 cursor-default"
                style={{
                  backgroundColor: `rgba(59, 130, 246, ${opacity})`,
                }}
                title={`${formatDateKey(parseDateKey(dateKey))}: ${completed}/${activeHabits.length}`}
              />
            );
          })}
        </div>
        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-slate-400">Less</span>
          <div className="flex gap-1">
            {[0.15, 0.3, 0.5, 0.7, 1].map((o) => (
              <div
                key={o}
                className="w-4 h-4 rounded"
                style={{ backgroundColor: `rgba(59, 130, 246, ${o})` }}
              />
            ))}
          </div>
          <span className="text-xs text-slate-400">More</span>
        </div>
      </div>
    </div>
  );
}
