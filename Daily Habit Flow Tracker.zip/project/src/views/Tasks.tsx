import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import type { TaskPriority } from '@/types';
import { todayKey, formatDateKey, addDays, relativeDay, parseDateKey, formatDateShort } from '@/utils/date';
import EmptyState from '@/components/EmptyState';
import Modal from '@/components/Modal';
import {
  Plus,
  ListTodo,
  Trash2,
  Pencil,
  Flag,
  Check,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

const PRIORITY_CONFIG: Record<
  TaskPriority,
  { label: string; color: string; dot: string; bg: string }
> = {
  high: {
    label: 'High',
    color: 'text-error-600 dark:text-error-400',
    dot: 'bg-error-500',
    bg: 'bg-error-50 dark:bg-error-900/20',
  },
  medium: {
    label: 'Medium',
    color: 'text-warning-600 dark:text-warning-400',
    dot: 'bg-warning-500',
    bg: 'bg-warning-50 dark:bg-warning-900/20',
  },
  low: {
    label: 'Low',
    color: 'text-success-600 dark:text-success-400',
    dot: 'bg-success-500',
    bg: 'bg-success-50 dark:bg-success-900/20',
  },
};

const PRIORITY_ORDER: Record<TaskPriority, number> = { high: 0, medium: 1, low: 2 };

export default function Tasks() {
  const { data, addTask, updateTask, toggleTask, deleteTask } = useApp();
  const [selectedDate, setSelectedDate] = useState(todayKey());
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [taskDate, setTaskDate] = useState(todayKey());

  function openAdd() {
    setEditingTask(null);
    setTitle('');
    setPriority('medium');
    setTaskDate(selectedDate);
    setModalOpen(true);
  }

  function openEdit(id: string) {
    const task = data.tasks.find((t) => t.id === id);
    if (!task) return;
    setEditingTask(id);
    setTitle(task.title);
    setPriority(task.priority);
    setTaskDate(task.date);
    setModalOpen(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    if (editingTask) {
      updateTask(editingTask, { title: title.trim(), priority, date: taskDate });
    } else {
      addTask(title.trim(), priority, taskDate);
    }
    setModalOpen(false);
  }

  function shiftDate(days: number) {
    const d = parseDateKey(selectedDate);
    const newDate = formatDateKey(addDays(d, days));
    setSelectedDate(newDate);
  }

  const dayTasks = data.tasks
    .filter((t) => t.date === selectedDate)
    .sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      return PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority];
    });

  const completedCount = dayTasks.filter((t) => t.completed).length;
  const isToday = selectedDate === todayKey();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Tasks</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Stay organized with daily to-dos
          </p>
        </div>
        <button onClick={openAdd} className="btn-primary">
          <Plus size={18} /> New Task
        </button>
      </div>

      {/* Date selector */}
      <div className="card p-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => shiftDate(-1)}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          <div className="text-center">
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">
              {relativeDay(selectedDate)}
            </p>
            <p className="text-xs text-slate-400">{formatDateShort(parseDateKey(selectedDate))}</p>
          </div>
          <button
            onClick={() => shiftDate(1)}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>
        {!isToday && (
          <div className="mt-3">
            <button
              onClick={() => setSelectedDate(todayKey())}
              className="w-full py-2 rounded-lg bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 text-sm font-medium hover:bg-primary-100 dark:hover:bg-primary-900/30 transition-colors flex items-center justify-center gap-2"
            >
              <CalendarIcon size={15} /> Back to today
            </button>
          </div>
        )}
      </div>

      {/* Progress bar */}
      {dayTasks.length > 0 && (
        <div className="flex items-center gap-3">
          <div className="flex-1 h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-accent-400 to-accent-600 transition-all duration-500"
              style={{
                width: `${(completedCount / dayTasks.length) * 100}%`,
              }}
            />
          </div>
          <span className="text-sm font-medium text-slate-500 dark:text-slate-400">
            {completedCount}/{dayTasks.length}
          </span>
        </div>
      )}

      {/* Tasks list */}
      {dayTasks.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={<ListTodo size={28} />}
            title="No tasks for this day"
            description="Add a task to keep track of what you need to get done."
            action={
              <button onClick={openAdd} className="btn-primary">
                <Plus size={16} /> Add task
              </button>
            }
          />
        </div>
      ) : (
        <div className="space-y-2">
          {dayTasks.map((task) => {
            const prio = PRIORITY_CONFIG[task.priority];
            return (
              <div
                key={task.id}
                className={`card p-4 flex items-center gap-3 ${
                  task.completed ? 'opacity-60' : ''
                }`}
              >
                {/* Checkbox */}
                <button
                  onClick={() => toggleTask(task.id)}
                  className={`flex-shrink-0 w-6 h-6 rounded-md border-2 flex items-center justify-center transition-all ${
                    task.completed
                      ? 'bg-accent-500 border-accent-500'
                      : 'border-slate-300 dark:border-slate-600 hover:border-accent-400'
                  }`}
                  aria-label={task.completed ? 'Mark incomplete' : 'Mark complete'}
                >
                  {task.completed && <Check className="text-white" size={16} />}
                </button>

                {/* Priority indicator */}
                <span className={`w-2 h-2 rounded-full ${prio.dot}`} />

                {/* Title */}
                <span
                  className={`flex-1 text-sm ${
                    task.completed
                      ? 'text-slate-400 line-through'
                      : 'text-slate-700 dark:text-slate-200'
                  }`}
                >
                  {task.title}
                </span>

                {/* Priority badge */}
                <span
                  className={`text-xs font-medium px-2 py-1 rounded-md ${prio.bg} ${prio.color} flex items-center gap-1`}
                >
                  <Flag size={11} /> {prio.label}
                </span>

                {/* Actions */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEdit(task.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors"
                    aria-label="Edit task"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    onClick={() => deleteTask(task.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-error-500 hover:bg-error-50 dark:hover:bg-error-900/20 transition-colors"
                    aria-label="Delete task"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingTask ? 'Edit Task' : 'New Task'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Task
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What needs to be done?"
              className="input-field"
              autoFocus
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Priority
            </label>
            <div className="flex gap-2">
              {(['high', 'medium', 'low'] as TaskPriority[]).map((p) => {
                const cfg = PRIORITY_CONFIG[p];
                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                      priority === p
                        ? `${cfg.bg} ${cfg.color} ring-2 ring-current ring-opacity-30`
                        : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                    {cfg.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Date
            </label>
            <input
              type="date"
              value={taskDate}
              onChange={(e) => setTaskDate(e.target.value)}
              className="input-field"
              required
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1">
              {editingTask ? 'Save Changes' : 'Add Task'}
            </button>
            <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
