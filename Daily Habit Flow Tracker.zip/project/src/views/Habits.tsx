import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { HABIT_COLORS, type Habit, type HabitColor, type HabitFrequency } from '@/types';
import { todayKey } from '@/utils/date';
import {
  isHabitCompleted,
  calculateStreak,
  calculateLongestStreak,
  getTotalCompletions,
} from '@/utils/habit';
import Modal from '@/components/Modal';
import EmptyState from '@/components/EmptyState';
import {
  Plus,
  Flame,
  CheckCircle2,
  Pencil,
  Trash2,
  Repeat,
  Trophy,
  X,
} from 'lucide-react';

const ICON_OPTIONS = [
  '💪', '🏃', '📚', '🧘', '💧', '🥗', '😴', '🧠',
  '✍️', '🎯', '🎨', '🎸', '💻', '🌱', '☀️', '🦷',
  '💊', '🚭', '🚶', '🚴', '🏋️', '⏰', '📝', '🙏',
];

const COLOR_OPTIONS: HabitColor[] = ['blue', 'green', 'amber', 'red', 'teal', 'purple', 'pink'];

export default function Habits() {
  const { data, addHabit, updateHabit, deleteHabit, toggleHabit } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('💪');
  const [color, setColor] = useState<HabitColor>('blue');
  const [frequency, setFrequency] = useState<HabitFrequency>('daily');
  const [targetCount, setTargetCount] = useState(1);

  const today = todayKey();
  const activeHabits = data.habits.filter((h) => !h.archived);

  function openAdd() {
    setEditingHabit(null);
    setName('');
    setIcon('💪');
    setColor('blue');
    setFrequency('daily');
    setTargetCount(1);
    setModalOpen(true);
  }

  function openEdit(habit: Habit) {
    setEditingHabit(habit);
    setName(habit.name);
    setIcon(habit.icon);
    setColor(habit.color);
    setFrequency(habit.frequency);
    setTargetCount(habit.targetCount);
    setModalOpen(true);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    if (editingHabit) {
      updateHabit(editingHabit.id, {
        name: name.trim(),
        icon,
        color,
        frequency,
        targetCount: Math.max(1, targetCount),
      });
    } else {
      addHabit({ name: name.trim(), icon, color, frequency, targetCount: Math.max(1, targetCount) });
    }
    setModalOpen(false);
  }

  function handleDelete(id: string) {
    deleteHabit(id);
    setConfirmDelete(null);
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Habits</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Build routines that stick
          </p>
        </div>
        <button onClick={openAdd} className="btn-primary">
          <Plus size={18} /> New Habit
        </button>
      </div>

      {/* Habits list */}
      {activeHabits.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={<Flame size={28} />}
            title="No habits yet"
            description="Create your first habit to start building a daily routine. Track streaks, set targets, and watch your progress grow."
            action={
              <button onClick={openAdd} className="btn-primary">
                <Plus size={16} /> Create habit
              </button>
            }
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeHabits.map((habit) => {
            const colors = HABIT_COLORS[habit.color];
            const completed = isHabitCompleted(habit, today, data.habitLogs);
            const streak = calculateStreak(habit, data.habitLogs);
            const longest = calculateLongestStreak(habit, data.habitLogs);
            const total = getTotalCompletions(habit, data.habitLogs);

            return (
              <div key={habit.id} className="card card-hover p-5">
                {/* Top row */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-xl ${colors.bg} flex items-center justify-center text-2xl`}
                    >
                      {habit.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-800 dark:text-slate-100">
                        {habit.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={`text-xs ${colors.text} font-medium capitalize`}>
                          {habit.color}
                        </span>
                        {habit.targetCount > 1 && (
                          <span className="text-xs text-slate-400">
                            × {habit.targetCount}/day
                          </span>
                        )}
                        {habit.frequency === 'weekly' && (
                          <span className="flex items-center gap-1 text-xs text-slate-400">
                            <Repeat size={11} /> weekly
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEdit(habit)}
                      className="p-2 rounded-lg text-slate-400 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors"
                      aria-label="Edit habit"
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      onClick={() => setConfirmDelete(habit.id)}
                      className="p-2 rounded-lg text-slate-400 hover:text-error-500 hover:bg-error-50 dark:hover:bg-error-900/20 transition-colors"
                      aria-label="Delete habit"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                {/* Stats row */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="text-center py-2 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                    <div className="flex items-center justify-center gap-1 text-orange-500">
                      <Flame size={15} />
                      <span className="text-lg font-bold">{streak}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">Streak</p>
                  </div>
                  <div className="text-center py-2 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                    <div className="flex items-center justify-center gap-1 text-amber-500">
                      <Trophy size={15} />
                      <span className="text-lg font-bold">{longest}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">Best</p>
                  </div>
                  <div className="text-center py-2 rounded-lg bg-slate-50 dark:bg-slate-700/40">
                    <div className="flex items-center justify-center gap-1 text-primary-500">
                      <CheckCircle2 size={15} />
                      <span className="text-lg font-bold">{total}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">Total</p>
                  </div>
                </div>

                {/* Complete button */}
                <button
                  onClick={() => toggleHabit(habit.id, today, habit.targetCount)}
                  className={`w-full py-3 rounded-xl font-medium text-sm transition-all duration-200 flex items-center justify-center gap-2 ${
                    completed
                      ? `${colors.dot} text-white`
                      : `border-2 border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-primary-400 hover:text-primary-600 dark:hover:text-primary-400`
                  }`}
                >
                  {completed ? (
                    <>
                      <CheckCircle2 size={18} /> Completed Today
                    </>
                  ) : (
                    <>
                      <Plus size={18} /> Mark Complete
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingHabit ? 'Edit Habit' : 'New Habit'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Habit Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Morning meditation"
              className="input-field"
              autoFocus
              required
            />
          </div>

          {/* Icon picker */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Icon
            </label>
            <div className="grid grid-cols-8 gap-2">
              {ICON_OPTIONS.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setIcon(ic)}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center text-lg transition-all ${
                    icon === ic
                      ? 'bg-primary-100 dark:bg-primary-900/30 ring-2 ring-primary-500'
                      : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600'
                  }`}
                >
                  {ic}
                </button>
              ))}
            </div>
          </div>

          {/* Color picker */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Color
            </label>
            <div className="flex gap-2 flex-wrap">
              {COLOR_OPTIONS.map((c) => {
                const col = HABIT_COLORS[c];
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className={`w-8 h-8 rounded-full ${col.dot} transition-all ${
                      color === c
                        ? 'ring-2 ring-offset-2 ring-slate-400 dark:ring-offset-slate-800 scale-110'
                        : 'hover:scale-110'
                    }`}
                    aria-label={c}
                  />
                );
              })}
            </div>
          </div>

          {/* Frequency */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Frequency
            </label>
            <div className="flex gap-2">
              {(['daily', 'weekly'] as HabitFrequency[]).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setFrequency(f)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-medium capitalize transition-all ${
                    frequency === f
                      ? 'bg-primary-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Target count */}
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Daily Target Count
            </label>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setTargetCount((c) => Math.max(1, c - 1))}
                className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 font-bold text-lg flex items-center justify-center"
              >
                −
              </button>
              <span className="text-xl font-bold text-slate-800 dark:text-white w-12 text-center">
                {targetCount}
              </span>
              <button
                type="button"
                onClick={() => setTargetCount((c) => Math.min(10, c + 1))}
                className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 font-bold text-lg flex items-center justify-center"
              >
                +
              </button>
              <span className="text-sm text-slate-400 ml-2">times per day</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1">
              {editingHabit ? 'Save Changes' : 'Create Habit'}
            </button>
            <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete confirmation */}
      <Modal
        open={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        title="Delete Habit?"
        maxWidth="max-w-sm"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 rounded-xl bg-error-50 dark:bg-error-900/20">
            <div className="w-10 h-10 rounded-full bg-error-100 dark:bg-error-900/40 flex items-center justify-center">
              <Trash2 className="text-error-600" size={20} />
            </div>
            <p className="text-sm text-slate-700 dark:text-slate-300">
              This will permanently delete the habit and all its completion history. This cannot be undone.
            </p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => handleDelete(confirmDelete!)} className="btn-danger flex-1">
              <Trash2 size={16} /> Delete
            </button>
            <button onClick={() => setConfirmDelete(null)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
