import { useState, useRef } from 'react';
import { useApp } from '@/context/AppContext';
import Modal from '@/components/Modal';
import {
  Sun,
  Moon,
  Trash2,
  Download,
  Upload,
  AlertTriangle,
  Info,
} from 'lucide-react';

export default function Settings() {
  const { theme, setTheme, data, clearAllData, exportData, importData } = useApp();
  const [confirmClear, setConfirmClear] = useState(false);
  const [importModal, setImportModal] = useState(false);
  const [importText, setImportText] = useState('');
  const [importResult, setImportResult] = useState<'success' | 'error' | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleExport() {
    const json = exportData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `habitflow-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      setImportText(text);
      setImportModal(true);
    };
    reader.readAsText(file);
  }

  function handleImport() {
    const success = importData(importText);
    setImportResult(success ? 'success' : 'error');
    if (success) {
      setTimeout(() => {
        setImportModal(false);
        setImportResult(null);
        setImportText('');
      }, 1500);
    }
  }

  const habitCount = data.habits.length;
  const logCount = data.habitLogs.length;
  const taskCount = data.tasks.length;
  const goalCount = data.goals.length;
  const challengeCount = data.challenges.length;

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Settings</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Customize your experience and manage your data
        </p>
      </div>

      {/* Appearance */}
      <div className="card p-6">
        <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-4">
          Appearance
        </h2>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setTheme('light')}
            className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
              theme === 'light'
                ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                : 'border-slate-200 dark:border-slate-600 hover:border-slate-300'
            }`}
          >
            <Sun className="text-amber-500" size={24} />
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">
              Light Mode
            </span>
          </button>
          <button
            onClick={() => setTheme('dark')}
            className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
              theme === 'dark'
                ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                : 'border-slate-200 dark:border-slate-600 hover:border-slate-300'
            }`}
          >
            <Moon className="text-primary-500" size={24} />
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">
              Dark Mode
            </span>
          </button>
        </div>
      </div>

      {/* Data stats */}
      <div className="card p-6">
        <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-4">
          Your Data
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-5">
          {[
            { label: 'Habits', value: habitCount },
            { label: 'Logs', value: logCount },
            { label: 'Tasks', value: taskCount },
            { label: 'Goals', value: goalCount },
            { label: 'Challenges', value: challengeCount },
          ].map((stat) => (
            <div
              key={stat.label}
              className="text-center py-3 rounded-xl bg-slate-50 dark:bg-slate-700/40"
            >
              <p className="text-xl font-bold text-slate-800 dark:text-white">
                {stat.value}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="space-y-2">
          <button
            onClick={handleExport}
            className="w-full py-3 rounded-xl border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 font-medium text-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2"
          >
            <Download size={18} /> Export data (JSON)
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-3 rounded-xl border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 font-medium text-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2"
          >
            <Upload size={18} /> Import data
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>
      </div>

      {/* Storage info */}
      <div className="card p-6">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary-50 dark:bg-primary-900/20 flex items-center justify-center flex-shrink-0">
            <Info className="text-primary-600 dark:text-primary-400" size={20} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-200">
              Local Storage
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Your data is stored in your browser's local storage and persists across
              page refreshes. It stays on your device and is never sent to any server.
            </p>
          </div>
        </div>
      </div>

      {/* Danger zone */}
      <div className="card p-6 border-error-200 dark:border-error-900/40">
        <h2 className="text-base font-semibold text-error-600 dark:text-error-400 mb-2">
          Danger Zone
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
          Permanently delete all your data. This cannot be undone.
        </p>
        <button
          onClick={() => setConfirmClear(true)}
          className="btn-danger"
        >
          <Trash2 size={16} /> Clear all data
        </button>
      </div>

      {/* About */}
      <div className="text-center py-4">
        <p className="text-sm text-slate-400 dark:text-slate-500">
          HabitFlow v1.0 - Built with care for your daily growth
        </p>
      </div>

      {/* Clear confirmation */}
      <Modal
        open={confirmClear}
        onClose={() => setConfirmClear(false)}
        title="Clear All Data?"
        maxWidth="max-w-sm"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 rounded-xl bg-error-50 dark:bg-error-900/20">
            <div className="w-10 h-10 rounded-full bg-error-100 dark:bg-error-900/40 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="text-error-600" size={20} />
            </div>
            <p className="text-sm text-slate-700 dark:text-slate-300">
              This will permanently delete all habits, logs, tasks, goals, and challenges.
              Make sure to export a backup first if you want to keep your data.
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => {
                clearAllData();
                setConfirmClear(false);
              }}
              className="btn-danger flex-1"
            >
              <Trash2 size={16} /> Yes, delete everything
            </button>
            <button onClick={() => setConfirmClear(false)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </div>
      </Modal>

      {/* Import modal */}
      <Modal
        open={importModal}
        onClose={() => {
          setImportModal(false);
          setImportResult(null);
        }}
        title="Import Data"
        maxWidth="max-w-lg"
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Review the data below and confirm to import. This will replace all your
            current data.
          </p>
          <textarea
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            className="input-field font-mono text-xs h-48 resize-none"
            placeholder="Paste JSON data here..."
          />
          {importResult === 'success' && (
            <p className="text-sm text-success-600 dark:text-success-400 font-medium">
              Data imported successfully!
            </p>
          )}
          {importResult === 'error' && (
            <p className="text-sm text-error-600 dark:text-error-400 font-medium">
              Invalid JSON data. Please check and try again.
            </p>
          )}
          <div className="flex gap-3">
            <button
              onClick={handleImport}
              className="btn-primary flex-1"
              disabled={!importText.trim()}
            >
              <Upload size={16} /> Import
            </button>
            <button
              onClick={() => {
                setImportModal(false);
                setImportResult(null);
              }}
              className="btn-secondary"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
