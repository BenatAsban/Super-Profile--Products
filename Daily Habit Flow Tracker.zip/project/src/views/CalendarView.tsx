import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { HABIT_COLORS } from '@/types';
import {
  formatDateKey,
  getMonthDays,
  formatMonth,
  addDays,
  isToday,
  parseDateKey,
  relativeDay,
} from '@/utils/date';
import { isHabitCompleted } from '@/utils/habit';
import {
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Flame,
  Circle,
  ListTodo,
  Check,
} from 'lucide-react';

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function Calendar() {
  const { data, toggleHabit } = useApp();
  const [viewDate, setViewDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(formatDateKey(new Date()));

  const monthDays = getMonthDays(viewDate);
  const activeHabits = data.habits.filter((h) => !h.archived);

  function getDayCompletion(dateKey: string): { completed: number; total: number; rate: number } {
    const total = activeHabits.length;
    const completed = activeHabits.filter((h) =>
      isHabitCompleted(h, dateKey, data.habitLogs)
    ).length;
    return {
      completed,
      total,
      rate: total > 0 ? (completed / total) * 100 : 0,
    };
  }

  function prevMonth() {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1));
  }

  function nextMonth() {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1));
  }

  function goToday() {
    const now = new Date();
    setViewDate(now);
    setSelectedDate(formatDateKey(now));
  }

  const selectedDayHabits = activeHabits;
  const selectedDayTasks = data.tasks.filter((t) => t.date === selectedDate);
  const selectedDayCompletion = getDayCompletion(selectedDate);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Calendar</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Review your history and plan ahead
          </p>
        </div>
        <button onClick={goToday} className="btn-secondary">
          Today
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar grid */}
        <div className="card p-6 lg:col-span-2">
          {/* Month navigation */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100">
              {formatMonth(viewDate)}
            </h2>
            <div className="flex items-center gap-1">
              <button
                onClick={prevMonth}
                className="p-2 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <ChevronLeft size={20} />
              </button>
              <button
                onClick={nextMonth}
                className="p-2 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>

          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {WEEKDAYS.map((day) => (
              <div
                key={day}
                className="text-center text-xs font-medium text-slate-400 py-2"
              >
                {day}
              </div>
            ))}
          </div>

          {/* Days grid */}
          <div className="grid grid-cols-7 gap-1">
            {monthDays.map((date) => {
              const dateKey = formatDateKey(date);
              const inCurrentMonth = date.getMonth() === viewDate.getMonth();
              const today = isToday(dateKey);
              const selected = dateKey === selectedDate;
              const { completed, total, rate } = getDayCompletion(dateKey);
              const hasTasks = data.tasks.some((t) => t.date === dateKey);

              return (
                <button
                  key={dateKey}
                  onClick={() => setSelectedDate(dateKey)}
                  className={`relative aspect-square rounded-xl flex flex-col items-center justify-center transition-all text-sm ${
                    selected
                      ? 'bg-primary-600 text-white shadow-lg shadow-primary-500/30'
                      : today
                      ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                      : inCurrentMonth
                      ? 'hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
                      : 'text-slate-300 dark:text-slate-600'
                  }`}
                >
                  <span className={`font-medium ${today && !selected ? 'text-primary-600 dark:text-primary-400' : ''}`}>
                    {date.getDate()}
                  </span>
                  {/* Completion indicator */}
                  {total > 0 && (
                    <div className="flex items-center gap-0.5 mt-0.5">
                      {rate === 100 ? (
                        <CheckCircle2
                          size={11}
                          className={selected ? 'text-white' : 'text-success-500'}
                        />
                      ) : rate > 0 ? (
                        <div className={`w-1.5 h-1.5 rounded-full ${
                          selected ? 'bg-white/70' : 'bg-primary-400'
                        }`} />
                      ) : null}
                      {hasTasks && (
                        <div className={`w-1.5 h-1.5 rounded-full ${
                          selected ? 'bg-white/70' : 'bg-accent-400'
                        }`} />
                      )}
                    </div>
                  )}
                  {total === 0 && hasTasks && (
                    <div className={`w-1.5 h-1.5 rounded-full mt-0.5 ${
                      selected ? 'bg-white/70' : 'bg-accent-400'
                    }`} />
                  )}
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 mt-4 pt-4 border-t border-slate-100 dark:border-slate-700">
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <CheckCircle2 size={14} className="text-success-500" />
              All done
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <div className="w-2 h-2 rounded-full bg-primary-400" />
              Partial
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <div className="w-2 h-2 rounded-full bg-accent-400" />
              Has tasks
            </div>
          </div>
        </div>

        {/* Day detail panel */}
        <div className="card p-6">
          <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-1">
            {relativeDay(selectedDate)}
          </h2>
          <p className="text-xs text-slate-400 mb-4">
            {parseDateKey(selectedDate).toLocaleDateString('en-US', {
              weekday: 'long',
              month: 'long',
              day: 'numeric',
              year: 'numeric',
            })}
          </p>

          {/* Day progress */}
          {selectedDayHabits.length > 0 && (
            <div className="mb-4">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-sm text-slate-600 dark:text-slate-300">
                  Habits completed
                </span>
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                  {selectedDayCompletion.completed}/{selectedDayCompletion.total}
                </span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-primary-400 to-primary-600 transition-all duration-500"
                  style={{ width: `${selectedDayCompletion.rate}%` }}
                />
              </div>
            </div>
          )}

          {/* Habits for selected day */}
          {selectedDayHabits.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Flame className="text-slate-300 dark:text-slate-600 mb-2" size={32} />
              <p className="text-sm text-slate-400">No habits to track</p>
            </div>
          ) : (
            <div className="space-y-2 mb-4">
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                Habits
              </p>
              {selectedDayHabits.map((habit) => {
                const colors = HABIT_COLORS[habit.color];
                const completed = isHabitCompleted(habit, selectedDate, data.habitLogs);
                return (
                  <div
                    key={habit.id}
                    className={`flex items-center gap-2.5 p-2.5 rounded-lg transition-all ${
                      completed ? colors.bg : 'bg-slate-50 dark:bg-slate-700/40'
                    }`}
                  >
                    <button
                      onClick={() => toggleHabit(habit.id, selectedDate, habit.targetCount)}
                      className={`flex-shrink-0 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                        completed
                          ? `${colors.dot} border-transparent`
                          : 'border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {completed && <Check className="text-white" size={12} />}
                    </button>
                    <span className="text-sm">{habit.icon}</span>
                    <span
                      className={`flex-1 text-sm truncate ${
                        completed
                          ? 'text-slate-500 dark:text-slate-400 line-through'
                          : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {habit.name}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Tasks for selected day */}
          {selectedDayTasks.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                Tasks
              </p>
              {selectedDayTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center gap-2.5 p-2.5 rounded-lg bg-slate-50 dark:bg-slate-700/40"
                >
                  {task.completed ? (
                    <CheckCircle2 size={18} className="text-accent-500 flex-shrink-0" />
                  ) : (
                    <Circle size={18} className="text-slate-300 dark:text-slate-600 flex-shrink-0" />
                  )}
                  <span
                    className={`flex-1 text-sm truncate ${
                      task.completed
                        ? 'text-slate-400 line-through'
                        : 'text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    {task.title}
                  </span>
                  <span
                    className={`w-2 h-2 rounded-full ${
                      task.priority === 'high'
                        ? 'bg-error-500'
                        : task.priority === 'medium'
                        ? 'bg-warning-500'
                        : 'bg-success-500'
                    }`}
                  />
                </div>
              ))}
            </div>
          )}

          {selectedDayHabits.length === 0 && selectedDayTasks.length === 0 && (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <ListTodo className="text-slate-300 dark:text-slate-600 mb-2" size={32} />
              <p className="text-sm text-slate-400">Nothing scheduled</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
