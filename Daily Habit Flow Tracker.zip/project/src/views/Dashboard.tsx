import { useApp } from '@/context/AppContext';
import { HABIT_COLORS, type ViewName } from '@/types';
import { todayKey, formatDateLong, parseDateKey, formatWeekday } from '@/utils/date';
import {
  isHabitCompleted,
  calculateStreak,
  getCompletionRate,
  getLastNDays,
} from '@/utils/habit';
import ProgressRing from '@/components/ProgressRing';
import EmptyState from '@/components/EmptyState';
import {
  Flame,
  CheckCircle2,
  TrendingUp,
  Target,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface DashboardProps {
  onNavigate: (view: ViewName) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { data, toggleHabit } = useApp();
  const today = todayKey();
  const todayDate = new Date();

  const activeHabits = data.habits.filter((h) => !h.archived);
  const completedToday = activeHabits.filter((h) =>
    isHabitCompleted(h, today, data.habitLogs)
  );
  const completionRate =
    activeHabits.length > 0
      ? Math.round((completedToday.length / activeHabits.length) * 100)
      : 0;

  // Tasks
  const tasksToday = data.tasks.filter((t) => t.date === today);
  const tasksDone = tasksToday.filter((t) => t.completed).length;

  // Streaks
  const bestStreak = Math.max(
    0,
    ...activeHabits.map((h) => calculateStreak(h, data.habitLogs))
  );

  // Weekly data
  const last7 = getLastNDays(7);
  const weeklyRate = getCompletionRate(activeHabits, data.habitLogs, last7);

  // Weekly mini chart data
  const weeklyData = last7.map((dateKey) => {
    const completed = activeHabits.filter((h) =>
      isHabitCompleted(h, dateKey, data.habitLogs)
    ).length;
    return {
      dateKey,
      day: formatWeekday(parseDateKey(dateKey)),
      completed,
      total: activeHabits.length,
      rate: activeHabits.length > 0 ? (completed / activeHabits.length) * 100 : 0,
    };
  });

  const maxCompleted = Math.max(1, ...weeklyData.map((d) => d.completed));

  const pendingTasks = tasksToday.filter((t) => !t.completed).slice(0, 5);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">
          {formatDateLong(todayDate)}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Let's make today productive!
        </p>
      </div>

      {/* Top cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Progress ring card */}
        <div className="card p-6 flex flex-col items-center justify-center sm:col-span-2 lg:col-span-1">
          <ProgressRing percentage={completionRate} size={130} strokeWidth={12}>
            <span className="text-3xl font-bold text-slate-800 dark:text-white">
              {completionRate}%
            </span>
            <span className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
              Today
            </span>
          </ProgressRing>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-3 text-center">
            {completedToday.length} of {activeHabits.length} habits done
          </p>
        </div>

        {/* Tasks card */}
        <div className="card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-11 h-11 rounded-xl bg-accent-50 dark:bg-accent-900/20 flex items-center justify-center">
              <CheckCircle2 className="text-accent-600 dark:text-accent-400" size={22} />
            </div>
            <span className="text-3xl font-bold text-slate-800 dark:text-white">
              {tasksDone}/{tasksToday.length}
            </span>
          </div>
          <div className="mt-4">
            <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
              Tasks completed
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
              {tasksToday.length - tasksDone} remaining
            </p>
          </div>
        </div>

        {/* Streak card */}
        <div className="card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-11 h-11 rounded-xl bg-orange-50 dark:bg-orange-900/20 flex items-center justify-center">
              <Flame className="text-orange-500" size={22} />
            </div>
            <span className="text-3xl font-bold text-slate-800 dark:text-white">
              {bestStreak}
            </span>
          </div>
          <div className="mt-4">
            <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
              Best streak
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
              {bestStreak === 1 ? 'day' : 'days'} in a row
            </p>
          </div>
        </div>

        {/* Weekly rate card */}
        <div className="card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-11 h-11 rounded-xl bg-primary-50 dark:bg-primary-900/20 flex items-center justify-center">
              <TrendingUp className="text-primary-600 dark:text-primary-400" size={22} />
            </div>
            <span className="text-3xl font-bold text-slate-800 dark:text-white">
              {weeklyRate}%
            </span>
          </div>
          <div className="mt-4">
            <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
              Weekly rate
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">
              Last 7 days
            </p>
          </div>
        </div>
      </div>

      {/* Today's habits */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100">
            Today's Habits
          </h2>
          <button
            onClick={() => onNavigate('habits')}
            className="flex items-center gap-1 text-sm text-primary-600 dark:text-primary-400 hover:gap-2 transition-all"
          >
            View all <ArrowRight size={15} />
          </button>
        </div>

        {activeHabits.length === 0 ? (
          <EmptyState
            icon={<Flame size={28} />}
            title="No habits yet"
            description="Create your first habit to start tracking your daily progress."
            action={
              <button onClick={() => onNavigate('habits')} className="btn-primary">
                <Sparkles size={16} /> Add a habit
              </button>
            }
          />
        ) : (
          <div className="space-y-2">
            {activeHabits.map((habit) => {
              const colors = HABIT_COLORS[habit.color];
              const completed = isHabitCompleted(habit, today, data.habitLogs);
              const streak = calculateStreak(habit, data.habitLogs);
              return (
                <div
                  key={habit.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-all duration-150 ${
                    completed
                      ? `${colors.bg} border-transparent`
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                  }`}
                >
                  <button
                    onClick={() => toggleHabit(habit.id, today, habit.targetCount)}
                    className={`flex-shrink-0 w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all ${
                      completed
                        ? `${colors.dot} border-transparent`
                        : 'border-slate-300 dark:border-slate-600 hover:border-slate-400'
                    }`}
                    aria-label={completed ? 'Mark incomplete' : 'Mark complete'}
                  >
                    {completed && <CheckCircle2 className="text-white" size={18} />}
                  </button>
                  <span className="text-lg">{habit.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-sm font-medium truncate ${
                        completed
                          ? 'text-slate-500 dark:text-slate-400 line-through'
                          : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {habit.name}
                    </p>
                  </div>
                  {streak > 0 && (
                    <span className="flex items-center gap-1 text-xs font-medium text-orange-500">
                      <Flame size={13} /> {streak}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom section: weekly chart + pending tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Weekly chart */}
        <div className="card p-6">
          <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100 mb-4">
            This Week
          </h2>
          <div className="flex items-end justify-between gap-2 h-32">
            {weeklyData.map((d) => (
              <div key={d.dateKey} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full flex-1 flex items-end">
                  <div
                    className={`w-full rounded-t-lg transition-all duration-500 ${
                      d.dateKey === today
                        ? 'bg-primary-500'
                        : d.completed > 0
                        ? 'bg-primary-300 dark:bg-primary-700'
                        : 'bg-slate-100 dark:bg-slate-700'
                    }`}
                    style={{
                      height: `${Math.max(4, (d.completed / maxCompleted) * 100)}%`,
                    }}
                  />
                </div>
                <span className="text-xs text-slate-400 dark:text-slate-500">
                  {d.day}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Pending tasks */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100">
              Pending Tasks
            </h2>
            <button
              onClick={() => onNavigate('tasks')}
              className="flex items-center gap-1 text-sm text-primary-600 dark:text-primary-400 hover:gap-2 transition-all"
            >
              View all <ArrowRight size={15} />
            </button>
          </div>
          {pendingTasks.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8">
              <CheckCircle2 className="text-success-500 mb-2" size={32} />
              <p className="text-sm text-slate-500 dark:text-slate-400">
                {tasksToday.length === 0 ? 'No tasks for today' : 'All tasks done!'}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {pendingTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-700/40"
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      task.priority === 'high'
                        ? 'bg-error-500'
                        : task.priority === 'medium'
                        ? 'bg-warning-500'
                        : 'bg-success-500'
                    }`}
                  />
                  <span className="text-sm text-slate-700 dark:text-slate-200 flex-1 truncate">
                    {task.title}
                  </span>
                  <span className="text-xs text-slate-400 capitalize">
                    {task.priority}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Active goals teaser */}
      {data.goals.filter((g) => !g.completed).length > 0 && (
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-semibold text-slate-800 dark:text-slate-100">
              Active Goals
            </h2>
            <button
              onClick={() => onNavigate('goals')}
              className="flex items-center gap-1 text-sm text-primary-600 dark:text-primary-400 hover:gap-2 transition-all"
            >
              View all <ArrowRight size={15} />
            </button>
          </div>
          <div className="space-y-3">
            {data.goals
              .filter((g) => !g.completed)
              .slice(0, 3)
              .map((goal) => {
                const pct = Math.min(100, Math.round((goal.current / goal.target) * 100));
                return (
                  <div key={goal.id}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200">
                        <Target size={15} className="text-primary-500" />
                        {goal.title}
                      </span>
                      <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                        {goal.current}/{goal.target}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-primary-400 to-primary-600 transition-all duration-700"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
}
