import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import type { GoalType } from '@/types';
import { todayKey, formatDateKey, parseDateKey, formatDateShort } from '@/utils/date';
import { calculateStreak } from '@/utils/habit';
import Modal from '@/components/Modal';
import EmptyState from '@/components/EmptyState';
import {
  Plus,
  Target,
  Trash2,
  Flag,
  Trophy,
  Zap,
  CheckCircle2,
  XCircle,
  Calendar as CalendarIcon,
} from 'lucide-react';

const GOAL_TYPE_LABELS: Record<GoalType, string> = {
  'habit-streak': 'Habit Streak (days)',
  'completion-count': 'Total Completions',
  'task-count': 'Tasks Completed',
};

export default function Goals() {
  const {
    data,
    addGoal,
    updateGoal,
    deleteGoal,
    addChallenge,
    updateChallenge,
    deleteChallenge,
  } = useApp();
  const [goalModal, setGoalModal] = useState(false);
  const [challengeModal, setChallengeModal] = useState(false);

  // Goal form
  const [goalTitle, setGoalTitle] = useState('');
  const [goalDesc, setGoalDesc] = useState('');
  const [goalType, setGoalType] = useState<GoalType>('habit-streak');
  const [goalTarget, setGoalTarget] = useState(30);
  const [goalDeadline, setGoalDeadline] = useState(formatDateKey(
    new Date(Date.now() + 30 * 86400000)
  ));

  // Challenge form
  const [chTitle, setChTitle] = useState('');
  const [chDesc, setChDesc] = useState('');
  const [chDuration, setChDuration] = useState(30);

  function openGoalModal() {
    setGoalTitle('');
    setGoalDesc('');
    setGoalType('habit-streak');
    setGoalTarget(30);
    setGoalDeadline(formatDateKey(new Date(Date.now() + 30 * 86400000)));
    setGoalModal(true);
  }

  function openChallengeModal() {
    setChTitle('');
    setChDesc('');
    setChDuration(30);
    setChallengeModal(true);
  }

  function handleGoalSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!goalTitle.trim()) return;
    addGoal({
      title: goalTitle.trim(),
      description: goalDesc.trim(),
      type: goalType,
      target: goalTarget,
      deadline: goalDeadline,
    });
    setGoalModal(false);
  }

  function handleChallengeSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!chTitle.trim()) return;
    addChallenge({
      title: chTitle.trim(),
      description: chDesc.trim(),
      durationDays: chDuration,
      startDate: todayKey(),
    });
    setChallengeModal(false);
  }

  // Auto-update goal progress based on data
  function getGoalProgress(goal: typeof data.goals[0]): number {
    if (goal.type === 'habit-streak') {
      const maxStreak = Math.max(
        0,
        ...data.habits
          .filter((h) => !h.archived)
          .map((h) => calculateStreak(h, data.habitLogs))
      );
      return Math.min(goal.target, maxStreak);
    }
    if (goal.type === 'completion-count') {
      const total = data.habitLogs.filter(
        (l) => data.habits.find((h) => h.id === l.habitId && !h.archived)
      ).length;
      return Math.min(goal.target, total);
    }
    if (goal.type === 'task-count') {
      const done = data.tasks.filter((t) => t.completed).length;
      return Math.min(goal.target, done);
    }
    return goal.current;
  }

  function getChallengeProgress(challenge: typeof data.challenges[0]): number {
    const start = parseDateKey(challenge.startDate);
    const now = new Date();
    const daysElapsed = Math.floor((now.getTime() - start.getTime()) / 86400000);
    return Math.min(challenge.durationDays, daysElapsed);
  }

  const activeGoals = data.goals.filter((g) => !g.completed);
  const completedGoals = data.goals.filter((g) => g.completed);
  const activeChallenges = data.challenges.filter((c) => c.status === 'active');

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">
          Goals & Challenges
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Set ambitious targets and challenge yourself
        </p>
      </div>

      {/* Goals section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Target className="text-primary-500" size={20} />
            Goals
          </h2>
          <button onClick={openGoalModal} className="btn-primary">
            <Plus size={18} /> New Goal
          </button>
        </div>

        {data.goals.length === 0 ? (
          <div className="card">
            <EmptyState
              icon={<Target size={28} />}
              title="No goals set"
              description="Set a goal to give yourself something to work towards. Track streaks, completions, and tasks."
              action={
                <button onClick={openGoalModal} className="btn-primary">
                  <Plus size={16} /> Set a goal
                </button>
              }
            />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeGoals.map((goal) => {
              const progress = getGoalProgress(goal);
              const pct = Math.min(100, Math.round((progress / goal.target) * 100));
              const isComplete = progress >= goal.target;
              return (
                <div key={goal.id} className="card card-hover p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-800 dark:text-slate-100">
                        {goal.title}
                      </h3>
                      {goal.description && (
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                          {goal.description}
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => deleteGoal(goal.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-error-500 hover:bg-error-50 dark:hover:bg-error-900/20 transition-colors flex-shrink-0"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs font-medium px-2 py-1 rounded-md bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400">
                      {GOAL_TYPE_LABELS[goal.type]}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-slate-400">
                      <CalendarIcon size={12} />
                      {formatDateShort(parseDateKey(goal.deadline))}
                    </span>
                  </div>

                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold text-slate-800 dark:text-white">
                      {progress}
                      <span className="text-sm text-slate-400 font-normal">
                        {' '}/ {goal.target}
                      </span>
                    </span>
                    <span className="text-sm font-medium text-primary-600 dark:text-primary-400">
                      {pct}%
                    </span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary-400 to-primary-600 transition-all duration-700"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  {isComplete && (
                    <button
                      onClick={() => updateGoal(goal.id, { completed: true })}
                      className="mt-3 w-full py-2 rounded-lg bg-success-500 text-white text-sm font-medium hover:bg-success-600 transition-colors flex items-center justify-center gap-2"
                    >
                      <Trophy size={16} /> Mark as achieved!
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Completed goals */}
        {completedGoals.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-slate-400 uppercase tracking-wide">
              Achieved
            </p>
            {completedGoals.map((goal) => (
              <div
                key={goal.id}
                className="card p-4 flex items-center gap-3 opacity-75"
              >
                <Trophy className="text-amber-500 flex-shrink-0" size={20} />
                <span className="flex-1 text-sm font-medium text-slate-600 dark:text-slate-300 line-through">
                  {goal.title}
                </span>
                <button
                  onClick={() => deleteGoal(goal.id)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-error-500 transition-colors"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Challenges section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Zap className="text-amber-500" size={20} />
            Challenges
          </h2>
          <button onClick={openChallengeModal} className="btn-primary">
            <Plus size={18} /> New Challenge
          </button>
        </div>

        {data.challenges.length === 0 ? (
          <div className="card">
            <EmptyState
              icon={<Zap size={28} />}
              title="No challenges yet"
              description="Challenge yourself to maintain habits for a set number of days. Push your limits!"
              action={
                <button onClick={openChallengeModal} className="btn-primary">
                  <Plus size={16} /> Start a challenge
                </button>
              }
            />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {data.challenges.map((challenge) => {
              const progress = getChallengeProgress(challenge);
              const pct = Math.min(100, Math.round((progress / challenge.durationDays) * 100));
              const isComplete = progress >= challenge.durationDays;
              const isActive = challenge.status === 'active';

              return (
                <div key={challenge.id} className="card card-hover p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-800 dark:text-slate-100">
                        {challenge.title}
                      </h3>
                      {challenge.description && (
                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                          {challenge.description}
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => deleteChallenge(challenge.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-error-500 hover:bg-error-50 dark:hover:bg-error-900/20 transition-colors flex-shrink-0"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs font-medium px-2 py-1 rounded-md bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400">
                      {challenge.durationDays}-day challenge
                    </span>
                    {isActive && (
                      <span className="flex items-center gap-1 text-xs text-slate-400">
                        <Flag size={12} /> Day {progress + 1}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold text-slate-800 dark:text-white">
                      {progress}
                      <span className="text-sm text-slate-400 font-normal">
                        {' '}/ {challenge.durationDays} days
                      </span>
                    </span>
                    <span className="text-sm font-medium text-amber-600 dark:text-amber-400">
                      {pct}%
                    </span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500 transition-all duration-700"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  {isActive && (
                    <div className="flex gap-2 mt-3">
                      {isComplete ? (
                        <button
                          onClick={() =>
                            updateChallenge(challenge.id, { status: 'completed' })
                          }
                          className="flex-1 py-2 rounded-lg bg-success-500 text-white text-sm font-medium hover:bg-success-600 transition-colors flex items-center justify-center gap-2"
                        >
                          <CheckCircle2 size={16} /> Complete
                        </button>
                      ) : (
                        <button
                          onClick={() =>
                            updateChallenge(challenge.id, { status: 'abandoned' })
                          }
                          className="flex-1 py-2 rounded-lg border border-slate-200 dark:border-slate-600 text-slate-500 text-sm font-medium hover:border-error-300 hover:text-error-500 transition-colors flex items-center justify-center gap-2"
                        >
                          <XCircle size={16} /> Give up
                        </button>
                      )}
                    </div>
                  )}

                  {challenge.status === 'completed' && (
                    <div className="mt-3 flex items-center gap-2 text-sm text-success-600 dark:text-success-400 font-medium">
                      <Trophy size={16} /> Challenge completed!
                    </div>
                  )}
                  {challenge.status === 'abandoned' && (
                    <div className="mt-3 flex items-center gap-2 text-sm text-slate-400 font-medium">
                      <XCircle size={16} /> Challenge abandoned
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Goal Modal */}
      <Modal open={goalModal} onClose={() => setGoalModal(false)} title="New Goal">
        <form onSubmit={handleGoalSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Goal Title
            </label>
            <input
              type="text"
              value={goalTitle}
              onChange={(e) => setGoalTitle(e.target.value)}
              placeholder="e.g. 30-day meditation streak"
              className="input-field"
              autoFocus
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Description (optional)
            </label>
            <input
              type="text"
              value={goalDesc}
              onChange={(e) => setGoalDesc(e.target.value)}
              placeholder="What does success look like?"
              className="input-field"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Type
            </label>
            <select
              value={goalType}
              onChange={(e) => setGoalType(e.target.value as GoalType)}
              className="input-field"
            >
              {Object.entries(GOAL_TYPE_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Target
              </label>
              <input
                type="number"
                value={goalTarget}
                onChange={(e) => setGoalTarget(Math.max(1, Number(e.target.value)))}
                className="input-field"
                min={1}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Deadline
              </label>
              <input
                type="date"
                value={goalDeadline}
                onChange={(e) => setGoalDeadline(e.target.value)}
                className="input-field"
                required
              />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1">
              Create Goal
            </button>
            <button type="button" onClick={() => setGoalModal(false)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Challenge Modal */}
      <Modal
        open={challengeModal}
        onClose={() => setChallengeModal(false)}
        title="New Challenge"
      >
        <form onSubmit={handleChallengeSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Challenge Title
            </label>
            <input
              type="text"
              value={chTitle}
              onChange={(e) => setChTitle(e.target.value)}
              placeholder="e.g. 100 days of code"
              className="input-field"
              autoFocus
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Description (optional)
            </label>
            <input
              type="text"
              value={chDesc}
              onChange={(e) => setChDesc(e.target.value)}
              placeholder="What's the challenge about?"
              className="input-field"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Duration (days)
            </label>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setChDuration((d) => Math.max(7, d - 7))}
                className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold flex items-center justify-center"
              >
                −
              </button>
              <span className="text-xl font-bold text-slate-800 dark:text-white w-16 text-center">
                {chDuration}
              </span>
              <button
                type="button"
                onClick={() => setChDuration((d) => Math.min(365, d + 7))}
                className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold flex items-center justify-center"
              >
                +
              </button>
              <span className="text-sm text-slate-400 ml-2">days</span>
            </div>
            <div className="flex gap-2 mt-2">
              {[7, 21, 30, 66, 100].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setChDuration(d)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                    chDuration === d
                      ? 'bg-primary-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-600'
                  }`}
                >
                  {d}d
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1">
              Start Challenge
            </button>
            <button type="button" onClick={() => setChallengeModal(false)} className="btn-secondary">
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
