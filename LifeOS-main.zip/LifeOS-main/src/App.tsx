import type { ReactNode } from 'react';
import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  BriefcaseBusiness,
  Check,
  CheckCircle2,
  CircleDollarSign,
  ClipboardList,
  Download,
  FileText,
  Gift,
  Languages,
  ListTodo,
  Menu,
  Moon,
  Pencil,
  Pill,
  Plus,
  Search,
  Settings,
  Sparkles,
  SunMedium,
  Target,
  Trash2,
  TrendingUp,
  Wallet,
  Bell,
  CalendarDays,
  X,
} from 'lucide-react';
import {
  Navigate,
  NavLink,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from 'react-router-dom';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';

type Lang = 'en' | 'ta';
type Theme = 'light' | 'dark';
type Priority = 'Low' | 'Medium' | 'High';
type TaskView = 'Today' | 'Upcoming' | 'Completed' | 'All';
type ExpType = 'income' | 'expense';

type Task = {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  dueTime?: string;
  priority: Priority;
  category: string;
  completed: boolean;
  createdAt: string;
};

type Expense = {
  id: string;
  type: ExpType;
  amount: number;
  category: string;
  description: string;
  date: string;
  createdAt: string;
};

type Habit = {
  id: string;
  title: string;
  description: string;
  completions: string[];
};

type Reminder = {
  id: string;
  title: string;
  date: string;
  time?: string;
  notes: string;
  type: string;
  completed: boolean;
};

type Medicine = {
  id: string;
  name: string;
  reminderTimes: string[];
  startDate: string;
  endDate?: string;
  notes: string;
  status: Record<string, 'taken' | 'skipped'>;
};

type DocumentItem = {
  id: string;
  name: string;
  reference: string;
  expiryDate: string;
};

type Goal = {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  deadline?: string;
};

type Profile = {
  name: string;
  language: Lang;
  theme: Theme;
  onboardingCompleted: boolean;
  interests: string[];
};

type Settings = {
  notifications: boolean;
  browserAlerts: boolean;
  dashboardWidgets: string[];
};

type AppData = {
  profile: Profile;
  tasks: Task[];
  expenses: Expense[];
  habits: Habit[];
  reminders: Reminder[];
  medicines: Medicine[];
  documents: DocumentItem[];
  goals: Goal[];
  learningHistory: string[];
  settings: Settings;
};

const STORAGE_KEY = 'lifeos-v1';
const defaultWidgets = ['tasks', 'expenses', 'reminders', 'habits'];

const translations: Record<Lang, Record<string, string>> = {
  en: {
    appName: 'LifeOS',
    tagLine: 'Make Every Day Count.',
    dashboard: 'Dashboard',
    tasks: 'Tasks',
    expenses: 'Expenses',
    habits: 'Habits',
    reminders: 'Reminders',
    medicine: 'Medicine',
    documents: 'Documents',
    learning: 'Daily Learning',
    helper: 'English Helper',
    goals: 'Goals',
    settings: 'Settings',
    welcome: 'Welcome back',
    startDay: 'Start Your Day',
    explore: 'Explore Features',
    mobileNote: 'Browser permission and device settings affect delivery.',
    aiNote: 'AI assistance is unavailable without a configured backend API.',
    medicalNote: 'This does not replace professional medical advice.',
    privacyNote: 'Your data lives in this browser only.',
  },
  ta: {
    appName: 'லைஃப்ஓஎஸ்',
    tagLine: 'ஒவ்வொரு நாளையும் பயனுள்ளதாக மாற்று.',
    dashboard: 'டாஷ்போர்டு',
    tasks: 'பணிகள்',
    expenses: 'செலவுகள்',
    habits: 'பழக்கங்கள்',
    reminders: 'நினைவூட்டல்கள்',
    medicine: 'மருந்து',
    documents: 'ஆவணங்கள்',
    learning: 'தினசரி கற்றல்',
    helper: 'ஆங்கில உதவி',
    goals: 'குறிக்கோள்கள்',
    settings: 'அமைப்புகள்',
    welcome: 'மீண்டும் வருக',
    startDay: 'உங்கள் நாளைத் தொடங்குங்கள்',
    explore: 'அம்சங்களைப் பாருங்கள்',
    mobileNote: 'உலாவி அனுமதி மற்றும் சாதன அமைப்புகள் வழங்கலை பாதிக்கும்.',
    aiNote: 'பின்னணி API அமைக்கப்படாததால் AI உதவி கிடைக்காது.',
    medicalNote: 'இது தொழில்முறை மருத்துவ ஆலோசனையை மாற்றாது.',
    privacyNote: 'உங்கள் தரவு இந்த உலாவியில் மட்டுமே சேமிக்கப்படும்.',
  },
};

const navItems = [
  { to: '/dashboard', label: 'dashboard', icon: ListTodo },
  { to: '/tasks', label: 'tasks', icon: ClipboardList },
  { to: '/expenses', label: 'expenses', icon: CircleDollarSign },
  { to: '/habits', label: 'habits', icon: Target },
  { to: '/reminders', label: 'reminders', icon: Bell },
  { to: '/medicine', label: 'medicine', icon: Pill },
  { to: '/documents', label: 'documents', icon: FileText },
  { to: '/learning', label: 'learning', icon: BookOpen },
  { to: '/helper', label: 'helper', icon: Languages },
  { to: '/goals', label: 'goals', icon: TrendingUp },
  { to: '/settings', label: 'settings', icon: Settings },
];

function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

function todayKey() {
  const d = new Date();
  return formatDateForStorage(d);
}

function formatDateForStorage(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function safeDate(dateString: string) {
  if (!dateString) return new Date();
  const date = new Date(`${dateString}T12:00:00`);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

function formatShortDate(dateString: string) {
  if (!dateString) return '—';
  const date = safeDate(dateString);
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: 'Asia/Kolkata',
  }).format(date);
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(value || 0);
}

function getGreeting(lang: Lang) {
  const hour = new Date().getHours();
  if (lang === 'ta') {
    if (hour < 12) return 'சிறந்த காலை! ☀️';
    if (hour < 17) return 'மதிய நேரம்! 🌤️';
    return 'மாலை வணக்கம்! 🌙';
  }
  if (hour < 12) return 'Good morning! ☀️';
  if (hour < 17) return 'Good afternoon! 🌤️';
  return 'Good evening! 🌙';
}

function getDefaultData(): AppData {
  return {
    profile: {
      name: '',
      language: 'en',
      theme: 'light',
      onboardingCompleted: false,
      interests: [],
    },
    tasks: [],
    expenses: [],
    habits: [],
    reminders: [],
    medicines: [],
    documents: [],
    goals: [],
    learningHistory: [],
    settings: {
      notifications: false,
      browserAlerts: false,
      dashboardWidgets: [...defaultWidgets],
    },
  };
}

function readAppData(): AppData {
  if (typeof window === 'undefined') return getDefaultData();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getDefaultData();
    const parsed = JSON.parse(raw) as Partial<AppData>;
    const fallback = getDefaultData();
    return {
      ...fallback,
      ...parsed,
      profile: { ...fallback.profile, ...parsed.profile },
      settings: { ...fallback.settings, ...parsed.settings },
      tasks: Array.isArray(parsed.tasks) ? parsed.tasks : [],
      expenses: Array.isArray(parsed.expenses) ? parsed.expenses : [],
      habits: Array.isArray(parsed.habits) ? parsed.habits : [],
      reminders: Array.isArray(parsed.reminders) ? parsed.reminders : [],
      medicines: Array.isArray(parsed.medicines) ? parsed.medicines : [],
      documents: Array.isArray(parsed.documents) ? parsed.documents : [],
      goals: Array.isArray(parsed.goals) ? parsed.goals : [],
      learningHistory: Array.isArray(parsed.learningHistory) ? parsed.learningHistory : [],
    };
  } catch {
    return getDefaultData();
  }
}

function saveAppData(data: AppData) {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }
}

function calculateStreak(completions: string[]) {
  if (!completions.length) return 0;
  const unique = [...new Set(completions)].sort().reverse();
  let streak = 0;
  let cursor = new Date();
  for (const entry of unique) {
    const date = safeDate(entry);
    const diffDays = Math.round((cursor.getTime() - date.getTime()) / 86400000);
    if (diffDays <= 1 && diffDays >= 0) {
      streak += 1;
      cursor = new Date(date.getTime() - 86400000);
    } else {
      break;
    }
  }
  return streak;
}

function getDailyLesson(date: Date) {
  const lessons = [
    {
      id: 'word-1',
      title: 'Meticulous',
      content: 'careful about details; very precise.',
      meaning: 'Tamil meaning: விவரங்களைக் கவனமாகக் கவனிப்பவர்.',
      fact: 'Being meticulous helps with planning, work quality, and daily routines.',
      quiz: {
        question: 'Which sentence is correct?',
        options: ['She was meticulous with her notes.', 'He meticuloused the plan.', 'The meticulous is on the table.'],
        answer: 'She was meticulous with her notes.',
      },
    },
    {
      id: 'word-2',
      title: 'Resilient',
      content: 'able to recover quickly from difficulties.',
      meaning: 'Tamil meaning: சவால்களிலிருந்து விரைவாக மீளும் திறன்.',
      fact: 'Resilience is often built through small, consistent habits.',
      quiz: {
        question: 'A resilient person is usually:',
        options: ['Quick to give up', 'Able to recover well', 'Always perfect'],
        answer: 'Able to recover well',
      },
    },
    {
      id: 'word-3',
      title: 'Practical',
      content: 'useful and realistic in daily life.',
      meaning: 'Tamil meaning: நடைமுறைக்கு ஏற்ற, பயனுள்ள.',
      fact: 'Practical habits are often easier to keep over time than perfect routines.',
      quiz: {
        question: 'Which is the most practical habit?',
        options: ['Do everything at once', 'Walk for 15 minutes after lunch', 'Skip all planning'],
        answer: 'Walk for 15 minutes after lunch',
      },
    },
  ];
  const index = Array.from(date.toISOString().slice(0, 10)).reduce((sum, char) => sum + char.charCodeAt(0), 0) % lessons.length;
  return lessons[index];
}

function App() {
  const [data, setData] = useState<AppData>(() => readAppData());
  const location = useLocation();

  useEffect(() => {
    saveAppData(data);
  }, [data]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', data.profile.theme === 'dark');
  }, [data.profile.theme]);

  const isProtectedRoute = ['/dashboard', '/tasks', '/expenses', '/habits', '/reminders', '/medicine', '/documents', '/learning', '/helper', '/goals', '/settings'].includes(location.pathname);

  if (isProtectedRoute && !data.profile.onboardingCompleted) {
    return <Navigate to="/onboarding" replace />;
  }

  return (
    <Routes>
      <Route path="/" element={<LandingPage data={data} setData={setData} />} />
      <Route path="/onboarding" element={<OnboardingPage data={data} setData={setData} />} />
      <Route path="/dashboard" element={<AppLayout data={data} setData={setData}><DashboardPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/tasks" element={<AppLayout data={data} setData={setData}><TasksPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/expenses" element={<AppLayout data={data} setData={setData}><ExpensesPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/habits" element={<AppLayout data={data} setData={setData}><HabitsPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/reminders" element={<AppLayout data={data} setData={setData}><RemindersPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/medicine" element={<AppLayout data={data} setData={setData}><MedicinePage data={data} setData={setData} /></AppLayout>} />
      <Route path="/documents" element={<AppLayout data={data} setData={setData}><DocumentsPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/learning" element={<AppLayout data={data} setData={setData}><LearningPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/helper" element={<AppLayout data={data} setData={setData}><HelperPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/goals" element={<AppLayout data={data} setData={setData}><GoalsPage data={data} setData={setData} /></AppLayout>} />
      <Route path="/settings" element={<AppLayout data={data} setData={setData}><SettingsPage data={data} setData={setData} /></AppLayout>} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

function AppLayout({ children, data, setData }: { children: ReactNode; data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const t = translations[data.profile.language] || translations.en;
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <div className="mx-auto flex max-w-[1500px] gap-4 p-3 md:p-5">
        <aside className="hidden w-72 shrink-0 rounded-3xl border border-slate-200 bg-white/80 p-4 shadow-soft backdrop-blur dark:border-slate-700 dark:bg-slate-900/80 lg:block">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-teal-500 text-lg font-bold text-white">L</div>
            <div>
              <div className="text-xl font-bold">{t.appName}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{t.tagLine}</div>
            </div>
          </div>

          <nav className="space-y-1.5">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300'
                      : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                  }`
                }
              >
                <Icon size={18} />
                <span>{t[label]}</span>
              </NavLink>
            ))}
          </nav>

          <div className="mt-8 rounded-2xl border border-indigo-100 bg-indigo-50 p-3 dark:border-indigo-500/40 dark:bg-indigo-500/10">
            <p className="text-xs uppercase tracking-[0.18em] text-indigo-700 dark:text-indigo-300">Quick add</p>
            <div className="mt-3 grid gap-2">
              {['task', 'expense', 'reminder', 'goal'].map((kind) => (
                <button
                  key={kind}
                  onClick={() => navigate(kind === 'task' ? '/tasks' : kind === 'expense' ? '/expenses' : kind === 'reminder' ? '/reminders' : '/goals')}
                  className="flex items-center justify-between rounded-xl bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition hover:shadow dark:bg-slate-800 dark:text-slate-200"
                >
                  <span className="capitalize">{kind}</span>
                  <Plus size={16} />
                </button>
              ))}
            </div>
          </div>
        </aside>

        <main className="flex-1 pb-24 md:pb-6">
          <header className="sticky top-0 z-20 mb-4 rounded-2xl border border-slate-200 bg-white/80 p-3 shadow-soft backdrop-blur dark:border-slate-700 dark:bg-slate-900/80 lg:rounded-3xl">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button onClick={() => setMobileOpen((prev) => !prev)} className="rounded-xl border border-slate-200 p-2 text-slate-700 dark:border-slate-700 dark:text-slate-200 lg:hidden">
                  <Menu size={18} />
                </button>
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{t.appName}</div>
                  <div className="font-semibold">{t.welcome}</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setData((prev) => ({ ...prev, profile: { ...prev.profile, theme: prev.profile.theme === 'dark' ? 'light' : 'dark' } }))}
                  className="rounded-xl border border-slate-200 p-2 text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                  aria-label="Toggle theme"
                >
                  {data.profile.theme === 'dark' ? <SunMedium size={18} /> : <Moon size={18} />}
                </button>
                <button className="rounded-xl border border-slate-200 p-2 text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800" aria-label="Notifications">
                  <Bell size={18} />
                </button>
              </div>
            </div>

            {mobileOpen && (
              <div className="mt-3 space-y-1.5 lg:hidden">
                {navItems.map(({ to, label, icon: Icon }) => (
                  <NavLink
                    key={to}
                    to={to}
                    onClick={() => setMobileOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium ${
                        isActive ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300' : 'text-slate-600 dark:text-slate-300'
                      }`
                    }
                  >
                    <Icon size={18} />
                    <span>{t[label]}</span>
                  </NavLink>
                ))}
              </div>
            )}
          </header>

          <div className="space-y-5">{children}</div>
        </main>
      </div>

      <nav className="fixed bottom-0 left-0 z-30 flex w-full border-t border-slate-200 bg-white/90 px-2 py-2 backdrop-blur dark:border-slate-700 dark:bg-slate-950/90 lg:hidden">
        <div className="mx-auto grid w-full max-w-md grid-cols-5 gap-2">
          {navItems.slice(0, 5).map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex flex-col items-center justify-center gap-1 rounded-xl px-2 py-2 text-[10px] font-medium ${
                  isActive ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300' : 'text-slate-600 dark:text-slate-300'
                }`
              }
            >
              <Icon size={16} />
              <span>{t[label]}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}

function LandingPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const navigate = useNavigate();
  const t = translations[data.profile.language] || translations.en;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-6 md:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-teal-500 text-lg font-bold text-white">L</div>
          <div>
            <div className="text-xl font-bold">{t.appName}</div>
            <div className="text-xs text-slate-500 dark:text-slate-400">{t.tagLine}</div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setData((prev) => ({ ...prev, profile: { ...prev.profile, language: prev.profile.language === 'en' ? 'ta' : 'en' } }))}
            className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
          >
            {data.profile.language === 'en' ? 'தமிழ்' : 'English'}
          </button>
          <button onClick={() => navigate('/onboarding')} className="link-button bg-indigo-600 text-white hover:bg-indigo-500">
            {t.startDay}
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-16 px-4 pb-20 md:px-6">
        <section className="grid items-center gap-8 py-10 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-medium text-indigo-700 dark:border-indigo-500/40 dark:bg-indigo-500/10 dark:text-indigo-300">
              <Sparkles size={14} /> Everyday life made simpler
            </div>
            <h1 className="max-w-xl text-4xl font-black tracking-tight md:text-6xl">Your Entire Day. One Simple Space.</h1>
            <p className="mt-5 max-w-xl text-lg text-slate-600 dark:text-slate-300">
              Manage your tasks, money, habits, reminders and personal goals — all in one place.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <button onClick={() => navigate('/onboarding')} className="link-button bg-indigo-600 text-white hover:bg-indigo-500">
                {t.startDay}
              </button>
              <a href="#features" className="link-button border border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">
                {t.explore}
              </a>
            </div>
          </div>

          <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-soft dark:border-slate-700 dark:bg-slate-900">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800">
              <div className="mb-2 flex items-center justify-between text-sm font-medium text-slate-600 dark:text-slate-300">
                <span>Today</span>
                <span className="badge bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">82% complete</span>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between rounded-xl bg-white p-2 dark:bg-slate-900">
                  <span>Submit report</span>
                  <CheckCircle2 className="text-emerald-500" size={18} />
                </div>
                <div className="flex items-center justify-between rounded-xl bg-white p-2 dark:bg-slate-900">
                  <span>Pay electricity bill</span>
                  <span className="text-amber-500">Due today</span>
                </div>
                <div className="flex items-center justify-between rounded-xl bg-white p-2 dark:bg-slate-900">
                  <span>Evening walk</span>
                  <span className="text-sky-500">Ready</span>
                </div>
              </div>
            </div>

            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl bg-indigo-50 p-4 dark:bg-indigo-500/10">
                <div className="text-xs uppercase tracking-[0.18em] text-indigo-600 dark:text-indigo-300">Budget</div>
                <div className="mt-2 text-2xl font-bold">₹10,000</div>
                <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">₹4,200 left</div>
              </div>
              <div className="rounded-2xl bg-teal-50 p-4 dark:bg-teal-500/10">
                <div className="text-xs uppercase tracking-[0.18em] text-teal-600 dark:text-teal-300">Habits</div>
                <div className="mt-2 text-2xl font-bold">6/7</div>
                <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">Current streak: 12</div>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="space-y-8">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-indigo-600 dark:text-indigo-300">Core features</p>
            <h2 className="mt-1 text-3xl font-bold">Everything you need for a calmer day</h2>
          </div>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {[
              ['Daily planning', 'Keep your tasks, deadlines, and reminders visible in one place.'],
              ['Money clarity', 'Track income, spending, and monthly budgets without spreadsheets.'],
              ['Healthy routines', 'Build habits with streaks and weekly progress.'],
              ['Life admin', 'Manage medicine schedules, docs, and important dates with ease.'],
            ].map(([title, desc]) => (
              <div key={title} className="card p-5">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
                  <Sparkles size={18} />
                </div>
                <h3 className="text-lg font-semibold">{title}</h3>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="grid gap-5 lg:grid-cols-3">
          {[
            ['How it works', '1. Capture the essentials. 2. Track your rhythm. 3. Review what matters.'],
            ['Mobile-friendly', 'A responsive layout keeps the app usable from phone to desktop.'],
            ['Privacy-first', 'This version stores data in the browser only and avoids unnecessary personal data collection.'],
          ].map(([title, text]) => (
            <div key={title} className="card p-6">
              <h3 className="text-xl font-semibold">{title}</h3>
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">{text}</p>
            </div>
          ))}
        </section>

        <section className="space-y-5">
          <h3 className="text-3xl font-bold">Frequently asked questions</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {[
              ['What does it store?', 'Tasks, expenses, habits, reminders, goals, and local settings in browser localStorage.'],
              ['Does it require registration?', 'No. The first-run onboarding is local and optional.'],
              ['Can I use Tamil?', 'Yes. English and Tamil switching is included.'],
              ['What about notifications?', 'Browser notifications are supported only when the permission is granted.'],
            ].map(([q, a]) => (
              <div key={q} className="card p-5">
                <p className="font-semibold">{q}</p>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{a}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-[32px] bg-gradient-to-r from-indigo-600 to-teal-500 p-8 text-white shadow-soft">
          <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-sm uppercase tracking-[0.2em] text-indigo-100">Ready to begin?</p>
              <h3 className="mt-2 text-3xl font-bold">Make your next day feel lighter.</h3>
            </div>
            <button onClick={() => navigate('/onboarding')} className="link-button bg-white text-indigo-700 hover:bg-slate-100">
              {t.startDay}
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}

function OnboardingPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const navigate = useNavigate();
  const [name, setName] = useState(data.profile.name || '');
  const [language, setLanguage] = useState<Lang>(data.profile.language || 'en');
  const [theme, setTheme] = useState<Theme>(data.profile.theme || 'light');
  const [interests, setInterests] = useState<string[]>(data.profile.interests || []);
  const items = ['Health', 'Learning', 'Career', 'Family', 'Money', 'Home', 'Focus', 'Wellbeing'];

  const toggle = (item: string) => {
    setInterests((prev) => (prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]));
  };

  const continueSetup = () => {
    if (!name.trim()) return;
    setData((prev) => ({
      ...prev,
      profile: { ...prev.profile, name: name.trim(), language, theme, interests, onboardingCompleted: true },
    }));
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-100 px-4 py-10 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <div className="mx-auto max-w-3xl card p-6 md:p-8">
        <p className="text-sm uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-300">Welcome</p>
        <h1 className="mt-2 text-3xl font-bold">Set up your LifeOS</h1>

        <div className="mt-6 grid gap-5">
          <div>
            <label className="mb-2 block text-sm font-medium">Display name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 dark:border-slate-700 dark:bg-slate-900" />
          </div>
          <div className="grid gap-5 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium">Language</label>
              <select value={language} onChange={(e) => setLanguage(e.target.value as Lang)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 dark:border-slate-700 dark:bg-slate-900">
                <option value="en">English</option>
                <option value="ta">தமிழ்</option>
              </select>
            </div>
            <div>
              <label className="mb-2 block text-sm font-medium">Theme</label>
              <select value={theme} onChange={(e) => setTheme(e.target.value as Theme)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 dark:border-slate-700 dark:bg-slate-900">
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>
          </div>

          <div>
            <label className="mb-3 block text-sm font-medium">Main interests</label>
            <div className="flex flex-wrap gap-2">
              {items.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => toggle(item)}
                  className={`rounded-full border px-3 py-1.5 text-sm ${
                    interests.includes(item)
                      ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300'
                      : 'border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end gap-3">
          <button onClick={() => navigate('/')} className="rounded-xl border border-slate-200 px-4 py-2.5 font-medium text-slate-700 dark:border-slate-700 dark:text-slate-200">Later</button>
          <button onClick={continueSetup} className="rounded-xl bg-indigo-600 px-4 py-2.5 font-medium text-white hover:bg-indigo-500">Continue</button>
        </div>
      </div>
    </div>
  );
}

function DashboardPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const dailyTotal = useMemo(() => {
    const tasksScore = data.tasks.length ? Math.round((data.tasks.filter((task) => task.completed).length / data.tasks.length) * 100) : 0;
    const habitsScore = data.habits.length ? Math.round((data.habits.filter((habit) => habit.completions.includes(todayKey())).length / data.habits.length) * 100) : 0;
    return Math.round((tasksScore + habitsScore) / 2);
  }, [data.tasks, data.habits]);

  const todayTasks = data.tasks.filter((task) => task.dueDate === todayKey() && !task.completed);
  const monthlySpend = data.expenses.filter((entry) => entry.type === 'expense' && entry.date.startsWith(new Date().toISOString().slice(0, 7))).reduce((sum, item) => sum + item.amount, 0);
  const budgetLeft = 15000 - monthlySpend;

  const widgets = [
    { id: 'tasks', title: 'Today’s tasks', content: <TodayTasksCard data={data} setData={setData} /> },
    { id: 'expenses', title: 'Quick expense', content: <QuickExpenseCard data={data} setData={setData} /> },
    { id: 'reminders', title: 'Upcoming reminders', content: <ReminderWidget data={data} /> },
    { id: 'habits', title: 'Habit progress', content: <HabitsWidget data={data} /> },
  ].filter((widget) => data.settings.dashboardWidgets.includes(widget.id));

  return (
    <div className="space-y-5">
      <div className="card p-5 md:p-6">
        <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">{getGreeting(data.profile.language)}</p>
            <h1 className="mt-1 text-3xl font-bold">{data.profile.name || 'LifeOS user'}</h1>
          </div>
          <div className="text-right">
            <div className="text-sm text-slate-500 dark:text-slate-400">{formatShortDate(todayKey())}</div>
            <div className="text-lg font-semibold">{new Date().toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', timeZone: 'Asia/Kolkata' })}</div>
          </div>
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl bg-indigo-50 p-4 dark:bg-indigo-500/10">
            <div className="text-sm text-indigo-700 dark:text-indigo-300">Daily progress</div>
            <div className="mt-2 text-3xl font-bold">{dailyTotal}%</div>
          </div>
          <div className="rounded-2xl bg-teal-50 p-4 dark:bg-teal-500/10">
            <div className="text-sm text-teal-700 dark:text-teal-300">Tasks today</div>
            <div className="mt-2 text-3xl font-bold">{todayTasks.length}</div>
          </div>
          <div className="rounded-2xl bg-amber-50 p-4 dark:bg-amber-500/10">
            <div className="text-sm text-amber-700 dark:text-amber-300">Budget left</div>
            <div className="mt-2 text-3xl font-bold">{formatCurrency(Math.max(0, budgetLeft))}</div>
          </div>
        </div>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        {widgets.map((widget) => (
          <div key={widget.id} className="card p-4 md:p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold">{widget.title}</h3>
              {widget.id === 'tasks' && <span className="badge bg-indigo-100 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">{todayTasks.length} due</span>}
            </div>
            {widget.content}
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <LearningWidget data={data} setData={setData} />
        <ImportantDatesWidget data={data} />
        <QuickActions data={data} />
      </div>
    </div>
  );
}

function TodayTasksCard({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const items = data.tasks.filter((task) => task.dueDate === todayKey()).slice(0, 4);

  if (!items.length) {
    return <div className="rounded-2xl border border-dashed border-slate-200 p-4 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">No tasks for today. Add one to get started.</div>;
  }

  return (
    <div className="space-y-3">
      {items.map((task) => (
        <button
          key={task.id}
          onClick={() => setData((prev) => ({ ...prev, tasks: prev.tasks.map((item) => item.id === task.id ? { ...item, completed: !item.completed } : item) }))}
          className="flex w-full items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3 text-left transition hover:border-indigo-200 dark:border-slate-700 dark:bg-slate-800"
        >
          <div className="flex items-center gap-3">
            <div className={`flex h-5 w-5 items-center justify-center rounded-full ${task.completed ? 'bg-emerald-500 text-white' : 'border border-slate-300 bg-white dark:border-slate-600 dark:bg-slate-700'}`}>
              {task.completed && <Check size={12} />}
            </div>
            <div>
              <div className="font-medium">{task.title}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400">{task.priority} • {task.category}</div>
            </div>
          </div>
          <ArrowRight size={16} className="text-slate-400" />
        </button>
      ))}
    </div>
  );
}

function QuickExpenseCard({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [type, setType] = useState<ExpType>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Food');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(todayKey());

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <select value={type} onChange={(e) => setType(e.target.value as ExpType)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-800">
          <option value="expense">Expense</option>
          <option value="income">Income</option>
        </select>
        <select value={category} onChange={(e) => setCategory(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-800">
          {['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Education', 'Other'].map((option) => (
            <option key={option} value={option}>{option}</option>
          ))}
        </select>
      </div>
      <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" step="0.01" placeholder="Amount" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-800" />
      <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-800" />
      <input value={date} onChange={(e) => setDate(e.target.value)} type="date" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-800" />
      <button
        onClick={() => {
          const value = Number(amount);
          if (!amount || Number.isNaN(value) || value <= 0) return;
          setData((prev) => ({
            ...prev,
            expenses: [{ id: uid('expense'), type, category, description: description || 'Quick entry', amount: Number(value.toFixed(2)), date, createdAt: new Date().toISOString() }, ...prev.expenses],
          }));
          setAmount('');
          setDescription('');
        }}
        className="w-full rounded-xl bg-indigo-600 px-3 py-2.5 font-medium text-white hover:bg-indigo-500"
      >
        Add entry
      </button>
    </div>
  );
}

function ReminderWidget({ data }: { data: AppData }) {
  const reminders = data.reminders.filter((item) => !item.completed).slice(0, 3);

  if (!reminders.length) {
    return <div className="rounded-2xl border border-dashed border-slate-200 p-4 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">No reminders waiting.</div>;
  }

  return (
    <div className="space-y-3">
      {reminders.map((reminder) => (
        <div key={reminder.id} className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800">
          <div className="flex items-center justify-between">
            <div className="font-medium">{reminder.title}</div>
            <span className="badge bg-sky-100 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300">{reminder.type}</span>
          </div>
          <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">{formatShortDate(reminder.date)} {reminder.time ? `• ${reminder.time}` : ''}</div>
        </div>
      ))}
    </div>
  );
}

function HabitsWidget({ data }: { data: AppData }) {
  const habits = data.habits.slice(0, 3);

  if (!habits.length) {
    return <div className="rounded-2xl border border-dashed border-slate-200 p-4 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">No habits yet.</div>;
  }

  return (
    <div className="space-y-3">
      {habits.map((habit) => {
        const done = habit.completions.includes(todayKey());
        return (
          <div key={habit.id} className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800">
            <div className="flex items-center justify-between">
              <span className="font-medium">{habit.title}</span>
              <span className={`badge ${done ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200'}`}>
                {done ? 'Done' : 'Open'}
              </span>
            </div>
            <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">Streak: {calculateStreak(habit.completions)}</div>
          </div>
        );
      })}
    </div>
  );
}

function LearningWidget({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const lesson = getDailyLesson(new Date());
  const learned = data.learningHistory.includes(lesson.id);

  return (
    <div className="card p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2"><BookOpen size={18} className="text-indigo-600" /><h3 className="text-lg font-semibold">Daily learning</h3></div>
        <button onClick={() => setData((prev) => ({ ...prev, learningHistory: prev.learningHistory.includes(lesson.id) ? prev.learningHistory : [...prev.learningHistory, lesson.id] }))} className="rounded-xl bg-indigo-600 px-3 py-2 text-sm text-white hover:bg-indigo-500">
          {learned ? 'Learned' : 'Mark learned'}
        </button>
      </div>

      <div className="space-y-3">
        <div className="rounded-2xl bg-indigo-50 p-3 dark:bg-indigo-500/10">
          <div className="text-xs uppercase tracking-[0.15em] text-indigo-600 dark:text-indigo-300">Word</div>
          <div className="mt-1 text-xl font-bold">{lesson.title}</div>
          <div className="mt-1 text-slate-600 dark:text-slate-300">{lesson.content}</div>
        </div>
        <div className="rounded-xl border border-slate-200 p-3 text-sm dark:border-slate-700">{lesson.fact}</div>
      </div>
    </div>
  );
}

function ImportantDatesWidget({ data }: { data: AppData }) {
  const items = data.reminders.filter((reminder) => !reminder.completed).slice(0, 3);

  return (
    <div className="card p-5">
      <div className="mb-3 flex items-center gap-2"><CalendarDays size={18} className="text-teal-600" /><h3 className="text-lg font-semibold">Important dates</h3></div>
      {items.length ? (
        <div className="space-y-3">
          {items.map((item) => (
            <div key={item.id} className="rounded-xl border border-slate-200 p-3 dark:border-slate-700">
              <div className="font-medium">{item.title}</div>
              <div className="text-sm text-slate-600 dark:text-slate-300">{formatShortDate(item.date)}</div>
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-slate-200 p-4 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">No upcoming dates to watch.</div>
      )}
    </div>
  );
}

function QuickActions({ data }: { data: AppData }) {
  const navigate = useNavigate();
  return (
    <div className="card p-5">
      <div className="mb-3 flex items-center gap-2"><Plus size={18} className="text-indigo-600" /><h3 className="text-lg font-semibold">Quick actions</h3></div>
      <div className="grid gap-2">
        <button onClick={() => navigate('/tasks')} className="rounded-xl bg-slate-100 px-3 py-2 text-left text-sm dark:bg-slate-800">Add Task</button>
        <button onClick={() => navigate('/expenses')} className="rounded-xl bg-slate-100 px-3 py-2 text-left text-sm dark:bg-slate-800">Add Expense</button>
        <button onClick={() => navigate('/reminders')} className="rounded-xl bg-slate-100 px-3 py-2 text-left text-sm dark:bg-slate-800">Add Reminder</button>
        <button onClick={() => navigate('/learning')} className="rounded-xl bg-slate-100 px-3 py-2 text-left text-sm dark:bg-slate-800">Start Learning</button>
      </div>
    </div>
  );
}

function TasksPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [search, setSearch] = useState('');
  const [view, setView] = useState<TaskView>('Today');
  const [sort, setSort] = useState<'date' | 'priority'>('date');
  const [showEditor, setShowEditor] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: '',
    description: '',
    dueDate: todayKey(),
    dueTime: '',
    priority: 'Medium' as Priority,
    category: 'General',
    completed: false,
  });

  const filtered = useMemo(() => {
    let items = [...data.tasks];
    if (search.trim()) items = items.filter((task) => `${task.title} ${task.description} ${task.category}`.toLowerCase().includes(search.trim().toLowerCase()));
    if (view === 'Today') items = items.filter((task) => task.dueDate === todayKey());
    if (view === 'Upcoming') items = items.filter((task) => task.dueDate > todayKey() && !task.completed);
    if (view === 'Completed') items = items.filter((task) => task.completed);
    if (sort === 'priority') {
      const rank: Record<Priority, number> = { Low: 1, Medium: 2, High: 3 };
      items.sort((a, b) => rank[b.priority] - rank[a.priority]);
    } else {
      items.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
    }
    return items;
  }, [data.tasks, search, sort, view]);

  const openNew = () => {
    setEditingId(null);
    setForm({ title: '', description: '', dueDate: todayKey(), dueTime: '', priority: 'Medium', category: 'General', completed: false });
    setShowEditor(true);
  };

  const openEdit = (task: Task) => {
    setEditingId(task.id);
    setForm({ title: task.title, description: task.description, dueDate: task.dueDate, dueTime: task.dueTime || '', priority: task.priority, category: task.category, completed: task.completed });
    setShowEditor(true);
  };

  const save = () => {
    if (!form.title.trim()) return;
    if (editingId) {
      setData((prev) => ({
        ...prev,
        tasks: prev.tasks.map((task) => task.id === editingId ? { ...task, title: form.title.trim(), description: form.description.trim(), dueDate: form.dueDate, dueTime: form.dueTime, priority: form.priority, category: form.category, completed: form.completed } : task),
      }));
    } else {
      setData((prev) => ({
        ...prev,
        tasks: [{ id: uid('task'), title: form.title.trim(), description: form.description.trim(), dueDate: form.dueDate, dueTime: form.dueTime, priority: form.priority, category: form.category, completed: false, createdAt: new Date().toISOString() }, ...prev.tasks],
      }));
    }
    setShowEditor(false);
  };

  const removeTask = (id: string) => {
    if (!window.confirm('Delete this task?')) return;
    setData((prev) => ({ ...prev, tasks: prev.tasks.filter((task) => task.id !== id) }));
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Tasks</h1>
            <div className="mt-1 text-sm text-slate-500 dark:text-slate-400">{data.tasks.length ? Math.round((data.tasks.filter((task) => task.completed).length / data.tasks.length) * 100) : 0}% completed</div>
          </div>
          <button onClick={openNew} className="link-button bg-indigo-600 text-white hover:bg-indigo-500">
            <Plus size={16} className="mr-2" /> Add Task
          </button>
        </div>

        <div className="mt-5 flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 text-slate-400" size={16} />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tasks" className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-4 dark:border-slate-700 dark:bg-slate-900" />
          </div>
          <select value={sort} onChange={(e) => setSort(e.target.value as 'date' | 'priority')} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900">
            <option value="date">Sort by date</option>
            <option value="priority">Sort by priority</option>
          </select>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {(['Today', 'Upcoming', 'Completed', 'All'] as TaskView[]).map((tab) => (
            <button key={tab} onClick={() => setView(tab)} className={`rounded-full px-3 py-1.5 text-sm font-medium ${view === tab ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200'}`}>
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="card p-5">
        {filtered.length ? (
          <div className="space-y-3">
            {filtered.map((task) => (
              <div key={task.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800/80">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <button onClick={() => setData((prev) => ({ ...prev, tasks: prev.tasks.map((item) => item.id === task.id ? { ...item, completed: !item.completed } : item) }))} className={`mt-0.5 flex h-5 w-5 items-center justify-center rounded-full border ${task.completed ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-300 bg-white dark:border-slate-600 dark:bg-slate-700'}`}>
                      {task.completed && <Check size={12} />}
                    </button>
                    <div>
                      <div className="font-semibold">{task.title}</div>
                      {task.description && <div className="text-sm text-slate-500 dark:text-slate-400">{task.description}</div>}
                      <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span>{formatShortDate(task.dueDate)}</span>
                        {task.dueTime && <span>{task.dueTime}</span>}
                        <span>{task.category}</span>
                        <span>{task.priority}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(task)} className="rounded-xl border border-slate-200 p-2 dark:border-slate-700"><Pencil size={14} /></button>
                    <button onClick={() => removeTask(task.id)} className="rounded-xl border border-slate-200 p-2 text-red-500 dark:border-slate-700"><Trash2 size={14} /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-slate-200 p-6 text-center text-slate-500 dark:border-slate-700 dark:text-slate-400">No tasks match this view.</div>
        )}
      </div>

      {showEditor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-xl rounded-3xl bg-white p-5 shadow-soft dark:bg-slate-900">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-xl font-bold">{editingId ? 'Edit task' : 'New task'}</h3>
              <button onClick={() => {
                if (form.title.trim() || form.description.trim()) {
                  if (window.confirm('Discard unsaved changes?')) setShowEditor(false);
                } else {
                  setShowEditor(false);
                }
              }} className="rounded-xl border border-slate-200 p-2 dark:border-slate-700"><X size={15} /></button>
            </div>
            <div className="space-y-4">
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Task title" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-800" />
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description" className="min-h-[100px] w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-800" />
              <div className="grid gap-3 md:grid-cols-2">
                <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-800" />
                <input type="time" value={form.dueTime} onChange={(e) => setForm({ ...form, dueTime: e.target.value })} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-800" />
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as Priority })} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-800">
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>
                <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Category" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-800" />
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-3">
              <button onClick={() => setShowEditor(false)} className="rounded-xl border border-slate-200 px-4 py-2.5 text-slate-700 dark:border-slate-700 dark:text-slate-200">Cancel</button>
              <button onClick={save} className="rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ExpensesPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [type, setType] = useState<ExpType>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Food');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(todayKey());
  const [filterMonth, setFilterMonth] = useState(new Date().toISOString().slice(0, 7));
  const [filterCategory, setFilterCategory] = useState('All');

  const spending = data.expenses.filter((entry) => entry.type === 'expense' && entry.date.startsWith(filterMonth)).reduce((sum, entry) => sum + entry.amount, 0);
  const income = data.expenses.filter((entry) => entry.type === 'income' && entry.date.startsWith(filterMonth)).reduce((sum, entry) => sum + entry.amount, 0);
  const remaining = 15000 - spending;

  const pieData = useMemo(() => {
    const map = new Map<string, number>();
    data.expenses.forEach((entry) => {
      if (entry.type === 'expense' && entry.date.startsWith(filterMonth)) {
        map.set(entry.category, (map.get(entry.category) || 0) + entry.amount);
      }
    });
    return [...map.entries()].map(([name, value]) => ({ name, value }));
  }, [data.expenses, filterMonth]);

  const filtered = data.expenses.filter((entry) => entry.date.startsWith(filterMonth) && (filterCategory === 'All' || entry.category === filterCategory));

  const exportCsv = () => {
    const rows = [['Type', 'Date', 'Category', 'Description', 'Amount']];
    filtered.forEach((entry) => rows.push([entry.type, entry.date, entry.category, entry.description, String(entry.amount)]));
    const text = rows.map((row) => row.join(',')).join('\n');
    const blob = new Blob([text], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `lifeos-${filterMonth}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const saveEntry = () => {
    const value = Number(amount);
    if (!amount || Number.isNaN(value) || value <= 0) return;
    setData((prev) => ({
      ...prev,
      expenses: [{ id: uid('expense'), type, amount: Number(value.toFixed(2)), category, description: description || 'Transaction', date, createdAt: new Date().toISOString() }, ...prev.expenses],
    }));
    setAmount('');
    setDescription('');
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <div className="mb-4 flex items-center justify-between">
          <h1 className="text-3xl font-bold">Expenses</h1>
          <button onClick={exportCsv} className="link-button border border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">
            <Download size={16} className="mr-2" /> Export CSV
          </button>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl bg-emerald-50 p-4 dark:bg-emerald-500/10">
            <div className="text-sm text-emerald-700 dark:text-emerald-300">Income</div>
            <div className="mt-2 text-2xl font-bold">{formatCurrency(income)}</div>
          </div>
          <div className="rounded-2xl bg-rose-50 p-4 dark:bg-rose-500/10">
            <div className="text-sm text-rose-700 dark:text-rose-300">Spending</div>
            <div className="mt-2 text-2xl font-bold">{formatCurrency(spending)}</div>
          </div>
          <div className="rounded-2xl bg-indigo-50 p-4 dark:bg-indigo-500/10">
            <div className="text-sm text-indigo-700 dark:text-indigo-300">Remaining</div>
            <div className="mt-2 text-2xl font-bold">{formatCurrency(remaining)}</div>
          </div>
        </div>
        {remaining < 2000 && <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">Your spending is approaching or above the monthly budget.</div>}
      </div>

      <div className="grid gap-5 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="card p-5">
          <h3 className="text-xl font-semibold">Add entry</h3>
          <div className="mt-4 space-y-3">
            <select value={type} onChange={(e) => setType(e.target.value as ExpType)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900">
              <option value="expense">Expense</option>
              <option value="income">Income</option>
            </select>
            <input value={amount} onChange={(e) => setAmount(e.target.value)} step="0.01" type="number" placeholder="Amount" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900">
              {['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Education', 'Other'].map((option) => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
            <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
            <input value={date} onChange={(e) => setDate(e.target.value)} type="date" className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
            <button onClick={saveEntry} className="w-full rounded-xl bg-indigo-600 px-3 py-2.5 font-medium text-white hover:bg-indigo-500">Save transaction</button>
          </div>
        </div>

        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between gap-3">
            <h3 className="text-xl font-semibold">Spending breakdown</h3>
            <input type="month" value={filterMonth} onChange={(e) => setFilterMonth(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-900" />
          </div>
          <div className="h-64">
            {pieData.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={80} label>
                    {pieData.map((entry, index) => (
                      <Cell key={entry.name} fill={['#4F46E5', '#14B8A6', '#F59E0B', '#EF4444', '#8B5CF6', '#0EA5E9', '#F97316'][index % 7]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(Number(value))} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center rounded-2xl border border-dashed border-slate-200 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">No spending data.</div>
            )}
          </div>
        </div>
      </div>

      <div className="card p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-xl font-semibold">Recent transactions</h3>
          <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-900">
            <option value="All">All categories</option>
            {['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Education', 'Other'].map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>
        <div className="space-y-3">
          {filtered.length ? filtered.map((item) => (
            <div key={item.id} className="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800">
              <div>
                <div className="font-medium">{item.description}</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">{item.category} • {formatShortDate(item.date)}</div>
              </div>
              <div className="flex items-center gap-3">
                <div className={`text-right font-semibold ${item.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {item.type === 'income' ? '+' : '-'}{formatCurrency(item.amount)}
                </div>
                <button onClick={() => setData((prev) => ({ ...prev, expenses: prev.expenses.filter((entry) => entry.id !== item.id) }))} className="rounded-xl border border-slate-200 p-2 text-red-500 dark:border-slate-700"><Trash2 size={14} /></button>
              </div>
            </div>
          )) : <div className="rounded-2xl border border-dashed border-slate-200 p-5 text-center text-slate-500 dark:border-slate-700 dark:text-slate-400">No transactions for this filter.</div>}
        </div>
      </div>
    </div>
  );
}

function HabitsPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const addHabit = () => {
    if (!title.trim()) return;
    setData((prev) => ({ ...prev, habits: [{ id: uid('habit'), title: title.trim(), description: description.trim(), completions: [] }, ...prev.habits] }));
    setTitle('');
    setDescription('');
  };

  const toggleHabit = (habitId: string) => {
    const key = todayKey();
    setData((prev) => ({ ...prev, habits: prev.habits.map((habit) => habit.id === habitId ? { ...habit, completions: habit.completions.includes(key) ? habit.completions.filter((date) => date !== key) : [...habit.completions, key] } : habit) }));
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h1 className="text-3xl font-bold">Habits</h1>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Habit title" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        </div>
        <div className="mt-3 flex justify-end"><button onClick={addHabit} className="rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">Add habit</button></div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {data.habits.length ? data.habits.map((habit) => {
          const done = habit.completions.includes(todayKey());
          const weekDates = Array.from({ length: 7 }, (_, index) => {
            const date = new Date();
            date.setDate(date.getDate() - (6 - index));
            return formatDateForStorage(date);
          });

          return (
            <div key={habit.id} className="card p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xl font-semibold">{habit.title}</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">{habit.description || 'No description'}</div>
                </div>
                <button onClick={() => setData((prev) => ({ ...prev, habits: prev.habits.filter((item) => item.id !== habit.id) }))} className="rounded-xl border border-slate-200 p-2 text-red-500 dark:border-slate-700"><Trash2 size={14} /></button>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">Current streak</div>
                  <div className="text-2xl font-bold">{calculateStreak(habit.completions)}</div>
                </div>
                <button onClick={() => toggleHabit(habit.id)} className={`rounded-xl px-4 py-2 font-medium ${done ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-100'}`}>
                  {done ? 'Completed' : 'Mark done'}
                </button>
              </div>
              <div className="mt-4 grid grid-cols-7 gap-2">
                {weekDates.map((dayKey) => {
                  const isDone = habit.completions.includes(dayKey);
                  return (
                    <div key={dayKey} className={`flex h-9 items-center justify-center rounded-lg text-xs ${isDone ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-slate-100 dark:bg-slate-800'}`}>
                      {new Date(`${dayKey}T12:00:00`).getDate()}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        }) : <div className="card p-5 text-slate-500 dark:text-slate-400">No habits created yet.</div>}
      </div>
    </div>
  );
}

function RemindersPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(todayKey());
  const [time, setTime] = useState('');
  const [notes, setNotes] = useState('');
  const [type, setType] = useState('Personal');
  const [view, setView] = useState<'Today' | 'Upcoming' | 'Past Due'>('Upcoming');

  const filtered = data.reminders.filter((reminder) => {
    if (view === 'Today') return reminder.date === todayKey();
    if (view === 'Upcoming') return reminder.date >= todayKey();
    return reminder.date < todayKey();
  });

  const addReminder = () => {
    if (!title.trim()) return;
    setData((prev) => ({ ...prev, reminders: [{ id: uid('reminder'), title: title.trim(), date, time, notes, type, completed: false }, ...prev.reminders] }));
    setTitle('');
    setTime('');
    setNotes('');
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h1 className="text-3xl font-bold">Reminders</h1>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Reminder title" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <select value={type} onChange={(e) => setType(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900">
            {['Personal', 'Bill', 'Appointment', 'Birthday', 'Renewal', 'Custom'].map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        </div>
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Notes" className="mt-3 min-h-[90px] w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        <div className="mt-3 flex items-center justify-between gap-3">
          <div className="text-sm text-slate-500 dark:text-slate-400">Browser permissions and device settings affect delivery.</div>
          <button onClick={addReminder} className="rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">Add reminder</button>
        </div>
      </div>

      <div className="card p-5">
        <div className="mb-4 flex flex-wrap gap-2">
          {(['Today', 'Upcoming', 'Past Due'] as Array<'Today' | 'Upcoming' | 'Past Due'>).map((tab) => (
            <button key={tab} onClick={() => setView(tab)} className={`rounded-full px-3 py-1.5 text-sm font-medium ${view === tab ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>
              {tab}
            </button>
          ))}
        </div>
        {filtered.length ? (
          <div className="space-y-3">
            {filtered.map((item) => (
              <div key={item.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold">{item.title}</div>
                    <div className="text-sm text-slate-500 dark:text-slate-400">{formatShortDate(item.date)} {item.time ? `• ${item.time}` : ''}</div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => setData((prev) => ({ ...prev, reminders: prev.reminders.map((r) => r.id === item.id ? { ...r, completed: !r.completed } : r) }))} className={`rounded-xl px-3 py-1.5 text-sm ${item.completed ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>{item.completed ? 'Done' : 'Mark done'}</button>
                    <button onClick={() => setData((prev) => ({ ...prev, reminders: prev.reminders.filter((r) => r.id !== item.id) }))} className="rounded-xl border border-slate-200 p-2 text-red-500 dark:border-slate-700"><Trash2 size={14} /></button>
                  </div>
                </div>
                {item.notes && <div className="mt-2 text-sm text-slate-600 dark:text-slate-300">{item.notes}</div>}
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-slate-200 p-6 text-center text-slate-500 dark:border-slate-700 dark:text-slate-400">No reminders in this view.</div>
        )}
      </div>
    </div>
  );
}

function MedicinePage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [name, setName] = useState('');
  const [times, setTimes] = useState('08:00');
  const [startDate, setStartDate] = useState(todayKey());
  const [endDate, setEndDate] = useState('');
  const [notes, setNotes] = useState('');

  const addMedicine = () => {
    if (!name.trim()) return;
    setData((prev) => ({ ...prev, medicines: [{ id: uid('med'), name: name.trim(), reminderTimes: times.split(',').map((v) => v.trim()).filter(Boolean), startDate, endDate: endDate || undefined, notes, status: {} }, ...prev.medicines] }));
    setName('');
    setTimes('08:00');
    setNotes('');
    setEndDate('');
  };

  const mark = (medicineId: string, timeValue: string, value: 'taken' | 'skipped') => {
    setData((prev) => ({ ...prev, medicines: prev.medicines.map((item) => item.id === medicineId ? { ...item, status: { ...item.status, [`${todayKey()}-${timeValue}`]: value } } : item) }));
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h1 className="text-3xl font-bold">Medicine schedule</h1>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Medicine name" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input value={times} onChange={(e) => setTimes(e.target.value)} placeholder="Times (comma-separated)" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        </div>
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Notes" className="mt-3 min-h-[90px] w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        <div className="mt-4 flex items-center justify-between gap-3">
          <div className="text-sm text-slate-500 dark:text-slate-400">This does not replace professional medical advice.</div>
          <button onClick={addMedicine} className="rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">Add medicine</button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {data.medicines.length ? data.medicines.map((medicine) => (
          <div key={medicine.id} className="card p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xl font-semibold">{medicine.name}</div>
                <div className="text-sm text-slate-500 dark:text-slate-400">{medicine.reminderTimes.join(', ')}</div>
              </div>
              <div className="badge bg-indigo-100 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">{medicine.startDate}</div>
            </div>
            {medicine.notes && <div className="mt-3 text-sm text-slate-600 dark:text-slate-300">{medicine.notes}</div>}
            <div className="mt-4 space-y-2">
              {medicine.reminderTimes.map((timeValue) => {
                const status = medicine.status[`${todayKey()}-${timeValue}`];
                return (
                  <div key={timeValue} className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800">
                    <div>{timeValue}</div>
                    <div className="flex gap-2">
                      <button onClick={() => mark(medicine.id, timeValue, 'taken')} className={`rounded-xl px-3 py-1.5 text-sm ${status === 'taken' ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Taken</button>
                      <button onClick={() => mark(medicine.id, timeValue, 'skipped')} className={`rounded-xl px-3 py-1.5 text-sm ${status === 'skipped' ? 'bg-rose-500 text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>Skipped</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )) : <div className="card p-5 text-slate-500 dark:text-slate-400">No medicines added yet.</div>}
      </div>
    </div>
  );
}

function DocumentsPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [name, setName] = useState('');
  const [reference, setReference] = useState('');
  const [expiryDate, setExpiryDate] = useState('');

  const addDocument = () => {
    if (!name.trim() || !expiryDate) return;
    setData((prev) => ({ ...prev, documents: [{ id: uid('doc'), name: name.trim(), reference: reference.trim(), expiryDate }, ...prev.documents] }));
    setName('');
    setReference('');
    setExpiryDate('');
  };

  const daysLeft = (dateString: string) => {
    const diff = safeDate(dateString).getTime() - new Date(todayKey()).getTime();
    return Math.ceil(diff / 86400000);
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h1 className="text-3xl font-bold">Documents</h1>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Document name" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Reference label" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input type="date" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        </div>
        <div className="mt-3 flex justify-end"><button onClick={addDocument} className="rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">Add document</button></div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {data.documents.length ? data.documents.map((item) => {
          const remaining = daysLeft(item.expiryDate);
          const status = remaining < 0 ? 'Expired' : remaining <= 30 ? 'Due soon' : 'Active';
          return (
            <div key={item.id} className="card p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xl font-semibold">{item.name}</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">{item.reference || 'No reference'}</div>
                </div>
                <span className={`badge ${status === 'Expired' ? 'bg-rose-100 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300' : status === 'Due soon' ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300'}`}>{status}</span>
              </div>
              <div className="mt-3 text-sm text-slate-600 dark:text-slate-300">Expiry: {formatShortDate(item.expiryDate)}</div>
              <div className="mt-3 text-lg font-semibold">{remaining < 0 ? `${Math.abs(remaining)} days expired` : `${remaining} days remaining`}</div>
            </div>
          );
        }) : <div className="card p-5 text-slate-500 dark:text-slate-400">No documents added yet.</div>}
      </div>
    </div>
  );
}

function LearningPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const lesson = getDailyLesson(new Date());
  const learned = data.learningHistory.includes(lesson.id);

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <div className="flex items-center justify-between gap-3">
          <h1 className="text-3xl font-bold">Daily learning</h1>
          <button onClick={() => setData((prev) => ({ ...prev, learningHistory: prev.learningHistory.includes(lesson.id) ? prev.learningHistory : [...prev.learningHistory, lesson.id] }))} className="rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">
            {learned ? 'Learned' : 'Mark as learned'}
          </button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="card p-5">
          <div className="text-sm uppercase tracking-[0.18em] text-indigo-600 dark:text-indigo-300">Featured lesson</div>
          <div className="mt-3 text-3xl font-bold">{lesson.title}</div>
          <div className="mt-3 text-slate-600 dark:text-slate-300">{lesson.content}</div>
          <div className="mt-4 rounded-xl bg-slate-50 p-3 text-sm dark:bg-slate-800">{lesson.meaning}</div>
        </div>

        <div className="card p-5">
          <div className="text-sm uppercase tracking-[0.18em] text-teal-600 dark:text-teal-300">Daily fact</div>
          <div className="mt-3 text-lg font-semibold">{lesson.fact}</div>
          <div className="mt-5 rounded-xl border border-slate-200 p-4 dark:border-slate-700">
            <div className="font-medium">{lesson.quiz.question}</div>
            <div className="mt-3 flex flex-wrap gap-2">
              {lesson.quiz.options.map((option) => (
                <button key={option} className="rounded-full border border-slate-200 px-3 py-1.5 text-sm dark:border-slate-700">{option}</button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function HelperPage({ data }: { data: AppData }) {
  const [sentence, setSentence] = useState('');
  const [category, setCategory] = useState('Office English');

  const suggestions = useMemo(() => {
    const lower = sentence.toLowerCase();
    const result: string[] = [];
    if (lower.includes('please')) result.push('Please share the updated file by 4 PM.');
    if (lower.includes('sorry')) result.push('Sorry for the delay. I will send the revised version shortly.');
    if (lower.includes('interview')) result.push('I would be glad to share a brief overview of my experience and skills.');
    if (lower.includes('call')) result.push('Could we connect for a short call at 3:30 PM today?');
    if (lower.includes('thank')) result.push('Thank you for your time and consideration.');
    if (!result.length) result.push('Try: “Could you share the details by today?”');
    return result.slice(0, 3);
  }, [sentence]);

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h1 className="text-3xl font-bold">English helper</h1>
        <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
          {data.profile.language === 'ta' ? 'அதிநவீன AI உதவி கிடைக்கவில்லை. உள்ளூர் விதிகள் அடிப்படையில் பரிந்துரைகள் வழங்கப்படுகின்றன.' : 'Advanced AI is unavailable in this version. Suggestions come from local rules and guidance.'}
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-[1fr_220px]">
          <input value={sentence} onChange={(e) => setSentence(e.target.value)} placeholder="Type a sentence or message" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900">
            {['Office English', 'Job Interviews', 'Phone Conversations', 'Everyday Conversations', 'Polite Messages', 'Grammar Practice'].map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>

        <div className="mt-5 grid gap-3">
          {suggestions.map((option) => (
            <div key={option} className="rounded-2xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200">{option}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

function GoalsPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [title, setTitle] = useState('');
  const [target, setTarget] = useState('');
  const [current, setCurrent] = useState('');
  const [deadline, setDeadline] = useState('');
  const [description, setDescription] = useState('');

  const addGoal = () => {
    if (!title.trim()) return;
    const targetValue = Number(target || 1);
    const currentValue = Number(current || 0);
    setData((prev) => ({ ...prev, goals: [{ id: uid('goal'), title: title.trim(), description: description.trim(), target: targetValue, current: currentValue, deadline: deadline || undefined }, ...prev.goals] }));
    setTitle('');
    setTarget('');
    setCurrent('');
    setDeadline('');
    setDescription('');
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h1 className="text-3xl font-bold">Goals</h1>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Goal title" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input value={target} onChange={(e) => setTarget(e.target.value)} type="number" placeholder="Target" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input value={current} onChange={(e) => setCurrent(e.target.value)} type="number" placeholder="Current progress" className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
          <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        </div>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="mt-3 min-h-[90px] w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900" />
        <div className="mt-3 flex justify-end"><button onClick={addGoal} className="rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">Add goal</button></div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {data.goals.length ? data.goals.map((goal) => {
          const progress = Math.min(100, Math.round((goal.current / Math.max(goal.target, 1)) * 100));
          return (
            <div key={goal.id} className="card p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xl font-semibold">{goal.title}</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400">{goal.description || 'No description'}</div>
                </div>
                <div className="badge bg-indigo-100 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">{progress}%</div>
              </div>
              <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
                <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-teal-500" style={{ width: `${progress}%` }} />
              </div>
              <div className="mt-4 flex items-center justify-between text-sm text-slate-600 dark:text-slate-300">
                <span>{goal.current} / {goal.target}</span>
                {goal.deadline && <span>{formatShortDate(goal.deadline)}</span>}
              </div>
              <div className="mt-4">
                <input type="number" value={goal.current} onChange={(e) => setData((prev) => ({ ...prev, goals: prev.goals.map((item) => item.id === goal.id ? { ...item, current: Number(e.target.value || 0) } : item) }))} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-900" />
              </div>
            </div>
          );
        }) : <div className="card p-5 text-slate-500 dark:text-slate-400">No goals added yet.</div>}
      </div>
    </div>
  );
}

function SettingsPage({ data, setData }: { data: AppData; setData: React.Dispatch<React.SetStateAction<AppData>> }) {
  const [message, setMessage] = useState('');

  const requestPermission = async () => {
    if (typeof Notification === 'undefined') {
      setMessage('This browser does not support notifications.');
      return;
    }
    const permission = await Notification.requestPermission();
    setData((prev) => ({ ...prev, settings: { ...prev.settings, browserAlerts: permission === 'granted' } }));
    setMessage(permission === 'granted' ? 'Notification permission granted.' : 'Permission denied. In-app alerts still work.');
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'lifeos-export.json';
    link.click();
    URL.revokeObjectURL(link.href);
    setMessage('Local data export created.');
  };

  const clearLocal = () => {
    if (!window.confirm('Clear all local LifeOS data? This cannot be undone.')) return;
    setData(getDefaultData());
    setMessage('Local data cleared.');
  };

  return (
    <div className="space-y-5">
      <div className="card p-5">
        <h1 className="text-3xl font-bold">Settings</h1>
        {message && <div className="mt-3 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300">{message}</div>}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="text-xl font-semibold">Preferences</h3>
          <div className="mt-4 space-y-4">
            <div className="flex items-center justify-between rounded-xl border border-slate-200 p-3 dark:border-slate-700">
              <span>Language</span>
              <select value={data.profile.language} onChange={(e) => setData((prev) => ({ ...prev, profile: { ...prev.profile, language: e.target.value as Lang } }))} className="rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-900">
                <option value="en">English</option>
                <option value="ta">தமிழ்</option>
              </select>
            </div>
            <div className="flex items-center justify-between rounded-xl border border-slate-200 p-3 dark:border-slate-700">
              <span>Theme</span>
              <select value={data.profile.theme} onChange={(e) => setData((prev) => ({ ...prev, profile: { ...prev.profile, theme: e.target.value as Theme } }))} className="rounded-xl border border-slate-200 bg-white px-3 py-2 dark:border-slate-700 dark:bg-slate-900">
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>
            <div className="flex items-center justify-between rounded-xl border border-slate-200 p-3 dark:border-slate-700">
              <span>Currency</span>
              <div className="font-medium">₹ INR</div>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h3 className="text-xl font-semibold">Notifications</h3>
          <div className="mt-4 space-y-4">
            <div className="flex items-center justify-between rounded-xl border border-slate-200 p-3 dark:border-slate-700">
              <span>Browser alerts</span>
              <button onClick={requestPermission} className="rounded-xl bg-indigo-600 px-3 py-2 text-sm text-white hover:bg-indigo-500">Request permission</button>
            </div>
            <div className="flex items-center justify-between rounded-xl border border-slate-200 p-3 dark:border-slate-700">
              <span>In-app reminders</span>
              <input type="checkbox" checked={data.settings.notifications} onChange={(e) => setData((prev) => ({ ...prev, settings: { ...prev.settings, notifications: e.target.checked } }))} className="h-5 w-5" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="text-xl font-semibold">Widget visibility</h3>
          <div className="mt-4 space-y-3">
            {['tasks', 'expenses', 'reminders', 'habits'].map((widget) => (
              <label key={widget} className="flex items-center justify-between rounded-xl border border-slate-200 p-3 dark:border-slate-700">
                <span className="capitalize">{widget}</span>
                <input type="checkbox" checked={data.settings.dashboardWidgets.includes(widget)} onChange={(e) => setData((prev) => {
                  const set = new Set(prev.settings.dashboardWidgets);
                  if (e.target.checked) set.add(widget); else set.delete(widget);
                  return { ...prev, settings: { ...prev.settings, dashboardWidgets: [...set] } };
                })} className="h-5 w-5" />
              </label>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h3 className="text-xl font-semibold">Data management</h3>
          <div className="mt-4 space-y-3">
            <button onClick={exportData} className="w-full rounded-xl bg-slate-100 px-3 py-2.5 text-left dark:bg-slate-800">Export local data</button>
            <button onClick={clearLocal} className="w-full rounded-xl bg-red-500 px-3 py-2.5 text-left text-white">Clear local data</button>
            <div className="rounded-xl border border-slate-200 p-3 text-sm text-slate-600 dark:border-slate-700 dark:text-slate-300">This browser stores your data locally. It is not synchronized between devices in this version.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100 px-4 dark:bg-slate-950">
      <div className="card max-w-md p-8 text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-rose-100 text-2xl text-rose-600 dark:bg-rose-500/10 dark:text-rose-300">404</div>
        <h1 className="text-2xl font-bold">Page not found</h1>
        <p className="mt-2 text-slate-600 dark:text-slate-300">The page you were looking for does not exist.</p>
        <button onClick={() => navigate('/dashboard')} className="mt-5 rounded-xl bg-indigo-600 px-4 py-2.5 text-white hover:bg-indigo-500">Back to dashboard</button>
      </div>
    </div>
  );
}

export default App;
