import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import type { AppData, Transaction, ClosingRecord, BusinessProfile, AccountBalances } from "@/types";
import { STORAGE_KEY, APP_VERSION, DEFAULT_EXPENSE_CATEGORIES, DEFAULT_INCOME_CATEGORIES } from "@/lib/constants";
import { generateTransactionId, generateClosingId } from "@/lib/id";
import { nowISO, todayDate } from "@/lib/format";

const defaultProfile: BusinessProfile = {
  businessName: "",
  ownerName: "",
  phone: "",
  address: "",
  financialYearStart: "04-01",
  currency: "INR",
  language: "english",
};

const defaultData: AppData = {
  version: APP_VERSION,
  profile: defaultProfile,
  openingBalances: { cash: 0, upi: 0, bank: 0 },
  transactions: [],
  closings: [],
  customExpenseCategories: [],
  customIncomeCategories: [],
  onboarded: false,
  demoLoaded: false,
};

function loadData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultData;
    const parsed = JSON.parse(raw);
    return validateData(parsed);
  } catch {
    return defaultData;
  }
}

export function validateData(data: unknown): AppData {
  if (!data || typeof data !== "object") return { ...defaultData };
  const d = data as Partial<AppData>;
  return {
    version: APP_VERSION,
    profile: { ...defaultProfile, ...(d.profile || {}) },
    openingBalances: {
      cash: Math.max(0, Math.round(Number(d.openingBalances?.cash) || 0)),
      upi: Math.max(0, Math.round(Number(d.openingBalances?.upi) || 0)),
      bank: Math.max(0, Math.round(Number(d.openingBalances?.bank) || 0)),
    },
    transactions: Array.isArray(d.transactions) ? d.transactions.filter(isValidTransaction) : [],
    closings: Array.isArray(d.closings) ? d.closings.filter(isValidClosing) : [],
    customExpenseCategories: Array.isArray(d.customExpenseCategories) ? d.customExpenseCategories.filter((c) => typeof c === "string") : [],
    customIncomeCategories: Array.isArray(d.customIncomeCategories) ? d.customIncomeCategories.filter((c) => typeof c === "string") : [],
    onboarded: Boolean(d.onboarded),
    demoLoaded: Boolean(d.demoLoaded),
  };
}

function isValidTransaction(t: unknown): t is Transaction {
  if (!t || typeof t !== "object") return false;
  const tx = t as Transaction;
  return (
    typeof tx.id === "string" &&
    (tx.type === "income" || tx.type === "expense") &&
    typeof tx.date === "string" &&
    typeof tx.description === "string" &&
    typeof tx.amount === "number" &&
    tx.amount > 0 &&
    (tx.paymentMethod === "cash" || tx.paymentMethod === "upi" || tx.paymentMethod === "bank")
  );
}

function isValidClosing(c: unknown): c is ClosingRecord {
  if (!c || typeof c !== "object") return false;
  const cl = c as ClosingRecord;
  return typeof cl.id === "string" && typeof cl.date === "string";
}

interface AppContextValue {
  data: AppData;
  // Profile
  updateProfile: (profile: BusinessProfile) => void;
  // Opening balances
  setOpeningBalances: (balances: AccountBalances) => void;
  // Transactions
  addTransaction: (tx: Omit<Transaction, "id" | "createdAt">) => Transaction;
  updateTransaction: (id: string, tx: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  // Closings
  saveClosing: (closing: Omit<ClosingRecord, "id" | "createdAt"> & { id?: string }) => void;
  deleteClosing: (id: string) => void;
  // Categories
  addExpenseCategory: (cat: string) => void;
  addIncomeCategory: (cat: string) => void;
  // Onboarding
  setOnboarded: (val: boolean) => void;
  // Demo
  loadDemoData: () => void;
  removeDemoData: () => void;
  // Data management
  exportData: () => string;
  importData: (json: string) => { success: boolean; message: string };
  clearAllData: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => loadData());

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // storage full or unavailable
    }
  }, [data]);

  const updateProfile = useCallback((profile: BusinessProfile) => {
    setData((d) => ({ ...d, profile }));
  }, []);

  const setOpeningBalances = useCallback((balances: AccountBalances) => {
    setData((d) => ({ ...d, openingBalances: balances }));
  }, []);

  const addTransaction = useCallback((tx: Omit<Transaction, "id" | "createdAt">): Transaction => {
    const newTx: Transaction = {
      ...tx,
      id: generateTransactionId(),
      createdAt: nowISO(),
    };
    setData((d) => ({ ...d, transactions: [...d.transactions, newTx] }));
    return newTx;
  }, []);

  const updateTransaction = useCallback((id: string, updates: Partial<Transaction>) => {
    setData((d) => ({
      ...d,
      transactions: d.transactions.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    }));
  }, []);

  const deleteTransaction = useCallback((id: string) => {
    setData((d) => ({
      ...d,
      transactions: d.transactions.filter((t) => t.id !== id),
    }));
  }, []);

  const saveClosing = useCallback((closing: Omit<ClosingRecord, "id" | "createdAt"> & { id?: string }) => {
    setData((d) => {
      if (closing.id) {
        // Update existing
        return {
          ...d,
          closings: d.closings.map((c) =>
            c.id === closing.id
              ? { ...c, ...closing, id: closing.id! }
              : c
          ),
        };
      }
      // Check if closing for this date already exists
      const existing = d.closings.find((c) => c.date === closing.date);
      if (existing) {
        return {
          ...d,
          closings: d.closings.map((c) =>
            c.date === closing.date
              ? { ...c, ...closing, id: existing.id }
              : c
          ),
        };
      }
      const newClosing: ClosingRecord = {
        ...closing,
        id: generateClosingId(),
        createdAt: nowISO(),
      };
      return { ...d, closings: [...d.closings, newClosing] };
    });
  }, []);

  const deleteClosing = useCallback((id: string) => {
    setData((d) => ({
      ...d,
      closings: d.closings.filter((c) => c.id !== id),
    }));
  }, []);

  const addExpenseCategory = useCallback((cat: string) => {
    const trimmed = cat.trim();
    if (!trimmed) return;
    setData((d) => {
      const all = [...DEFAULT_EXPENSE_CATEGORIES, ...d.customExpenseCategories];
      if (all.includes(trimmed)) return d;
      return { ...d, customExpenseCategories: [...d.customExpenseCategories, trimmed] };
    });
  }, []);

  const addIncomeCategory = useCallback((cat: string) => {
    const trimmed = cat.trim();
    if (!trimmed) return;
    setData((d) => {
      const all = [...DEFAULT_INCOME_CATEGORIES, ...d.customIncomeCategories];
      if (all.includes(trimmed)) return d;
      return { ...d, customIncomeCategories: [...d.customIncomeCategories, trimmed] };
    });
  }, []);

  const setOnboarded = useCallback((val: boolean) => {
    setData((d) => ({ ...d, onboarded: val }));
  }, []);

  const loadDemoData = useCallback(() => {
    setData((d) => {
      // Remove old demo first
      const realTx = d.transactions.filter((t) => !t.isDemo);
      const realClosings = d.closings;
      const today = todayDate();
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yDate = yesterday.toISOString().slice(0, 10);
      const twoDaysAgo = new Date();
      twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
      const tda = twoDaysAgo.toISOString().slice(0, 10);

      const demoTx: Transaction[] = [
        { id: generateTransactionId(), type: "income", date: tda, time: "09:15", incomeType: "sales", incomeCategory: "Sales", description: "Morning sales [DEMO]", customer: "Walk-in customer", amount: 450000, paymentMethod: "cash", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "income", date: tda, time: "14:30", incomeType: "sales", incomeCategory: "Sales", description: "Afternoon UPI sales [DEMO]", customer: "Ramesh", amount: 320000, paymentMethod: "upi", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "expense", date: tda, time: "11:00", expenseCategory: "Stock and Purchases", description: "Stock purchase [DEMO]", payee: "Wholesale supplier", amount: 200000, paymentMethod: "cash", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "income", date: yDate, time: "10:00", incomeType: "sales", incomeCategory: "Sales", description: "Sales batch 1 [DEMO]", customer: "Walk-in", amount: 280000, paymentMethod: "cash", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "income", date: yDate, time: "16:45", incomeType: "service", incomeCategory: "Service Income", description: "Repair service [DEMO]", customer: "Suresh", amount: 150000, paymentMethod: "upi", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "expense", date: yDate, time: "09:30", expenseCategory: "Electricity", description: "Electricity bill [DEMO]", amount: 35000, paymentMethod: "bank", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "expense", date: yDate, time: "13:00", expenseCategory: "Food and Refreshments", description: "Tea and snacks [DEMO]", amount: 5000, paymentMethod: "cash", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "income", date: today, time: "09:30", incomeType: "sales", incomeCategory: "Sales", description: "Morning sales [DEMO]", customer: "Walk-in customer", amount: 520000, paymentMethod: "cash", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "income", date: today, time: "11:15", incomeType: "sales", incomeCategory: "Sales", description: "UPI payment [DEMO]", customer: "Priya", amount: 180000, paymentMethod: "upi", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "income", date: today, time: "14:00", incomeType: "service", incomeCategory: "Service Income", description: "Service charge [DEMO]", customer: "Kumar", amount: 75000, paymentMethod: "bank", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "expense", date: today, time: "10:30", expenseCategory: "Transport", description: "Auto charges [DEMO]", amount: 3000, paymentMethod: "cash", createdAt: nowISO(), isDemo: true },
        { id: generateTransactionId(), type: "expense", date: today, time: "15:00", expenseCategory: "Internet and Phone", description: "Phone recharge [DEMO]", amount: 4000, paymentMethod: "upi", createdAt: nowISO(), isDemo: true },
      ];

      return {
        ...d,
        openingBalances: { cash: 500000, upi: 0, bank: 0 },
        transactions: [...realTx, ...demoTx],
        closings: realClosings,
        demoLoaded: true,
      };
    });
  }, []);

  const removeDemoData = useCallback(() => {
    setData((d) => ({
      ...d,
      transactions: d.transactions.filter((t) => !t.isDemo),
      demoLoaded: false,
    }));
  }, []);

  const exportData = useCallback((): string => {
    return JSON.stringify(data, null, 2);
  }, [data]);

  const importData = useCallback((json: string): { success: boolean; message: string } => {
    try {
      const parsed = JSON.parse(json);
      const validated = validateData(parsed);
      setData(validated);
      return { success: true, message: "Data imported successfully." };
    } catch (e) {
      return { success: false, message: "Invalid JSON data. Import failed." };
    }
  }, []);

  const clearAllData = useCallback(() => {
    setData({ ...defaultData });
  }, []);

  return (
    <AppContext.Provider
      value={{
        data,
        updateProfile,
        setOpeningBalances,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        saveClosing,
        deleteClosing,
        addExpenseCategory,
        addIncomeCategory,
        setOnboarded,
        loadDemoData,
        removeDemoData,
        exportData,
        importData,
        clearAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
