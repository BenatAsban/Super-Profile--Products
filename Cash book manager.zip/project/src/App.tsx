import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppProvider } from "@/store/AppContext";
import AppLayout from "@/components/layout/AppLayout";
import LandingPage from "@/pages/LandingPage";
import Dashboard from "@/pages/Dashboard";
import TransactionList from "@/pages/TransactionList";
import CashBook from "@/pages/CashBook";
import DayClosing from "@/pages/DayClosing";
import TransactionHistory from "@/pages/TransactionHistory";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/app" element={<AppLayout />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="income" element={<TransactionList type="income" />} />
            <Route path="expenses" element={<TransactionList type="expense" />} />
            <Route path="cashbook" element={<CashBook />} />
            <Route path="closing" element={<DayClosing />} />
            <Route path="history" element={<TransactionHistory />} />
            <Route path="reports" element={<Reports />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AppProvider>
  );
}
