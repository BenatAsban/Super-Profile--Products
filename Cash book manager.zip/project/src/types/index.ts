export type PaymentMethod = "cash" | "upi" | "bank";

export type TransactionType = "income" | "expense";

export type IncomeType = "sales" | "service" | "other";

export interface Transaction {
  id: string;
  type: TransactionType;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM or ""
  incomeType?: IncomeType;
  expenseCategory?: string;
  incomeCategory?: string;
  description: string;
  customer?: string;
  payee?: string;
  reference?: string;
  amount: number; // in paise (integer)
  paymentMethod: PaymentMethod;
  notes?: string;
  createdAt: string; // ISO timestamp for deterministic ordering
  isDemo?: boolean;
}

export interface AccountBalances {
  cash: number; // paise
  upi: number;
  bank: number;
}

export interface ClosingRecord {
  id: string;
  date: string;
  actualCash: number | null;
  actualUpi: number | null;
  actualBank: number | null;
  notes: string;
  createdAt: string;
}

export interface BusinessProfile {
  businessName: string;
  ownerName: string;
  phone: string;
  address: string;
  financialYearStart: string; // MM-DD
  currency: string;
  language: "english" | "tamil";
}

export interface AppData {
  version: number;
  profile: BusinessProfile;
  openingBalances: AccountBalances;
  transactions: Transaction[];
  closings: ClosingRecord[];
  customExpenseCategories: string[];
  customIncomeCategories: string[];
  onboarded: boolean;
  demoLoaded: boolean;
}
