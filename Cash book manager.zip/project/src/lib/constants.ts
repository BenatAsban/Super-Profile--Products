import type { IncomeType, PaymentMethod } from "@/types";

export const DEFAULT_EXPENSE_CATEGORIES = [
  "Stock and Purchases",
  "Rent",
  "Electricity",
  "Internet and Phone",
  "Salary and Wages",
  "Transport",
  "Food and Refreshments",
  "Repairs and Maintenance",
  "Office Supplies",
  "Marketing",
  "Other Expenses",
];

export const DEFAULT_INCOME_CATEGORIES = [
  "Sales",
  "Service Income",
  "Other Income",
];

export const INCOME_TYPES: { value: IncomeType; label: string; labelTa: string }[] = [
  { value: "sales", label: "Sales", labelTa: "விற்பனை" },
  { value: "service", label: "Service Income", labelTa: "சேவை வருவாய்" },
  { value: "other", label: "Other Income", labelTa: "பிற வருவாய்" },
];

export const PAYMENT_METHODS: { value: PaymentMethod; label: string; labelTa: string }[] = [
  { value: "cash", label: "Cash", labelTa: "பணம்" },
  { value: "upi", label: "UPI", labelTa: "UPI" },
  { value: "bank", label: "Bank", labelTa: "வங்கி" },
];

export const STORAGE_KEY = "dscbm_2026_data";

export const APP_VERSION = 1;
