/** Format paise (integer) to Indian Rupee string: ₹1,25,000.00 */
export function formatRupee(paise: number): string {
  const sign = paise < 0 ? "-" : "";
  const abs = Math.abs(Math.round(paise));
  const rupees = Math.floor(abs / 100);
  const paisePart = abs % 100;
  const formatted = rupees.toLocaleString("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  // en-IN locale already groups with Indian numbering; ensure paise
  const parts = formatted.split(".");
  const intPart = parts[0];
  const decPart = paisePart.toString().padStart(2, "0");
  return `${sign}₹${intPart}.${decPart}`;
}

/** Format without ₹ symbol, just the number with Indian grouping */
export function formatNumber(paise: number): string {
  const sign = paise < 0 ? "-" : "";
  const abs = Math.abs(Math.round(paise));
  const rupees = Math.floor(abs / 100);
  const paisePart = abs % 100;
  const intStr = rupees.toLocaleString("en-IN");
  const decPart = paisePart.toString().padStart(2, "0");
  return `${sign}${intStr}.${decPart}`;
}

/** Convert a rupee string/number input to paise integer */
export function rupeesToPaise(input: string | number): number {
  const num = typeof input === "string" ? parseFloat(input) : input;
  if (isNaN(num)) return 0;
  return Math.round(num * 100);
}

/** Format date YYYY-MM-DD to display: 22 Oct 2026 */
export function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-").map(Number);
  if (!y || !m || !d) return dateStr;
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${d} ${months[m - 1]} ${y}`;
}

/** Format time HH:MM to 12-hour: 10:30 AM */
export function formatTime(timeStr: string): string {
  if (!timeStr) return "";
  const [h, m] = timeStr.split(":").map(Number);
  if (h === undefined || m === undefined) return timeStr;
  const period = h >= 12 ? "PM" : "AM";
  const hour12 = h % 12 || 12;
  return `${hour12}:${m.toString().padStart(2, "0")} ${period}`;
}

/** Get today's date as YYYY-MM-DD */
export function todayDate(): string {
  const now = new Date();
  const tz = now.getTimezoneOffset() * 60000;
  return new Date(now - tz).toISOString().slice(0, 10);
}

/** Current time as HH:MM */
export function nowTime(): string {
  const now = new Date();
  return `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
}

/** Current ISO timestamp */
export function nowISO(): string {
  return new Date().toISOString();
}

/** Get month key YYYY-MM from date string */
export function monthKey(dateStr: string): string {
  return dateStr.slice(0, 7);
}

/** Month name from YYYY-MM */
export function monthLabel(ym: string): string {
  const [y, m] = ym.split("-").map(Number);
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  return `${months[m - 1]} ${y}`;
}

/** Check if a date is within a range (inclusive) */
export function isInRange(dateStr: string, from?: string, to?: string): boolean {
  if (from && dateStr < from) return false;
  if (to && dateStr > to) return false;
  return true;
}
