/** Generate a unique transaction ID: TXN-YYYYMMDD-XXXX */
let counter = 0;
export function generateTransactionId(): string {
  const now = new Date();
  const ymd = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, "0")}${now.getDate().toString().padStart(2, "0")}`;
  counter = (counter + 1) % 10000;
  const suffix = (Date.now() % 10000).toString().padStart(4, "0");
  return `TXN-${ymd}-${suffix}`;
}

/** Generate a closing record ID: CLS-YYYYMMDD-XXXX */
export function generateClosingId(): string {
  const now = new Date();
  const ymd = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, "0")}${now.getDate().toString().padStart(2, "0")}`;
  const suffix = (Date.now() % 10000).toString().padStart(4, "0");
  return `CLS-${ymd}-${suffix}`;
}
