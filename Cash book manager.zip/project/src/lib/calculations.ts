import type { Transaction, AccountBalances, PaymentMethod, ClosingRecord } from "@/types";

export interface AccountSummary {
  method: PaymentMethod;
  opening: number;
  receipts: number;
  payments: number;
  closing: number;
}

export interface DailySummary {
  date: string;
  income: number;
  expense: number;
  netFlow: number;
  cashIn: number;
  cashOut: number;
  upiIn: number;
  upiOut: number;
  bankIn: number;
  bankOut: number;
}

/** Sort transactions deterministically: by date, then time, then createdAt */
export function sortTransactions(txs: Transaction[]): Transaction[] {
  return [...txs].sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    const aTime = a.time || "99:99";
    const bTime = b.time || "99:99";
    if (aTime !== bTime) return aTime.localeCompare(bTime);
    return a.createdAt.localeCompare(b.createdAt);
  });
}

/** Filter transactions by date range */
export function filterByDateRange(txs: Transaction[], from?: string, to?: string): Transaction[] {
  return txs.filter((t) => {
    if (from && t.date < from) return false;
    if (to && t.date > to) return false;
    return true;
  });
}

/** Total income for a set of transactions */
export function totalIncome(txs: Transaction[]): number {
  return txs.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
}

/** Total expense for a set of transactions */
export function totalExpense(txs: Transaction[]): number {
  return txs.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
}

/** Income for a specific date */
export function incomeForDate(txs: Transaction[], date: string): number {
  return totalIncome(txs.filter((t) => t.date === date));
}

/** Expense for a specific date */
export function expenseForDate(txs: Transaction[], date: string): number {
  return totalExpense(txs.filter((t) => t.date === date));
}

/** Income/expense by payment method for a set of transactions */
export function methodBreakdown(txs: Transaction[]): Record<PaymentMethod, { in: number; out: number }> {
  const result: Record<PaymentMethod, { in: number; out: number }> = {
    cash: { in: 0, out: 0 },
    upi: { in: 0, out: 0 },
    bank: { in: 0, out: 0 },
  };
  for (const t of txs) {
    if (t.type === "income") result[t.paymentMethod].in += t.amount;
    else result[t.paymentMethod].out += t.amount;
  }
  return result;
}

/** Current balance for an account = opening + receipts - payments (all transactions up to today) */
export function accountBalance(
  opening: number,
  txs: Transaction[],
  method: PaymentMethod,
  upToDate?: string
): number {
  let bal = opening;
  for (const t of sortTransactions(txs)) {
    if (upToDate && t.date > upToDate) continue;
    if (t.paymentMethod !== method) continue;
    if (t.type === "income") bal += t.amount;
    else bal -= t.amount;
  }
  return bal;
}

/** All account balances */
export function allAccountBalances(
  opening: AccountBalances,
  txs: Transaction[],
  upToDate?: string
): AccountBalances {
  return {
    cash: accountBalance(opening.cash, txs, "cash", upToDate),
    upi: accountBalance(opening.upi, txs, "upi", upToDate),
    bank: accountBalance(opening.bank, txs, "bank", upToDate),
  };
}

/** Combined total balance */
export function combinedBalance(
  opening: AccountBalances,
  txs: Transaction[],
  upToDate?: string
): number {
  const b = allAccountBalances(opening, txs, upToDate);
  return b.cash + b.upi + b.bank;
}

/** Opening balance for a specific date = previous day's closing balance */
export function openingBalanceForDate(
  opening: AccountBalances,
  txs: Transaction[],
  method: PaymentMethod,
  date: string
): number {
  // All transactions before the given date
  const priorTx = txs.filter((t) => t.date < date);
  return accountBalance(opening[method], priorTx, method);
}

/** Closing balance for a specific date */
export function closingBalanceForDate(
  opening: AccountBalances,
  txs: Transaction[],
  method: PaymentMethod,
  date: string
): number {
  const open = openingBalanceForDate(opening, txs, method, date);
  const dayTx = txs.filter((t) => t.date === date && t.paymentMethod === method);
  const rec = dayTx.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const pay = dayTx.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  return open + rec - pay;
}

/** Running balance ledger for a specific account (or all) */
export interface LedgerEntry {
  transaction: Transaction;
  runningBalance: number;
}

export function runningBalanceLedger(
  opening: AccountBalances,
  txs: Transaction[],
  method: PaymentMethod | "all"
): LedgerEntry[] {
  const sorted = sortTransactions(txs).filter((t) =>
    method === "all" ? true : t.paymentMethod === method
  );

  // Track per-account balances
  const bal: AccountBalances = { ...opening };
  const entries: LedgerEntry[] = [];

  for (const t of sorted) {
    if (t.type === "income") bal[t.paymentMethod] += t.amount;
    else bal[t.paymentMethod] -= t.amount;

    if (method === "all") {
      entries.push({ transaction: t, runningBalance: bal.cash + bal.upi + bal.bank });
    } else {
      entries.push({ transaction: t, runningBalance: bal[method] });
    }
  }

  return entries;
}

/** Daily summary for a date range */
export function dailySummaries(
  txs: Transaction[],
  from: string,
  to: string
): DailySummary[] {
  const dates: string[] = [];
  const cur = new Date(from);
  const end = new Date(to);
  while (cur <= end) {
    const tz = cur.getTimezoneOffset() * 60000;
    dates.push(new Date(cur.getTime() - tz).toISOString().slice(0, 10));
    cur.setDate(cur.getDate() + 1);
  }

  return dates.map((date) => {
    const dayTx = txs.filter((t) => t.date === date);
    const mb = methodBreakdown(dayTx);
    return {
      date,
      income: totalIncome(dayTx),
      expense: totalExpense(dayTx),
      netFlow: totalIncome(dayTx) - totalExpense(dayTx),
      cashIn: mb.cash.in,
      cashOut: mb.cash.out,
      upiIn: mb.upi.in,
      upiOut: mb.upi.out,
      bankIn: mb.bank.in,
      bankOut: mb.bank.out,
    };
  });
}

/** Monthly summary: { YYYY-MM: { income, expense } } */
export function monthlySummary(txs: Transaction[]): { month: string; income: number; expense: number }[] {
  const map = new Map<string, { income: number; expense: number }>();
  for (const t of txs) {
    const m = t.date.slice(0, 7);
    if (!map.has(m)) map.set(m, { income: 0, expense: 0 });
    const entry = map.get(m)!;
    if (t.type === "income") entry.income += t.amount;
    else entry.expense += t.amount;
  }
  return Array.from(map.entries())
    .map(([month, val]) => ({ month, ...val }))
    .sort((a, b) => a.month.localeCompare(b.month));
}

/** Category-wise expense breakdown */
export function expenseByCategory(txs: Transaction[]): { category: string; amount: number }[] {
  const map = new Map<string, number>();
  for (const t of txs) {
    if (t.type !== "expense") continue;
    const cat = t.expenseCategory || "Other";
    map.set(cat, (map.get(cat) || 0) + t.amount);
  }
  return Array.from(map.entries())
    .map(([category, amount]) => ({ category, amount }))
    .sort((a, b) => b.amount - a.amount);
}

/** Income by category breakdown */
export function incomeByCategory(txs: Transaction[]): { category: string; amount: number }[] {
  const map = new Map<string, number>();
  for (const t of txs) {
    if (t.type !== "income") continue;
    const cat = t.incomeCategory || t.incomeType || "Other";
    map.set(cat, (map.get(cat) || 0) + t.amount);
  }
  return Array.from(map.entries())
    .map(([category, amount]) => ({ category, amount }))
    .sort((a, b) => b.amount - a.amount);
}

/** Reconciliation calculation for a date */
export interface ReconciliationResult {
  method: PaymentMethod;
  opening: number;
  receipts: number;
  payments: number;
  expectedClosing: number;
  actualClosing: number | null;
  difference: number | null;
  status: "matched" | "shortage" | "excess" | "not_reconciled";
}

export function calculateReconciliation(
  opening: AccountBalances,
  txs: Transaction[],
  closing: ClosingRecord | undefined,
  date: string
): ReconciliationResult[] {
  const methods: PaymentMethod[] = ["cash", "upi", "bank"];
  return methods.map((method) => {
    const open = openingBalanceForDate(opening, txs, method, date);
    const dayTx = txs.filter((t) => t.date === date && t.paymentMethod === method);
    const receipts = dayTx.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
    const payments = dayTx.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
    const expectedClosing = open + receipts - payments;

    let actualClosing: number | null = null;
    if (closing) {
      if (method === "cash" && closing.actualCash !== null) actualClosing = closing.actualCash;
      if (method === "upi" && closing.actualUpi !== null) actualClosing = closing.actualUpi;
      if (method === "bank" && closing.actualBank !== null) actualClosing = closing.actualBank;
    }

    let difference: number | null = null;
    let status: ReconciliationResult["status"] = "not_reconciled";
    if (actualClosing !== null) {
      difference = actualClosing - expectedClosing;
      if (difference === 0) status = "matched";
      else if (difference < 0) status = "shortage";
      else status = "excess";
    }

    return { method, opening: open, receipts, payments, expectedClosing, actualClosing, difference, status };
  });
}

/** Month-to-date income */
export function monthToDateIncome(txs: Transaction[], date: string): number {
  const ym = date.slice(0, 7);
  return totalIncome(txs.filter((t) => t.date.slice(0, 7) === ym));
}

/** Month-to-date expense */
export function monthToDateExpense(txs: Transaction[], date: string): number {
  const ym = date.slice(0, 7);
  return totalExpense(txs.filter((t) => t.date.slice(0, 7) === ym));
}

/** Unique dates that have transactions */
export function transactionDates(txs: Transaction[]): string[] {
  const set = new Set(txs.map((t) => t.date));
  return Array.from(set).sort();
}
