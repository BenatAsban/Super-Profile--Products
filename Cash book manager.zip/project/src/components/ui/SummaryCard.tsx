import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";

interface SummaryCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  color: "emerald" | "red" | "blue" | "orange" | "slate" | "indigo";
  subtext?: string;
}

const colorMap = {
  emerald: { bg: "bg-emerald-50", icon: "bg-emerald-500 text-white", text: "text-emerald-700" },
  red: { bg: "bg-red-50", icon: "bg-red-500 text-white", text: "text-red-700" },
  blue: { bg: "bg-blue-50", icon: "bg-blue-500 text-white", text: "text-blue-700" },
  orange: { bg: "bg-orange-50", icon: "bg-orange-500 text-white", text: "text-orange-700" },
  slate: { bg: "bg-slate-50", icon: "bg-slate-600 text-white", text: "text-slate-700" },
  indigo: { bg: "bg-indigo-50", icon: "bg-indigo-500 text-white", text: "text-indigo-700" },
};

export default function SummaryCard({ label, value, icon: Icon, color, subtext }: SummaryCardProps) {
  const c = colorMap[color];
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-4 lg:p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wide truncate">{label}</p>
          <p className={`text-xl lg:text-2xl font-bold mt-1 ${c.text}`}>{value}</p>
          {subtext && <p className="text-xs text-slate-400 mt-1">{subtext}</p>}
        </div>
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${c.icon}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}
