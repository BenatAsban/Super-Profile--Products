import { useState, useEffect } from "react";
import { useApp } from "@/store/AppContext";
import { Input, Select, Textarea } from "@/components/ui/FormField";
import Modal from "@/components/ui/Modal";
import { rupeesToPaise, todayDate, nowTime } from "@/lib/format";
import { DEFAULT_EXPENSE_CATEGORIES, DEFAULT_INCOME_CATEGORIES, INCOME_TYPES, PAYMENT_METHODS } from "@/lib/constants";
import type { Transaction, TransactionType, IncomeType, PaymentMethod } from "@/types";

interface TransactionFormProps {
  open: boolean;
  onClose: () => void;
  type: TransactionType;
  editTransaction?: Transaction | null;
}

export default function TransactionForm({ open, onClose, type, editTransaction }: TransactionFormProps) {
  const { data, addTransaction, updateTransaction, addExpenseCategory, addIncomeCategory } = useApp();

  const [date, setDate] = useState(todayDate());
  const [time, setTime] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cash");
  const [incomeType, setIncomeType] = useState<IncomeType>("sales");
  const [incomeCategory, setIncomeCategory] = useState("Sales");
  const [expenseCategory, setExpenseCategory] = useState("Stock and Purchases");
  const [customer, setCustomer] = useState("");
  const [payee, setPayee] = useState("");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [customCatInput, setCustomCatInput] = useState("");

  const isIncome = type === "income";

  useEffect(() => {
    if (editTransaction) {
      setDate(editTransaction.date);
      setTime(editTransaction.time || "");
      setDescription(editTransaction.description);
      setAmount((editTransaction.amount / 100).toString());
      setPaymentMethod(editTransaction.paymentMethod);
      if (isIncome) {
        setIncomeType(editTransaction.incomeType || "sales");
        setIncomeCategory(editTransaction.incomeCategory || "Sales");
      } else {
        setExpenseCategory(editTransaction.expenseCategory || "Stock and Purchases");
      }
      setCustomer(editTransaction.customer || "");
      setPayee(editTransaction.payee || "");
      setReference(editTransaction.reference || "");
      setNotes(editTransaction.notes || "");
    } else {
      setDate(todayDate());
      setTime("");
      setDescription("");
      setAmount("");
      setPaymentMethod("cash");
      setIncomeType("sales");
      setIncomeCategory("Sales");
      setExpenseCategory("Stock and Purchases");
      setCustomer("");
      setPayee("");
      setReference("");
      setNotes("");
    }
    setErrors({});
  }, [editTransaction, open, isIncome]);

  const allExpenseCats = [...DEFAULT_EXPENSE_CATEGORIES, ...data.customExpenseCategories];
  const allIncomeCats = [...DEFAULT_INCOME_CATEGORIES, ...data.customIncomeCategories];

  const handleAddCustomCategory = () => {
    const cat = customCatInput.trim();
    if (!cat) return;
    if (isIncome) {
      addIncomeCategory(cat);
      setIncomeCategory(cat);
    } else {
      addExpenseCategory(cat);
      setExpenseCategory(cat);
    }
    setCustomCatInput("");
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!date) e.date = "Date is required";
    if (!description.trim()) e.description = "Description is required";
    const amtPaise = rupeesToPaise(amount);
    if (amtPaise <= 0) e.amount = "Amount must be greater than zero";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const amtPaise = rupeesToPaise(amount);
    const base = {
      type,
      date,
      time: time || "",
      description: description.trim(),
      amount: amtPaise,
      paymentMethod,
      reference: reference.trim() || undefined,
      notes: notes.trim() || undefined,
    };

    if (isIncome) {
      const incomeData = {
        ...base,
        incomeType,
        incomeCategory,
        customer: customer.trim() || undefined,
      };
      if (editTransaction) {
        updateTransaction(editTransaction.id, incomeData);
      } else {
        addTransaction(incomeData);
      }
    } else {
      const expenseData = {
        ...base,
        expenseCategory,
        payee: payee.trim() || undefined,
      };
      if (editTransaction) {
        updateTransaction(editTransaction.id, expenseData);
      } else {
        addTransaction(expenseData);
      }
    }
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editTransaction ? `Edit ${isIncome ? "Income" : "Expense"}` : `Add ${isIncome ? "Income" : "Expense"}`}
      size="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <Input
            label="Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            error={errors.date}
            required
          />
          <Input
            label="Time (optional)"
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
          />
        </div>

        {isIncome && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select
              label="Income Type"
              value={incomeType}
              onChange={(e) => {
                const val = e.target.value as IncomeType;
                setIncomeType(val);
                if (val === "sales") setIncomeCategory("Sales");
                else if (val === "service") setIncomeCategory("Service Income");
                else setIncomeCategory("Other Income");
              }}
              required
            >
              {INCOME_TYPES.map((t) => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </Select>
            <Select
              label="Category"
              value={incomeCategory}
              onChange={(e) => setIncomeCategory(e.target.value)}
              required
            >
              {allIncomeCats.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>
          </div>
        )}

        {!isIncome && (
          <div>
            <Select
              label="Expense Category"
              value={expenseCategory}
              onChange={(e) => setExpenseCategory(e.target.value)}
              required
            >
              {allExpenseCats.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>
            <div className="flex gap-2 mt-2">
              <input
                type="text"
                value={customCatInput}
                onChange={(e) => setCustomCatInput(e.target.value)}
                placeholder="Add custom category"
                className="flex-1 px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={handleAddCustomCategory}
                className="px-3 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium hover:bg-slate-200"
              >
                Add
              </button>
            </div>
          </div>
        )}

        <Input
          label="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          error={errors.description}
          placeholder={isIncome ? "e.g., Daily sales, Service charge" : "e.g., Stock purchase, Rent payment"}
          required
        />

        {isIncome ? (
          <Input
            label="Customer Name (optional)"
            value={customer}
            onChange={(e) => setCustomer(e.target.value)}
            placeholder="Customer name"
          />
        ) : (
          <Input
            label="Supplier / Payee (optional)"
            value={payee}
            onChange={(e) => setPayee(e.target.value)}
            placeholder="Supplier or payee name"
          />
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input
            label="Reference / Receipt No. (optional)"
            value={reference}
            onChange={(e) => setReference(e.target.value)}
            placeholder="Receipt number"
          />
          <Input
            label={`Amount (₹)${isIncome ? "" : ""}`}
            type="number"
            step="0.01"
            min="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            error={errors.amount}
            placeholder="0.00"
            required
          />
        </div>

        <Select
          label={isIncome ? "Received Through" : "Paid Through"}
          value={paymentMethod}
          onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
          required
        >
          {PAYMENT_METHODS.map((m) => (
            <option key={m.value} value={m.value}>{m.label}</option>
          ))}
        </Select>

        <Textarea
          label="Notes (optional)"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Additional notes"
        />

        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-lg text-sm font-medium text-slate-700 bg-gray-100 hover:bg-gray-200"
          >
            Cancel
          </button>
          <button
            type="submit"
            className={`px-5 py-2.5 rounded-lg text-sm font-medium text-white ${
              isIncome ? "bg-emerald-500 hover:bg-emerald-600" : "bg-red-500 hover:bg-red-600"
            }`}
          >
            {editTransaction ? "Update" : "Save"} {isIncome ? "Income" : "Expense"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
