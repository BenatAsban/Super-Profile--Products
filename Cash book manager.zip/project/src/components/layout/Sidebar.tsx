import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  TrendingUp,
  TrendingDown,
  BookOpen,
  CalendarCheck,
  History,
  FileBarChart,
  Settings,
  Wallet,
  X,
} from "lucide-react";
import { useApp } from "@/store/AppContext";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

const navItems = [
  { to: "/app/dashboard", label: "Dashboard", labelTa: "டாஷ்போர்டு", icon: LayoutDashboard },
  { to: "/app/income", label: "Income", labelTa: "வருவாய்", icon: TrendingUp },
  { to: "/app/expenses", label: "Expenses", labelTa: "செலவுகள்", icon: TrendingDown },
  { to: "/app/cashbook", label: "Cash Book", labelTa: "பண புத்தகம்", icon: BookOpen },
  { to: "/app/closing", label: "Day Closing", labelTa: "நாள் முடிப்பு", icon: CalendarCheck },
  { to: "/app/history", label: "Transaction History", labelTa: "பரிவர்த்தனை வரலாறு", icon: History },
  { to: "/app/reports", label: "Reports", labelTa: "அறிக்கைகள்", icon: FileBarChart },
  { to: "/app/settings", label: "Settings", labelTa: "அமைப்புகள்", icon: Settings },
];

export default function Sidebar({ open, onClose }: SidebarProps) {
  const { data } = useApp();
  const location = useLocation();
  const isTamil = data.profile.language === "tamil";

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white flex flex-col transition-transform duration-300 lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Logo */}
        <div className="flex items-center justify-between px-5 py-5 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center shrink-0">
              <Wallet className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm font-bold leading-tight truncate">
                {data.profile.businessName || "Cash Book Manager"}
              </h1>
              <p className="text-xs text-slate-400">India 2026</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-3">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = location.pathname === item.to;
              return (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    onClick={onClose}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      active
                        ? "bg-emerald-500 text-white"
                        : "text-slate-300 hover:bg-slate-800 hover:text-white"
                    }`}
                  >
                    <Icon className="w-4.5 h-4.5 shrink-0" style={{ width: 18, height: 18 }} />
                    <span>{isTamil ? item.labelTa : item.label}</span>
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-slate-700 text-xs text-slate-400">
          <p>Local browser storage only.</p>
          <p className="mt-1">No cloud sync or bank sync.</p>
        </div>
      </aside>
    </>
  );
}
