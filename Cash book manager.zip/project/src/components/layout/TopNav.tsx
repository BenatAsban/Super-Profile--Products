import { useState } from "react";
import { Menu, Plus, X } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { useApp } from "@/store/AppContext";

interface TopNavProps {
  onMenuClick: () => void;
}

export default function TopNav({ onMenuClick }: TopNavProps) {
  const { data } = useApp();
  const location = useLocation();
  const [showQuick, setShowQuick] = useState(false);

  const pageNames: Record<string, string> = {
    "/app/dashboard": "Dashboard",
    "/app/income": "Income & Sales",
    "/app/expenses": "Expenses",
    "/app/cashbook": "Cash Book",
    "/app/closing": "Day Closing",
    "/app/history": "Transaction History",
    "/app/reports": "Reports",
    "/app/settings": "Settings",
  };

  const currentName = pageNames[location.pathname] || "Dashboard";

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 lg:px-6 py-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
        >
          <Menu className="w-5 h-5 text-slate-700" />
        </button>
        <h2 className="text-lg font-bold text-slate-900">{currentName}</h2>
        {data.demoLoaded && data.transactions.some((t) => t.isDemo) && (
          <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">
            Demo data loaded
          </span>
        )}
      </div>

      <div className="flex items-center gap-2">
        <div className="relative">
          <button
            onClick={() => setShowQuick(!showQuick)}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Quick Add</span>
          </button>
          {showQuick && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowQuick(false)} />
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-20">
                <Link
                  to="/app/income?action=add"
                  onClick={() => setShowQuick(false)}
                  className="flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-gray-50"
                >
                  <Plus className="w-4 h-4 text-emerald-500" />
                  Add Income
                </Link>
                <Link
                  to="/app/expenses?action=add"
                  onClick={() => setShowQuick(false)}
                  className="flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-gray-50"
                >
                  <Plus className="w-4 h-4 text-red-500" />
                  Add Expense
                </Link>
                <Link
                  to="/app/closing"
                  onClick={() => setShowQuick(false)}
                  className="flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-gray-50"
                >
                  <X className="w-4 h-4 text-orange-500" />
                  Close Day
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
