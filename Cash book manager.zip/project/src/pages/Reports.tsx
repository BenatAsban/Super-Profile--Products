import { useState, useMemo } from "react";
import { FileBarChart, Download, Printer, TrendingUp, TrendingDown, Wallet, Banknote, CreditCard, Building2, Calendar } from "lucide-react";
import { useApp } from "@/store/AppContext";
import { formatRupee, formatDate, todayDate, monthLabel } from "@/lib/format";
import { PAYMENT_METHODS, DEFAULT_EXPENSE_CATEGORIES, DEFAULT_INCOME_CATEGORIES } from "@/lib/constants";
import {
  filterByDateRange,
  totalIncome,
  totalExpense,
  methodBreakdown,
  expenseByCategory,
  monthlySummary,
  dailySummaries,
  allAccountBalances,
  calculateReconciliation,
  sortTransactions,
} from "@/lib/calculations";
import { toCSV, downloadCSV } from "@/lib/csv";
import { Input, Select } from "@/components/ui/FormField";
import EmptyState from "@/components/ui/EmptyState";
import type { PaymentMethod } from "@/types";

type ReportType = "daily_income" | "daily_expense" | "cashbook" | "closing" | "monthly_income" | "monthly_expense" | "method_breakdown" | "category_expense" | "net_cashflow" | "account_summary" | "reconciliation_diff";

export default function Reports() {
  const { data } = useApp();
  const today = todayDate();
  const firstOfMonth = today.slice(0, 7) + "-01";
  const [reportType, setReportType] = useState<ReportType>("daily_income");
  const [from, setFrom] = useState(firstOfMonth);
  const [to, setTo] = useState(today);
  const [filterCategory, setFilterCategory] = useState("");
  const [filterMethod, setFilterMethod] = useState<PaymentMethod | "">("");

  const allCategories = useMemo(() => {
    const set = new Set<string>([...DEFAULT_EXPENSE_CATEGORIES, ...DEFAULT_INCOME_CATEGORIES, ...data.customExpenseCategories, ...data.customIncomeCategories]);
    return Array.from(set);
  }, [data.customExpenseCategories, data.customIncomeCategories]);

  const filteredTx = useMemo(() => {
    let txs = filterByDateRange(data.transactions, from, to);
    if (filterCategory) {
      txs = txs.filter((t) => (t.incomeCategory || t.expenseCategory || "") === filterCategory);
    }
    if (filterMethod) {
      txs = txs.filter((t) => t.paymentMethod === filterMethod);
    }
    return txs;
  }, [data.transactions, from, to, filterCategory, filterMethod]);

  const balances = useMemo(() => allAccountBalances(data.openingBalances, data.transactions), [data.openingBalances, data.transactions]);

  if (data.transactions.length === 0) {
    return (
      <EmptyState
        icon={<FileBarChart className="w-8 h-8 text-slate-400" />}
        title="No reports available"
        message="Record some transactions first, then generate reports for any date range."
      />
    );
  }

  const handleExport = () => {
    let rows: Record<string, string | number>[] = [];
    let filename = "report";

    switch (reportType) {
      case "daily_income": {
        const daily = dailySummaries(filteredTx.filter((t) => t.type === "income"), from, to);
        rows = daily.map((d) => ({ Date: d.date, Income: (d.income / 100).toFixed(2) }));
        filename = "daily_income_report";
        break;
      }
      case "daily_expense": {
        const daily = dailySummaries(filteredTx.filter((t) => t.type === "expense"), from, to);
        rows = daily.map((d) => ({ Date: d.date, Expense: (d.expense / 100).toFixed(2) }));
        filename = "daily_expense_report";
        break;
      }
      case "cashbook": {
        rows = filteredTx.map((t) => ({
          Date: t.date, ID: t.id, Description: t.description,
          Type: t.type, Method: t.paymentMethod,
          Income: t.type === "income" ? (t.amount / 100).toFixed(2) : "",
          Expense: t.type === "expense" ? (t.amount / 100).toFixed(2) : "",
        }));
        filename = "cashbook_report";
        break;
      }
      case "monthly_income": {
        rows = monthlySummary(filteredTx.filter((t) => t.type === "income")).map((m) => ({ Month: m.month, Income: (m.income / 100).toFixed(2) }));
        filename = "monthly_income_report";
        break;
      }
      case "monthly_expense": {
        rows = monthlySummary(filteredTx.filter((t) => t.type === "expense")).map((m) => ({ Month: m.month, Expense: (m.expense / 100).toFixed(2) }));
        filename = "monthly_expense_report";
        break;
      }
      case "method_breakdown": {
        const mb = methodBreakdown(filteredTx);
        rows = PAYMENT_METHODS.map((m) => ({
          Method: m.label,
          Receipts: (mb[m.value].in / 100).toFixed(2),
          Payments: (mb[m.value].out / 100).toFixed(2),
          Net: ((mb[m.value].in - mb[m.value].out) / 100).toFixed(2),
        }));
        filename = "payment_method_report";
        break;
      }
      case "category_expense": {
        rows = expenseByCategory(filteredTx).map((c) => ({ Category: c.category, Amount: (c.amount / 100).toFixed(2) }));
        filename = "category_expense_report";
        break;
      }
      case "net_cashflow": {
        const daily = dailySummaries(filteredTx, from, to);
        rows = daily.map((d) => ({
          Date: d.date,
          Income: (d.income / 100).toFixed(2),
          Expense: (d.expense / 100).toFixed(2),
          Net: (d.netFlow / 100).toFixed(2),
        }));
        filename = "net_cashflow_report";
        break;
      }
      case "account_summary": {
        const mb = methodBreakdown(filteredTx);
        rows = PAYMENT_METHODS.map((m) => ({
          Account: m.label,
          "Opening Balance": (data.openingBalances[m.value] / 100).toFixed(2),
          Receipts: (mb[m.value].in / 100).toFixed(2),
          Payments: (mb[m.value].out / 100).toFixed(2),
          "Current Balance": (balances[m.value] / 100).toFixed(2),
        }));
        filename = "account_summary_report";
        break;
      }
      case "reconciliation_diff": {
        const dates = [...new Set(data.closings.map((c) => c.date))].sort();
        rows = dates.map((d) => {
          const closing = data.closings.find((c) => c.date === d);
          const recon = calculateReconciliation(data.openingBalances, data.transactions, closing, d);
          const cash = recon.find((r) => r.method === "cash");
          return {
            Date: d,
            "Cash Expected": cash ? (cash.expectedClosing / 100).toFixed(2) : "",
            "Cash Actual": cash?.actualClosing !== null && cash?.actualClosing !== undefined ? (cash.actualClosing / 100).toFixed(2) : "",
            "Cash Difference": cash?.difference !== null && cash?.difference !== undefined ? (cash.difference / 100).toFixed(2) : "",
            Status: cash?.status || "",
          };
        });
        filename = "reconciliation_report";
        break;
      }
      case "closing": {
        rows = data.closings.sort((a, b) => a.date.localeCompare(b.date)).map((c) => {
          const recon = calculateReconciliation(data.openingBalances, data.transactions, c, c.date);
          const cash = recon.find((r) => r.method === "cash")!;
          return {
            Date: c.date,
            "Cash Expected": (cash.expectedClosing / 100).toFixed(2),
            "Cash Actual": cash.actualCash !== null ? (cash.actualCash / 100).toFixed(2) : "",
            "Cash Diff": cash.difference !== null ? (cash.difference / 100).toFixed(2) : "",
            "UPI Actual": c.actualUpi !== null ? (c.actualUpi / 100).toFixed(2) : "",
            "Bank Actual": c.actualBank !== null ? (c.actualBank / 100).toFixed(2) : "",
            Notes: c.notes,
          };
        });
        filename = "closing_report";
        break;
      }
    }
    downloadCSV(`${filename}_${from}_to_${to}.csv`, toCSV(rows));
  };

  const handlePrint = () => {
    window.print();
  };

  const totalIn = totalIncome(filteredTx);
  const totalOut = totalExpense(filteredTx);
  const netFlow = totalIn - totalOut;
  const mb = methodBreakdown(filteredTx);

  const reportTypes: { value: ReportType; label: string }[] = [
    { value: "daily_income", label: "Daily Income Report" },
    { value: "daily_expense", label: "Daily Expense Report" },
    { value: "cashbook", label: "Daily Cash Book" },
    { value: "closing", label: "Daily Closing Balance Report" },
    { value: "monthly_income", label: "Monthly Income Summary" },
    { value: "monthly_expense", label: "Monthly Expense Summary" },
    { value: "method_breakdown", label: "Payment Method Breakdown" },
    { value: "category_expense", label: "Category-wise Expense Report" },
    { value: "net_cashflow", label: "Net Cash Flow Report" },
    { value: "account_summary", label: "Account Balance Summary" },
    { value: "reconciliation_diff", label: "Reconciliation Difference Report" },
  ];

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3 print:hidden">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <Select label="Report Type" value={reportType} onChange={(e) => setReportType(e.target.value as ReportType)}>
            {reportTypes.map((r) => (
              <option key={r.value} value={r.value}>{r.label}</option>
            ))}
          </Select>
          <Input label="From Date" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          <Input label="To Date" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          <Select label="Category" value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
            <option value="">All Categories</option>
            {allCategories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </Select>
          <Select label="Payment Method" value={filterMethod} onChange={(e) => setFilterMethod(e.target.value as PaymentMethod | "")}>
            <option value="">All Methods</option>
            {PAYMENT_METHODS.map((m) => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </Select>
        </div>
        <div className="flex justify-end gap-2">
          <button onClick={handlePrint} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-gray-200 text-sm font-medium text-slate-700 hover:bg-gray-50">
            <Printer className="w-4 h-4" /> Print
          </button>
          <button onClick={handleExport} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      {/* Print header */}
      <div className="hidden print:block">
        <h1 className="text-2xl font-bold">{data.profile.businessName || "Cash Book Manager"}</h1>
        <p className="text-sm text-slate-600">{reportTypes.find((r) => r.value === reportType)?.label}</p>
        <p className="text-sm text-slate-500">Period: {formatDate(from)} to {formatDate(to)}</p>
      </div>

      {/* Summary totals */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <p className="text-xs text-slate-500 font-medium">Total Income</p>
          </div>
          <p className="text-xl font-bold text-emerald-600">{formatRupee(totalIn)}</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingDown className="w-4 h-4 text-red-500" />
            <p className="text-xs text-slate-500 font-medium">Total Expense</p>
          </div>
          <p className="text-xl font-bold text-red-600">{formatRupee(totalOut)}</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-1">
            <Wallet className="w-4 h-4 text-slate-500" />
            <p className="text-xs text-slate-500 font-medium">Net Cash Flow</p>
          </div>
          <p className={`text-xl font-bold ${netFlow >= 0 ? "text-emerald-600" : "text-red-600"}`}>{formatRupee(netFlow)}</p>
        </div>
        <div className="bg-slate-900 rounded-xl p-4 text-white">
          <div className="flex items-center gap-2 mb-1">
            <Calendar className="w-4 h-4 text-slate-300" />
            <p className="text-xs text-slate-300 font-medium">Records</p>
          </div>
          <p className="text-xl font-bold">{filteredTx.length}</p>
        </div>
      </div>

      <p className="text-xs text-slate-400 -mt-2">
        Note: Net cash flow shows receipts minus payments. This is not the same as accounting profit, which also considers inventory, depreciation, and other factors.
      </p>

      {/* Report content */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          {reportType === "daily_income" && <DailyReport txs={filteredTx.filter((t) => t.type === "income")} from={from} to={to} kind="income" />}
          {reportType === "daily_expense" && <DailyReport txs={filteredTx.filter((t) => t.type === "expense")} from={from} to={to} kind="expense" />}
          {reportType === "cashbook" && <CashbookReport txs={filteredTx} />}
          {reportType === "closing" && <ClosingReport data={data} />}
          {reportType === "monthly_income" && <MonthlyReport txs={filteredTx.filter((t) => t.type === "income")} kind="income" />}
          {reportType === "monthly_expense" && <MonthlyReport txs={filteredTx.filter((t) => t.type === "expense")} kind="expense" />}
          {reportType === "method_breakdown" && <MethodReport mb={mb} />}
          {reportType === "category_expense" && <CategoryReport txs={filteredTx} />}
          {reportType === "net_cashflow" && <NetFlowReport txs={filteredTx} from={from} to={to} />}
          {reportType === "account_summary" && <AccountSummaryReport opening={data.openingBalances} balances={balances} mb={mb} />}
          {reportType === "reconciliation_diff" && <ReconciliationReport data={data} />}
        </div>
      </div>
    </div>
  );
}

function ReportTable({ headers, rows }: { headers: string[]; rows: (string | number)[][] }) {
  return (
    <table className="w-full text-sm">
      <thead className="bg-slate-50 text-slate-600">
        <tr>
          {headers.map((h, i) => (
            <th key={i} className={`px-4 py-3 font-semibold ${h === "Amount" || h.includes("Balance") || h.includes("Income") || h.includes("Expense") || h === "Net" ? "text-right" : "text-left"}`}>{h}</th>
          ))}
        </tr>
      </thead>
      <tbody className="divide-y divide-gray-100">
        {rows.length === 0 ? (
          <tr><td colSpan={headers.length} className="text-center py-12 text-slate-400">No data for selected filters.</td></tr>
        ) : (
          rows.map((row, i) => (
            <tr key={i} className="hover:bg-gray-50">
              {row.map((cell, j) => (
                <td key={j} className={`px-4 py-3 ${typeof cell === "string" && cell.startsWith("₹") ? "text-right font-medium" : "text-left"} text-slate-700`}>{cell}</td>
              ))}
            </tr>
          ))
        )}
      </tbody>
    </table>
  );
}

function DailyReport({ txs, from, to, kind }: { txs: import("@/types").Transaction[]; from: string; to: string; kind: "income" | "expense" }) {
  const daily = dailySummaries(txs, from, to).filter((d) => kind === "income" ? d.income > 0 : d.expense > 0);
  const headers = ["Date", kind === "income" ? "Income" : "Expense"];
  const rows = daily.map((d) => [formatDate(d.date), formatRupee(kind === "income" ? d.income : d.expense)]);
  const total = daily.reduce((s, d) => s + (kind === "income" ? d.income : d.expense), 0);
  return (
    <>
      <ReportTable headers={headers} rows={rows} />
      <div className="px-4 py-3 border-t border-gray-200 bg-slate-50 flex justify-between font-bold text-slate-900">
        <span>Total</span>
        <span>{formatRupee(total)}</span>
      </div>
    </>
  );
}

function CashbookReport({ txs }: { txs: import("@/types").Transaction[] }) {
  const sorted = sortTransactions(txs);
  const headers = ["Date", "ID", "Description", "Method", "Income", "Expense"];
  const rows = sorted.map((t) => [
    formatDate(t.date),
    t.id,
    t.description,
    t.paymentMethod.toUpperCase(),
    t.type === "income" ? formatRupee(t.amount) : "-",
    t.type === "expense" ? formatRupee(t.amount) : "-",
  ]);
  return <ReportTable headers={headers} rows={rows} />;
}

function MonthlyReport({ txs, kind }: { txs: import("@/types").Transaction[]; kind: "income" | "expense" }) {
  const monthly = monthlySummary(txs);
  const headers = ["Month", kind === "income" ? "Income" : "Expense"];
  const rows = monthly.map((m) => [monthLabel(m.month), formatRupee(kind === "income" ? m.income : m.expense)]);
  const total = monthly.reduce((s, m) => s + (kind === "income" ? m.income : m.expense), 0);
  return (
    <>
      <ReportTable headers={headers} rows={rows} />
      <div className="px-4 py-3 border-t border-gray-200 bg-slate-50 flex justify-between font-bold text-slate-900">
        <span>Total</span>
        <span>{formatRupee(total)}</span>
      </div>
    </>
  );
}

function MethodReport({ mb }: { mb: Record<PaymentMethod, { in: number; out: number }> }) {
  const headers = ["Method", "Receipts", "Payments", "Net"];
  const rows = PAYMENT_METHODS.map((m) => [
    m.label,
    formatRupee(mb[m.value].in),
    formatRupee(mb[m.value].out),
    formatRupee(mb[m.value].in - mb[m.value].out),
  ]);
  return <ReportTable headers={headers} rows={rows} />;
}

function CategoryReport({ txs }: { txs: import("@/types").Transaction[] }) {
  const cats = expenseByCategory(txs);
  const headers = ["Category", "Amount"];
  const rows = cats.map((c) => [c.category, formatRupee(c.amount)]);
  const total = cats.reduce((s, c) => s + c.amount, 0);
  return (
    <>
      <ReportTable headers={headers} rows={rows} />
      <div className="px-4 py-3 border-t border-gray-200 bg-slate-50 flex justify-between font-bold text-slate-900">
        <span>Total</span>
        <span>{formatRupee(total)}</span>
      </div>
    </>
  );
}

function NetFlowReport({ txs, from, to }: { txs: import("@/types").Transaction[]; from: string; to: string }) {
  const daily = dailySummaries(txs, from, to).filter((d) => d.income > 0 || d.expense > 0);
  const headers = ["Date", "Income", "Expense", "Net Flow"];
  const rows = daily.map((d) => [formatDate(d.date), formatRupee(d.income), formatRupee(d.expense), formatRupee(d.netFlow)]);
  const totalIn = daily.reduce((s, d) => s + d.income, 0);
  const totalOut = daily.reduce((s, d) => s + d.expense, 0);
  return (
    <>
      <ReportTable headers={headers} rows={rows} />
      <div className="px-4 py-3 border-t border-gray-200 bg-slate-50 flex justify-between font-bold text-slate-900">
        <span>Total: Income {formatRupee(totalIn)} · Expense {formatRupee(totalOut)}</span>
        <span>Net: {formatRupee(totalIn - totalOut)}</span>
      </div>
    </>
  );
}

function AccountSummaryReport({ opening, balances, mb }: { opening: import("@/types").AccountBalances; balances: import("@/types").AccountBalances; mb: Record<PaymentMethod, { in: number; out: number }> }) {
  const headers = ["Account", "Opening", "Receipts", "Payments", "Current Balance"];
  const rows = PAYMENT_METHODS.map((m) => [
    m.label,
    formatRupee(opening[m.value]),
    formatRupee(mb[m.value].in),
    formatRupee(mb[m.value].out),
    formatRupee(balances[m.value]),
  ]);
  const totalOpening = opening.cash + opening.upi + opening.bank;
  const totalBal = balances.cash + balances.upi + balances.bank;
  return (
    <>
      <ReportTable headers={headers} rows={rows} />
      <div className="px-4 py-3 border-t border-gray-200 bg-slate-50 flex justify-between font-bold text-slate-900">
        <span>Combined Total</span>
        <span>{formatRupee(totalBal)}</span>
      </div>
    </>
  );
}

function ClosingReport({ data }: { data: import("@/types").AppData }) {
  const closings = [...data.closings].sort((a, b) => a.date.localeCompare(b.date));
  const headers = ["Date", "Cash Expected", "Cash Actual", "Cash Diff", "UPI Actual", "Bank Actual", "Status"];
  const rows = closings.map((c) => {
    const recon = calculateReconciliation(data.openingBalances, data.transactions, c, c.date);
    const cash = recon.find((r) => r.method === "cash")!;
    return [
      formatDate(c.date),
      formatRupee(cash.expectedClosing),
      cash.actualClosing !== null ? formatRupee(cash.actualClosing) : "-",
      cash.difference !== null ? formatRupee(cash.difference) : "-",
      c.actualUpi !== null ? formatRupee(c.actualUpi) : "-",
      c.actualBank !== null ? formatRupee(c.actualBank) : "-",
      cash.status,
    ];
  });
  return <ReportTable headers={headers} rows={rows} />;
}

function ReconciliationReport({ data }: { data: import("@/types").AppData }) {
  const dates = [...new Set(data.closings.map((c) => c.date))].sort().reverse();
  const headers = ["Date", "Account", "Expected", "Actual", "Difference", "Status"];
  const rows: (string | number)[][] = [];
  for (const d of dates) {
    const closing = data.closings.find((c) => c.date === d);
    const recon = calculateReconciliation(data.openingBalances, data.transactions, closing, d);
    for (const r of recon) {
      if (r.actualClosing !== null) {
        rows.push([
          formatDate(d),
          r.method.toUpperCase(),
          formatRupee(r.expectedClosing),
          formatRupee(r.actualClosing),
          r.difference !== null ? formatRupee(r.difference) : "-",
          r.status,
        ]);
      }
    }
  }
  return <ReportTable headers={headers} rows={rows} />;
}
