import { useState, useMemo, useEffect } from "react";
import { CalendarCheck, Save, Trash2, Banknote, CreditCard, Building2, CheckCircle, AlertTriangle, AlertCircle } from "lucide-react";
import { useApp } from "@/store/AppContext";
import { formatRupee, formatDate, todayDate, rupeesToPaise } from "@/lib/format";
import { PAYMENT_METHODS } from "@/lib/constants";
import { calculateReconciliation } from "@/lib/calculations";
import { Input, Textarea } from "@/components/ui/FormField";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import EmptyState from "@/components/ui/EmptyState";
import type { PaymentMethod } from "@/types";

export default function DayClosing() {
  const { data, saveClosing, deleteClosing } = useApp();
  const [date, setDate] = useState(todayDate());
  const [actualCash, setActualCash] = useState("");
  const [actualUpi, setActualUpi] = useState("");
  const [actualBank, setActualBank] = useState("");
  const [notes, setNotes] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const existingClosing = useMemo(
    () => data.closings.find((c) => c.date === date),
    [data.closings, date]
  );

  const reconciliation = useMemo(
    () => calculateReconciliation(data.openingBalances, data.transactions, existingClosing, date),
    [data.openingBalances, data.transactions, existingClosing, date]
  );

  // Load values when date changes or existing closing found
  useEffect(() => {
    if (existingClosing) {
      setActualCash(existingClosing.actualCash !== null ? (existingClosing.actualCash / 100).toString() : "");
      setActualUpi(existingClosing.actualUpi !== null ? (existingClosing.actualUpi / 100).toString() : "");
      setActualBank(existingClosing.actualBank !== null ? (existingClosing.actualBank / 100).toString() : "");
      setNotes(existingClosing.notes || "");
    } else {
      setActualCash("");
      setActualUpi("");
      setActualBank("");
      setNotes("");
    }
    setSaved(false);
  }, [date, existingClosing]);

  const handleSave = () => {
    const parseOrNull = (val: string): number | null => {
      if (!val.trim()) return null;
      const paise = rupeesToPaise(val);
      return paise >= 0 ? paise : null;
    };

    saveClosing({
      id: existingClosing?.id,
      date,
      actualCash: parseOrNull(actualCash),
      actualUpi: parseOrNull(actualUpi),
      actualBank: parseOrNull(actualBank),
      notes: notes.trim(),
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleDelete = () => {
    if (deleteId) {
      deleteClosing(deleteId);
      setDeleteId(null);
    }
  };

  const statusConfig = {
    matched: { icon: CheckCircle, color: "text-emerald-600", bg: "bg-emerald-50 border-emerald-200", label: "Matched" },
    shortage: { icon: AlertTriangle, color: "text-red-600", bg: "bg-red-50 border-red-200", label: "Shortage" },
    excess: { icon: AlertCircle, color: "text-orange-600", bg: "bg-orange-50 border-orange-200", label: "Excess" },
    not_reconciled: { icon: AlertCircle, color: "text-slate-400", bg: "bg-slate-50 border-slate-200", label: "Not Reconciled" },
  };

  const accountIcons = { cash: Banknote, upi: CreditCard, bank: Building2 };

  const hasTransactionsForDate = data.transactions.some((t) => t.date === date);

  if (data.transactions.length === 0) {
    return (
      <EmptyState
        icon={<CalendarCheck className="w-8 h-8 text-slate-400" />}
        title="No transactions to reconcile"
        message="Record some income and expenses first, then come back to close your day and reconcile balances."
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Date selector */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
          <Input
            label="Business Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            max={todayDate()}
          />
          <div className="text-sm text-slate-500">
            {existingClosing ? (
              <p className="text-emerald-600 font-medium">A closing record exists for this date. You can edit it below.</p>
            ) : (
              <p>No closing record for this date yet.</p>
            )}
          </div>
        </div>
      </div>

      {!hasTransactionsForDate && (
        <div className="flex items-start gap-3 bg-amber-50 rounded-xl p-4 border border-amber-200">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <p className="text-sm text-amber-800">No transactions were recorded on {formatDate(date)}. You can still save a closing record.</p>
        </div>
      )}

      {/* Reconciliation cards */}
      <div className="grid lg:grid-cols-3 gap-4">
        {reconciliation.map((r) => {
          const Icon = accountIcons[r.method];
          const sc = statusConfig[r.status];
          const StatusIcon = sc.icon;
          return (
            <div key={r.method} className={`rounded-xl border-2 p-5 ${sc.bg}`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Icon className="w-5 h-5 text-slate-700" />
                  <h3 className="font-bold text-slate-900 capitalize">{r.method}</h3>
                </div>
                <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${sc.color} bg-white`}>
                  <StatusIcon className="w-3.5 h-3.5" /> {sc.label}
                </span>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Opening Balance</span>
                  <span className="font-medium text-slate-900">{formatRupee(r.opening)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-emerald-600">+ Receipts</span>
                  <span className="font-medium text-emerald-600">{formatRupee(r.receipts)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-red-600">- Payments</span>
                  <span className="font-medium text-red-600">{formatRupee(r.payments)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-gray-200">
                  <span className="font-semibold text-slate-700">Expected Closing</span>
                  <span className="font-bold text-slate-900">{formatRupee(r.expectedClosing)}</span>
                </div>
              </div>

              {/* Actual balance input */}
              <div className="mt-4">
                <Input
                  label={`Actual ${r.method === "cash" ? "Cash Counted" : r.method === "upi" ? "UPI Balance (if checked)" : "Bank Balance (if checked)"}`}
                  type="number"
                  step="0.01"
                  min="0"
                  value={r.method === "cash" ? actualCash : r.method === "upi" ? actualUpi : actualBank}
                  onChange={(e) => {
                    if (r.method === "cash") setActualCash(e.target.value);
                    else if (r.method === "upi") setActualUpi(e.target.value);
                    else setActualBank(e.target.value);
                  }}
                  placeholder="Enter actual amount"
                />
              </div>

              {r.actualClosing !== null && (
                <div className="mt-3 space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Actual Closing</span>
                    <span className="font-medium text-slate-900">{formatRupee(r.actualClosing)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Difference</span>
                    <span className={`font-bold ${r.difference === 0 ? "text-emerald-600" : r.difference < 0 ? "text-red-600" : "text-orange-600"}`}>
                      {r.difference !== null ? formatRupee(r.difference) : "-"}
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Notes and Save */}
      <div className="bg-white rounded-xl border border-gray-200 p-5 space-y-4">
        <Textarea
          label="Reconciliation Notes (optional)"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Add any notes about discrepancies, reasons for shortage/excess, etc."
        />
        <div className="flex flex-wrap items-center justify-between gap-3">
          {saved && (
            <p className="text-sm text-emerald-600 font-medium flex items-center gap-1">
              <CheckCircle className="w-4 h-4" /> Closing record saved successfully.
            </p>
          )}
          <div className="flex gap-2 ml-auto">
            {existingClosing && (
              <button
                onClick={() => setDeleteId(existingClosing.id)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-red-50 text-red-600 text-sm font-medium hover:bg-red-100"
              >
                <Trash2 className="w-4 h-4" /> Delete Record
              </button>
            )}
            <button
              onClick={handleSave}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600"
            >
              <Save className="w-4 h-4" /> {existingClosing ? "Update Closing" : "Save Closing"}
            </button>
          </div>
        </div>
      </div>

      {/* Previous closings */}
      {data.closings.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="font-bold text-slate-900 mb-3">Previous Closing Records</h3>
          <div className="space-y-2">
            {data.closings.sort((a, b) => b.date.localeCompare(a.date)).map((c) => {
              const recon = calculateReconciliation(data.openingBalances, data.transactions, c, c.date);
              const allMatched = recon.every((r) => r.status === "matched" || r.actualClosing === null);
              const anyShortage = recon.some((r) => r.status === "shortage");
              const anyExcess = recon.some((r) => r.status === "excess");
              return (
                <div key={c.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-slate-900">{formatDate(c.date)}</p>
                    {c.notes && <p className="text-xs text-slate-400 mt-0.5">{c.notes}</p>}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right text-xs">
                      {c.actualCash !== null && <p className="text-slate-600">Cash: {formatRupee(c.actualCash)}</p>}
                      {c.actualUpi !== null && <p className="text-slate-600">UPI: {formatRupee(c.actualUpi)}</p>}
                      {c.actualBank !== null && <p className="text-slate-600">Bank: {formatRupee(c.actualBank)}</p>}
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      allMatched ? "bg-emerald-50 text-emerald-600" : anyShortage ? "bg-red-50 text-red-600" : anyExcess ? "bg-orange-50 text-orange-600" : "bg-slate-50 text-slate-500"
                    }`}>
                      {allMatched ? "Matched" : anyShortage ? "Shortage" : anyExcess ? "Excess" : "Partial"}
                    </span>
                    <button
                      onClick={() => setDate(c.date)}
                      className="text-xs text-emerald-600 hover:underline"
                    >
                      View
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <ConfirmDialog
        open={!!deleteId}
        title="Delete Closing Record"
        message="Are you sure you want to delete this closing record? The transactions will remain, only the reconciliation data will be removed."
        confirmLabel="Delete"
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
