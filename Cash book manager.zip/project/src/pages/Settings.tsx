import { useState, useRef } from "react";
import { Settings as SettingsIcon, Download, Upload, Trash2, AlertCircle, Building2, Wallet, Tag, Database, CheckCircle } from "lucide-react";
import { useApp } from "@/store/AppContext";
import { Input, Select, Textarea } from "@/components/ui/FormField";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import { formatRupee, rupeesToPaise } from "@/lib/format";
import { DEFAULT_EXPENSE_CATEGORIES, DEFAULT_INCOME_CATEGORIES } from "@/lib/constants";
import type { BusinessProfile } from "@/types";

export default function Settings() {
  const { data, updateProfile, setOpeningBalances, addExpenseCategory, addIncomeCategory, exportData, importData, clearAllData, removeDemoData } = useApp();
  const [profile, setProfile] = useState<BusinessProfile>(data.profile);
  const [openingCashStr, setOpeningCashStr] = useState((data.openingBalances.cash / 100).toString());
  const [openingUpiStr, setOpeningUpiStr] = useState((data.openingBalances.upi / 100).toString());
  const [openingBankStr, setOpeningBankStr] = useState((data.openingBalances.bank / 100).toString());
  const [savedProfile, setSavedProfile] = useState(false);
  const [savedOpening, setSavedOpening] = useState(false);
  const [customExpCat, setCustomExpCat] = useState("");
  const [customIncCat, setCustomIncCat] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmImport, setConfirmImport] = useState(false);
  const [importJson, setImportJson] = useState("");
  const [importResult, setImportResult] = useState<{ success: boolean; message: string } | null>(null);
  const [clearStep, setClearStep] = useState(1);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSaveProfile = () => {
    updateProfile(profile);
    setSavedProfile(true);
    setTimeout(() => setSavedProfile(false), 3000);
  };

  const handleSaveOpening = () => {
    setOpeningBalances({
      cash: Math.max(0, rupeesToPaise(openingCashStr)),
      upi: Math.max(0, rupeesToPaise(openingUpiStr)),
      bank: Math.max(0, rupeesToPaise(openingBankStr)),
    });
    setSavedOpening(true);
    setTimeout(() => setSavedOpening(false), 3000);
  };

  const handleExportJson = () => {
    const json = exportData();
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `cashbook_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setImportJson(event.target?.result as string);
      setConfirmImport(true);
    };
    reader.readAsText(file);
  };

  const handleImportConfirm = () => {
    const result = importData(importJson);
    setImportResult(result);
    setConfirmImport(false);
    setImportJson("");
    if (fileInputRef.current) fileInputRef.current.value = "";
    setTimeout(() => setImportResult(null), 5000);
  };

  const handleClearAll = () => {
    if (clearStep === 1) {
      setClearStep(2);
    } else {
      clearAllData();
      setConfirmClear(false);
      setClearStep(1);
    }
  };

  const allExpCats = [...DEFAULT_EXPENSE_CATEGORIES, ...data.customExpenseCategories];
  const allIncCats = [...DEFAULT_INCOME_CATEGORIES, ...data.customIncomeCategories];

  return (
    <div className="space-y-4 max-w-4xl">
      {/* Business Profile */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center">
            <Building2 className="w-4.5 h-4.5 text-blue-600" style={{ width: 18, height: 18 }} />
          </div>
          <h3 className="font-bold text-slate-900">Business Profile</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label="Business Name" value={profile.businessName} onChange={(e) => setProfile({ ...profile, businessName: e.target.value })} placeholder="Your business name" />
          <Input label="Owner Name (optional)" value={profile.ownerName} onChange={(e) => setProfile({ ...profile, ownerName: e.target.value })} />
          <Input label="Phone (optional)" value={profile.phone} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} />
          <Input label="Address (optional)" value={profile.address} onChange={(e) => setProfile({ ...profile, address: e.target.value })} />
          <Input label="Financial Year Start" type="date" value={profile.financialYearStart ? `${new Date().getFullYear()}-${profile.financialYearStart}` : ""} onChange={(e) => {
            const md = e.target.value.slice(5);
            setProfile({ ...profile, financialYearStart: md });
          }} hint="Indian financial year typically starts April 1" />
          <Select label="Default Language" value={profile.language} onChange={(e) => setProfile({ ...profile, language: e.target.value as "english" | "tamil" })}>
            <option value="english">English</option>
            <option value="tamil">Tamil</option>
          </Select>
        </div>
        <div className="flex items-center justify-end gap-3 mt-4">
          {savedProfile && <p className="text-sm text-emerald-600 flex items-center gap-1"><CheckCircle className="w-4 h-4" /> Saved</p>}
          <button onClick={handleSaveProfile} className="px-5 py-2.5 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600">
            Save Profile
          </button>
        </div>
      </div>

      {/* Opening Balances */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-lg bg-orange-100 flex items-center justify-center">
            <Wallet className="w-4.5 h-4.5 text-orange-600" style={{ width: 18, height: 18 }} />
          </div>
          <h3 className="font-bold text-slate-900">Opening Balances</h3>
        </div>
        <p className="text-xs text-slate-500 mb-4">These are starting funds, not income. They will be added to account totals but excluded from income reports.</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Input label="Opening Cash (₹)" type="number" step="0.01" min="0" value={openingCashStr} onChange={(e) => setOpeningCashStr(e.target.value)} />
          <Input label="Opening UPI (₹)" type="number" step="0.01" min="0" value={openingUpiStr} onChange={(e) => setOpeningUpiStr(e.target.value)} />
          <Input label="Opening Bank (₹)" type="number" step="0.01" min="0" value={openingBankStr} onChange={(e) => setOpeningBankStr(e.target.value)} />
        </div>
        <div className="flex items-center justify-end gap-3 mt-4">
          {savedOpening && <p className="text-sm text-emerald-600 flex items-center gap-1"><CheckCircle className="w-4 h-4" /> Saved</p>}
          <button onClick={handleSaveOpening} className="px-5 py-2.5 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600">
            Save Balances
          </button>
        </div>
      </div>

      {/* Custom Categories */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-lg bg-indigo-100 flex items-center justify-center">
            <Tag className="w-4.5 h-4.5 text-indigo-600" style={{ width: 18, height: 18 }} />
          </div>
          <h3 className="font-bold text-slate-900">Categories</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-semibold text-slate-700 mb-2">Expense Categories</h4>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {allExpCats.map((c) => (
                <span key={c} className="text-xs px-2.5 py-1 rounded-full bg-red-50 text-red-600">{c}</span>
              ))}
            </div>
            <div className="flex gap-2">
              <input type="text" value={customExpCat} onChange={(e) => setCustomExpCat(e.target.value)} placeholder="New expense category" className="flex-1 px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500" />
              <button onClick={() => { addExpenseCategory(customExpCat); setCustomExpCat(""); }} className="px-3 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium hover:bg-slate-200">Add</button>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-700 mb-2">Income Categories</h4>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {allIncCats.map((c) => (
                <span key={c} className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-600">{c}</span>
              ))}
            </div>
            <div className="flex gap-2">
              <input type="text" value={customIncCat} onChange={(e) => setCustomIncCat(e.target.value)} placeholder="New income category" className="flex-1 px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500" />
              <button onClick={() => { addIncomeCategory(customIncCat); setCustomIncCat(""); }} className="px-3 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium hover:bg-slate-200">Add</button>
            </div>
          </div>
        </div>
      </div>

      {/* Data Management */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center">
            <Database className="w-4.5 h-4.5 text-slate-600" style={{ width: 18, height: 18 }} />
          </div>
          <h3 className="font-bold text-slate-900">Data Management</h3>
        </div>

        {importResult && (
          <div className={`mb-4 p-3 rounded-lg text-sm ${importResult.success ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
            {importResult.message}
          </div>
        )}

        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 rounded-lg">
            <div>
              <p className="text-sm font-medium text-slate-900">Export All Data (JSON)</p>
              <p className="text-xs text-slate-500">Download a complete backup of all your transactions and settings.</p>
            </div>
            <button onClick={handleExportJson} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-gray-200 text-sm font-medium text-slate-700 hover:bg-gray-50">
              <Download className="w-4 h-4" /> Export JSON
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 rounded-lg">
            <div>
              <p className="text-sm font-medium text-slate-900">Import Data (JSON)</p>
              <p className="text-xs text-slate-500">Restore from a backup file. This will replace all current data.</p>
            </div>
            <div className="flex gap-2">
              <input ref={fileInputRef} type="file" accept=".json,application/json" onChange={handleFileImport} className="hidden" />
              <button onClick={() => fileInputRef.current?.click()} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white border border-gray-200 text-sm font-medium text-slate-700 hover:bg-gray-50">
                <Upload className="w-4 h-4" /> Choose File
              </button>
            </div>
          </div>

          {data.demoLoaded && data.transactions.some((t) => t.isDemo) && (
            <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
              <div>
                <p className="text-sm font-medium text-amber-900">Demo Data Loaded</p>
                <p className="text-xs text-amber-700">Remove demo transactions to keep only your real records.</p>
              </div>
              <button onClick={removeDemoData} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-white text-sm font-medium hover:bg-amber-600">
                Remove Demo Data
              </button>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-red-50 rounded-lg border border-red-200">
            <div>
              <p className="text-sm font-medium text-red-900">Clear All Data</p>
              <p className="text-xs text-red-700">Permanently delete all transactions, closings, and settings. This cannot be undone.</p>
            </div>
            <button onClick={() => { setConfirmClear(true); setClearStep(1); }} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500 text-white text-sm font-medium hover:bg-red-600">
              <Trash2 className="w-4 h-4" /> Clear All
            </button>
          </div>
        </div>
      </div>

      {/* Storage Warning */}
      <div className="flex items-start gap-3 bg-amber-50 rounded-xl p-4 border border-amber-200">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-800">
          <p className="font-semibold mb-1">Local Storage Warning</p>
          <p>Your records are stored in this browser only. They may be lost if you clear your browser data, use private/incognito mode, or switch devices. Export regular backups using the JSON export above.</p>
          <p className="mt-1">This app does not provide cloud backup, automatic bank synchronization, or cross-device synchronization.</p>
        </div>
      </div>

      {/* Confirm dialogs */}
      <ConfirmDialog
        open={confirmImport}
        title="Import Data"
        message="This will replace ALL your current data with the imported data. Are you sure you want to continue?"
        confirmLabel="Import & Replace"
        variant="warning"
        onConfirm={handleImportConfirm}
        onCancel={() => { setConfirmImport(false); setImportJson(""); }}
      />
      <ConfirmDialog
        open={confirmClear}
        title={clearStep === 1 ? "Clear All Data?" : "Are you absolutely sure?"}
        message={clearStep === 1
          ? "This will permanently delete all transactions, closing records, categories, and settings. This action cannot be undone."
          : "This is your final warning. All data will be permanently erased. Click 'Delete Everything' to proceed."
        }
        confirmLabel={clearStep === 1 ? "Continue" : "Delete Everything"}
        onConfirm={handleClearAll}
        onCancel={() => { setConfirmClear(false); setClearStep(1); }}
      />
    </div>
  );
}
