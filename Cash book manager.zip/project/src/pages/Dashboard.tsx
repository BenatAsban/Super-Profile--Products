import { useMemo } from "react";
import { Link } from "react-router-dom";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  Banknote,
  CreditCard,
  Building2,
  ArrowRight,
  BookOpen,
  CalendarCheck,
  Plus,
  FileBarChart,
  Receipt,
  AlertCircle,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { useApp } from "@/store/AppContext";
import { formatRupee, todayDate, formatDate, formatTime } from "@/lib/format";
import {
  incomeForDate,
  expenseForDate,
  methodBreakdown,
  allAccountBalances,
  monthToDateIncome,
  monthToDateExpense,
  dailySummaries,
  monthlySummary,
  expenseByCategory,
  sortTransactions,
} from "@/lib/calculations";
import SummaryCard from "@/components/ui/SummaryCard";
import EmptyState from "@/components/ui/EmptyState";

export default function Dashboard() {
  const { data } = useApp();
  const today = todayDate();
  const txs = data.transactions;

  const hasTransactions = txs.length > 0;

  const todayIncome = useMemo(() => incomeForDate(txs, today), [txs, today]);
  const todayExpense = useMemo(() => expenseForDate(txs, today), [txs, today]);
  const netFlow = todayIncome - todayExpense;
  const todayTx = useMemo(() => txs.filter((t) => t.date === today), [txs, today]);
  const mb = useMemo(() => methodBreakdown(todayTx), [todayTx]);
  const balances = useMemo(() => allAccountBalances(data.openingBalances, txs), [data.openingBalances, txs]);
  const mtdIncome = useMemo(() => monthToDateIncome(txs, today), [txs, today]);
  const mtdExpense = useMemo(() => monthToDateExpense(txs, today), [txs, today]);

  const last7Days = useMemo(() => {
    const to = today;
    const from = new Date();
    from.setDate(from.getDate() - 6);
    const fromStr = from.toISOString().slice(0, 10);
    return dailySummaries(txs, fromStr, to).map((d) => ({
      date: d.date.slice(5),
      Income: d.income / 100,
      Expense: d.expense / 100,
    }));
  }, [txs, today]);

  const monthlyData = useMemo(() => {
    return monthlySummary(txs).slice(-6).map((m) => ({
      month: m.month.slice(5),
      Income: m.income / 100,
      Expense: m.expense / 100,
    }));
  }, [txs]);

  const methodPie = useMemo(() => {
    const allMb = methodBreakdown(txs);
    return [
      { name: "Cash", value: (allMb.cash.in + allMb.cash.out) / 100 },
      { name: "UPI", value: (allMb.upi.in + allMb.upi.out) / 100 },
      { name: "Bank", value: (allMb.bank.in + allMb.bank.out) / 100 },
    ].filter((d) => d.value > 0);
  }, [txs]);

  const expenseCats = useMemo(() => expenseByCategory(txs).slice(0, 5), [txs]);

  const recentTx = useMemo(() => sortTransactions(txs).slice(-8).reverse(), [txs]);

  if (!hasTransactions) {
    return (
      <div className="max-w-2xl mx-auto">
        <EmptyState
          icon={<Receipt className="w-8 h-8 text-slate-400" />}
          title="No transactions yet"
          message="Start by recording your first income or expense. You can also try the demo data to see how the dashboard works."
          action={{ label: "Start Recording", onClick: () => (window.location.href = "/app/income?action=add") }}
        />
        <div className="mt-6 grid sm:grid-cols-2 gap-3 max-w-md mx-auto">
          <Link to="/app/income" className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600">
            <Plus className="w-4 h-4" /> Add Income
          </Link>
          <Link to="/app/expenses" className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-500 text-white text-sm font-medium hover:bg-red-600">
            <Plus className="w-4 h-4" /> Add Expense
          </Link>
        </div>
      </div>
    );
  }

  const pieColors = ["#f97316", "#3b82f6", "#10b981"];

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <SummaryCard label="Today's Income" value={formatRupee(todayIncome)} icon={TrendingUp} color="emerald" />
        <SummaryCard label="Today's Expenses" value={formatRupee(todayExpense)} icon={TrendingDown} color="red" />
        <SummaryCard
          label="Net Cash Flow"
          value={formatRupee(netFlow)}
          icon={Wallet}
          color={netFlow >= 0 ? "emerald" : "red"}
        />
        <SummaryCard label="Cash Balance" value={formatRupee(balances.cash)} icon={Banknote} color="orange" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <SummaryCard label="UPI Collections" value={formatRupee(mb.upi.in)} icon={CreditCard} color="blue" subtext={`Out: ${formatRupee(mb.upi.out)}`} />
        <SummaryCard label="Bank Transactions" value={formatRupee(mb.bank.in)} icon={Building2} color="indigo" subtext={`Out: ${formatRupee(mb.bank.out)}`} />
        <SummaryCard label="MTD Income" value={formatRupee(mtdIncome)} icon={TrendingUp} color="emerald" />
        <SummaryCard label="MTD Expenses" value={formatRupee(mtdExpense)} icon={TrendingDown} color="red" />
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-wrap gap-2">
          <Link to="/app/income?action=add" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600">
            <Plus className="w-4 h-4" /> Add Income
          </Link>
          <Link to="/app/expenses?action=add" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500 text-white text-sm font-medium hover:bg-red-600">
            <Plus className="w-4 h-4" /> Add Expense
          </Link>
          <Link to="/app/cashbook" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium hover:bg-slate-200">
            <BookOpen className="w-4 h-4" /> Open Cash Book
          </Link>
          <Link to="/app/closing" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-orange-500 text-white text-sm font-medium hover:bg-orange-600">
            <CalendarCheck className="w-4 h-4" /> Close Day
          </Link>
        </div>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Daily income vs expense */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="font-bold text-slate-900 mb-4">Income vs Expense (Last 7 Days)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={last7Days}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `₹${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`} />
              <Tooltip formatter={(v: number) => formatRupee(Math.round(v * 100))} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Income" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Expense" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Payment method breakdown */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="font-bold text-slate-900 mb-4">Payment Method Breakdown</h3>
          {methodPie.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={methodPie} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}>
                  {methodPie.map((_, i) => (
                    <Cell key={i} fill={pieColors[i]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => formatRupee(Math.round(v * 100))} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[250px] flex items-center justify-center text-slate-400 text-sm">No data</div>
          )}
        </div>
      </div>

      {/* Monthly chart */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h3 className="font-bold text-slate-900 mb-4">Monthly Income & Expense</h3>
        {monthlyData.length > 0 ? (
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `₹${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`} />
              <Tooltip formatter={(v: number) => formatRupee(Math.round(v * 100))} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Income" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Expense" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[250px] flex items-center justify-center text-slate-400 text-sm">No data</div>
        )}
      </div>

      {/* Recent transactions + expense categories */}
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-slate-900">Recent Transactions</h3>
            <Link to="/app/history" className="text-sm text-emerald-600 hover:text-emerald-700 flex items-center gap-1">
              View All <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="space-y-2">
            {recentTx.map((t) => (
              <div key={t.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-slate-900 truncate">{t.description}</p>
                  <p className="text-xs text-slate-400">
                    {formatDate(t.date)} {t.time && formatTime(t.time)} · {t.paymentMethod.toUpperCase()}
                  </p>
                </div>
                <p className={`text-sm font-bold shrink-0 ml-3 ${t.type === "income" ? "text-emerald-600" : "text-red-600"}`}>
                  {t.type === "income" ? "+" : "-"}{formatRupee(t.amount)}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="font-bold text-slate-900 mb-4">Expense Categories (Top 5)</h3>
          {expenseCats.length > 0 ? (
            <div className="space-y-3">
              {expenseCats.map((c) => {
                const maxAmt = expenseCats[0].amount;
                const pct = maxAmt > 0 ? (c.amount / maxAmt) * 100 : 0;
                return (
                  <div key={c.category}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-slate-700">{c.category}</span>
                      <span className="font-bold text-slate-900">{formatRupee(c.amount)}</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-red-400 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-slate-400">No expenses recorded yet.</p>
          )}
        </div>
      </div>

      {/* Account balances + closing status */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Banknote className="w-5 h-5 text-orange-500" />
            <h3 className="font-bold text-slate-900">Cash Account</h3>
          </div>
          <p className="text-2xl font-bold text-slate-900">{formatRupee(balances.cash)}</p>
          <p className="text-xs text-slate-400 mt-1">Opening: {formatRupee(data.openingBalances.cash)}</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <CreditCard className="w-5 h-5 text-blue-500" />
            <h3 className="font-bold text-slate-900">UPI Account</h3>
          </div>
          <p className="text-2xl font-bold text-slate-900">{formatRupee(balances.upi)}</p>
          <p className="text-xs text-slate-400 mt-1">Opening: {formatRupee(data.openingBalances.upi)}</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Building2 className="w-5 h-5 text-emerald-500" />
            <h3 className="font-bold text-slate-900">Bank Account</h3>
          </div>
          <p className="text-2xl font-bold text-slate-900">{formatRupee(balances.bank)}</p>
          <p className="text-xs text-slate-400 mt-1">Opening: {formatRupee(data.openingBalances.bank)}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
              <Wallet className="w-5 h-5 text-slate-600" />
            </div>
            <div>
              <p className="text-sm text-slate-500">Combined Total Balance</p>
              <p className="text-2xl font-bold text-slate-900">{formatRupee(balances.cash + balances.upi + balances.bank)}</p>
            </div>
          </div>
          <Link to="/app/reports" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium hover:bg-slate-200">
            <FileBarChart className="w-4 h-4" /> View Reports
          </Link>
        </div>
      </div>

      {/* Local storage warning */}
      <div className="flex items-start gap-3 bg-amber-50 rounded-xl p-4 border border-amber-200">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <p className="text-xs text-amber-800">
          Your records are stored in this browser only. Clearing browser data will remove them. Export backups regularly from Settings.
        </p>
      </div>
    </div>
  );
}
