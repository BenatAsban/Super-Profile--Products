import { useState, useMemo, useEffect } from "react";
import { Search, Plus, Pencil, Trash2, Download, Filter, X } from "lucide-react";
import { useApp } from "@/store/AppContext";
import { useSearchParams } from "react-router-dom";
import { formatRupee, formatDate, formatTime } from "@/lib/format";
import { PAYMENT_METHODS, DEFAULT_EXPENSE_CATEGORIES, DEFAULT_INCOME_CATEGORIES } from "@/lib/constants";
import { toCSV, downloadCSV } from "@/lib/csv";
import TransactionForm from "@/components/TransactionForm";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import EmptyState from "@/components/ui/EmptyState";
import { Input, Select } from "@/components/ui/FormField";
import type { TransactionType } from "@/types";

interface TransactionListProps {
  type: TransactionType;
}

export default function TransactionList({ type }: TransactionListProps) {
  const { data, deleteTransaction } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();
  const [formOpen, setFormOpen] = useState(false);
  const [editTx, setEditTx] = useState<typeof data.transactions[0] | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [filterMethod, setFilterMethod] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const isIncome = type === "income";

  // Check for ?action=add on mount
  useEffect(() => {
    if (searchParams.get("action") === "add") {
      setFormOpen(true);
      searchParams.delete("action");
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const allCategories = isIncome
    ? [...DEFAULT_INCOME_CATEGORIES, ...data.customIncomeCategories]
    : [...DEFAULT_EXPENSE_CATEGORIES, ...data.customExpenseCategories];

  const filteredTx = useMemo(() => {
    return data.transactions
      .filter((t) => t.type === type)
      .filter((t) => {
        if (search) {
          const q = search.toLowerCase();
          const match =
            t.description.toLowerCase().includes(q) ||
            t.id.toLowerCase().includes(q) ||
            (t.customer || "").toLowerCase().includes(q) ||
            (t.payee || "").toLowerCase().includes(q) ||
            (t.reference || "").toLowerCase().includes(q);
          if (!match) return false;
        }
        if (filterDateFrom && t.date < filterDateFrom) return false;
        if (filterDateTo && t.date > filterDateTo) return false;
        if (filterCategory) {
          const cat = isIncome ? t.incomeCategory : t.expenseCategory;
          if (cat !== filterCategory) return false;
        }
        if (filterMethod && t.paymentMethod !== filterMethod) return false;
        return true;
      })
      .sort((a, b) => {
        if (a.date !== b.date) return b.date.localeCompare(a.date);
        const aTime = a.time || "";
        const bTime = b.time || "";
        if (aTime !== bTime) return bTime.localeCompare(aTime);
        return b.createdAt.localeCompare(a.createdAt);
      });
  }, [data.transactions, type, search, filterDateFrom, filterDateTo, filterCategory, filterMethod, isIncome]);

  const totalAmount = filteredTx.reduce((s, t) => s + t.amount, 0);

  const handleEdit = (tx: typeof data.transactions[0]) => {
    setEditTx(tx);
    setFormOpen(true);
  };

  const handleAdd = () => {
    setEditTx(null);
    setFormOpen(true);
  };

  const handleDelete = () => {
    if (deleteId) {
      deleteTransaction(deleteId);
      setDeleteId(null);
    }
  };

  const handleExport = () => {
    const rows = filteredTx.map((t) => ({
      "Transaction ID": t.id,
      Date: t.date,
      Time: t.time || "",
      Type: isIncome ? t.incomeType || "" : t.expenseCategory || "",
      Description: t.description,
      [isIncome ? "Customer" : "Payee"]: isIncome ? (t.customer || "") : (t.payee || ""),
      "Reference": t.reference || "",
      "Payment Method": t.paymentMethod.toUpperCase(),
      "Amount (₹)": (t.amount / 100).toFixed(2),
      Notes: t.notes || "",
    }));
    const filename = `${isIncome ? "income" : "expenses"}_${new Date().toISOString().slice(0, 10)}.csv`;
    downloadCSV(filename, toCSV(rows));
  };

  const clearFilters = () => {
    setSearch("");
    setFilterDateFrom("");
    setFilterDateTo("");
    setFilterCategory("");
    setFilterMethod("");
  };

  const hasFilters = search || filterDateFrom || filterDateTo || filterCategory || filterMethod;

  if (data.transactions.filter((t) => t.type === type).length === 0 && !hasFilters) {
    return (
      <div className="max-w-2xl mx-auto">
        <EmptyState
          icon={<Plus className="w-8 h-8 text-slate-400" />}
          title={`No ${isIncome ? "income" : "expense"} records yet`}
          message={`Start recording your ${isIncome ? "daily sales and income" : "business expenses"} to see them here.`}
          action={{ label: `Add ${isIncome ? "Income" : "Expense"}`, onClick: handleAdd }}
        />
        <TransactionForm open={formOpen} onClose={() => setFormOpen(false)} type={type} editTransaction={editTx} />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-bold text-slate-900">
            {isIncome ? "Income & Sales Records" : "Expense Records"}
          </h3>
          <p className="text-sm text-slate-500">{filteredTx.length} records · Total: {formatRupee(totalAmount)}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white border border-gray-200 text-sm font-medium text-slate-700 hover:bg-gray-50"
          >
            <Download className="w-4 h-4" /> Export CSV
          </button>
          <button
            onClick={handleAdd}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-medium ${
              isIncome ? "bg-emerald-500 hover:bg-emerald-600" : "bg-red-500 hover:bg-red-600"
            }`}
          >
            <Plus className="w-4 h-4" /> Add {isIncome ? "Income" : "Expense"}
          </button>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by ID, description, customer, or reference..."
              className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`inline-flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium ${
              showFilters || hasFilters ? "bg-emerald-50 border-emerald-200 text-emerald-700" : "bg-white border-gray-200 text-slate-700"
            }`}
          >
            <Filter className="w-4 h-4" /> Filters
          </button>
        </div>

        {showFilters && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-3 border-t border-gray-100">
            <Input label="From Date" type="date" value={filterDateFrom} onChange={(e) => setFilterDateFrom(e.target.value)} />
            <Input label="To Date" type="date" value={filterDateTo} onChange={(e) => setFilterDateTo(e.target.value)} />
            <Select label="Category" value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
              <option value="">All Categories</option>
              {allCategories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </Select>
            <Select label="Payment Method" value={filterMethod} onChange={(e) => setFilterMethod(e.target.value)}>
              <option value="">All Methods</option>
              {PAYMENT_METHODS.map((m) => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </Select>
            {hasFilters && (
              <button onClick={clearFilters} className="inline-flex items-center gap-1 text-sm text-red-500 hover:text-red-600 col-span-full">
                <X className="w-3.5 h-3.5" /> Clear all filters
              </button>
            )}
          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-3 font-semibold whitespace-nowrap">Date</th>
                <th className="text-left px-4 py-3 font-semibold whitespace-nowrap hidden sm:table-cell">ID</th>
                <th className="text-left px-4 py-3 font-semibold">Description</th>
                <th className="text-left px-4 py-3 font-semibold hidden md:table-cell">{isIncome ? "Customer" : "Payee"}</th>
                <th className="text-left px-4 py-3 font-semibold hidden lg:table-cell">Category</th>
                <th className="text-left px-4 py-3 font-semibold hidden sm:table-cell">Method</th>
                <th className="text-right px-4 py-3 font-semibold">Amount</th>
                <th className="text-right px-4 py-3 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredTx.map((t) => (
                <tr key={t.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 whitespace-nowrap text-slate-700">
                    {formatDate(t.date)}
                    {t.time && <span className="block text-xs text-slate-400">{formatTime(t.time)}</span>}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-xs text-slate-500 hidden sm:table-cell">{t.id}</td>
                  <td className="px-4 py-3">
                    <p className="text-slate-900 font-medium">{t.description}{t.isDemo && <span className="ml-1 text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">DEMO</span>}</p>
                    {t.reference && <p className="text-xs text-slate-400">Ref: {t.reference}</p>}
                  </td>
                  <td className="px-4 py-3 text-slate-600 hidden md:table-cell">{isIncome ? t.customer || "-" : t.payee || "-"}</td>
                  <td className="px-4 py-3 text-slate-600 hidden lg:table-cell">{isIncome ? t.incomeCategory : t.expenseCategory}</td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-600 uppercase">{t.paymentMethod}</span>
                  </td>
                  <td className={`px-4 py-3 text-right font-bold whitespace-nowrap ${isIncome ? "text-emerald-600" : "text-red-600"}`}>
                    {isIncome ? "+" : "-"}{formatRupee(t.amount)}
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <button onClick={() => handleEdit(t)} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => setDeleteId(t.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredTx.length === 0 && (
          <div className="py-12 text-center text-slate-400 text-sm">No records match your filters.</div>
        )}
      </div>

      <TransactionForm open={formOpen} onClose={() => setFormOpen(false)} type={type} editTransaction={editTx} />
      <ConfirmDialog
        open={!!deleteId}
        title="Delete Transaction"
        message="Are you sure you want to delete this transaction? This action cannot be undone and will affect all balance calculations."
        confirmLabel="Delete"
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
