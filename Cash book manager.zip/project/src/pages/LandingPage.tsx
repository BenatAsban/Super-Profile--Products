import { Link } from "react-router-dom";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  BookOpen,
  CalendarCheck,
  FileBarChart,
  ArrowRight,
  CheckCircle,
  Shield,
  Smartphone,
  IndianRupee,
  Banknote,
  CreditCard,
  Building2,
  Star,
  ChevronDown,
} from "lucide-react";
import { useState } from "react";
import { useApp } from "@/store/AppContext";

export default function LandingPage() {
  const { loadDemoData } = useApp();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleTryDemo = () => {
    loadDemoData();
  };

  const faqs = [
    {
      q: "Does this app connect to my bank account or UPI?",
      a: "No. This application records transactions you enter manually. It does not connect to bank accounts, UPI apps, or payment gateways. It does not transfer money or sync balances automatically.",
    },
    {
      q: "Where is my data stored?",
      a: "All your transaction records are stored locally in your browser's storage. They stay on your device. Clearing your browser data will remove the records, so please export backups regularly.",
    },
    {
      q: "Can I use this on multiple devices?",
      a: "Data is stored per browser. It does not sync across devices automatically. You can export your data as a JSON file and import it on another device.",
    },
    {
      q: "Is this certified accounting software?",
      a: "No. This is a simple cash book and transaction tracking tool. It is not a substitute for professional accounting software or a chartered accountant. It helps you track daily sales, expenses, and cash balances.",
    },
    {
      q: "What payment methods does it track?",
      a: "Cash, UPI, and Bank transactions are tracked separately. You can see account-wise balances and a combined total at any time.",
    },
    {
      q: "Can I export my reports?",
      a: "Yes. You can export reports as CSV files and download all your data as a JSON backup.",
    },
  ];

  const features = [
    { icon: TrendingUp, title: "Income & Sales Tracking", desc: "Record daily sales, service income, and other receipts with customer details and references." },
    { icon: TrendingDown, title: "Expense Management", desc: "Track expenses by category - stock, rent, salary, electricity, transport, and more." },
    { icon: BookOpen, title: "Cash Book Ledger", desc: "Chronological ledger with running balances for Cash, UPI, and Bank accounts." },
    { icon: CalendarCheck, title: "Day Closing & Reconciliation", desc: "Enter actual cash counted, compare with expected balance, and spot shortages or excess." },
    { icon: FileBarChart, title: "Reports & Exports", desc: "Daily, monthly, and category-wise reports with CSV export for your records." },
    { icon: Smartphone, title: "Mobile Responsive", desc: "Works on your phone, tablet, and desktop. Perfect for use at the shop counter." },
  ];

  const steps = [
    { num: "1", title: "Set Up Your Business", desc: "Enter your business name and opening balances for Cash, UPI, and Bank accounts." },
    { num: "2", title: "Record Daily Transactions", desc: "Add your income and expenses as they happen. Choose the payment method for each entry." },
    { num: "3", title: "Close the Day & Review", desc: "Count your cash, enter the actual balance, reconcile, and export your reports." },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="sticky top-0 z-40 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-500 flex items-center justify-center">
              <Wallet className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-sm font-bold text-slate-900 block leading-tight">Cash Book Manager</span>
              <span className="text-[10px] text-slate-400">India 2026</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/app/dashboard"
              className="text-sm font-medium text-slate-600 hover:text-slate-900 hidden sm:block"
            >
              Open App
            </Link>
            <Link
              to="/app/dashboard"
              className="px-4 py-2 rounded-lg bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600"
            >
              Start Tracking
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-white to-blue-50" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-medium mb-5">
                <IndianRupee className="w-3.5 h-3.5" />
                Made for Indian small businesses
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 leading-tight">
                Track your daily sales,
                <span className="text-emerald-600"> cash, UPI</span> and
                <span className="text-blue-600"> bank</span> transactions
              </h1>
              <p className="mt-5 text-lg text-slate-600 leading-relaxed">
                A simple daily cash book for shopkeepers, freelancers, and small business owners.
                Record income and expenses, track Cash/UPI/Bank balances, reconcile your day,
                and export reports - all in one place.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  to="/app/dashboard"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 transition-colors shadow-lg shadow-emerald-500/20"
                >
                  Start Tracking
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <button
                  onClick={handleTryDemo}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white border border-gray-200 text-slate-700 font-semibold hover:bg-gray-50 transition-colors"
                >
                  Try Demo
                </button>
              </div>
              <div className="mt-6 flex items-center gap-5 text-sm text-slate-500">
                <span className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500" /> No signup needed
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500" /> Works offline
                </span>
              </div>
            </div>

            {/* Dashboard Preview */}
            <div className="relative">
              <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 p-5 lg:p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-slate-900">Dashboard Preview</h3>
                  <span className="text-xs text-slate-400">Today</span>
                </div>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-emerald-50 rounded-xl p-3.5">
                    <p className="text-xs text-slate-500 font-medium">Today's Income</p>
                    <p className="text-lg font-bold text-emerald-700 mt-0.5">₹7,750.00</p>
                  </div>
                  <div className="bg-red-50 rounded-xl p-3.5">
                    <p className="text-xs text-slate-500 font-medium">Today's Expenses</p>
                    <p className="text-lg font-bold text-red-700 mt-0.5">₹700.00</p>
                  </div>
                  <div className="bg-blue-50 rounded-xl p-3.5">
                    <p className="text-xs text-slate-500 font-medium">UPI Collections</p>
                    <p className="text-lg font-bold text-blue-700 mt-0.5">₹1,800.00</p>
                  </div>
                  <div className="bg-orange-50 rounded-xl p-3.5">
                    <p className="text-xs text-slate-500 font-medium">Cash Balance</p>
                    <p className="text-lg font-bold text-orange-700 mt-0.5">₹10,450.00</p>
                  </div>
                </div>
                <div className="bg-slate-50 rounded-xl p-4">
                  <div className="flex items-end justify-between gap-1.5 h-24">
                    {[40, 65, 35, 80, 55, 90, 70].map((h, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1">
                        <div className="w-full rounded-t bg-gradient-to-t from-emerald-400 to-emerald-500" style={{ height: `${h}%` }} />
                        <span className="text-[9px] text-slate-400">{["M", "T", "W", "T", "F", "S", "S"][i]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 bg-white rounded-xl shadow-lg p-3 border border-gray-100 hidden lg:block">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                    <CalendarCheck className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">Day Closed</p>
                    <p className="text-[10px] text-slate-400">Reconciled</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 lg:py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Everything you need to track your business</h2>
            <p className="mt-3 text-slate-600 max-w-2xl mx-auto">
              From daily sales to day-end reconciliation, manage all your financial transactions in one simple tool.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <div key={i} className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="w-11 h-11 rounded-xl bg-emerald-100 flex items-center justify-center mb-4">
                    <Icon className="w-5.5 h-5.5 text-emerald-600" style={{ width: 22, height: 22 }} />
                  </div>
                  <h3 className="font-bold text-slate-900 mb-2">{f.title}</h3>
                  <p className="text-sm text-slate-600">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Account Types */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-slate-900">Track three accounts separately</h2>
            <p className="mt-3 text-slate-600">Cash, UPI, and Bank - each with its own balance and ledger.</p>
          </div>
          <div className="grid sm:grid-cols-3 gap-5">
            <div className="rounded-xl border-2 border-orange-200 bg-orange-50 p-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-orange-500 flex items-center justify-center mx-auto mb-3">
                <Banknote className="w-7 h-7 text-white" />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">Cash</h3>
              <p className="text-sm text-slate-600 mt-1">Track physical cash receipts and payments</p>
            </div>
            <div className="rounded-xl border-2 border-blue-200 bg-blue-50 p-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-blue-500 flex items-center justify-center mx-auto mb-3">
                <CreditCard className="w-7 h-7 text-white" />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">UPI</h3>
              <p className="text-sm text-slate-600 mt-1">Record UPI collections and payments</p>
            </div>
            <div className="rounded-xl border-2 border-emerald-200 bg-emerald-50 p-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500 flex items-center justify-center mx-auto mb-3">
                <Building2 className="w-7 h-7 text-white" />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">Bank</h3>
              <p className="text-sm text-slate-600 mt-1">Track bank deposits and withdrawals</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 lg:py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">How it works</h2>
            <p className="mt-3 text-slate-300">Three simple steps to manage your daily transactions.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((s, i) => (
              <div key={i} className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  {s.num}
                </div>
                <h3 className="font-bold text-lg mb-2">{s.title}</h3>
                <p className="text-sm text-slate-300">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link
              to="/app/dashboard"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-500 text-white font-semibold hover:bg-emerald-600 transition-colors"
            >
              Get Started Now
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16 bg-white">
        <div className="max-w-md mx-auto px-4 sm:px-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-medium mb-4">
            <Star className="w-3.5 h-3.5" /> Launch Offer
          </div>
          <h2 className="text-3xl font-bold text-slate-900">Simple Pricing</h2>
          <div className="mt-8 bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-8 text-white shadow-xl">
            <p className="text-slate-300 text-sm">One-time purchase</p>
            <div className="flex items-baseline justify-center gap-2 mt-2">
              <span className="text-5xl font-bold">₹149</span>
              <span className="text-xl text-slate-400 line-through">₹249</span>
            </div>
            <p className="text-sm text-slate-300 mt-2">Launch price for a limited time</p>
            <div className="mt-6 space-y-2 text-left">
              {[
                "Full access to all features",
                "Unlimited transactions",
                "CSV and JSON export",
                "No recurring fees",
                "Use on any device with a browser",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" /> {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-10">Frequently Asked Questions</h2>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-5 py-4 text-left"
                >
                  <span className="font-semibold text-slate-900 text-sm">{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-slate-400 shrink-0 transition-transform ${openFaq === i ? "rotate-180" : ""}`}
                  />
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-4 text-sm text-slate-600 leading-relaxed">{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-8 bg-white border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="flex items-start gap-3 bg-amber-50 rounded-xl p-4 border border-amber-200">
            <Shield className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 leading-relaxed">
              This application records transactions locally in your browser. It does not connect to bank accounts,
              UPI apps, or payment processors. It does not transfer money, verify bank balances, or provide certified
              accounting services. Always export regular backups. This is not a substitute for professional accounting software.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-slate-900 text-slate-400 text-center text-sm">
        <p>Daily Sales & Cash Book Manager India 2026</p>
        <p className="mt-1 text-xs">Built for Indian small businesses. All data stays in your browser.</p>
      </footer>
    </div>
  );
}
