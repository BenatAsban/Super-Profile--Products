import { useState, useMemo } from "react";
import { BookOpen, Download, Banknote, CreditCard, Building2, Wallet } from "lucide-react";
import { useApp } from "@/store/AppContext";
import { formatRupee, formatDate, formatTime, todayDate } from "@/lib/format";
import { PAYMENT_METHODS } from "@/lib/constants";
import {
  runningBalanceLedger,
  allAccountBalances,
  openingBalanceForDate,
  closingBalanceForDate,
  sortTransactions,
} from "@/lib/calculations";
import { toCSV, downloadCSV } from "@/lib/csv";
import { Input, Select } from "@/components/ui/FormField";
import EmptyState from "@/components/ui/EmptyState";
import type { PaymentMethod } from "@/types";

export default function CashBook() {
  const { data } = useApp();
  const [account, setAccount] = useState<PaymentMethod | "all">("all");
  const [date, setDate] = useState(todayDate());

  const balances = useMemo(
    () => allAccountBalances(data.openingBalances, data.transactions),
    [data.openingBalances, data.transactions]
  );

  // Filter transactions up to and including the selected date
  const txsUpToDate = useMemo(
    () => data.transactions.filter((t) => t.date <= date),
    [data.transactions, date]
  );

  const ledger = useMemo(
    () => runningBalanceLedger(data.openingBalances, txsUpToDate, account),
    [data.openingBalances, txsUpToDate, account]
  );

  const accountIcons = {
    cash: Banknote,
    upi: CreditCard,
    bank: Building2,
  };

  if (data.transactions.length === 0) {
    return (
      <EmptyState
        icon={<BookOpen className="w-8 h-8 text-slate-400" />}
        title="Cash book is empty"
        message="Once you start recording transactions, your cash book ledger with running balances will appear here."
      />
    );
  }

  const handleExport = () => {
    const rows = ledger.map((e) => ({
      Date: e.transaction.date,
      Time: e.transaction.time || "",
      "Transaction ID": e.transaction.id,
      Description: e.transaction.description,
      Type: e.transaction.type === "income" ? "Income" : "Expense",
      "Payment Method": e.transaction.paymentMethod.toUpperCase(),
      Income: e.transaction.type === "income" ? (e.transaction.amount / 100).toFixed(2) : "",
      Expense: e.transaction.type === "expense" ? (e.transaction.amount / 100).toFixed(2) : "",
      "Running Balance": (e.runningBalance / 100).toFixed(2),
      Reference: e.transaction.reference || "",
    }));
    downloadCSV(`cashbook_${date}.csv`, toCSV(rows));
  };

  return (
    <div className="space-y-4">
      {/* Account balance cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {PAYMENT_METHODS.map((m) => {
          const Icon = accountIcons[m.value];
          const colorClass = m.value === "cash" ? "text-orange-600 bg-orange-50" : m.value === "upi" ? "text-blue-600 bg-blue-50" : "text-emerald-600 bg-emerald-50";
          return (
            <div key={m.value} className="bg-white rounded-xl border border-gray-200 p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${colorClass}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-sm font-medium text-slate-600">{m.label}</span>
              </div>
              <p className="text-xl font-bold text-slate-900">{formatRupee(balances[m.value])}</p>
            </div>
          );
        })}
        <div className="bg-slate-900 rounded-xl p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-white/10">
              <Wallet className="w-4 h-4" />
            </div>
            <span className="text-sm font-medium text-slate-300">Total</span>
          </div>
          <p className="text-xl font-bold">{formatRupee(balances.cash + balances.upi + balances.bank)}</p>
        </div>
      </div>

      {/* Date & Account selectors */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input
            label="Cash Book Date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            max={todayDate()}
          />
          <Select
            label="Account Filter"
            value={account}
            onChange={(e) => setAccount(e.target.value as PaymentMethod | "all")}
          >
            <option value="all">All Accounts</option>
            {PAYMENT_METHODS.map((m) => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </Select>
        </div>

        {/* Day summary */}
        <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 border-t border-gray-100">
          {PAYMENT_METHODS.map((m) => {
            if (account !== "all" && account !== m.value) return null;
            const open = openingBalanceForDate(data.openingBalances, data.transactions, m.value, date);
            const close = closingBalanceForDate(data.openingBalances, data.transactions, m.value, date);
            return (
              <div key={m.value} className="bg-slate-50 rounded-lg p-3">
                <p className="text-xs text-slate-500 font-medium">{m.label} - Selected Date</p>
                <p className="text-sm text-slate-700 mt-1">Opening: <span className="font-semibold">{formatRupee(open)}</span></p>
                <p className="text-sm text-slate-700">Closing: <span className="font-semibold">{formatRupee(close)}</span></p>
              </div>
            );
          })}
        </div>

        <div className="mt-3 flex justify-end">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white border border-gray-200 text-sm font-medium text-slate-700 hover:bg-gray-50"
          >
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      {/* Ledger table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="px-5 py-3 border-b border-gray-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-900">Ledger - {formatDate(date)}</h3>
          <span className="text-xs text-slate-400">{ledger.length} entries up to this date</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-3 font-semibold whitespace-nowrap">Date & Time</th>
                <th className="text-left px-4 py-3 font-semibold whitespace-nowrap hidden sm:table-cell">Txn ID</th>
                <th className="text-left px-4 py-3 font-semibold">Description</th>
                <th className="text-left px-4 py-3 font-semibold hidden md:table-cell">Method</th>
                <th className="text-right px-4 py-3 font-semibold text-emerald-600">Income</th>
                <th className="text-right px-4 py-3 font-semibold text-red-600">Expense</th>
                <th className="text-right px-4 py-3 font-semibold">Running Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {ledger.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    No transactions up to {formatDate(date)}.
                  </td>
                </tr>
              ) : (
                ledger.map((e) => (
                  <tr key={e.transaction.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 whitespace-nowrap text-slate-700">
                      {formatDate(e.transaction.date)}
                      {e.transaction.time && <span className="block text-xs text-slate-400">{formatTime(e.transaction.time)}</span>}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-xs text-slate-500 hidden sm:table-cell">{e.transaction.id}</td>
                    <td className="px-4 py-3">
                      <p className="text-slate-900 font-medium">{e.transaction.description}</p>
                      {e.transaction.reference && <p className="text-xs text-slate-400">Ref: {e.transaction.reference}</p>}
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-600 uppercase">{e.transaction.paymentMethod}</span>
                    </td>
                    <td className="px-4 py-3 text-right text-emerald-600 font-medium whitespace-nowrap">
                      {e.transaction.type === "income" ? formatRupee(e.transaction.amount) : "-"}
                    </td>
                    <td className="px-4 py-3 text-right text-red-600 font-medium whitespace-nowrap">
                      {e.transaction.type === "expense" ? formatRupee(e.transaction.amount) : "-"}
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-slate-900 whitespace-nowrap">{formatRupee(e.runningBalance)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Previous closings */}
      {data.closings.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="font-bold text-slate-900 mb-3">Saved Closing Records</h3>
          <div className="space-y-2">
            {sortTransactions(data.transactions).length > 0 && data.closings.sort((a, b) => b.date.localeCompare(a.date)).map((c) => (
              <div key={c.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                <div>
                  <p className="text-sm font-medium text-slate-900">{formatDate(c.date)}</p>
                  {c.notes && <p className="text-xs text-slate-400">{c.notes}</p>}
                </div>
                <div className="text-right text-sm">
                  {c.actualCash !== null && <p className="text-slate-600">Cash: {formatRupee(c.actualCash)}</p>}
                  {c.actualUpi !== null && <p className="text-slate-600">UPI: {formatRupee(c.actualUpi)}</p>}
                  {c.actualBank !== null && <p className="text-slate-600">Bank: {formatRupee(c.actualBank)}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
