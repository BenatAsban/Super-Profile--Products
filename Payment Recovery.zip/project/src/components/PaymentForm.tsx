import { useState } from 'react';
import type { Invoice, PaymentMethod } from '@/lib/types';
import { Field, Select, TextInput, Textarea } from '@/components/ui/Field';
import { outstanding } from '@/lib/calculations';
import { formatCurrency, todayISO } from '@/lib/format';

interface PaymentFormProps {
  invoice: Invoice;
  onSubmit: (data: {
    paymentDate: string;
    amount: number;
    method: PaymentMethod;
    reference?: string;
    notes?: string;
  }) => void;
}

export default function PaymentForm({ invoice, onSubmit }: PaymentFormProps) {
  const bal = outstanding(invoice);
  const [paymentDate, setPaymentDate] = useState(todayISO());
  const [amount, setAmount] = useState(String(bal > 0 ? bal : ''));
  const [method, setMethod] = useState<PaymentMethod>('UPI');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  return (
    <form
      id="payment-form"
      onSubmit={(e) => {
        e.preventDefault();
        const errs: Record<string, string> = {};
        const amt = parseFloat(amount);
        if (Number.isNaN(amt) || amt <= 0) errs.amount = 'Enter a valid amount greater than 0.';
        if (amt > bal) errs.amount = `Amount exceeds outstanding balance of ${formatCurrency(bal)}.`;
        if (!paymentDate) errs.paymentDate = 'Required.';
        setErrors(errs);
        if (Object.keys(errs).length) return;
        onSubmit({
          paymentDate,
          amount: amt,
          method,
          reference: reference.trim() || undefined,
          notes: notes.trim() || undefined,
        });
      }}
    >
      <div className="mb-4 rounded-xl bg-slate-50 border border-slate-200 px-4 py-3 text-sm">
        <div className="flex justify-between">
          <span className="text-slate-500">Invoice Amount</span>
          <span className="font-medium text-slate-900">{formatCurrency(invoice.amount)}</span>
        </div>
        <div className="flex justify-between mt-1">
          <span className="text-slate-500">Already Received</span>
          <span className="font-medium text-emerald-600">{formatCurrency(invoice.amountReceived)}</span>
        </div>
        <div className="flex justify-between mt-1 pt-1 border-t border-slate-200">
          <span className="text-slate-500">Outstanding Balance</span>
          <span className="font-bold text-orange-600">{formatCurrency(bal)}</span>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Payment Date" required error={errors.paymentDate}>
          <TextInput type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} />
        </Field>
        <Field label="Amount Received (₹)" required error={errors.amount}>
          <TextInput
            type="number"
            min="0"
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
          />
        </Field>
        <Field label="Payment Method" required>
          <Select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
            <option value="UPI">UPI</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Cash">Cash</option>
            <option value="Other">Other</option>
          </Select>
        </Field>
        <Field label="Transaction Reference">
          <TextInput
            value={reference}
            onChange={(e) => setReference(e.target.value)}
            placeholder="UPI ID, NEFT ref, etc."
          />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Notes">
            <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>
        </div>
      </div>
      <button type="submit" className="hidden" />
    </form>
  );
}
