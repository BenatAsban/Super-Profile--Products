import { useEffect, useState } from 'react';
import type { Client, Invoice } from '@/lib/types';
import { Field, Select, TextInput, Textarea } from '@/components/ui/Field';
import { nextInvoiceNumber } from '@/lib/calculations';
import { todayISO } from '@/lib/format';

interface InvoiceFormProps {
  clients: Client[];
  existing?: Invoice | null;
  onSubmit: (data: {
    invoiceNumber: string;
    clientId: string;
    invoiceDate: string;
    dueDate: string;
    amount: number;
    notes?: string;
  }) => void;
  onCancel: () => void;
}

export default function InvoiceForm({ clients, existing, onSubmit, onCancel }: InvoiceFormProps) {
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [clientId, setClientId] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(todayISO());
  const [dueDate, setDueDate] = useState(todayISO());
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (existing) {
      setInvoiceNumber(existing.invoiceNumber);
      setClientId(existing.clientId);
      setInvoiceDate(existing.invoiceDate);
      setDueDate(existing.dueDate);
      setAmount(String(existing.amount));
      setNotes(existing.notes || '');
    }
  }, [existing]);

  return (
    <form
      id="invoice-form"
      onSubmit={(e) => {
        e.preventDefault();
        const errs: Record<string, string> = {};
        if (!invoiceNumber.trim()) errs.invoiceNumber = 'Invoice number is required.';
        if (!clientId) errs.clientId = 'Please select a client.';
        if (!invoiceDate) errs.invoiceDate = 'Required.';
        if (!dueDate) errs.dueDate = 'Required.';
        const amt = parseFloat(amount);
        if (Number.isNaN(amt) || amt <= 0) errs.amount = 'Enter a valid amount greater than 0.';
        if (new Date(dueDate) < new Date(invoiceDate))
          errs.dueDate = 'Due date cannot be before invoice date.';
        setErrors(errs);
        if (Object.keys(errs).length) return;
        onSubmit({
          invoiceNumber: invoiceNumber.trim(),
          clientId,
          invoiceDate,
          dueDate,
          amount: amt,
          notes: notes.trim() || undefined,
        });
      }}
    >
      {clients.length === 0 && (
        <div className="mb-4 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3 text-sm text-amber-800">
          You need to add a client first before creating an invoice.
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Invoice Number" required error={errors.invoiceNumber}>
          <div className="flex gap-2">
            <TextInput
              value={invoiceNumber}
              onChange={(e) => setInvoiceNumber(e.target.value)}
              placeholder="INV-2026-001"
            />
            {!existing && (
              <button
                type="button"
                onClick={() => setInvoiceNumber(nextInvoiceNumber([]))}
                className="shrink-0 rounded-xl border border-slate-300 px-3 text-xs font-medium text-slate-600 hover:bg-slate-50"
              >
                Auto
              </button>
            )}
          </div>
        </Field>
        <Field label="Client" required error={errors.clientId}>
          <Select value={clientId} onChange={(e) => setClientId(e.target.value)}>
            <option value="">Select a client…</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
                {c.businessName ? ` — ${c.businessName}` : ''}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Invoice Date" required error={errors.invoiceDate}>
          <TextInput type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
        </Field>
        <Field label="Due Date" required error={errors.dueDate}>
          <TextInput type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        </Field>
        <Field label="Invoice Amount (₹)" required error={errors.amount}>
          <TextInput
            type="number"
            min="0"
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
          />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Notes" hint="Optional — visible only to you">
            <Textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Project description, scope, etc."
            />
          </Field>
        </div>
      </div>
      <button type="submit" className="hidden" />
      <button type="button" onClick={onCancel} className="hidden" />
    </form>
  );
}
