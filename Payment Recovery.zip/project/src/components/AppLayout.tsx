import { NavLink, useLocation } from 'react-router-dom';
import { useState, type ReactNode } from 'react';
import {
  LayoutDashboard,
  FileText,
  Users,
  CreditCard,
  MessageCircle,
  BarChart3,
  Settings,
  Menu,
  X,
  Wallet,
  Plus,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';

const navItems = [
  { to: '/app', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/app/invoices', label: 'Invoices', icon: FileText },
  { to: '/app/clients', label: 'Clients', icon: Users },
  { to: '/app/payments', label: 'Payments', icon: CreditCard },
  { to: '/app/reminders', label: 'Reminders', icon: MessageCircle },
  { to: '/app/reports', label: 'Reports', icon: BarChart3 },
  { to: '/app/settings', label: 'Settings', icon: Settings },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  const { data } = useApp();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();

  const currentLabel =
    navItems.find((n) => (n.end ? location.pathname === n.to : location.pathname.startsWith(n.to)))?.label ??
    'Dashboard';

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Sidebar - desktop */}
      <aside className="hidden lg:flex fixed inset-y-0 left-0 w-64 flex-col border-r border-slate-200 bg-white z-30">
        <SidebarContent businessName={data.settings.businessName} onClose={() => setSidebarOpen(false)} />
      </aside>

      {/* Sidebar - mobile */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white shadow-xl flex flex-col animate-[slideInLeft_0.2s_ease-out]">
            <SidebarContent businessName={data.settings.businessName} onClose={() => setSidebarOpen(false)} />
          </aside>
        </div>
      )}

      <div className="lg:pl-64">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-slate-200">
          <div className="flex items-center justify-between px-4 sm:px-6 h-16">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden rounded-lg p-2 text-slate-600 hover:bg-slate-100"
                aria-label="Open menu"
              >
                <Menu size={20} />
              </button>
              <h1 className="text-lg font-semibold text-slate-900">{currentLabel}</h1>
            </div>
            <NavLink
              to="/app/invoices?new=1"
              className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 transition-colors"
            >
              <Plus size={16} />
              <span className="hidden sm:inline">New Invoice</span>
            </NavLink>
          </div>
        </header>

        <main className="px-4 sm:px-6 py-6 max-w-7xl mx-auto">{children}</main>
      </div>
    </div>
  );
}

function SidebarContent({ businessName, onClose }: { businessName: string; onClose: () => void }) {
  return (
    <>
      <div className="flex items-center justify-between px-5 h-16 border-b border-slate-100 shrink-0">
        <NavLink to="/" className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-900 text-white">
            <Wallet size={18} />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-bold text-slate-900">Payment Recovery</p>
            <p className="text-[11px] text-slate-400">Tracker India</p>
          </div>
        </NavLink>
        <button
          onClick={onClose}
          className="lg:hidden rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"
          aria-label="Close menu"
        >
          <X size={18} />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`
              }
            >
              <Icon size={18} />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      <div className="border-t border-slate-100 px-5 py-4 shrink-0">
        <p className="text-xs font-medium text-slate-500 truncate">{businessName}</p>
        <p className="mt-0.5 text-[11px] text-slate-400">Data stored in this browser</p>
      </div>
    </>
  );
}
