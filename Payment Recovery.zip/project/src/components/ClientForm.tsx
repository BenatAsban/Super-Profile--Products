import { useEffect, useState } from 'react';
import type { Client } from '@/lib/types';
import { Field, TextInput, Textarea } from '@/components/ui/Field';

interface ClientFormProps {
  existing?: Client | null;
  onSubmit: (data: {
    name: string;
    businessName?: string;
    phone?: string;
    email?: string;
    address?: string;
    notes?: string;
  }) => void;
}

export default function ClientForm({ existing, onSubmit }: ClientFormProps) {
  const [name, setName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (existing) {
      setName(existing.name);
      setBusinessName(existing.businessName || '');
      setPhone(existing.phone || '');
      setEmail(existing.email || '');
      setAddress(existing.address || '');
      setNotes(existing.notes || '');
    }
  }, [existing]);

  return (
    <form
      id="client-form"
      onSubmit={(e) => {
        e.preventDefault();
        const errs: Record<string, string> = {};
        if (!name.trim()) errs.name = 'Client name is required.';
        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errs.email = 'Enter a valid email.';
        if (phone && !/^[0-9+\-\s()]{7,15}$/.test(phone)) errs.phone = 'Enter a valid phone number.';
        setErrors(errs);
        if (Object.keys(errs).length) return;
        onSubmit({
          name: name.trim(),
          businessName: businessName.trim() || undefined,
          phone: phone.trim() || undefined,
          email: email.trim() || undefined,
          address: address.trim() || undefined,
          notes: notes.trim() || undefined,
        });
      }}
    >
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Client Name" required error={errors.name}>
          <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Arjun Mehta" />
        </Field>
        <Field label="Business Name">
          <TextInput
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            placeholder="e.g. Mehta Retail Solutions"
          />
        </Field>
        <Field label="Phone" error={errors.phone}>
          <TextInput value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="9876543210" />
        </Field>
        <Field label="Email" error={errors.email}>
          <TextInput
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="client@example.com"
          />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Address">
            <TextInput value={address} onChange={(e) => setAddress(e.target.value)} placeholder="City, State" />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="Notes">
            <Textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Project details, preferences, etc."
            />
          </Field>
        </div>
      </div>
      <button type="submit" className="hidden" />
    </form>
  );
}
