import type { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}

export default function Card({ children, className = '', onClick }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-2xl border border-slate-200 shadow-sm ${onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''} ${className}`}
    >
      {children}
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: string;
  icon: ReactNode;
  accent?: 'emerald' | 'orange' | 'red' | 'slate' | 'blue';
  subtitle?: string;
}

const accents: Record<NonNullable<StatCardProps['accent']>, { ring: string; icon: string }> = {
  emerald: { ring: 'ring-emerald-100', icon: 'bg-emerald-50 text-emerald-600' },
  orange: { ring: 'ring-orange-100', icon: 'bg-orange-50 text-orange-600' },
  red: { ring: 'ring-red-100', icon: 'bg-red-50 text-red-600' },
  slate: { ring: 'ring-slate-100', icon: 'bg-slate-100 text-slate-600' },
  blue: { ring: 'ring-blue-100', icon: 'bg-blue-50 text-blue-600' },
};

export function StatCard({ label, value, icon, accent = 'slate', subtitle }: StatCardProps) {
  const a = accents[accent];
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 tracking-tight truncate">{value}</p>
          {subtitle && <p className="mt-1 text-xs text-slate-400">{subtitle}</p>}
        </div>
        <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${a.icon}`}>
          {icon}
        </div>
      </div>
    </Card>
  );
}
