import type { AppData, Client, Invoice, Payment } from './types';
import { uid } from './format';

function isoDaysFromNow(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function generateSampleData(): AppData {
  const c1: Client = {
    id: uid('c_'),
    name: 'Arjun Mehta',
    businessName: 'Mehta Retail Solutions',
    phone: '9876543210',
    email: 'arjun@mehtaretail.in',
    address: 'T Nagar, Chennai',
    notes: 'Website redesign client',
    createdAt: new Date().toISOString(),
    isSample: true,
  };
  const c2: Client = {
    id: uid('c_'),
    name: 'Priya Nair',
    businessName: 'Bloom Florists',
    phone: '9123456780',
    email: 'priya@bloomflorists.com',
    address: 'Indiranagar, Bengaluru',
    notes: 'Monthly retainer for social media',
    createdAt: new Date().toISOString(),
    isSample: true,
  };
  const c3: Client = {
    id: uid('c_'),
    name: 'Karan Shah',
    businessName: 'Shah & Co. CA',
    phone: '9988776655',
    email: 'karan@shahco.in',
    address: 'Andheri West, Mumbai',
    notes: 'Accounting software setup',
    createdAt: new Date().toISOString(),
    isSample: true,
  };
  const c4: Client = {
    id: uid('c_'),
    name: 'Deepika Reddy',
    businessName: 'Glide Yoga Studio',
    phone: '9001122334',
    email: 'deepika@glideyoga.in',
    address: 'Jubilee Hills, Hyderabad',
    notes: 'Booking app maintenance',
    createdAt: new Date().toISOString(),
    isSample: true,
  };

  const clients = [c1, c2, c3, c4];

  const inv1: Invoice = {
    id: uid('i_'),
    invoiceNumber: 'INV-2026-001',
    clientId: c1.id,
    invoiceDate: isoDaysFromNow(-45),
    dueDate: isoDaysFromNow(-15),
    amount: 45000,
    amountReceived: 45000,
    notes: 'E-commerce website redesign - final payment',
    createdAt: new Date().toISOString(),
    isSample: true,
  };
  const inv2: Invoice = {
    id: uid('i_'),
    invoiceNumber: 'INV-2026-002',
    clientId: c2.id,
    invoiceDate: isoDaysFromNow(-30),
    dueDate: isoDaysFromNow(-2),
    amount: 18000,
    amountReceived: 9000,
    notes: 'Social media retainer - Feb & Mar',
    createdAt: new Date().toISOString(),
    isSample: true,
  };
  const inv3: Invoice = {
    id: uid('i_'),
    invoiceNumber: 'INV-2026-003',
    clientId: c3.id,
    invoiceDate: isoDaysFromNow(-20),
    dueDate: isoDaysFromNow(-8),
    amount: 65000,
    amountReceived: 0,
    notes: 'Tally integration & training',
    createdAt: new Date().toISOString(),
    isSample: true,
  };
  const inv4: Invoice = {
    id: uid('i_'),
    invoiceNumber: 'INV-2026-004',
    clientId: c4.id,
    invoiceDate: isoDaysFromNow(-10),
    dueDate: isoDaysFromNow(5),
    amount: 25000,
    amountReceived: 0,
    notes: 'Booking app - Phase 2',
    createdAt: new Date().toISOString(),
    isSample: true,
  };
  const inv5: Invoice = {
    id: uid('i_'),
    invoiceNumber: 'INV-2026-005',
    clientId: c1.id,
    invoiceDate: isoDaysFromNow(-5),
    dueDate: isoDaysFromNow(10),
    amount: 30000,
    amountReceived: 15000,
    notes: 'SEO optimization - March',
    createdAt: new Date().toISOString(),
    isSample: true,
  };

  const invoices = [inv1, inv2, inv3, inv4, inv5];

  const payments: Payment[] = [
    {
      id: uid('p_'),
      invoiceId: inv1.id,
      paymentDate: isoDaysFromNow(-40),
      amount: 20000,
      method: 'UPI',
      reference: 'UPI-784512',
      notes: 'Advance',
      createdAt: new Date().toISOString(),
      isSample: true,
    },
    {
      id: uid('p_'),
      invoiceId: inv1.id,
      paymentDate: isoDaysFromNow(-15),
      amount: 25000,
      method: 'Bank Transfer',
      reference: 'NEFT-992133',
      notes: 'Final payment',
      createdAt: new Date().toISOString(),
      isSample: true,
    },
    {
      id: uid('p_'),
      invoiceId: inv2.id,
      paymentDate: isoDaysFromNow(-25),
      amount: 9000,
      method: 'UPI',
      reference: 'UPI-332109',
      notes: 'Partial',
      createdAt: new Date().toISOString(),
      isSample: true,
    },
    {
      id: uid('p_'),
      invoiceId: inv5.id,
      paymentDate: isoDaysFromNow(-3),
      amount: 15000,
      method: 'Cash',
      notes: 'Advance',
      createdAt: new Date().toISOString(),
      isSample: true,
    },
  ];

  return {
    clients,
    invoices,
    payments,
    settings: {
      businessName: 'Freelance Studio',
      contactName: 'Rahul Verma',
      phone: '9800000000',
      email: 'hello@freelancestudio.in',
      address: 'Anna Nagar, Chennai',
      currency: 'INR',
      language: 'en',
    },
    onboarded: true,
  };
}
