import type { AppData, Invoice, Payment } from './types';
import { DEFAULT_SETTINGS, emptyData } from './types';

const STORAGE_KEY = 'cprt-data-v1';

export function loadData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...emptyData };
    const parsed = JSON.parse(raw) as Partial<AppData>;
    return {
      clients: Array.isArray(parsed.clients) ? parsed.clients : [],
      invoices: Array.isArray(parsed.invoices) ? parsed.invoices : [],
      payments: Array.isArray(parsed.payments) ? parsed.payments : [],
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
      onboarded: Boolean(parsed.onboarded),
    };
  } catch {
    return { ...emptyData };
  }
}

export function saveData(data: AppData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save data', e);
  }
}

export function clearData(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear data', e);
  }
}

export function importData(text: string): { ok: boolean; data?: AppData; error?: string } {
  try {
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== 'object') {
      return { ok: false, error: 'File is not valid JSON object.' };
    }
    const data: AppData = {
      clients: Array.isArray(parsed.clients) ? parsed.clients : [],
      invoices: Array.isArray(parsed.invoices) ? parsed.invoices : [],
      payments: Array.isArray(parsed.payments) ? parsed.payments : [],
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
      onboarded: Boolean(parsed.onboarded),
    };
    // basic shape validation
    for (const inv of data.invoices) {
      if (!inv.id || !inv.clientId || typeof inv.amount !== 'number') {
        return { ok: false, error: 'One or more invoices are missing required fields.' };
      }
    }
    for (const c of data.clients) {
      if (!c.id || !c.name) {
        return { ok: false, error: 'One or more clients are missing required fields.' };
      }
    }
    return { ok: true, data };
  } catch (e) {
    return { ok: false, error: 'Could not parse JSON file. Please check the file.' };
  }
}

export function exportData(data: AppData): string {
  return JSON.stringify(data, null, 2);
}

export function paymentsForInvoice(invoiceId: string, payments: Payment[]): Payment[] {
  return payments
    .filter((p) => p.invoiceId === invoiceId)
    .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
}

export function clientOutstanding(clientId: string, invoices: Invoice[]): number {
  return invoices
    .filter((i) => i.clientId === clientId)
    .reduce((sum, i) => sum + Math.max(0, i.amount - i.amountReceived), 0);
}
