export type PaymentMethod = 'Cash' | 'UPI' | 'Bank Transfer' | 'Other';

export type InvoiceStatus = 'Paid' | 'Pending' | 'Overdue';

export interface Client {
  id: string;
  name: string;
  businessName?: string;
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
  createdAt: string;
  isSample?: boolean;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  invoiceDate: string;
  dueDate: string;
  amount: number;
  amountReceived: number;
  notes?: string;
  createdAt: string;
  isSample?: boolean;
}

export interface Payment {
  id: string;
  invoiceId: string;
  paymentDate: string;
  amount: number;
  method: PaymentMethod;
  reference?: string;
  notes?: string;
  createdAt: string;
  isSample?: boolean;
}

export interface Settings {
  businessName: string;
  contactName?: string;
  phone?: string;
  email?: string;
  address?: string;
  currency: string;
  language: 'en' | 'ta';
  gstin?: string;
}

export interface AppData {
  clients: Client[];
  invoices: Invoice[];
  payments: Payment[];
  settings: Settings;
  onboarded: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  businessName: 'My Business',
  currency: 'INR',
  language: 'en',
};

export const emptyData: AppData = {
  clients: [],
  invoices: [],
  payments: [],
  settings: DEFAULT_SETTINGS,
  onboarded: false,
};
