import type { Invoice, Payment } from './types';

function escapeCSV(value: string | number | undefined): string {
  if (value === undefined || value === null) return '';
  const s = String(value);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function invoicesToCSV(
  rows: { invoice: Invoice; clientName: string; outstanding: number; status: string }[]
): string {
  const header = [
    'Invoice Number',
    'Client',
    'Invoice Date',
    'Due Date',
    'Amount',
    'Received',
    'Outstanding',
    'Status',
    'Notes',
  ];
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push(
      [
        escapeCSV(r.invoice.invoiceNumber),
        escapeCSV(r.clientName),
        escapeCSV(r.invoice.invoiceDate),
        escapeCSV(r.invoice.dueDate),
        escapeCSV(r.invoice.amount),
        escapeCSV(r.invoice.amountReceived),
        escapeCSV(r.outstanding),
        escapeCSV(r.status),
        escapeCSV(r.invoice.notes || ''),
      ].join(',')
    );
  }
  return lines.join('\n');
}

export function paymentsToCSV(rows: { payment: Payment; invoiceNumber: string; clientName: string }[]): string {
  const header = [
    'Invoice Number',
    'Client',
    'Payment Date',
    'Amount',
    'Method',
    'Reference',
    'Notes',
  ];
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push(
      [
        escapeCSV(r.invoiceNumber),
        escapeCSV(r.clientName),
        escapeCSV(r.payment.paymentDate),
        escapeCSV(r.payment.amount),
        escapeCSV(r.payment.method),
        escapeCSV(r.payment.reference || ''),
        escapeCSV(r.payment.notes || ''),
      ].join(',')
    );
  }
  return lines.join('\n');
}

export function downloadCSV(filename: string, csv: string): void {
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadJSON(filename: string, text: string): void {
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
