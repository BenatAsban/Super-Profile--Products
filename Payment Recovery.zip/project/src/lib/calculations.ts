import type { Invoice, InvoiceStatus } from './types';
import { daysOverdue } from './format';

export function outstanding(invoice: Invoice): number {
  return Math.max(0, invoice.amount - invoice.amountReceived);
}

export function invoiceStatus(invoice: Invoice): InvoiceStatus {
  const bal = outstanding(invoice);
  if (bal <= 0) return 'Paid';
  if (daysOverdue(invoice.dueDate) > 0) return 'Overdue';
  return 'Pending';
}

export function statusColor(status: InvoiceStatus): {
  text: string;
  bg: string;
  border: string;
  dot: string;
} {
  switch (status) {
    case 'Paid':
      return {
        text: 'text-emerald-700',
        bg: 'bg-emerald-50',
        border: 'border-emerald-200',
        dot: 'bg-emerald-500',
      };
    case 'Overdue':
      return {
        text: 'text-red-700',
        bg: 'bg-red-50',
        border: 'border-red-200',
        dot: 'bg-red-500',
      };
    case 'Pending':
    default:
      return {
        text: 'text-orange-700',
        bg: 'bg-orange-50',
        border: 'border-orange-200',
        dot: 'bg-orange-500',
      };
  }
}

export function nextInvoiceNumber(existing: Invoice[]): string {
  const year = new Date().getFullYear();
  const prefix = `INV-${year}-`;
  const nums = existing
    .map((i) => i.invoiceNumber)
    .filter((n) => n.startsWith(prefix))
    .map((n) => parseInt(n.replace(prefix, ''), 10))
    .filter((n) => !Number.isNaN(n));
  const next = nums.length ? Math.max(...nums) + 1 : 1;
  return `${prefix}${String(next).padStart(3, '0')}`;
}
