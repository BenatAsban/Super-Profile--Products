import { useEffect, useMemo, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Plus,
  Search,
  FileText,
  Eye,
  Pencil,
  Trash2,
  CreditCard,
  MessageCircle,
  X,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import EmptyState from '@/components/ui/EmptyState';
import Badge from '@/components/ui/Badge';
import { Field, Select, TextInput } from '@/components/ui/Field';
import InvoiceForm from '@/components/InvoiceForm';
import PaymentForm from '@/components/PaymentForm';
import { formatCurrency, formatDate, daysOverdue } from '@/lib/format';
import { invoiceStatus, outstanding, statusColor } from '@/lib/calculations';
import { paymentsForInvoice } from '@/lib/storage';
import type { Invoice, InvoiceStatus } from '@/lib/types';

type SortKey = 'dueDate' | 'amount' | 'recent';

export default function InvoicesPage() {
  const { data, addInvoice, updateInvoice, deleteInvoice, addPayment } = useApp();
  const { notify } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Invoice | null>(null);
  const [viewing, setViewing] = useState<Invoice | null>(null);
  const [paying, setPaying] = useState<Invoice | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | InvoiceStatus>('All');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [sortBy, setSortBy] = useState<SortKey>('recent');

  useEffect(() => {
    if (searchParams.get('new') === '1') {
      setShowForm(true);
      setEditing(null);
    }
  }, [searchParams]);

  const clientName = (id: string) => data.clients.find((c) => c.id === id)?.name || 'Unknown';

  const filtered = useMemo(() => {
    let list = [...data.invoices];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (i) =>
          i.invoiceNumber.toLowerCase().includes(q) ||
          clientName(i.clientId).toLowerCase().includes(q)
      );
    }
    if (statusFilter !== 'All') {
      list = list.filter((i) => invoiceStatus(i) === statusFilter);
    }
    if (fromDate) {
      list = list.filter((i) => i.invoiceDate >= fromDate);
    }
    if (toDate) {
      list = list.filter((i) => i.invoiceDate <= toDate);
    }
    list.sort((a, b) => {
      if (sortBy === 'dueDate') return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      if (sortBy === 'amount') return b.amount - a.amount;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    return list;
  }, [data.invoices, data.clients, search, statusFilter, fromDate, toDate, sortBy]);

  const closeForm = () => {
    setShowForm(false);
    setEditing(null);
    if (searchParams.get('new')) {
      searchParams.delete('new');
      setSearchParams(searchParams);
    }
  };

  const handleAddInvoice = (form: {
    invoiceNumber: string;
    clientId: string;
    invoiceDate: string;
    dueDate: string;
    amount: number;
    notes?: string;
  }) => {
    if (editing) {
      updateInvoice(editing.id, form);
      notify('Invoice updated successfully.');
    } else {
      addInvoice(form);
      notify('Invoice created successfully.');
    }
    closeForm();
  };

  const handleAddPayment = (p: {
    paymentDate: string;
    amount: number;
    method: 'Cash' | 'UPI' | 'Bank Transfer' | 'Other';
    reference?: string;
    notes?: string;
  }) => {
    if (!paying) return;
    addPayment({ ...p, invoiceId: paying.id });
    notify(`Payment of ${formatCurrency(p.amount)} recorded.`);
    setPaying(null);
    // refresh viewing if same
    if (viewing && viewing.id === paying.id) {
      setViewing({ ...paying, amountReceived: paying.amountReceived + p.amount });
    }
  };

  if (data.invoices.length === 0 && !showForm) {
    return (
      <EmptyState
        icon={<FileText size={28} />}
        title="No invoices yet"
        description="Create your first invoice to start tracking payments, due dates and outstanding balances."
        action={
          <Button size="lg" onClick={() => setShowForm(true)}>
            <Plus size={18} /> Create Your First Invoice
          </Button>
        }
      />
    );
  }

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <Card className="p-4">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-sm font-semibold text-slate-700">
              {filtered.length} invoice{filtered.length === 1 ? '' : 's'}
            </h2>
            <Button size="sm" onClick={() => { setEditing(null); setShowForm(true); }}>
              <Plus size={16} /> New Invoice
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <TextInput
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search invoice or client…"
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as 'All' | InvoiceStatus)}>
              <option value="All">All statuses</option>
              <option value="Paid">Paid</option>
              <option value="Pending">Pending</option>
              <option value="Overdue">Overdue</option>
            </Select>
            <div className="flex gap-2">
              <TextInput type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} title="From date" />
              <TextInput type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} title="To date" />
            </div>
            <Select value={sortBy} onChange={(e) => setSortBy(e.target.value as SortKey)}>
              <option value="recent">Sort: Most recent</option>
              <option value="dueDate">Sort: Due date</option>
              <option value="amount">Sort: Amount (high to low)</option>
            </Select>
          </div>
          {(search || statusFilter !== 'All' || fromDate || toDate) && (
            <button
              onClick={() => { setSearch(''); setStatusFilter('All'); setFromDate(''); setToDate(''); }}
              className="text-xs text-slate-500 hover:text-slate-700 inline-flex items-center gap-1"
            >
              <X size={12} /> Clear filters
            </button>
          )}
        </div>
      </Card>

      {/* List */}
      {filtered.length === 0 ? (
        <Card className="p-6">
          <p className="text-sm text-slate-400 text-center py-8">No invoices match your filters.</p>
        </Card>
      ) : (
        <Card className="overflow-hidden">
          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left font-medium px-5 py-3">Invoice</th>
                  <th className="text-left font-medium px-5 py-3">Client</th>
                  <th className="text-left font-medium px-5 py-3">Due Date</th>
                  <th className="text-right font-medium px-5 py-3">Amount</th>
                  <th className="text-right font-medium px-5 py-3">Outstanding</th>
                  <th className="text-left font-medium px-5 py-3">Status</th>
                  <th className="text-right font-medium px-5 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((inv) => {
                  const st = invoiceStatus(inv);
                  const sc = statusColor(st);
                  const bal = outstanding(inv);
                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/50">
                      <td className="px-5 py-3">
                        <p className="font-medium text-slate-900">{inv.invoiceNumber}</p>
                        <p className="text-xs text-slate-400">{formatDate(inv.invoiceDate)}</p>
                      </td>
                      <td className="px-5 py-3 text-slate-700">{clientName(inv.clientId)}</td>
                      <td className="px-5 py-3">
                        <p className="text-slate-700">{formatDate(inv.dueDate)}</p>
                        {st === 'Overdue' && (
                          <p className="text-xs text-red-600">{daysOverdue(inv.dueDate)} days overdue</p>
                        )}
                      </td>
                      <td className="px-5 py-3 text-right font-medium text-slate-900">
                        {formatCurrency(inv.amount)}
                      </td>
                      <td className="px-5 py-3 text-right font-medium">
                        <span className={bal > 0 ? 'text-orange-600' : 'text-emerald-600'}>
                          {formatCurrency(bal)}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${sc.bg} ${sc.text} ${sc.border}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${sc.dot}`} />
                          {st}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <IconBtn title="View" onClick={() => setViewing(inv)}>
                            <Eye size={15} />
                          </IconBtn>
                          {bal > 0 && (
                            <IconBtn title="Record payment" onClick={() => setPaying(inv)}>
                              <CreditCard size={15} />
                            </IconBtn>
                          )}
                          <IconBtn title="Edit" onClick={() => { setEditing(inv); setShowForm(true); }}>
                            <Pencil size={15} />
                          </IconBtn>
                          <IconBtn title="Delete" onClick={() => setDeleteId(inv.id)} danger>
                            <Trash2 size={15} />
                          </IconBtn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-slate-100">
            {filtered.map((inv) => {
              const st = invoiceStatus(inv);
              const sc = statusColor(st);
              const bal = outstanding(inv);
              return (
                <div key={inv.id} className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-medium text-slate-900">{inv.invoiceNumber}</p>
                      <p className="text-sm text-slate-500 truncate">{clientName(inv.clientId)}</p>
                    </div>
                    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs font-medium ${sc.bg} ${sc.text} ${sc.border} shrink-0`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${sc.dot}`} />
                      {st}
                    </span>
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <p className="text-slate-400">Amount</p>
                      <p className="font-semibold text-slate-900">{formatCurrency(inv.amount)}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">Outstanding</p>
                      <p className={`font-semibold ${bal > 0 ? 'text-orange-600' : 'text-emerald-600'}`}>
                        {formatCurrency(bal)}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-400">Due</p>
                      <p className="font-medium text-slate-700">{formatDate(inv.dueDate)}</p>
                    </div>
                  </div>
                  <div className="mt-3 flex gap-1">
                    <Button size="sm" variant="outline" onClick={() => setViewing(inv)} className="flex-1">
                      <Eye size={14} /> View
                    </Button>
                    {bal > 0 && (
                      <Button size="sm" variant="outline" onClick={() => setPaying(inv)} className="flex-1">
                        <CreditCard size={14} /> Pay
                      </Button>
                    )}
                    <IconBtn title="Edit" onClick={() => { setEditing(inv); setShowForm(true); }}>
                      <Pencil size={15} />
                    </IconBtn>
                    <IconBtn title="Delete" onClick={() => setDeleteId(inv.id)} danger>
                      <Trash2 size={15} />
                    </IconBtn>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Form modal */}
      <Modal
        open={showForm}
        onClose={closeForm}
        title={editing ? 'Edit Invoice' : 'New Invoice'}
        size="lg"
        footer={
          <>
            <Button variant="outline" onClick={closeForm}>Cancel</Button>
            <Button
              onClick={() => {
                const form = document.getElementById('invoice-form') as HTMLFormElement | null;
                form?.requestSubmit();
              }}
            >
              {editing ? 'Save Changes' : 'Create Invoice'}
            </Button>
          </>
        }
      >
        <InvoiceForm
          clients={data.clients}
          existing={editing}
          onSubmit={handleAddInvoice}
          onCancel={closeForm}
        />
      </Modal>

      {/* View modal */}
      <Modal
        open={!!viewing}
        onClose={() => setViewing(null)}
        title={`Invoice ${viewing?.invoiceNumber || ''}`}
        size="lg"
      >
        {viewing && <InvoiceDetail invoice={viewing} />}
      </Modal>

      {/* Payment modal */}
      <Modal
        open={!!paying}
        onClose={() => setPaying(null)}
        title="Record Payment"
        size="md"
        footer={
          <>
            <Button variant="outline" onClick={() => setPaying(null)}>Cancel</Button>
            <Button
              variant="success"
              onClick={() => {
                const form = document.getElementById('payment-form') as HTMLFormElement | null;
                form?.requestSubmit();
              }}
            >
              Record Payment
            </Button>
          </>
        }
      >
        {paying && (
          <PaymentForm invoice={paying} onSubmit={handleAddPayment} />
        )}
      </Modal>

      {/* Delete confirm */}
      <ConfirmDialog
        open={!!deleteId}
        title="Delete Invoice?"
        message="This will permanently delete the invoice and all its payment history. This cannot be undone."
        confirmLabel="Delete"
        destructive
        onConfirm={() => {
          if (deleteId) {
            deleteInvoice(deleteId);
            notify('Invoice deleted.');
            setDeleteId(null);
          }
        }}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );

  function InvoiceDetail({ invoice }: { invoice: Invoice }) {
    const invPayments = paymentsForInvoice(invoice.id, data.payments);
    const st = invoiceStatus(invoice);
    const sc = statusColor(st);
    const bal = outstanding(invoice);
    const client = data.clients.find((c) => c.id === invoice.clientId);

    return (
      <div className="space-y-5">
        <div className="grid sm:grid-cols-2 gap-4">
          <DetailRow label="Client" value={client?.name || '—'} />
          <DetailRow label="Business" value={client?.businessName || '—'} />
          <DetailRow label="Invoice Date" value={formatDate(invoice.invoiceDate)} />
          <DetailRow label="Due Date" value={formatDate(invoice.dueDate)} />
          <DetailRow label="Invoice Amount" value={formatCurrency(invoice.amount)} />
          <DetailRow label="Amount Received" value={formatCurrency(invoice.amountReceived)} />
          <DetailRow label="Outstanding" value={formatCurrency(bal)} accent={bal > 0 ? 'orange' : 'emerald'} />
          <div>
            <p className="text-xs text-slate-400 mb-1">Status</p>
            <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${sc.bg} ${sc.text} ${sc.border}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${sc.dot}`} />
              {st}
            </span>
          </div>
        </div>

        {invoice.notes && (
          <div>
            <p className="text-xs text-slate-400 mb-1">Notes</p>
            <p className="text-sm text-slate-700 bg-slate-50 rounded-lg p-3">{invoice.notes}</p>
          </div>
        )}

        {/* Payment history */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-semibold text-slate-900">Payment History</p>
            {bal > 0 && (
              <Button size="sm" variant="success" onClick={() => setPaying(invoice)}>
                <CreditCard size={14} /> Add Payment
              </Button>
            )}
          </div>
          {invPayments.length === 0 ? (
            <p className="text-sm text-slate-400 py-4 text-center bg-slate-50 rounded-lg">
              No payments recorded yet.
            </p>
          ) : (
            <div className="space-y-2">
              {invPayments.map((p) => (
                <div key={p.id} className="flex items-center justify-between rounded-lg border border-slate-100 px-4 py-2.5">
                  <div>
                    <p className="text-sm font-medium text-slate-900">{formatCurrency(p.amount)}</p>
                    <p className="text-xs text-slate-400">
                      {formatDate(p.paymentDate)} · {p.method}
                      {p.reference ? ` · ${p.reference}` : ''}
                    </p>
                  </div>
                  <Badge color="emerald">Received</Badge>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reminder shortcut */}
        {bal > 0 && (
          <Link
            to="/app/reminders"
            className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            <MessageCircle size={16} /> Send a payment reminder
          </Link>
        )}
      </div>
    );
  }
}

function DetailRow({ label, value, accent }: { label: string; value: string; accent?: 'orange' | 'emerald' }) {
  const color = accent === 'orange' ? 'text-orange-600' : accent === 'emerald' ? 'text-emerald-600' : 'text-slate-900';
  return (
    <div>
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <p className={`text-sm font-medium ${color}`}>{value}</p>
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  title,
  danger,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  danger?: boolean;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`rounded-lg p-2 transition-colors ${
        danger
          ? 'text-slate-400 hover:bg-red-50 hover:text-red-600'
          : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
      }`}
    >
      {children}
    </button>
  );
}
