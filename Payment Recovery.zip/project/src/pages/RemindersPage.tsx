import { useMemo, useState } from 'react';
import { MessageCircle, Copy, Check, ExternalLink, Phone } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import EmptyState from '@/components/ui/EmptyState';
import Badge from '@/components/ui/Badge';
import { Textarea } from '@/components/ui/Field';
import { formatCurrency, formatDate, daysOverdue, todayISO } from '@/lib/format';
import { invoiceStatus, outstanding } from '@/lib/calculations';
import type { Invoice } from '@/lib/types';

type ReminderType = 'due_today' | 'overdue_7' | 'overdue_30' | 'friendly';

const reminderTypes: { id: ReminderType; label: string; desc: string }[] = [
  { id: 'due_today', label: 'Due Today', desc: 'Polite reminder for payment due today' },
  { id: 'overdue_7', label: 'Overdue 7+ days', desc: 'Firm follow-up after a week' },
  { id: 'overdue_30', label: 'Overdue 30+ days', desc: 'Strong reminder for long overdue' },
  { id: 'friendly', label: 'General Follow-up', desc: 'Soft, friendly check-in' },
];

export default function RemindersPage() {
  const { data } = useApp();
  const { notify } = useToast();
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  const [reminderType, setReminderType] = useState<ReminderType>('friendly');
  const [language, setLanguage] = useState<'en' | 'ta'>('en');
  const [message, setMessage] = useState('');
  const [copied, setCopied] = useState(false);

  const clientName = (id: string) => data.clients.find((c) => c.id === id)?.name || 'Client';
  const clientPhone = (id: string) => data.clients.find((c) => c.id === id)?.phone || '';

  const outstandingInvoices = useMemo(
    () =>
      data.invoices
        .filter((i) => outstanding(i) > 0)
        .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()),
    [data.invoices]
  );

  const selectedInvoice = data.invoices.find((i) => i.id === selectedInvoiceId) as Invoice | undefined;

  const generateMessage = (
    inv: Invoice | undefined,
    type: ReminderType,
    lang: 'en' | 'ta'
  ): string => {
    if (!inv) return '';
    const name = clientName(inv.clientId);
    const invNum = inv.invoiceNumber;
    const bal = formatCurrency(outstanding(inv));
    const due = formatDate(inv.dueDate);
    const business = data.settings.businessName;

    if (lang === 'ta') {
      const base = `வணக்கம் ${name},\n\n${invNum} இன்வாய்ஸ் தொகை ${bal} கட்ட வேண்டியது. கடைசி தேதி ${due}.\n\nகட்டணம் செலுத்த மறந்திருந்தால், இந்த நினைவூட்டல் உதவும் என நம்புகிறேன். ஏதேனும் கேள்வி இருந்தால் தயவு செய்து தொடர்பு கொள்ளவும்.\n\nநன்றி,\n${business}`;
      return base;
    }

    switch (type) {
      case 'due_today':
        return `Hi ${name},\n\nThis is a friendly reminder that invoice ${invNum} for ${bal} is due today (${due}).\n\nWhenever you get a chance to process the payment, it would be much appreciated. Let me know if you need any help or have any questions.\n\nThank you,\n${business}`;
      case 'overdue_7': {
        const days = Math.max(7, daysOverdue(inv.dueDate));
        return `Hi ${name},\n\nI hope you're doing well. Just following up on invoice ${invNum} for ${bal}, which was due on ${due} (about ${days} days ago).\n\nI understand things can get busy — could you please let me know when the payment can be processed? If there's any issue or concern, I'm happy to discuss.\n\nThank you for your attention to this.\nBest regards,\n${business}`;
      }
      case 'overdue_30': {
        const days = Math.max(30, daysOverdue(inv.dueDate));
        return `Dear ${name},\n\nI'm writing regarding invoice ${invNum} for ${bal}, which is now ${days} days past the due date of ${due}.\n\nThis is a significant delay and I would appreciate an update on the payment status at the earliest. If there is a problem I'm not aware of, please let me know so we can resolve it.\n\nI look forward to your prompt response.\n\nRegards,\n${business}`;
      }
      case 'friendly':
      default:
        return `Hi ${name},\n\nI hope everything is going well! Just a gentle reminder about invoice ${invNum} for ${bal} (due ${due}).\n\nNo rush at all — just keeping it on your radar. Feel free to reach out if you have any questions.\n\nThanks,\n${business}`;
    }
  };

  const handleSelectInvoice = (id: string) => {
    setSelectedInvoiceId(id);
    const inv = data.invoices.find((i) => i.id === id);
    if (inv) {
      const days = daysOverdue(inv.dueDate);
      let autoType: ReminderType = 'friendly';
      if (days === 0) autoType = 'due_today';
      else if (days >= 30) autoType = 'overdue_30';
      else if (days >= 7) autoType = 'overdue_7';
      else if (days > 0) autoType = 'overdue_7';
      setReminderType(autoType);
      setMessage(generateMessage(inv, autoType, language));
    }
  };

  const handleTypeChange = (type: ReminderType) => {
    setReminderType(type);
    if (selectedInvoice) setMessage(generateMessage(selectedInvoice, type, language));
  };

  const handleLanguageChange = (lang: 'en' | 'ta') => {
    setLanguage(lang);
    if (selectedInvoice) setMessage(generateMessage(selectedInvoice, reminderType, lang));
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      notify('Message copied to clipboard.');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      notify('Could not copy. Please select and copy manually.', 'error');
    }
  };

  const handleOpenWhatsApp = () => {
    const phone = clientPhone(selectedInvoice?.clientId || '');
    const cleaned = phone.replace(/[^0-9]/g, '');
    const withCountry = cleaned.length === 10 ? `91${cleaned}` : cleaned;
    const url = `https://wa.me/${withCountry}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  if (outstandingInvoices.length === 0) {
    return (
      <EmptyState
        icon={<MessageCircle size={28} />}
        title="No pending payments to remind"
        description="All your invoices are fully paid. When you have outstanding payments, you can generate WhatsApp reminders here."
      />
    );
  }

  return (
    <div className="space-y-5">
      <div className="grid lg:grid-cols-3 gap-5">
        {/* Invoice selector */}
        <Card className="p-4 lg:col-span-1 self-start">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">Select Invoice</h3>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {outstandingInvoices.map((inv) => {
              const st = invoiceStatus(inv);
              const days = daysOverdue(inv.dueDate);
              const isSelected = inv.id === selectedInvoiceId;
              return (
                <button
                  key={inv.id}
                  onClick={() => handleSelectInvoice(inv.id)}
                  className={`w-full text-left rounded-xl border p-3 transition-colors ${
                    isSelected
                      ? 'border-slate-900 bg-slate-50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">{inv.invoiceNumber}</p>
                      <p className="text-xs text-slate-500 truncate">{clientName(inv.clientId)}</p>
                    </div>
                    <p className="text-sm font-semibold text-orange-600 shrink-0">
                      {formatCurrency(outstanding(inv))}
                    </p>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Badge color={st === 'Overdue' ? 'red' : 'orange'}>
                      {st === 'Overdue' ? `${days}d overdue` : `Due ${formatDate(inv.dueDate)}`}
                    </Badge>
                    {clientPhone(inv.clientId) && (
                      <span className="inline-flex items-center gap-1 text-xs text-slate-400">
                        <Phone size={11} /> {clientPhone(inv.clientId)}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </Card>

        {/* Message composer */}
        <div className="lg:col-span-2 space-y-4">
          {!selectedInvoice ? (
            <Card className="p-12">
              <div className="text-center">
                <MessageCircle size={32} className="mx-auto text-slate-300" />
                <p className="mt-3 text-sm text-slate-500">
                  Select an invoice from the left to generate a reminder message.
                </p>
              </div>
            </Card>
          ) : (
            <>
              <Card className="p-4">
                <h3 className="text-sm font-semibold text-slate-700 mb-3">Reminder Type</h3>
                <div className="grid sm:grid-cols-2 gap-2">
                  {reminderTypes.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => handleTypeChange(t.id)}
                      className={`text-left rounded-xl border p-3 transition-colors ${
                        reminderType === t.id
                          ? 'border-slate-900 bg-slate-50'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <p className="text-sm font-medium text-slate-900">{t.label}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{t.desc}</p>
                    </button>
                  ))}
                </div>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => handleLanguageChange('en')}
                    className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                      language === 'en' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    English
                  </button>
                  <button
                    onClick={() => handleLanguageChange('ta')}
                    className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                      language === 'ta' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    தமிழ் (Tamil)
                  </button>
                </div>
              </Card>

              <Card className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-slate-700">Message (editable)</h3>
                  <button
                    onClick={() => selectedInvoice && setMessage(generateMessage(selectedInvoice, reminderType, language))}
                    className="text-xs text-slate-500 hover:text-slate-700"
                  >
                    Reset to template
                  </button>
                </div>
                <Textarea
                  rows={10}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="font-mono text-sm leading-relaxed"
                />
                <div className="mt-3 flex flex-col sm:flex-row gap-2">
                  <Button variant="outline" onClick={handleCopy} className="flex-1">
                    {copied ? <Check size={16} /> : <Copy size={16} />}
                    {copied ? 'Copied!' : 'Copy Message'}
                  </Button>
                  <Button
                    variant="success"
                    onClick={handleOpenWhatsApp}
                    className="flex-1"
                    disabled={!clientPhone(selectedInvoice.clientId)}
                  >
                    <MessageCircle size={16} />
                    Open WhatsApp
                    <ExternalLink size={14} />
                  </Button>
                </div>
                {!clientPhone(selectedInvoice.clientId) && (
                  <p className="mt-2 text-xs text-amber-600">
                    This client has no phone number. Copy the message and send it manually.
                  </p>
                )}
                <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                  Messages are not sent automatically. Review the text, edit if needed, then copy or open WhatsApp to send it yourself.
                </p>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
