import { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { Download, BarChart3, AlertTriangle, Users, CreditCard, FileText } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import EmptyState from '@/components/ui/EmptyState';
import Badge from '@/components/ui/Badge';
import { TextInput } from '@/components/ui/Field';
import { formatCurrency, formatDate, daysOverdue, monthKey, monthLabel } from '@/lib/format';
import { invoiceStatus, outstanding } from '@/lib/calculations';
import { invoicesToCSV, paymentsToCSV, downloadCSV } from '@/lib/csv';

type Tab = 'monthly' | 'outstanding' | 'overdue' | 'clients' | 'payments';

const tabs: { id: Tab; label: string; icon: typeof BarChart3 }[] = [
  { id: 'monthly', label: 'Monthly Summary', icon: BarChart3 },
  { id: 'outstanding', label: 'Outstanding', icon: FileText },
  { id: 'overdue', label: 'Overdue Report', icon: AlertTriangle },
  { id: 'clients', label: 'Client-wise', icon: Users },
  { id: 'payments', label: 'Payment History', icon: CreditCard },
];

export default function ReportsPage() {
  const { data } = useApp();
  const { notify } = useToast();
  const [tab, setTab] = useState<Tab>('monthly');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const clientName = (id: string) => data.clients.find((c) => c.id === id)?.name || 'Unknown';

  const dateInRange = (d: string) => {
    if (fromDate && d < fromDate) return false;
    if (toDate && d > toDate) return false;
    return true;
  };

  const filteredInvoices = useMemo(
    () => data.invoices.filter((i) => dateInRange(i.invoiceDate)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data.invoices, fromDate, toDate]
  );

  const filteredPayments = useMemo(
    () => data.payments.filter((p) => dateInRange(p.paymentDate)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data.payments, fromDate, toDate]
  );

  const monthlyData = useMemo(() => {
    const map = new Map<string, { month: string; invoiced: number; collected: number }>();
    for (const inv of filteredInvoices) {
      const k = monthKey(inv.invoiceDate);
      if (!map.has(k)) map.set(k, { month: monthLabel(k), invoiced: 0, collected: 0 });
      map.get(k)!.invoiced += inv.amount;
    }
    for (const p of filteredPayments) {
      const k = monthKey(p.paymentDate);
      if (!map.has(k)) map.set(k, { month: monthLabel(k), invoiced: 0, collected: 0 });
      map.get(k)!.collected += p.amount;
    }
    return Array.from(map.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([, v]) => v);
  }, [filteredInvoices, filteredPayments]);

  const outstandingRows = useMemo(
    () =>
      filteredInvoices
        .map((inv) => ({
          invoice: inv,
          clientName: clientName(inv.clientId),
          outstanding: outstanding(inv),
          status: invoiceStatus(inv),
        }))
        .filter((r) => r.outstanding > 0)
        .sort((a, b) => new Date(b.invoice.dueDate).getTime() - new Date(a.invoice.dueDate).getTime()),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [filteredInvoices, data.clients]
  );

  const overdueRows = useMemo(
    () =>
      filteredInvoices
        .filter((i) => invoiceStatus(i) === 'Overdue')
        .map((inv) => ({
          invoice: inv,
          clientName: clientName(inv.clientId),
          outstanding: outstanding(inv),
          daysOverdue: daysOverdue(inv.dueDate),
        }))
        .sort((a, b) => b.daysOverdue - a.daysOverdue),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [filteredInvoices, data.clients]
  );

  const clientRows = useMemo(() => {
    const map = new Map<string, { invoiced: number; received: number; outstanding: number }>();
    for (const inv of filteredInvoices) {
      if (!map.has(inv.clientId)) map.set(inv.clientId, { invoiced: 0, received: 0, outstanding: 0 });
      const e = map.get(inv.clientId)!;
      e.invoiced += inv.amount;
      e.received += inv.amountReceived;
      e.outstanding += outstanding(inv);
    }
    return Array.from(map.entries())
      .map(([clientId, v]) => ({
        client: data.clients.find((c) => c.id === clientId),
        ...v,
      }))
      .filter((r) => r.client)
      .sort((a, b) => b.outstanding - a.outstanding) as {
      client: NonNullable<ReturnType<typeof data.clients.find>>;
      invoiced: number;
      received: number;
      outstanding: number;
    }[];
  }, [filteredInvoices, data.clients]);

  const paymentRows = useMemo(
    () =>
      filteredPayments
        .map((p) => {
          const inv = data.invoices.find((i) => i.id === p.invoiceId);
          return {
            payment: p,
            invoiceNumber: inv?.invoiceNumber || '—',
            clientName: inv ? clientName(inv.clientId) : 'Unknown',
          };
        })
        .sort((a, b) => new Date(b.payment.paymentDate).getTime() - new Date(a.payment.paymentDate).getTime()),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [filteredPayments, data.invoices, data.clients]
  );

  const handleExportCSV = () => {
    if (tab === 'monthly') {
      const csv = [
        'Month,Invoiced,Collected',
        ...monthlyData.map((m) => `${m.month},${m.invoiced},${m.collected}`),
      ].join('\n');
      downloadCSV('monthly-summary.csv', csv);
    } else if (tab === 'outstanding') {
      downloadCSV('outstanding-report.csv', invoicesToCSV(outstandingRows));
    } else if (tab === 'overdue') {
      downloadCSV('overdue-report.csv', invoicesToCSV(overdueRows.map((r) => ({
        invoice: r.invoice,
        clientName: r.clientName,
        outstanding: r.outstanding,
        status: 'Overdue',
      }))));
    } else if (tab === 'clients') {
      const csv = [
        'Client,Business,Invoiced,Received,Outstanding',
        ...clientRows.map((r) =>
          `"${r.client.name}","${r.client.businessName || ''}",${r.invoiced},${r.received},${r.outstanding}`
        ),
      ].join('\n');
      downloadCSV('client-wise-report.csv', csv);
    } else if (tab === 'payments') {
      downloadCSV('payment-history.csv', paymentsToCSV(paymentRows));
    }
    notify('CSV exported successfully.');
  };

  if (data.invoices.length === 0 && data.clients.length === 0) {
    return (
      <EmptyState
        icon={<BarChart3 size={28} />}
        title="No data to report yet"
        description="Add clients and invoices to generate reports on your payments, outstanding balances and collections."
      />
    );
  }

  const totalInvoiced = filteredInvoices.reduce((s, i) => s + i.amount, 0);
  const totalCollected = filteredPayments.reduce((s, p) => s + p.amount, 0);
  const totalOutstanding = outstandingRows.reduce((s, r) => s + r.outstanding, 0);

  return (
    <div className="space-y-5">
      {/* Date filter */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-end gap-3">
          <div className="flex-1 grid sm:grid-cols-2 gap-3 w-full">
            <div>
              <label className="block text-xs text-slate-500 mb-1">From date</label>
              <TextInput type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">To date</label>
              <TextInput type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={handleExportCSV}>
            <Download size={15} /> Export CSV
          </Button>
        </div>
        {(fromDate || toDate) && (
          <button
            onClick={() => { setFromDate(''); setToDate(''); }}
            className="mt-2 text-xs text-slate-500 hover:text-slate-700"
          >
            Clear date filter
          </button>
        )}
      </Card>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-4 text-center">
          <p className="text-xs text-slate-400">Invoiced</p>
          <p className="text-lg sm:text-xl font-bold text-slate-900">{formatCurrency(totalInvoiced)}</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-xs text-slate-400">Collected</p>
          <p className="text-lg sm:text-xl font-bold text-emerald-600">{formatCurrency(totalCollected)}</p>
        </Card>
        <Card className="p-4 text-center">
          <p className="text-xs text-slate-400">Outstanding</p>
          <p className="text-lg sm:text-xl font-bold text-orange-600">{formatCurrency(totalOutstanding)}</p>
        </Card>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-medium transition-colors ${
                tab === t.id ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Icon size={15} /> {t.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <Card className="p-5">
        {tab === 'monthly' && (
          <div>
            <h3 className="font-semibold text-slate-900 mb-4">Invoiced vs Collected by Month</h3>
            {monthlyData.length === 0 ? (
              <p className="text-sm text-slate-400 py-12 text-center">No data in the selected range.</p>
            ) : (
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyData} margin={{ left: -8, right: 8, top: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                    <YAxis
                      tick={{ fontSize: 12, fill: '#94a3b8' }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(v) => `₹${v >= 1000 ? `${Math.round(v / 1000)}k` : v}`}
                    />
                    <Tooltip formatter={(v) => formatCurrency(Number(v))} contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 13 }} />
                    <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                    <Bar dataKey="invoiced" fill="#64748b" radius={[4, 4, 0, 0]} name="Invoiced" />
                    <Bar dataKey="collected" fill="#059669" radius={[4, 4, 0, 0]} name="Collected" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        )}

        {tab === 'outstanding' && (
          <ReportTable
            title="Outstanding Balances"
            empty="No outstanding invoices in the selected range."
            rows={outstandingRows.length}
            headers={['Invoice', 'Client', 'Due Date', 'Amount', 'Outstanding', 'Status']}
            render={() =>
              outstandingRows.map((r) => (
                <tr key={r.invoice.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-medium text-slate-900">{r.invoice.invoiceNumber}</td>
                  <td className="px-4 py-3 text-slate-700">{r.clientName}</td>
                  <td className="px-4 py-3 text-slate-700">{formatDate(r.invoice.dueDate)}</td>
                  <td className="px-4 py-3 text-right text-slate-700">{formatCurrency(r.invoice.amount)}</td>
                  <td className="px-4 py-3 text-right font-semibold text-orange-600">{formatCurrency(r.outstanding)}</td>
                  <td className="px-4 py-3"><Badge color={r.status === 'Overdue' ? 'red' : 'orange'}>{r.status}</Badge></td>
                </tr>
              ))
            }
          />
        )}

        {tab === 'overdue' && (
          <ReportTable
            title="Overdue Invoices"
            empty="No overdue invoices in the selected range."
            rows={overdueRows.length}
            headers={['Invoice', 'Client', 'Due Date', 'Days Overdue', 'Outstanding']}
            render={() =>
              overdueRows.map((r) => (
                <tr key={r.invoice.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-medium text-slate-900">{r.invoice.invoiceNumber}</td>
                  <td className="px-4 py-3 text-slate-700">{r.clientName}</td>
                  <td className="px-4 py-3 text-slate-700">{formatDate(r.invoice.dueDate)}</td>
                  <td className="px-4 py-3"><Badge color="red">{r.daysOverdue} days</Badge></td>
                  <td className="px-4 py-3 text-right font-bold text-red-600">{formatCurrency(r.outstanding)}</td>
                </tr>
              ))
            }
          />
        )}

        {tab === 'clients' && (
          <ReportTable
            title="Client-wise Outstanding"
            empty="No client data in the selected range."
            rows={clientRows.length}
            headers={['Client', 'Business', 'Invoiced', 'Received', 'Outstanding']}
            render={() =>
              clientRows.map((r) => (
                <tr key={r.client.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-medium text-slate-900">{r.client.name}</td>
                  <td className="px-4 py-3 text-slate-500">{r.client.businessName || '—'}</td>
                  <td className="px-4 py-3 text-right text-slate-700">{formatCurrency(r.invoiced)}</td>
                  <td className="px-4 py-3 text-right text-emerald-600">{formatCurrency(r.received)}</td>
                  <td className="px-4 py-3 text-right font-semibold text-orange-600">{formatCurrency(r.outstanding)}</td>
                </tr>
              ))
            }
          />
        )}

        {tab === 'payments' && (
          <ReportTable
            title="Payment History"
            empty="No payments in the selected range."
            rows={paymentRows.length}
            headers={['Date', 'Invoice', 'Client', 'Amount', 'Method', 'Reference']}
            render={() =>
              paymentRows.map((r) => (
                <tr key={r.payment.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 text-slate-700">{formatDate(r.payment.paymentDate)}</td>
                  <td className="px-4 py-3 font-medium text-slate-900">{r.invoiceNumber}</td>
                  <td className="px-4 py-3 text-slate-700">{r.clientName}</td>
                  <td className="px-4 py-3 text-right font-semibold text-emerald-600">{formatCurrency(r.payment.amount)}</td>
                  <td className="px-4 py-3"><Badge color="slate">{r.payment.method}</Badge></td>
                  <td className="px-4 py-3 text-slate-500">{r.payment.reference || '—'}</td>
                </tr>
              ))
            }
          />
        )}
      </Card>
    </div>
  );
}

function ReportTable({
  title,
  empty,
  rows,
  headers,
  render,
}: {
  title: string;
  empty: string;
  rows: number;
  headers: string[];
  render: () => React.ReactNode;
}) {
  return (
    <div>
      <h3 className="font-semibold text-slate-900 mb-4">{title}</h3>
      {rows === 0 ? (
        <p className="text-sm text-slate-400 py-12 text-center">{empty}</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                {headers.map((h, i) => (
                  <th key={h} className={`font-medium px-4 py-3 ${i >= headers.length - 3 ? 'text-right' : 'text-left'}`}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">{render()}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}
