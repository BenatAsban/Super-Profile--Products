import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Plus,
  Search,
  Users,
  Pencil,
  Trash2,
  Eye,
  Phone,
  Mail,
  MapPin,
  X,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import EmptyState from '@/components/ui/EmptyState';
import Badge from '@/components/ui/Badge';
import { TextInput } from '@/components/ui/Field';
import ClientForm from '@/components/ClientForm';
import { formatCurrency } from '@/lib/format';
import { clientOutstanding } from '@/lib/storage';
import type { Client } from '@/lib/types';

export default function ClientsPage() {
  const { data, addClient, updateClient, deleteClient } = useApp();
  const { notify } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [viewing, setViewing] = useState<Client | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (searchParams.get('new') === '1') {
      setShowForm(true);
      setEditing(null);
    }
  }, [searchParams]);

  const clientStats = (c: Client) => {
    const invs = data.invoices.filter((i) => i.clientId === c.id);
    const invoiced = invs.reduce((s, i) => s + i.amount, 0);
    const received = invs.reduce((s, i) => s + i.amountReceived, 0);
    const outstanding = clientOutstanding(c.id, data.invoices);
    return { invoiced, received, outstanding, invoiceCount: invs.length };
  };

  const filtered = useMemo(() => {
    let list = [...data.clients];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          (c.businessName || '').toLowerCase().includes(q) ||
          (c.phone || '').includes(q) ||
          (c.email || '').toLowerCase().includes(q)
      );
    }
    return list.sort((a, b) => a.name.localeCompare(b.name));
  }, [data.clients, search]);

  const closeForm = () => {
    setShowForm(false);
    setEditing(null);
    if (searchParams.get('new')) {
      searchParams.delete('new');
      setSearchParams(searchParams);
    }
  };

  const handleSubmit = (form: {
    name: string;
    businessName?: string;
    phone?: string;
    email?: string;
    address?: string;
    notes?: string;
  }) => {
    if (editing) {
      updateClient(editing.id, form);
      notify('Client updated.');
    } else {
      addClient(form);
      notify('Client added.');
    }
    closeForm();
  };

  const handleDelete = () => {
    if (!deleteId) return;
    const hasInvoices = data.invoices.some((i) => i.clientId === deleteId);
    deleteClient(deleteId);
    notify(hasInvoices ? 'Client and linked invoices deleted.' : 'Client deleted.');
    setDeleteId(null);
    if (viewing?.id === deleteId) setViewing(null);
  };

  const deleteClientObj = data.clients.find((c) => c.id === deleteId);
  const deleteHasInvoices = deleteId
    ? data.invoices.some((i) => i.clientId === deleteId)
    : false;

  if (data.clients.length === 0 && !showForm) {
    return (
      <EmptyState
        icon={<Users size={28} />}
        title="No clients yet"
        description="Add your first client to start creating invoices and tracking payments."
        action={
          <Button size="lg" onClick={() => setShowForm(true)}>
            <Plus size={18} /> Add Your First Client
          </Button>
        }
      />
    );
  }

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <Card className="p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <TextInput
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search clients…"
              className="pl-9"
            />
          </div>
          <Button size="sm" onClick={() => { setEditing(null); setShowForm(true); }}>
            <Plus size={16} /> New Client
          </Button>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <Card className="p-6">
          <p className="text-sm text-slate-400 text-center py-8">No clients match your search.</p>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => {
            const stats = clientStats(c);
            return (
              <Card key={c.id} className="p-5 flex flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-900 truncate">{c.name}</p>
                    {c.businessName && (
                      <p className="text-sm text-slate-500 truncate">{c.businessName}</p>
                    )}
                  </div>
                  {c.isSample && <Badge color="blue">Sample</Badge>}
                </div>

                <div className="mt-3 space-y-1 text-xs text-slate-500">
                  {c.phone && (
                    <p className="flex items-center gap-1.5">
                      <Phone size={12} /> {c.phone}
                    </p>
                  )}
                  {c.email && (
                    <p className="flex items-center gap-1.5 truncate">
                      <Mail size={12} /> {c.email}
                    </p>
                  )}
                  {c.address && (
                    <p className="flex items-center gap-1.5 truncate">
                      <MapPin size={12} /> {c.address}
                    </p>
                  )}
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 pt-3 border-t border-slate-100">
                  <div>
                    <p className="text-[10px] text-slate-400">Invoiced</p>
                    <p className="text-sm font-semibold text-slate-900">{formatCurrency(stats.invoiced)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400">Received</p>
                    <p className="text-sm font-semibold text-emerald-600">{formatCurrency(stats.received)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-slate-400">Outstanding</p>
                    <p className={`text-sm font-semibold ${stats.outstanding > 0 ? 'text-orange-600' : 'text-slate-400'}`}>
                      {formatCurrency(stats.outstanding)}
                    </p>
                  </div>
                </div>

                <div className="mt-4 flex gap-1 pt-3 border-t border-slate-100">
                  <Button size="sm" variant="outline" onClick={() => setViewing(c)} className="flex-1">
                    <Eye size={14} /> View
                  </Button>
                  <button
                    title="Edit"
                    onClick={() => { setEditing(c); setShowForm(true); }}
                    className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    title="Delete"
                    onClick={() => setDeleteId(c.id)}
                    className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Form modal */}
      <Modal
        open={showForm}
        onClose={closeForm}
        title={editing ? 'Edit Client' : 'New Client'}
        size="md"
        footer={
          <>
            <Button variant="outline" onClick={closeForm}>Cancel</Button>
            <Button
              onClick={() => {
                const form = document.getElementById('client-form') as HTMLFormElement | null;
                form?.requestSubmit();
              }}
            >
              {editing ? 'Save Changes' : 'Add Client'}
            </Button>
          </>
        }
      >
        <ClientForm existing={editing} onSubmit={handleSubmit} />
      </Modal>

      {/* View modal */}
      <Modal
        open={!!viewing}
        onClose={() => setViewing(null)}
        title={viewing?.name || ''}
        size="md"
      >
        {viewing && <ClientDetail client={viewing} />}
      </Modal>

      {/* Delete confirm */}
      <ConfirmDialog
        open={!!deleteId}
        title="Delete Client?"
        message={
          deleteHasInvoices
            ? `${deleteClientObj?.name} has linked invoices and payments. Deleting will also remove all those invoices and payment records. This cannot be undone.`
            : `Delete ${deleteClientObj?.name}? This cannot be undone.`
        }
        confirmLabel="Delete"
        destructive
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );

  function ClientDetail({ client }: { client: Client }) {
    const stats = clientStats(client);
    const invs = data.invoices
      .filter((i) => i.clientId === client.id)
      .sort((a, b) => new Date(b.invoiceDate).getTime() - new Date(a.invoiceDate).getTime());

    return (
      <div className="space-y-5">
        <div className="grid sm:grid-cols-2 gap-4">
          <DetailItem label="Business" value={client.businessName || '—'} />
          <DetailItem label="Phone" value={client.phone || '—'} />
          <DetailItem label="Email" value={client.email || '—'} />
          <DetailItem label="Address" value={client.address || '—'} />
        </div>

        {client.notes && (
          <div>
            <p className="text-xs text-slate-400 mb-1">Notes</p>
            <p className="text-sm text-slate-700 bg-slate-50 rounded-lg p-3">{client.notes}</p>
          </div>
        )}

        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-xl bg-slate-50 p-3 text-center">
            <p className="text-xs text-slate-400">Invoiced</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.invoiced)}</p>
          </div>
          <div className="rounded-xl bg-emerald-50 p-3 text-center">
            <p className="text-xs text-emerald-600">Received</p>
            <p className="text-lg font-bold text-emerald-700">{formatCurrency(stats.received)}</p>
          </div>
          <div className="rounded-xl bg-orange-50 p-3 text-center">
            <p className="text-xs text-orange-600">Outstanding</p>
            <p className="text-lg font-bold text-orange-700">{formatCurrency(stats.outstanding)}</p>
          </div>
        </div>

        <div>
          <p className="text-sm font-semibold text-slate-900 mb-2">Invoices ({invs.length})</p>
          {invs.length === 0 ? (
            <p className="text-sm text-slate-400 py-3 text-center bg-slate-50 rounded-lg">No invoices yet.</p>
          ) : (
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {invs.map((i) => (
                <div key={i.id} className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2 text-sm">
                  <span className="font-medium text-slate-900">{i.invoiceNumber}</span>
                  <span className="text-slate-500">{formatCurrency(i.amount)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <p className="text-sm text-slate-700">{value}</p>
    </div>
  );
}
