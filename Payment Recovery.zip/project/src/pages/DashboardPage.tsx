import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  IndianRupee,
  TrendingUp,
  Clock,
  AlertTriangle,
  Wallet,
  Plus,
  Users,
  CreditCard,
  ArrowRight,
  Bell,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import Card, { StatCard } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import EmptyState from '@/components/ui/EmptyState';
import Badge from '@/components/ui/Badge';
import { formatCurrency, formatDate, daysOverdue, monthKey, monthLabel, todayISO } from '@/lib/format';
import { invoiceStatus, outstanding, statusColor } from '@/lib/calculations';
import type { Invoice } from '@/lib/types';

export default function DashboardPage() {
  const { data, loadSampleData, setOnboarded } = useApp();
  const { invoices, clients, payments } = data;

  const stats = useMemo(() => {
    const totalInvoiced = invoices.reduce((s, i) => s + i.amount, 0);
    const totalReceived = invoices.reduce((s, i) => s + i.amountReceived, 0);
    const totalPending = invoices
      .filter((i) => invoiceStatus(i) === 'Pending')
      .reduce((s, i) => s + outstanding(i), 0);
    const totalOverdue = invoices
      .filter((i) => invoiceStatus(i) === 'Overdue')
      .reduce((s, i) => s + outstanding(i), 0);

    const now = new Date();
    const ym = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const collectedThisMonth = payments
      .filter((p) => monthKey(p.paymentDate) === ym)
      .reduce((s, p) => s + p.amount, 0);

    return { totalInvoiced, totalReceived, totalPending, totalOverdue, collectedThisMonth };
  }, [invoices, payments]);

  const monthlyData = useMemo(() => {
    const map = new Map<string, { month: string; invoiced: number; collected: number }>();
    // last 6 months
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      map.set(k, { month: monthLabel(k), invoiced: 0, collected: 0 });
    }
    for (const inv of invoices) {
      const k = monthKey(inv.invoiceDate);
      const entry = map.get(k);
      if (entry) entry.invoiced += inv.amount;
    }
    for (const p of payments) {
      const k = monthKey(p.paymentDate);
      const entry = map.get(k);
      if (entry) entry.collected += p.amount;
    }
    return Array.from(map.values());
  }, [invoices, payments]);

  const pieData = useMemo(
    () => [
      { name: 'Received', value: stats.totalReceived, color: '#059669' },
      { name: 'Pending', value: stats.totalPending, color: '#ea580c' },
      { name: 'Overdue', value: stats.totalOverdue, color: '#dc2626' },
    ].filter((d) => d.value > 0),
    [stats]
  );

  const recentInvoices = useMemo(
    () =>
      [...invoices]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5),
    [invoices]
  );

  const overdueInvoices = useMemo(
    () =>
      invoices
        .filter((i) => invoiceStatus(i) === 'Overdue')
        .sort((a, b) => daysOverdue(a.dueDate) - daysOverdue(b.dueDate))
        .slice(0, 5),
    [invoices]
  );

  const topClients = useMemo(() => {
    const map = new Map<string, number>();
    for (const inv of invoices) {
      const bal = outstanding(inv);
      if (bal > 0) map.set(inv.clientId, (map.get(inv.clientId) || 0) + bal);
    }
    return Array.from(map.entries())
      .map(([clientId, bal]) => ({
        client: clients.find((c) => c.id === clientId),
        balance: bal,
      }))
      .filter((x) => x.client)
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 5);
  }, [invoices, clients]);

  const clientName = (id: string) => clients.find((c) => c.id === id)?.name || 'Unknown';

  if (invoices.length === 0 && clients.length === 0) {
    return (
      <EmptyState
        icon={<Wallet size={28} />}
        title="Welcome! Let's track your first payment"
        description="You don't have any clients or invoices yet. Add a client, create an invoice, and start tracking what you're owed."
        action={
          <div className="flex flex-col sm:flex-row gap-2">
            <Link to="/app/invoices?new=1">
              <Button variant="primary" size="lg">
                <Plus size={18} /> Create Your First Invoice
              </Button>
            </Link>
            <Button
              variant="outline"
              size="lg"
              onClick={() => {
                loadSampleData();
              }}
            >
              Load Sample Data to Explore
            </Button>
          </div>
        }
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Onboarding checklist */}
      {!data.onboarded && (
        <OnboardingChecklist
          hasClients={clients.length > 0}
          hasInvoices={invoices.length > 0}
          hasPayments={payments.length > 0}
          onDismiss={() => setOnboarded(true)}
        />
      )}

      {/* Sample data banner */}
      {(invoices.some((i) => i.isSample) || clients.some((c) => c.isSample)) && (
        <div className="rounded-xl bg-blue-50 border border-blue-200 px-4 py-3 text-sm text-blue-800 flex items-center justify-between gap-3">
          <span>You are viewing sample demo data. Remove it anytime from Settings.</span>
          <Link to="/app/settings" className="shrink-0 font-medium underline">
            Go to Settings
          </Link>
        </div>
      )}

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <StatCard
          label="Total Invoiced"
          value={formatCurrency(stats.totalInvoiced)}
          icon={<IndianRupee size={20} />}
          accent="slate"
        />
        <StatCard
          label="Total Received"
          value={formatCurrency(stats.totalReceived)}
          icon={<TrendingUp size={20} />}
          accent="emerald"
        />
        <StatCard
          label="Total Pending"
          value={formatCurrency(stats.totalPending)}
          icon={<Clock size={20} />}
          accent="orange"
        />
        <StatCard
          label="Total Overdue"
          value={formatCurrency(stats.totalOverdue)}
          icon={<AlertTriangle size={20} />}
          accent="red"
        />
        <StatCard
          label="Collected This Month"
          value={formatCurrency(stats.collectedThisMonth)}
          icon={<Wallet size={20} />}
          accent="blue"
          subtitle={formatDate(todayISO())}
        />
      </div>

      {/* Quick actions */}
      <div className="grid sm:grid-cols-3 gap-3">
        <QuickAction to="/app/invoices?new=1" icon={<Plus size={18} />} label="Add Invoice" />
        <QuickAction to="/app/clients?new=1" icon={<Users size={18} />} label="Add Client" />
        <QuickAction to="/app/payments?new=1" icon={<CreditCard size={18} />} label="Record Payment" />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-semibold text-slate-900 mb-1">Monthly Collection</h3>
          <p className="text-xs text-slate-400 mb-4">Invoiced vs collected over the last 6 months</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData} margin={{ left: -10, right: 8, top: 5 }}>
                <defs>
                  <linearGradient id="gradInv" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#64748b" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#64748b" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradCol" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis
                  tick={{ fontSize: 12, fill: '#94a3b8' }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `₹${v >= 1000 ? `${Math.round(v / 1000)}k` : v}`}
                />
                <Tooltip
                  formatter={(v) => formatCurrency(Number(v))}
                  contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 13 }}
                />
                <Area
                  type="monotone"
                  dataKey="invoiced"
                  stroke="#64748b"
                  fill="url(#gradInv)"
                  strokeWidth={2}
                  name="Invoiced"
                />
                <Area
                  type="monotone"
                  dataKey="collected"
                  stroke="#059669"
                  fill="url(#gradCol)"
                  strokeWidth={2}
                  name="Collected"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 mb-1">Paid vs Pending</h3>
          <p className="text-xs text-slate-400 mb-4">Current outstanding split</p>
          <div className="h-64">
            {pieData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-sm text-slate-400">
                No outstanding amounts
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                  >
                    {pieData.map((d) => (
                      <Cell key={d.name} fill={d.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v) => formatCurrency(Number(v))} contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', fontSize: 13 }} />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>
      </div>

      {/* Overdue alerts */}
      {overdueInvoices.length > 0 && (
        <Card className="p-5 border-red-200">
          <div className="flex items-center gap-2 mb-4">
            <Bell size={18} className="text-red-600" />
            <h3 className="font-semibold text-slate-900">Overdue Payment Alerts</h3>
            <Badge color="red">{overdueInvoices.length}</Badge>
          </div>
          <div className="space-y-2">
            {overdueInvoices.map((inv) => (
              <OverdueRow key={inv.id} invoice={inv} clientName={clientName(inv.clientId)} />
            ))}
          </div>
        </Card>
      )}

      {/* Recent invoices & top clients */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900">Recent Invoices</h3>
            <Link to="/app/invoices" className="text-sm text-slate-500 hover:text-slate-700 inline-flex items-center gap-1">
              View all <ArrowRight size={14} />
            </Link>
          </div>
          {recentInvoices.length === 0 ? (
            <p className="text-sm text-slate-400 py-6 text-center">No invoices yet.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentInvoices.map((inv) => {
                const st = invoiceStatus(inv);
                const sc = statusColor(st);
                return (
                  <div key={inv.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 truncate">{inv.invoiceNumber}</p>
                      <p className="text-xs text-slate-500 truncate">{clientName(inv.clientId)}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-semibold text-slate-900">{formatCurrency(inv.amount)}</p>
                      <span className={`inline-flex items-center gap-1 text-xs font-medium ${sc.text}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${sc.dot}`} />
                        {st}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 mb-4">Top Clients by Outstanding</h3>
          {topClients.length === 0 ? (
            <p className="text-sm text-slate-400 py-6 text-center">No outstanding balances.</p>
          ) : (
            <div className="space-y-3">
              {topClients.map(({ client, balance }) => (
                <div key={client!.id} className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 truncate">{client!.name}</p>
                    {client!.businessName && (
                      <p className="text-xs text-slate-500 truncate">{client!.businessName}</p>
                    )}
                  </div>
                  <span className="text-sm font-semibold text-orange-600 shrink-0">
                    {formatCurrency(balance)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function QuickAction({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3.5 hover:border-slate-300 hover:shadow-sm transition-all group"
    >
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-slate-700 group-hover:bg-slate-900 group-hover:text-white transition-colors">
        {icon}
      </div>
      <span className="text-sm font-medium text-slate-700">{label}</span>
      <ArrowRight size={15} className="ml-auto text-slate-300 group-hover:text-slate-500" />
    </Link>
  );
}

function OverdueRow({ invoice, clientName }: { invoice: Invoice; clientName: string }) {
  const days = daysOverdue(invoice.dueDate);
  return (
    <Link
      to="/app/reminders"
      className="flex items-center justify-between gap-3 rounded-xl bg-red-50/50 border border-red-100 px-4 py-3 hover:bg-red-50 transition-colors"
    >
      <div className="min-w-0">
        <p className="text-sm font-medium text-slate-900 truncate">
          {invoice.invoiceNumber} · {clientName}
        </p>
        <p className="text-xs text-red-600">
          {days} day{days === 1 ? '' : 's'} overdue · due {formatDate(invoice.dueDate)}
        </p>
      </div>
      <div className="text-right shrink-0">
        <p className="text-sm font-bold text-red-600">{formatCurrency(outstanding(invoice))}</p>
        <span className="text-xs text-slate-400">Send reminder →</span>
      </div>
    </Link>
  );
}

function OnboardingChecklist({
  hasClients,
  hasInvoices,
  hasPayments,
  onDismiss,
}: {
  hasClients: boolean;
  hasInvoices: boolean;
  hasPayments: boolean;
  onDismiss: () => void;
}) {
  const steps = [
    { label: 'Add your first client', done: hasClients, to: '/app/clients?new=1' },
    { label: 'Create an invoice', done: hasInvoices, to: '/app/invoices?new=1' },
    { label: 'Record a payment', done: hasPayments, to: '/app/payments?new=1' },
    { label: 'Review pending amounts', done: hasInvoices, to: '/app/invoices?filter=pending' },
    { label: 'Send a payment reminder', done: false, to: '/app/reminders' },
  ];
  const completed = steps.filter((s) => s.done).length;
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <h3 className="font-semibold text-slate-900">Getting started</h3>
          <p className="text-sm text-slate-500 mt-0.5">
            {completed} of {steps.length} steps complete
          </p>
        </div>
        <button onClick={onDismiss} className="text-xs text-slate-400 hover:text-slate-600">
          Dismiss
        </button>
      </div>
      <div className="space-y-2">
        {steps.map((s, i) => (
          <Link
            key={i}
            to={s.to}
            className="flex items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-slate-50"
          >
            <span
              className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold ${
                s.done ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-500'
              }`}
            >
              {s.done ? '✓' : i + 1}
            </span>
            <span className={`text-sm ${s.done ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
              {s.label}
            </span>
          </Link>
        ))}
      </div>
    </Card>
  );
}
