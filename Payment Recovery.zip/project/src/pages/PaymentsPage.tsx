import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Search, CreditCard, Trash2, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Modal from '@/components/ui/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import EmptyState from '@/components/ui/EmptyState';
import Badge from '@/components/ui/Badge';
import { Select, TextInput } from '@/components/ui/Field';
import PaymentForm from '@/components/PaymentForm';
import { formatCurrency, formatDate, todayISO, monthKey } from '@/lib/format';
import { outstanding } from '@/lib/calculations';
import type { Invoice, Payment, PaymentMethod } from '@/lib/types';

export default function PaymentsPage() {
  const { data, addPayment, deletePayment } = useApp();
  const { notify } = useToast();
  const [searchParams, setSearchParams] = useSearchParams();

  const [showForm, setShowForm] = useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [methodFilter, setMethodFilter] = useState<'All' | PaymentMethod>('All');
  const [monthFilter, setMonthFilter] = useState('');

  useEffect(() => {
    if (searchParams.get('new') === '1') {
      setShowForm(true);
    }
  }, [searchParams]);

  const invoiceMap = useMemo(() => {
    const m = new Map<string, Invoice>();
    data.invoices.forEach((i) => m.set(i.id, i));
    return m;
  }, [data.invoices]);

  const clientName = (invoiceId: string) => {
    const inv = invoiceMap.get(invoiceId);
    if (!inv) return 'Unknown';
    return data.clients.find((c) => c.id === inv.clientId)?.name || 'Unknown';
  };

  const enrichedPayments = useMemo(
    () =>
      data.payments.map((p) => ({
        payment: p,
        invoice: invoiceMap.get(p.invoiceId),
        clientName: clientName(p.invoiceId),
      })),
    [data.payments, invoiceMap, data.clients]
  );

  const filtered = useMemo(() => {
    let list = [...enrichedPayments];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (x) =>
          (x.invoice?.invoiceNumber || '').toLowerCase().includes(q) ||
          x.clientName.toLowerCase().includes(q) ||
          (x.payment.reference || '').toLowerCase().includes(q)
      );
    }
    if (methodFilter !== 'All') {
      list = list.filter((x) => x.payment.method === methodFilter);
    }
    if (monthFilter) {
      list = list.filter((x) => monthKey(x.payment.paymentDate) === monthFilter);
    }
    return list.sort(
      (a, b) => new Date(b.payment.paymentDate).getTime() - new Date(a.payment.paymentDate).getTime()
    );
  }, [enrichedPayments, search, methodFilter, monthFilter]);

  const totalCollected = filtered.reduce((s, x) => s + x.payment.amount, 0);

  // invoices with outstanding balance for the form selector
  const payableInvoices = useMemo(
    () =>
      data.invoices
        .filter((i) => outstanding(i) > 0)
        .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()),
    [data.invoices]
  );

  const closeForm = () => {
    setShowForm(false);
    setSelectedInvoiceId('');
    if (searchParams.get('new')) {
      searchParams.delete('new');
      setSearchParams(searchParams);
    }
  };

  const selectedInvoice = invoiceMap.get(selectedInvoiceId);

  const handleAddPayment = (p: {
    paymentDate: string;
    amount: number;
    method: PaymentMethod;
    reference?: string;
    notes?: string;
  }) => {
    if (!selectedInvoiceId || !selectedInvoice) return;
    addPayment({ ...p, invoiceId: selectedInvoiceId });
    notify(`Payment of ${formatCurrency(p.amount)} recorded for ${selectedInvoice.invoiceNumber}.`);
    closeForm();
  };

  const handleDelete = () => {
    if (!deleteId) return;
    deletePayment(deleteId);
    notify('Payment deleted. Invoice balance updated.');
    setDeleteId(null);
  };

  if (data.payments.length === 0 && !showForm) {
    return (
      <EmptyState
        icon={<CreditCard size={28} />}
        title="No payments recorded yet"
        description="Record your first payment against an invoice to track what you've received and update outstanding balances."
        action={
          payableInvoices.length > 0 ? (
            <Button size="lg" onClick={() => setShowForm(true)}>
              <Plus size={18} /> Record First Payment
            </Button>
          ) : (
            <Button size="lg" variant="outline" disabled>
              Create an invoice with an outstanding balance first
            </Button>
          )
        }
      />
    );
  }

  return (
    <div className="space-y-5">
      {/* Summary */}
      <Card className="p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500">Total Collected (filtered)</p>
            <p className="text-2xl font-bold text-emerald-600">{formatCurrency(totalCollected)}</p>
          </div>
          <Button size="sm" onClick={() => setShowForm(true)} disabled={payableInvoices.length === 0}>
            <Plus size={16} /> Record Payment
          </Button>
        </div>
      </Card>

      {/* Toolbar */}
      <Card className="p-4">
        <div className="grid sm:grid-cols-3 gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <TextInput
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search invoice, client, ref…"
              className="pl-9"
            />
          </div>
          <Select value={methodFilter} onChange={(e) => setMethodFilter(e.target.value as 'All' | PaymentMethod)}>
            <option value="All">All methods</option>
            <option value="UPI">UPI</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Cash">Cash</option>
            <option value="Other">Other</option>
          </Select>
          <TextInput type="month" value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)} />
        </div>
        {(search || methodFilter !== 'All' || monthFilter) && (
          <button
            onClick={() => { setSearch(''); setMethodFilter('All'); setMonthFilter(''); }}
            className="mt-2 text-xs text-slate-500 hover:text-slate-700 inline-flex items-center gap-1"
          >
            <X size={12} /> Clear filters
          </button>
        )}
      </Card>

      {filtered.length === 0 ? (
        <Card className="p-6">
          <p className="text-sm text-slate-400 text-center py-8">No payments match your filters.</p>
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left font-medium px-5 py-3">Date</th>
                  <th className="text-left font-medium px-5 py-3">Invoice</th>
                  <th className="text-left font-medium px-5 py-3">Client</th>
                  <th className="text-right font-medium px-5 py-3">Amount</th>
                  <th className="text-left font-medium px-5 py-3">Method</th>
                  <th className="text-left font-medium px-5 py-3">Reference</th>
                  <th className="text-right font-medium px-5 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map(({ payment, invoice, clientName }) => (
                  <tr key={payment.id} className="hover:bg-slate-50/50">
                    <td className="px-5 py-3 text-slate-700">{formatDate(payment.paymentDate)}</td>
                    <td className="px-5 py-3 font-medium text-slate-900">{invoice?.invoiceNumber || '—'}</td>
                    <td className="px-5 py-3 text-slate-700">{clientName}</td>
                    <td className="px-5 py-3 text-right font-semibold text-emerald-600">
                      {formatCurrency(payment.amount)}
                    </td>
                    <td className="px-5 py-3">
                      <Badge color="slate">{payment.method}</Badge>
                    </td>
                    <td className="px-5 py-3 text-slate-500">{payment.reference || '—'}</td>
                    <td className="px-5 py-3 text-right">
                      <button
                        title="Delete payment"
                        onClick={() => setDeleteId(payment.id)}
                        className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"
                      >
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile */}
          <div className="md:hidden divide-y divide-slate-100">
            {filtered.map(({ payment, invoice, clientName }) => (
              <div key={payment.id} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-medium text-slate-900">{invoice?.invoiceNumber || '—'}</p>
                    <p className="text-sm text-slate-500 truncate">{clientName}</p>
                  </div>
                  <p className="font-semibold text-emerald-600 shrink-0">{formatCurrency(payment.amount)}</p>
                </div>
                <div className="mt-2 flex items-center gap-2 text-xs text-slate-400">
                  <span>{formatDate(payment.paymentDate)}</span>
                  <span>·</span>
                  <Badge color="slate">{payment.method}</Badge>
                  {payment.reference && <span>· {payment.reference}</span>}
                  <button
                    onClick={() => setDeleteId(payment.id)}
                    className="ml-auto rounded p-1 text-slate-400 hover:text-red-600"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Payment form modal */}
      <Modal
        open={showForm}
        onClose={closeForm}
        title="Record Payment"
        size="md"
        footer={
          <>
            <Button variant="outline" onClick={closeForm}>Cancel</Button>
            <Button
              variant="success"
              onClick={() => {
                const form = document.getElementById('payment-form') as HTMLFormElement | null;
                form?.requestSubmit();
              }}
              disabled={!selectedInvoice}
            >
              Record Payment
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              Select Invoice <span className="text-red-500">*</span>
            </label>
            <Select
              value={selectedInvoiceId}
              onChange={(e) => setSelectedInvoiceId(e.target.value)}
              disabled={!!searchParams.get('new') && payableInvoices.length === 0}
            >
              <option value="">Choose an invoice…</option>
              {payableInvoices.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.invoiceNumber} — {clientName(i.clientId)} · Outstanding {formatCurrency(outstanding(i))}
                </option>
              ))}
            </Select>
            {payableInvoices.length === 0 && (
              <p className="mt-2 text-xs text-slate-400">
                All invoices are fully paid. Create a new invoice with an outstanding balance to record a payment.
              </p>
            )}
          </div>
          {selectedInvoice && (
            <PaymentForm invoice={selectedInvoice} onSubmit={handleAddPayment} />
          )}
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteId}
        title="Delete Payment?"
        message="This will remove the payment and increase the invoice's outstanding balance. This cannot be undone."
        confirmLabel="Delete"
        destructive
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
