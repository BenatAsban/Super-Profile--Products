import { useRef, useState } from 'react';
import {
  Settings as SettingsIcon,
  Download,
  Upload,
  Trash2,
  Database,
  AlertTriangle,
  Sparkles,
  FileSpreadsheet,
  Check,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useToast } from '@/components/ui/Toast';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import { Field, TextInput, Textarea, Select } from '@/components/ui/Field';
import { exportData, importData as parseImport } from '@/lib/storage';
import { downloadJSON, downloadCSV } from '@/lib/csv';
import { invoicesToCSV, paymentsToCSV } from '@/lib/csv';
import { invoiceStatus, outstanding } from '@/lib/calculations';

export default function SettingsPage() {
  const { data, updateSettings, importData, clearAll, removeSampleData, loadSampleData } = useApp();
  const { notify } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmImport, setConfirmImport] = useState<{ text: string; name: string } | null>(null);
  const [confirmSample, setConfirmSample] = useState(false);

  const [businessName, setBusinessName] = useState(data.settings.businessName);
  const [contactName, setContactName] = useState(data.settings.contactName || '');
  const [phone, setPhone] = useState(data.settings.phone || '');
  const [email, setEmail] = useState(data.settings.email || '');
  const [address, setAddress] = useState(data.settings.address || '');
  const [gstin, setGstin] = useState(data.settings.gstin || '');
  const [language, setLanguage] = useState(data.settings.language);

  const hasSample =
    data.clients.some((c) => c.isSample) ||
    data.invoices.some((i) => i.isSample) ||
    data.payments.some((p) => p.isSample);

  const handleSaveSettings = () => {
    updateSettings({
      businessName: businessName.trim() || 'My Business',
      contactName: contactName.trim() || undefined,
      phone: phone.trim() || undefined,
      email: email.trim() || undefined,
      address: address.trim() || undefined,
      gstin: gstin.trim() || undefined,
      language,
    });
    notify('Settings saved.');
  };

  const handleExportJSON = () => {
    downloadJSON('payment-tracker-backup.json', exportData(data));
    notify('Data exported as JSON.');
  };

  const handleExportAllCSV = () => {
    const invRows = data.invoices.map((inv) => ({
      invoice: inv,
      clientName: data.clients.find((c) => c.id === inv.clientId)?.name || 'Unknown',
      outstanding: outstanding(inv),
      status: invoiceStatus(inv),
    }));
    downloadCSV('invoices.csv', invoicesToCSV(invRows));
    const payRows = data.payments.map((p) => ({
      payment: p,
      invoiceNumber: data.invoices.find((i) => i.id === p.invoiceId)?.invoiceNumber || '—',
      clientName: data.clients.find((c) => c.id === data.invoices.find((i) => i.id === p.invoiceId)?.clientId)?.name || 'Unknown',
    }));
    downloadCSV('payments.csv', paymentsToCSV(payRows));
    notify('CSV files downloaded.');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result);
      const result = parseImport(text);
      if (!result.ok || !result.data) {
        notify(result.error || 'Invalid file.', 'error');
        return;
      }
      setConfirmImport({ text, name: file.name });
    };
    reader.onerror = () => notify('Could not read the file.', 'error');
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleConfirmImport = () => {
    if (!confirmImport) return;
    const result = parseImport(confirmImport.text);
    if (result.ok && result.data) {
      importData(result.data);
      notify('Data imported successfully.');
    } else {
      notify('Import failed.', 'error');
    }
    setConfirmImport(null);
  };

  const handleClearAll = () => {
    clearAll();
    notify('All data cleared.');
    setConfirmClear(false);
  };

  const handleRemoveSample = () => {
    removeSampleData();
    notify('Sample data removed.');
    setConfirmSample(false);
  };

  return (
    <div className="space-y-5 max-w-3xl">
      {/* Business profile */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <SettingsIcon size={18} className="text-slate-700" />
          <h3 className="font-semibold text-slate-900">Business Profile</h3>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Business Name" required>
            <TextInput value={businessName} onChange={(e) => setBusinessName(e.target.value)} />
          </Field>
          <Field label="Contact Name">
            <TextInput value={contactName} onChange={(e) => setContactName(e.target.value)} />
          </Field>
          <Field label="Phone">
            <TextInput value={phone} onChange={(e) => setPhone(e.target.value)} />
          </Field>
          <Field label="Email">
            <TextInput type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="GSTIN" hint="Optional">
            <TextInput value={gstin} onChange={(e) => setGstin(e.target.value)} placeholder="29ABCDE1234F1Z5" />
          </Field>
          <Field label="Language">
            <Select value={language} onChange={(e) => setLanguage(e.target.value as 'en' | 'ta')}>
              <option value="en">English</option>
              <option value="ta">தமிழ் (Tamil)</option>
            </Select>
          </Field>
          <div className="sm:col-span-2">
            <Field label="Address">
              <Textarea rows={2} value={address} onChange={(e) => setAddress(e.target.value)} />
            </Field>
          </div>
        </div>
        <div className="mt-4">
          <Button onClick={handleSaveSettings}>
            <Check size={16} /> Save Settings
          </Button>
        </div>
      </Card>

      {/* Demo data */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles size={18} className="text-blue-600" />
          <h3 className="font-semibold text-slate-900">Demo Data</h3>
        </div>
        {hasSample ? (
          <div className="space-y-3">
            <p className="text-sm text-slate-600">
              Sample demo data is currently loaded. You can remove it to keep only your real records.
            </p>
            <Button variant="outline" onClick={() => setConfirmSample(true)}>
              <Trash2 size={15} /> Remove Sample Data
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-slate-600">
              Load sample clients, invoices and payments to explore the dashboard and features.
            </p>
            <Button variant="outline" onClick={() => { loadSampleData(); notify('Sample data loaded.'); }}>
              <Sparkles size={15} /> Load Sample Data
            </Button>
          </div>
        )}
      </Card>

      {/* Data export */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Download size={18} className="text-slate-700" />
          <h3 className="font-semibold text-slate-900">Export Data</h3>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <Button variant="outline" onClick={handleExportJSON}>
            <Database size={15} /> Export JSON Backup
          </Button>
          <Button variant="outline" onClick={handleExportAllCSV}>
            <FileSpreadsheet size={15} /> Export CSV Files
          </Button>
        </div>
        <p className="mt-3 text-xs text-slate-400">
          Use JSON backup to restore all your data later. CSV files are for spreadsheet use.
        </p>
      </Card>

      {/* Data import */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Upload size={18} className="text-slate-700" />
          <h3 className="font-semibold text-slate-900">Import Data</h3>
        </div>
        <p className="text-sm text-slate-600 mb-3">
          Restore a previously exported JSON backup. This will <strong>replace all current data</strong>.
        </p>
        <input ref={fileRef} type="file" accept="application/json,.json" onChange={handleFileChange} className="hidden" />
        <Button variant="outline" onClick={() => fileRef.current?.click()}>
          <Upload size={15} /> Choose JSON File
        </Button>
      </Card>

      {/* Data warning */}
      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
        <div className="flex gap-3">
          <AlertTriangle size={20} className="text-amber-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-amber-900">Important: Local Storage Notice</h4>
            <p className="mt-1 text-sm text-amber-800 leading-relaxed">
              All your data is stored only in this browser's local storage. It is not backed up to the cloud
              and cannot be synced across devices. If you clear your browser data, use private/incognito mode,
              or switch browsers, your records may be lost. Export a JSON backup regularly to keep your data safe.
            </p>
            <p className="mt-2 text-sm font-medium text-amber-900">
              This app tracks payments — it does not collect money and is not professional accounting software.
            </p>
          </div>
        </div>
      </div>

      {/* Danger zone */}
      <Card className="p-5 border-red-200">
        <div className="flex items-center gap-2 mb-2">
          <Trash2 size={18} className="text-red-600" />
          <h3 className="font-semibold text-red-700">Danger Zone</h3>
        </div>
        <p className="text-sm text-slate-600 mb-3">
          Permanently delete all clients, invoices, payments and settings. This cannot be undone.
        </p>
        <Button variant="danger" onClick={() => setConfirmClear(true)}>
          <Trash2 size={15} /> Clear All Data
        </Button>
      </Card>

      {/* Confirm dialogs */}
      <ConfirmDialog
        open={confirmClear}
        title="Clear ALL Data?"
        message="This will permanently delete every client, invoice, payment and setting stored in this browser. There is no undo. Consider exporting a backup first."
        confirmLabel="Yes, Delete Everything"
        destructive
        onConfirm={handleClearAll}
        onCancel={() => setConfirmClear(false)}
      />
      <ConfirmDialog
        open={!!confirmImport}
        title="Replace Current Data?"
        message={`This will replace all your current data with the contents of "${confirmImport?.name}". Your existing records will be lost. Continue?`}
        confirmLabel="Replace Data"
        destructive
        onConfirm={handleConfirmImport}
        onCancel={() => setConfirmImport(null)}
      />
      <ConfirmDialog
        open={confirmSample}
        title="Remove Sample Data?"
        message="This will remove all records labeled as sample data. Your real clients, invoices and payments will remain."
        confirmLabel="Remove Samples"
        destructive
        onConfirm={handleRemoveSample}
        onCancel={() => setConfirmSample(false)}
      />
    </div>
  );
}
