import { Link } from 'react-router-dom';
import {
  Wallet,
  LayoutDashboard,
  FileText,
  Users,
  CreditCard,
  MessageCircle,
  BarChart3,
  Shield,
  ArrowRight,
  TrendingUp,
  Bell,
  IndianRupee,
  Smartphone,
} from 'lucide-react';
import { useState } from 'react';

const benefits = [
  {
    icon: TrendingUp,
    title: 'See exactly who owes you',
    desc: 'A live dashboard of invoiced, received, pending and overdue amounts — no spreadsheets required.',
  },
  {
    icon: Bell,
    title: 'Never miss a due date',
    desc: 'Automatic overdue alerts and ready-to-send WhatsApp reminders in English and Tamil.',
  },
  {
    icon: CreditCard,
    title: 'Record partial payments',
    desc: 'Track every UPI, cash and bank transfer against an invoice with full payment history.',
  },
  {
    icon: Smartphone,
    title: 'Works on your phone',
    desc: 'A responsive, mobile-friendly design built for freelancers on the move.',
  },
];

const features = [
  { icon: LayoutDashboard, title: 'Dashboard', desc: 'Summary cards, charts and overdue alerts.' },
  { icon: FileText, title: 'Invoice management', desc: 'Create, search, filter and track every invoice.' },
  { icon: Users, title: 'Client directory', desc: 'Per-client invoiced, received and outstanding totals.' },
  { icon: CreditCard, title: 'Payment recording', desc: 'Full or partial payments with history per invoice.' },
  { icon: MessageCircle, title: 'WhatsApp reminders', desc: 'Polite, editable reminders with one-tap open.' },
  { icon: BarChart3, title: 'Reports & CSV export', desc: 'Monthly, overdue and client-wise reports.' },
  { icon: Shield, title: 'Your data stays private', desc: 'Stored in your browser. No sign-up, no cloud.' },
];

const steps = [
  { n: '01', title: 'Add your clients', desc: 'Create a client in seconds with name, phone and email.' },
  { n: '02', title: 'Create invoices', desc: 'Generate invoice numbers, set amounts and due dates.' },
  { n: '03', title: 'Record & remind', desc: 'Log payments as they arrive and send WhatsApp follow-ups.' },
];

const faqs = [
  {
    q: 'Does this app collect payments for me?',
    a: 'No. The app helps you track invoices, payments and reminders. It does not process payments or connect to any payment gateway. You still receive money through your usual UPI, bank or cash channels.',
  },
  {
    q: 'Is my data safe?',
    a: 'All your data is stored locally in your browser using LocalStorage. It never leaves your device. Be aware that clearing browser data will remove your records, so use the JSON export feature in Settings to keep backups.',
  },
  {
    q: 'Do I need to create an account?',
    a: 'No account or login is required. Open the app and start tracking right away.',
  },
  {
    q: 'Is this accounting software?',
    a: 'No. This is a simple payment tracking tool for freelancers and small businesses. It is not a replacement for professional accounting software or a chartered accountant.',
  },
  {
    q: 'Can I use this on mobile?',
    a: 'Yes. The interface is fully responsive and works well on phones, tablets and desktops.',
  },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white text-slate-900">
      <Hero />
      <Benefits />
      <Preview />
      <Features />
      <HowItWorks />
      <Pricing />
      <FAQ />
      <FooterCTA />
      <Footer />
    </div>
  );
}

function Hero() {
  return (
    <header className="relative overflow-hidden border-b border-slate-100">
      <div className="absolute inset-0 bg-gradient-to-b from-slate-50 to-white" />
      <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-emerald-100/40 blur-3xl" />
      <div className="absolute -bottom-24 -left-24 h-96 w-96 rounded-full bg-orange-100/40 blur-3xl" />

      <nav className="relative max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-900 text-white">
            <Wallet size={18} />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-bold">Payment Recovery</p>
            <p className="text-[11px] text-slate-400">Tracker India 2026</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link
            to="/app"
            className="hidden sm:inline-flex items-center rounded-xl px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100"
          >
            Try Demo
          </Link>
          <Link
            to="/app"
            className="inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 transition-colors"
          >
            Start Tracking
            <ArrowRight size={15} />
          </Link>
        </div>
      </nav>

      <div className="relative max-w-6xl mx-auto px-5 sm:px-8 pt-12 pb-20 sm:pt-20 sm:pb-28 text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-1.5 text-xs font-medium text-slate-600 shadow-sm">
          <IndianRupee size={13} className="text-emerald-600" />
          Built for Indian freelancers & small businesses
        </span>
        <h1 className="mt-6 text-4xl sm:text-6xl font-bold tracking-tight leading-[1.1] max-w-3xl mx-auto">
          Get paid faster.
          <br />
          <span className="text-slate-400">Stop chasing clients.</span>
        </h1>
        <p className="mt-6 text-lg text-slate-600 max-w-xl mx-auto leading-relaxed">
          A simple payment tracking tool for invoices, pending amounts and WhatsApp
          reminders — built for freelancers, designers, consultants and agencies across India.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            to="/app"
            className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3.5 text-base font-semibold text-white hover:bg-slate-800 transition-colors shadow-lg shadow-slate-900/10"
          >
            Start Tracking Free
            <ArrowRight size={18} />
          </Link>
          <Link
            to="/app"
            className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3.5 text-base font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            Try Demo with Sample Data
          </Link>
        </div>
        <p className="mt-4 text-xs text-slate-400">No sign-up. No API keys. Works in your browser.</p>
      </div>
    </header>
  );
}

function Benefits() {
  return (
    <section className="py-20 sm:py-24 max-w-6xl mx-auto px-5 sm:px-8">
      <div className="grid sm:grid-cols-2 gap-6">
        {benefits.map((b) => {
          const Icon = b.icon;
          return (
            <div
              key={b.title}
              className="rounded-2xl border border-slate-200 p-6 sm:p-7 hover:shadow-md transition-shadow bg-white"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-white">
                <Icon size={20} />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{b.title}</h3>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed">{b.desc}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function Preview() {
  return (
    <section className="py-16 sm:py-20 bg-slate-50 border-y border-slate-100">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">A dashboard that tells you the truth</h2>
          <p className="mt-3 text-slate-600">
            Every number is calculated from your actual invoices and payments — no hardcoding, no faking.
          </p>
        </div>
        <div className="mt-12 rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 shadow-xl shadow-slate-900/5">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {[
              { label: 'Total Invoiced', value: '₹1,83,000', color: 'text-slate-900' },
              { label: 'Total Received', value: '₹89,000', color: 'text-emerald-600' },
              { label: 'Total Pending', value: '₹39,000', color: 'text-orange-600' },
              { label: 'Total Overdue', value: '₹74,000', color: 'text-red-600' },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-slate-100 p-4 bg-slate-50/50">
                <p className="text-xs text-slate-500">{s.label}</p>
                <p className={`mt-1.5 text-xl sm:text-2xl font-bold ${s.color}`}>{s.value}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 h-48 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-100 flex items-center justify-center">
            <p className="text-sm text-slate-400">Monthly collection chart appears here with your real data</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Features() {
  return (
    <section className="py-20 sm:py-24 max-w-6xl mx-auto px-5 sm:px-8">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Everything you need to follow up on payments</h2>
        <p className="mt-3 text-slate-600">A complete toolkit — no spreadsheets, no paid services, no complications.</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {features.map((f) => {
          const Icon = f.icon;
          return (
            <div key={f.title} className="rounded-2xl border border-slate-200 p-5 hover:border-slate-300 transition-colors">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-700">
                <Icon size={18} />
              </div>
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">{f.desc}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function HowItWorks() {
  return (
    <section className="py-16 sm:py-20 bg-slate-50 border-y border-slate-100">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Get started in three steps</h2>
        </div>
        <div className="grid sm:grid-cols-3 gap-6">
          {steps.map((s) => (
            <div key={s.n} className="relative rounded-2xl bg-white border border-slate-200 p-6">
              <span className="text-4xl font-bold text-slate-200">{s.n}</span>
              <h3 className="mt-2 text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section className="py-20 sm:py-24 max-w-3xl mx-auto px-5 sm:px-8 text-center">
      <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Simple one-time pricing</h2>
      <p className="mt-3 text-slate-600">No subscriptions. No hidden fees. Use it forever.</p>
      <div className="mt-12 inline-block rounded-3xl border-2 border-slate-900 bg-white p-8 sm:p-10 shadow-xl">
        <div className="flex items-center justify-center gap-3">
          <span className="text-lg text-slate-400 line-through">₹299</span>
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
            Launch offer
          </span>
        </div>
        <div className="mt-3 flex items-start justify-center">
          <IndianRupee size={32} className="mt-2 text-slate-900" />
          <span className="text-6xl font-bold tracking-tight">199</span>
        </div>
        <p className="mt-2 text-sm text-slate-500">one-time · lifetime access</p>
        <Link
          to="/app"
          className="mt-8 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-8 py-3.5 text-base font-semibold text-white hover:bg-slate-800 transition-colors"
        >
          Start Tracking Free
          <ArrowRight size={18} />
        </Link>
        <p className="mt-4 text-xs text-slate-400">Try the full app free with sample data.</p>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="py-20 sm:py-24 max-w-3xl mx-auto px-5 sm:px-8">
      <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-center">Frequently asked questions</h2>
      <div className="mt-10 space-y-3">
        {faqs.map((f, i) => (
          <div key={i} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full flex items-center justify-between px-5 py-4 text-left"
            >
              <span className="text-sm font-semibold text-slate-900">{f.q}</span>
              <span className={`text-slate-400 transition-transform ${open === i ? 'rotate-45' : ''}`}>
                +
              </span>
            </button>
            {open === i && (
              <p className="px-5 pb-4 text-sm text-slate-600 leading-relaxed">{f.a}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

function FooterCTA() {
  return (
    <section className="px-5 sm:px-8 pb-20">
      <div className="max-w-6xl mx-auto rounded-3xl bg-slate-900 px-6 py-14 sm:px-12 sm:py-16 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
          Stop wondering who owes you money
        </h2>
        <p className="mt-3 text-slate-300 max-w-lg mx-auto">
          Open the app, add a client, create your first invoice and send a reminder — all in under five minutes.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            to="/app"
            className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-base font-semibold text-slate-900 hover:bg-slate-100 transition-colors"
          >
            Start Tracking
            <ArrowRight size={18} />
          </Link>
          <Link
            to="/app"
            className="inline-flex items-center gap-2 rounded-xl border border-slate-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-slate-800 transition-colors"
          >
            Load Sample Data
          </Link>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-slate-100 py-10">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-900 text-white">
            <Wallet size={16} />
          </div>
          <span className="text-sm font-semibold">Payment Recovery Tracker India 2026</span>
        </div>
        <p className="text-xs text-slate-400 max-w-md text-center sm:text-right">
          This app tracks payments but does not itself collect money or replace professional accounting software.
        </p>
      </div>
    </footer>
  );
}