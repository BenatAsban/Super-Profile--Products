import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { AppData, Client, Invoice, Payment, Settings } from '@/lib/types';
import { DEFAULT_SETTINGS, emptyData } from '@/lib/types';
import { loadData, saveData, clearData } from '@/lib/storage';
import { generateSampleData } from '@/lib/sampleData';

interface AppContextValue {
  data: AppData;
  addClient: (c: Omit<Client, 'id' | 'createdAt'>) => Client;
  updateClient: (id: string, patch: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  addInvoice: (i: Omit<Invoice, 'id' | 'createdAt' | 'amountReceived'> & { amountReceived?: number }) => Invoice;
  updateInvoice: (id: string, patch: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  addPayment: (p: Omit<Payment, 'id' | 'createdAt'>) => Payment;
  deletePayment: (id: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  loadSampleData: () => void;
  removeSampleData: () => void;
  clearAll: () => void;
  importData: (imported: AppData) => void;
  setOnboarded: (v: boolean) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => loadData());

  useEffect(() => {
    saveData(data);
  }, [data]);

  const value = useMemo<AppContextValue>(() => {
    const addClient: AppContextValue['addClient'] = (c) => {
      const client: Client = {
        ...c,
        id: 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        createdAt: new Date().toISOString(),
      };
      setData((d) => ({ ...d, clients: [...d.clients, client] }));
      return client;
    };

    const updateClient: AppContextValue['updateClient'] = (id, patch) => {
      setData((d) => ({
        ...d,
        clients: d.clients.map((c) => (c.id === id ? { ...c, ...patch } : c)),
      }));
    };

    const deleteClient: AppContextValue['deleteClient'] = (id) => {
      setData((d) => ({
        ...d,
        clients: d.clients.filter((c) => c.id !== id),
        // cascade delete
        invoices: d.invoices.filter((i) => i.clientId !== id),
        payments: d.payments.filter((p) => {
          const inv = d.invoices.find((i) => i.id === p.invoiceId);
          return inv && inv.clientId !== id;
        }),
      }));
    };

    const addInvoice: AppContextValue['addInvoice'] = (i) => {
      const invoice: Invoice = {
        ...i,
        amountReceived: i.amountReceived ?? 0,
        id: 'i_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        createdAt: new Date().toISOString(),
      };
      setData((d) => ({ ...d, invoices: [...d.invoices, invoice] }));
      return invoice;
    };

    const updateInvoice: AppContextValue['updateInvoice'] = (id, patch) => {
      setData((d) => ({
        ...d,
        invoices: d.invoices.map((i) => (i.id === id ? { ...i, ...patch } : i)),
      }));
    };

    const deleteInvoice: AppContextValue['deleteInvoice'] = (id) => {
      setData((d) => ({
        ...d,
        invoices: d.invoices.filter((i) => i.id !== id),
        payments: d.payments.filter((p) => p.invoiceId !== id),
      }));
    };

    const addPayment: AppContextValue['addPayment'] = (p) => {
      const payment: Payment = {
        ...p,
        id: 'p_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        createdAt: new Date().toISOString(),
      };
      setData((d) => ({
        ...d,
        payments: [...d.payments, payment],
        invoices: d.invoices.map((i) =>
          i.id === p.invoiceId
            ? { ...i, amountReceived: i.amountReceived + p.amount }
            : i
        ),
      }));
      return payment;
    };

    const deletePayment: AppContextValue['deletePayment'] = (id) => {
      setData((d) => {
        const payment = d.payments.find((p) => p.id === id);
        if (!payment) return d;
        return {
          ...d,
          payments: d.payments.filter((p) => p.id !== id),
          invoices: d.invoices.map((i) =>
            i.id === payment.invoiceId
              ? { ...i, amountReceived: Math.max(0, i.amountReceived - payment.amount) }
              : i
          ),
        };
      });
    };

    const updateSettings: AppContextValue['updateSettings'] = (patch) => {
      setData((d) => ({ ...d, settings: { ...d.settings, ...patch } }));
    };

    const loadSampleData: AppContextValue['loadSampleData'] = () => {
      setData(generateSampleData());
    };

    const removeSampleData: AppContextValue['removeSampleData'] = () => {
      setData((d) => ({
        ...d,
        clients: d.clients.filter((c) => !c.isSample),
        invoices: d.invoices.filter((i) => !i.isSample),
        payments: d.payments.filter((p) => !p.isSample),
      }));
    };

    const clearAll: AppContextValue['clearAll'] = () => {
      clearData();
      setData({ ...emptyData, settings: DEFAULT_SETTINGS });
    };

    const importData: AppContextValue['importData'] = (imported) => {
      setData(imported);
    };

    const setOnboarded: AppContextValue['setOnboarded'] = (v) => {
      setData((d) => ({ ...d, onboarded: v }));
    };

    return {
      data,
      addClient,
      updateClient,
      deleteClient,
      addInvoice,
      updateInvoice,
      deleteInvoice,
      addPayment,
      deletePayment,
      updateSettings,
      loadSampleData,
      removeSampleData,
      clearAll,
      importData,
      setOnboarded,
    };
  }, [data]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
