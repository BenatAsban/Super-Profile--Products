import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from '@/context/AppContext';
import { ToastProvider } from '@/components/ui/Toast';
import AppLayout from '@/components/AppLayout';
import LandingPage from '@/pages/LandingPage';
import DashboardPage from '@/pages/DashboardPage';
import InvoicesPage from '@/pages/InvoicesPage';
import ClientsPage from '@/pages/ClientsPage';
import PaymentsPage from '@/pages/PaymentsPage';
import RemindersPage from '@/pages/RemindersPage';
import ReportsPage from '@/pages/ReportsPage';
import SettingsPage from '@/pages/SettingsPage';

export default function App() {
  return (
    <ToastProvider>
      <AppProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route
              path="/app"
              element={
                <AppLayout>
                  <DashboardPage />
                </AppLayout>
              }
            />
            <Route
              path="/app/invoices"
              element={
                <AppLayout>
                  <InvoicesPage />
                </AppLayout>
              }
            />
            <Route
              path="/app/clients"
              element={
                <AppLayout>
                  <ClientsPage />
                </AppLayout>
              }
            />
            <Route
              path="/app/payments"
              element={
                <AppLayout>
                  <PaymentsPage />
                </AppLayout>
              }
            />
            <Route
              path="/app/reminders"
              element={
                <AppLayout>
                  <RemindersPage />
                </AppLayout>
              }
            />
            <Route
              path="/app/reports"
              element={
                <AppLayout>
                  <ReportsPage />
                </AppLayout>
              }
            />
            <Route
              path="/app/settings"
              element={
                <AppLayout>
                  <SettingsPage />
                </AppLayout>
              }
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AppProvider>
    </ToastProvider>
  );
}
