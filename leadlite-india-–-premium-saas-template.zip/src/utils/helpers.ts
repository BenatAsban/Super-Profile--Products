import { Lead, LeadStatus, UserSettings } from '../types';

/**
 * Clean and format Indian phone number for wa.me links
 * Handles 10-digit numbers, numbers with +91, spaces, dashes
 */
export const formatPhoneForWhatsApp = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) {
    return `91${digits}`;
  }
  if (digits.length === 12 && digits.startsWith('91')) {
    return digits;
  }
  return digits;
};

/**
 * Builds a direct standard WhatsApp Click-to-Chat URL
 * Note: Uses wa.me link directly without third-party API dependencies
 */
export const buildWhatsAppLink = (phone: string, message: string): string => {
  const cleanPhone = formatPhoneForWhatsApp(phone);
  const encodedMsg = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encodedMsg}`;
};

/**
 * Generate standard Indian business follow-up message templates
 */
export const getWhatsAppTemplates = (lead: Lead, settings: UserSettings) => {
  const bizName = settings.businessName || 'our team';

  return [
    {
      id: 'initial-greeting',
      title: 'Namaste & Inquiry Greeting',
      message: `Namaste ${lead.name}, thank you for reaching out to ${bizName} regarding "${lead.businessInterest}". I would love to understand your requirements in detail. Would today or tomorrow be a convenient time for a quick 5-minute call?`,
    },
    {
      id: 'friendly-followup',
      title: 'Gentle Follow-up Check',
      message: `Hi ${lead.name}, this is following up on our earlier discussion regarding "${lead.businessInterest}". Just checking in to see if you have had time to review the details or if you have any questions for us at ${bizName}? Happy to help!`,
    },
    {
      id: 'quote-shared',
      title: 'Quotation Follow-up',
      message: `Namaste ${lead.name}, hope you are doing well! Have you had a chance to look over the quotation we prepared for "${lead.businessInterest}"? Please let me know if you would like any adjustments to the scope or pricing.`,
    },
    {
      id: 'meeting-confirmation',
      title: 'Appointment Confirmation',
      message: `Namaste ${lead.name}, confirming our scheduled discussion regarding "${lead.businessInterest}". Looking forward to speaking with you. Please feel free to message here if you need to reschedule.`,
    },
  ];
};

/**
 * Format Indian Rupee currency (e.g. ₹4,85,000)
 */
export const formatINR = (value: number | undefined | null): string => {
  if (value === undefined || value === null || isNaN(value)) return '₹0';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(value);
};

/**
 * Friendly relative date label (Overdue, Today, Tomorrow, etc.)
 */
export const getFollowUpUrgency = (
  dateStr: string
): { label: string; status: 'overdue' | 'today' | 'upcoming' | 'none'; daysDiff: number } => {
  if (!dateStr) return { label: 'No date', status: 'none', daysDiff: 0 };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const target = new Date(dateStr);
  target.setHours(0, 0, 0, 0);

  const diffTime = target.getTime() - today.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    const overdueDays = Math.abs(diffDays);
    return {
      label: overdueDays === 1 ? '1 day overdue' : `${overdueDays} days overdue`,
      status: 'overdue',
      daysDiff: diffDays,
    };
  } else if (diffDays === 0) {
    return { label: 'Due today', status: 'today', daysDiff: 0 };
  } else if (diffDays === 1) {
    return { label: 'Due tomorrow', status: 'upcoming', daysDiff: 1 };
  } else {
    return {
      label: `In ${diffDays} days (${dateStr})`,
      status: 'upcoming',
      daysDiff: diffDays,
    };
  }
};

/**
 * Formats a date string nicely (e.g. 15 Nov 2026)
 */
export const formatDateNice = (dateStr: string): string => {
  if (!dateStr) return '-';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

/**
 * Lead status badge color tokens
 */
export const getStatusStyle = (status: LeadStatus) => {
  switch (status) {
    case 'New':
      return {
        bg: 'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800',
        dot: 'bg-sky-500',
      };
    case 'Contacted':
      return {
        bg: 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800',
        dot: 'bg-indigo-500',
      };
    case 'Interested':
      return {
        bg: 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
        dot: 'bg-amber-500',
      };
    case 'Follow-up':
      return {
        bg: 'bg-orange-50 dark:bg-orange-950/40 text-orange-700 dark:text-orange-300 border border-orange-200 dark:border-orange-800',
        dot: 'bg-orange-500',
      };
    case 'Converted':
      return {
        bg: 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
        dot: 'bg-emerald-500',
      };
    case 'Not Interested':
      return {
        bg: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700',
        dot: 'bg-slate-400',
      };
  }
};

/**
 * Export Leads to CSV file
 */
export const exportLeadsToCSV = (leads: Lead[], businessName: string) => {
  const headers = [
    'ID',
    'Customer Name',
    'Phone',
    'Email',
    'City',
    'Service / Interest',
    'Source',
    'Status',
    'Estimated Value (INR)',
    'Next Follow-up Date',
    'Created Date',
    'Notes Summary',
  ];

  const escapeCSV = (str: string | number | undefined | null) => {
    if (str === undefined || str === null) return '""';
    const s = String(str).replace(/"/g, '""');
    return `"${s}"`;
  };

  const rows = leads.map((lead) => {
    const notesSummary = lead.notes.map((n) => `[${n.timestamp}] ${n.text}`).join(' | ');
    return [
      escapeCSV(lead.id),
      escapeCSV(lead.name),
      escapeCSV(lead.phone),
      escapeCSV(lead.email || ''),
      escapeCSV(lead.city || ''),
      escapeCSV(lead.businessInterest),
      escapeCSV(lead.source),
      escapeCSV(lead.status),
      lead.estimatedValue || 0,
      escapeCSV(lead.nextFollowUpDate),
      escapeCSV(lead.createdAt),
      escapeCSV(notesSummary),
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const cleanName = (businessName || 'LeadLite').toLowerCase().replace(/[^a-z0-9]/g, '_');
  link.setAttribute('href', url);
  link.setAttribute('download', `${cleanName}_leads_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

/**
 * Export complete application data to JSON backup
 */
export const exportBackupJSON = (data: {
  leads: Lead[];
  appointments: any[];
  quotations: any[];
  settings: UserSettings;
}) => {
  const backup = {
    app: 'LeadLite India',
    version: '1.0.0',
    exportTimestamp: new Date().toISOString(),
    ...data,
  };

  const jsonStr = JSON.stringify(backup, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute(
    'download',
    `leadlite_backup_${new Date().toISOString().split('T')[0]}.json`
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
