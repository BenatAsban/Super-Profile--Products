import React, { useState } from 'react';
import {
  Clock,
  AlertCircle,
  Calendar,
  CheckCircle2,
  MessageSquare,
  ChevronRight,
  Phone,
  Sparkles,
  Plus,
  ArrowRight,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { Lead } from '../types';
import {
  formatINR,
  formatDateNice,
  getStatusStyle,
  getFollowUpUrgency,
} from '../utils/helpers';

export const FollowupsPage: React.FC = () => {
  const {
    leads,
    updateFollowUpDate,
    markFollowUpComplete,
    setSelectedLead,
    setWhatsAppModalLead,
    addLeadNote,
  } = useLeadLite();

  const [activeTab, setActiveTab] = useState<'all' | 'today' | 'overdue' | 'upcoming'>('all');
  const [completeModalLead, setCompleteModalLead] = useState<Lead | null>(null);
  const [completeNote, setCompleteNote] = useState('');
  const [nextScheduledDate, setNextScheduledDate] = useState('');
  const [rescheduleLeadId, setRescheduleLeadId] = useState<string | null>(null);
  const [quickDate, setQuickDate] = useState('');

  // Classify follow-ups
  const activeFollowups = leads.filter(
    (l) => l.status !== 'Converted' && l.status !== 'Not Interested' && l.nextFollowUpDate
  );

  const overdueLeads = activeFollowups.filter(
    (l) => getFollowUpUrgency(l.nextFollowUpDate).status === 'overdue'
  );
  const todayLeads = activeFollowups.filter(
    (l) => getFollowUpUrgency(l.nextFollowUpDate).status === 'today'
  );
  const upcomingLeads = activeFollowups.filter(
    (l) => getFollowUpUrgency(l.nextFollowUpDate).status === 'upcoming'
  );

  const currentDisplayLeads =
    activeTab === 'overdue'
      ? overdueLeads
      : activeTab === 'today'
      ? todayLeads
      : activeTab === 'upcoming'
      ? upcomingLeads
      : [...overdueLeads, ...todayLeads, ...upcomingLeads];

  const handleMarkCompleteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!completeModalLead) return;

    markFollowUpComplete(
      completeModalLead.id,
      completeNote.trim() || 'Follow-up marked as completed',
      nextScheduledDate || undefined
    );
    setCompleteModalLead(null);
    setCompleteNote('');
    setNextScheduledDate('');
  };

  const handleQuickPostpone = (leadId: string, days: number) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    const dateStr = d.toISOString().split('T')[0];
    updateFollowUpDate(leadId, dateStr, `Postponed by ${days} days`);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Daily Follow-up Pipeline
          </h2>
          <p className="text-xs text-slate-500">
            Review customers awaiting response, schedule reminders, and connect via WhatsApp
          </p>
        </div>
      </div>

      {/* Segmented Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'all'
              ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-2xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          All Actionable ({activeFollowups.length})
        </button>

        <button
          onClick={() => setActiveTab('overdue')}
          className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'overdue'
              ? 'bg-rose-600 text-white shadow-2xs'
              : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
          }`}
        >
          <span>Overdue</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-200">
            {overdueLeads.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('today')}
          className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'today'
              ? 'bg-amber-600 text-white shadow-2xs'
              : 'text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40'
          }`}
        >
          <span>Due Today</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200">
            {todayLeads.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('upcoming')}
          className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'upcoming'
              ? 'bg-indigo-600 text-white shadow-2xs'
              : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40'
          }`}
        >
          <span>Upcoming Schedule</span>
          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-200">
            {upcomingLeads.length}
          </span>
        </button>
      </div>

      {/* Follow-ups List */}
      {currentDisplayLeads.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
          <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            All caught up in this bucket!
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            No pending follow-ups found for the selected view. Keep providing exceptional response times!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {currentDisplayLeads.map((lead) => {
            const urgency = getFollowUpUrgency(lead.nextFollowUpDate);
            const statusStyle = getStatusStyle(lead.status);

            return (
              <div
                key={lead.id}
                className={`p-5 rounded-2xl bg-white dark:bg-slate-900 border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  urgency.status === 'overdue'
                    ? 'border-rose-200 dark:border-rose-900/50 hover:border-rose-300'
                    : urgency.status === 'today'
                    ? 'border-amber-200 dark:border-amber-900/50 hover:border-amber-300'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                {/* Left: Lead Identity */}
                <div className="space-y-1.5 max-w-lg">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded ${
                        urgency.status === 'overdue'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                          : urgency.status === 'today'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {urgency.label}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-500">{lead.source}</span>
                    {lead.city && (
                      <>
                        <span className="text-xs text-slate-400">·</span>
                        <span className="text-xs text-slate-500">{lead.city}</span>
                      </>
                    )}
                  </div>

                  <h3
                    onClick={() => setSelectedLead(lead)}
                    className="text-base font-bold text-slate-900 dark:text-slate-100 hover:text-indigo-600 cursor-pointer"
                  >
                    {lead.name}
                  </h3>

                  <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400">
                    {lead.businessInterest}
                  </p>

                  {/* Latest Note preview */}
                  {lead.notes.length > 0 && (
                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 text-xs text-slate-600 dark:text-slate-400 border border-slate-100 dark:border-slate-800">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 mr-1.5">
                        Last Note:
                      </span>
                      {lead.notes[0].text}
                    </div>
                  )}
                </div>

                {/* Right: Actions & Reschedule */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 shrink-0">
                  {/* Estimated deal value */}
                  <div className="text-right sm:pr-4 sm:border-r border-slate-200 dark:border-slate-800">
                    <span className="text-[11px] text-slate-400 block">Est. Deal Value</span>
                    <span className="text-sm font-bold tabular-nums text-slate-900 dark:text-slate-100">
                      {formatINR(lead.estimatedValue)}
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2">
                    {/* WhatsApp Action */}
                    <button
                      onClick={() => setWhatsAppModalLead(lead)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors shadow-2xs"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </button>

                    {/* Mark Done / Reschedule */}
                    <button
                      onClick={() => setCompleteModalLead(lead)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Mark Done</span>
                    </button>

                    {/* Postpone menu */}
                    <div className="relative">
                      {rescheduleLeadId === lead.id ? (
                        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                          <button
                            onClick={() => {
                              handleQuickPostpone(lead.id, 1);
                              setRescheduleLeadId(null);
                            }}
                            className="px-2 py-1 text-[11px] font-medium bg-white dark:bg-slate-900 rounded-md"
                          >
                            +1d
                          </button>
                          <button
                            onClick={() => {
                              handleQuickPostpone(lead.id, 3);
                              setRescheduleLeadId(null);
                            }}
                            className="px-2 py-1 text-[11px] font-medium bg-white dark:bg-slate-900 rounded-md"
                          >
                            +3d
                          </button>
                          <button
                            onClick={() => {
                              handleQuickPostpone(lead.id, 7);
                              setRescheduleLeadId(null);
                            }}
                            className="px-2 py-1 text-[11px] font-medium bg-white dark:bg-slate-900 rounded-md"
                          >
                            +1w
                          </button>
                          <button
                            onClick={() => setRescheduleLeadId(null)}
                            className="px-1 text-slate-400"
                          >
                            &times;
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setRescheduleLeadId(lead.id)}
                          className="px-2.5 py-2 text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          Postpone
                        </button>
                      )}
                    </div>

                    <button
                      onClick={() => setSelectedLead(lead)}
                      className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                      title="Open full lead records"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Mark Completed Modal */}
      {completeModalLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                Complete Follow-up: {completeModalLead.name}
              </h3>
              <button
                onClick={() => setCompleteModalLead(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleMarkCompleteSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Outcome / Call Notes (Optional)
                </label>
                <textarea
                  rows={3}
                  value={completeNote}
                  onChange={(e) => setCompleteNote(e.target.value)}
                  placeholder="e.g. Spoke on phone. Customer requested quotation by tomorrow evening..."
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Schedule Next Follow-up (Leave blank if closed or none)
                </label>
                <input
                  type="date"
                  value={nextScheduledDate}
                  onChange={(e) => setNextScheduledDate(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCompleteModalLead(null)}
                  className="px-3 py-1.5 text-xs text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl"
                >
                  Save & Complete
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
