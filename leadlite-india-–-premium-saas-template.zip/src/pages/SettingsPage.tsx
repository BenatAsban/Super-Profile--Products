import React, { useState, useRef } from 'react';
import {
  Settings,
  Building,
  Phone,
  Mail,
  MapPin,
  IndianRupee,
  Moon,
  Sun,
  Download,
  Upload,
  RotateCcw,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  HardDrive,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';

export const SettingsPage: React.FC = () => {
  const {
    settings,
    updateSettings,
    exportJSON,
    importJSONBackup,
    resetToSampleData,
    clearAllData,
    leads,
    appointments,
    quotations,
  } = useLeadLite();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<{ success: boolean; message: string } | null>(
    null
  );
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const [formData, setFormData] = useState({
    businessName: settings.businessName || '',
    businessPhone: settings.businessPhone || '',
    businessEmail: settings.businessEmail || '',
    businessCity: settings.businessCity || '',
    businessAddress: settings.businessAddress || '',
    gstNumber: settings.gstNumber || '',
    defaultGstRate: settings.defaultGstRate || 18,
    defaultFollowUpDays: settings.defaultFollowUpDays || 3,
  });

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = importJSONBackup(content);
      setImportStatus(res);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-4xl space-y-8">
      {/* Top Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Application & Workspace Settings
        </h2>
        <p className="text-xs text-slate-500">
          Configure business details for quotations, manage localStorage data, and create JSON backups
        </p>
      </div>

      {/* Local Storage Architecture Notice */}
      <div className="p-4 rounded-2xl bg-sky-50/70 dark:bg-sky-950/30 border border-sky-200/60 dark:border-sky-900/40 text-xs text-sky-900 dark:text-sky-200 space-y-1.5">
        <div className="flex items-center gap-2 font-bold text-sky-950 dark:text-sky-100">
          <HardDrive className="w-4 h-4 text-sky-600 dark:text-sky-400" />
          <span>Local-First Browser Architecture</span>
        </div>
        <p className="leading-relaxed">
          LeadLite India operates 100% inside your browser's local storage. Your customer data never leaves your device or browser. To prevent loss when clearing browser cache, use the <strong>Export Workspace Backup</strong> button regularly.
        </p>
      </div>

      {/* Business Profile Form */}
      <form
        onSubmit={handleSaveProfile}
        className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-6 shadow-2xs"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Business Information
            </h3>
            <p className="text-xs text-slate-500">
              Appears on generated quotations and WhatsApp message templates
            </p>
          </div>
          {savedSuccess && (
            <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" /> Saved!
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Business / Studio Name *
            </label>
            <input
              type="text"
              required
              value={formData.businessName}
              onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
              placeholder="e.g. Apex Studio & Consultancy"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Official WhatsApp / Phone *
            </label>
            <input
              type="text"
              required
              value={formData.businessPhone}
              onChange={(e) => setFormData({ ...formData, businessPhone: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
              placeholder="+91 98200 12345"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Email Address
            </label>
            <input
              type="email"
              value={formData.businessEmail}
              onChange={(e) => setFormData({ ...formData, businessEmail: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
              placeholder="contact@apexstudio.in"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              City / State
            </label>
            <input
              type="text"
              value={formData.businessCity}
              onChange={(e) => setFormData({ ...formData, businessCity: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
              placeholder="Mumbai, Maharashtra"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Registered Office Address
            </label>
            <input
              type="text"
              value={formData.businessAddress}
              onChange={(e) => setFormData({ ...formData, businessAddress: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
              placeholder="Suite 402, Trade Link Hub, Lower Parel, Mumbai 400013"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              GSTIN / Tax Identification (Optional)
            </label>
            <input
              type="text"
              value={formData.gstNumber}
              onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value })}
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
              placeholder="27AABCU9603R1ZM"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Default Follow-up Gap (Days)
            </label>
            <input
              type="number"
              min="1"
              max="30"
              value={formData.defaultFollowUpDays}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  defaultFollowUpDays: Number(e.target.value) || 3,
                })
              }
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
            />
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors"
          >
            Save Profile Settings
          </button>
        </div>
      </form>

      {/* Theme & Display */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-2xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
          Display & Appearance
        </h3>
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
              Color Theme
            </span>
            <span className="text-xs text-slate-500">
              Current: {settings.theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
            </span>
          </div>
          <div className="flex items-center gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              onClick={() => updateSettings({ theme: 'light' })}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                settings.theme === 'light'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Sun className="w-3.5 h-3.5" /> Light
            </button>
            <button
              onClick={() => updateSettings({ theme: 'dark' })}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                settings.theme === 'dark'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'text-slate-400 hover:text-slate-100'
              }`}
            >
              <Moon className="w-3.5 h-3.5" /> Dark
            </button>
          </div>
        </div>
      </div>

      {/* Data Management: Backup & Restore */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-2xs">
        <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Backup, Restore & Reset
          </h3>
          <p className="text-xs text-slate-500">
            Export a full JSON copy of your database ({leads.length} leads, {appointments.length} appointments, {quotations.length} quotations)
          </p>
        </div>

        {importStatus && (
          <div
            className={`p-3 rounded-xl text-xs flex items-center justify-between ${
              importStatus.success
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : 'bg-rose-50 text-rose-800 border border-rose-200'
            }`}
          >
            <span>{importStatus.message}</span>
            <button onClick={() => setImportStatus(null)} className="text-slate-400 hover:text-slate-600">
              &times;
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Export JSON */}
          <button
            onClick={exportJSON}
            className="p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-left transition-colors space-y-1"
          >
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-semibold text-xs">
              <Download className="w-4 h-4" /> Export Backup (JSON)
            </div>
            <p className="text-[11px] text-slate-500">
              Save complete CRM records to your local device.
            </p>
          </button>

          {/* Import JSON */}
          <div className="relative">
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-left transition-colors space-y-1"
            >
              <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-semibold text-xs">
                <Upload className="w-4 h-4" /> Import Backup (JSON)
              </div>
              <p className="text-[11px] text-slate-500">
                Restore previously saved JSON database backup.
              </p>
            </button>
          </div>

          {/* Reset Demo Data */}
          <button
            onClick={resetToSampleData}
            className="p-4 rounded-xl border border-amber-200 dark:border-amber-800/60 bg-amber-50/40 dark:bg-amber-950/20 hover:bg-amber-50 text-left transition-colors space-y-1"
          >
            <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-semibold text-xs">
              <RotateCcw className="w-4 h-4" /> Reset Sample Demo Data
            </div>
            <p className="text-[11px] text-amber-700/80 dark:text-amber-400/80">
              Restore the original Indian business demo dataset.
            </p>
          </button>
        </div>

        {/* Clear All */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-rose-600 block">
              Danger Zone
            </span>
            <span className="text-[11px] text-slate-400">
              Erase all current leads, meetings, and quotations from this browser
            </span>
          </div>

          {!confirmClear ? (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="px-3 py-1.5 text-xs font-semibold text-rose-600 border border-rose-200 dark:border-rose-800 rounded-lg hover:bg-rose-50"
            >
              Clear All Data
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-xs text-rose-600 font-semibold">Are you sure?</span>
              <button
                type="button"
                onClick={() => {
                  clearAllData();
                  setConfirmClear(false);
                }}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 rounded-lg hover:bg-rose-700"
              >
                Yes, Erase
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="px-2 py-1 text-xs text-slate-500"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
