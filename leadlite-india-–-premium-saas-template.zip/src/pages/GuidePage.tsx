import React from 'react';
import {
  HelpCircle,
  MessageSquare,
  Clock,
  FileSpreadsheet,
  CalendarDays,
  HardDrive,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';

export const GuidePage: React.FC = () => {
  const { setActivePage } = useLeadLite();

  const sections = [
    {
      title: '1. The 3-Minute Daily Follow-up Habit',
      description:
        'In India, 68% of customers close with the first business that responds and follows up professionally. Here is the easiest routine:',
      steps: [
        'Open LeadLite every morning at 9:30 AM.',
        'Navigate to the Follow-ups tab and check "Due Today" and "Overdue".',
        'Click the WhatsApp button on each lead, choose the gentle follow-up template, and hit send.',
        'Mark completed or postpone by 2-3 days.',
      ],
      icon: Clock,
      actionLabel: 'Go to Follow-ups',
      actionPage: 'followups' as const,
    },
    {
      title: '2. WhatsApp Click-to-Chat without Adding Contacts',
      description:
        'You do NOT need to save every stranger in your phone contact list before sending a message. LeadLite creates standard WhatsApp direct links:',
      steps: [
        'Enter any 10-digit Indian mobile number (e.g. 98201 44552). LeadLite automatically adds the India country code +91.',
        'Select a pre-formatted polite Hindi/English message or customize it in the preview box.',
        'Click "Open in WhatsApp" to launch directly into WhatsApp Web or the WhatsApp desktop/mobile app.',
      ],
      icon: MessageSquare,
      actionLabel: 'Try on All Leads',
      actionPage: 'leads' as const,
    },
    {
      title: '3. Generating Commercial Quotations in 60 Seconds',
      description:
        'Stop writing messy quotation text notes on WhatsApp. A clean, branded PDF/printed estimate instantly builds trust:',
      steps: [
        'Go to Quotations & click "Create New Quotation".',
        'Pick the customer from your pipeline or enter their name.',
        'Add line items with rate and quantity. Toggle GST (18%, 12%, 5%) if applicable.',
        'Click "Print / Save PDF" or share the summary text directly on WhatsApp.',
      ],
      icon: FileSpreadsheet,
      actionLabel: 'Open Quotations',
      actionPage: 'quotations' as const,
    },
    {
      title: '4. Local Storage & Backing Up Your Records',
      description:
        'LeadLite is designed with zero cloud lock-in and 100% privacy for your customer contacts:',
      steps: [
        'All leads and notes are stored strictly inside your web browser on this machine.',
        'Before clearing browser cookies or switching computers, visit Settings & click "Export Backup (JSON)".',
        'You can also export a CSV file anytime to open your full lead list in Microsoft Excel or Google Sheets.',
      ],
      icon: HardDrive,
      actionLabel: 'Open Settings',
      actionPage: 'settings' as const,
    },
  ];

  const faqs = [
    {
      q: 'Does LeadLite require official WhatsApp Business API approvals or monthly fees?',
      a: 'No. LeadLite uses standard WhatsApp click-to-chat links (wa.me protocol). It opens directly in your existing WhatsApp Web or mobile app. You do not need third-party API keys, Meta developer approval, or recurring software fees.',
    },
    {
      q: 'Can multiple employees use this same browser database?',
      a: 'This version of LeadLite is a single-browser local storage application. It is ideal for individual proprietors, freelancers, or a single reception/admin desk computer. If another team member needs the data, simply export the JSON file and import it on their browser.',
    },
    {
      q: 'Is the quotation tool a substitute for Tally or Zoho Books?',
      a: 'No. LeadLite provides simple commercial estimates and price quotations to help you close deals faster with customers. For formal GST returns, e-invoicing, and accounting ledgers, continue using your chartered accountant or accounting tool.',
    },
    {
      q: 'What happens if I accidentally clear my browser cache?',
      a: 'Clearing browser site data will remove local storage. We strongly recommend making a weekly backup by clicking "Export Backup (JSON)" in Settings, which saves a permanent file on your computer.',
    },
  ];

  return (
    <div className="max-w-4xl space-y-8">
      {/* Top Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          LeadLite India – User Guide & Best Practices
        </h2>
        <p className="text-xs text-slate-500">
          Practical strategies to organize your pipeline, boost conversion rates, and manage customer communications
        </p>
      </div>

      {/* Guide Cards */}
      <div className="space-y-4">
        {sections.map((section, idx) => {
          const Icon = section.icon;

          return (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-2xs"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {section.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {section.description}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setActivePage(section.actionPage)}
                  className="hidden sm:inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline shrink-0"
                >
                  {section.actionLabel} &rarr;
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                {section.steps.map((st, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300">
                    <span className="w-4 h-4 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center text-[10px] font-mono shrink-0 mt-0.5">
                      {i + 1}
                    </span>
                    <span>{st}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Frequently Asked Questions */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-2xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 pb-3 border-b border-slate-100 dark:border-slate-800">
          Frequently Asked Questions
        </h3>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div key={i} className="space-y-1">
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <span className="text-indigo-600 dark:text-indigo-400 font-mono">Q.</span>
                {faq.q}
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed pl-5">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
