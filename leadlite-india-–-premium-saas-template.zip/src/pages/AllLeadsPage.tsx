import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Plus,
  Download,
  MessageSquare,
  ChevronRight,
  Phone,
  Mail,
  Calendar,
  IndianRupee,
  MapPin,
  Trash2,
  FileSpreadsheet,
  LayoutGrid,
  List,
  Sparkles,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { Lead, LeadStatus, LeadSource } from '../types';
import {
  formatINR,
  formatDateNice,
  getStatusStyle,
  getFollowUpUrgency,
} from '../utils/helpers';

export const AllLeadsPage: React.FC = () => {
  const {
    leads,
    setActivePage,
    setSelectedLead,
    setWhatsAppModalLead,
    exportCSV,
    deleteLead,
    searchQuery,
    setSearchQuery,
  } = useLeadLite();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'value' | 'followup'>('newest');
  const [viewLayout, setViewLayout] = useState<'table' | 'cards'>('table');

  const statuses: LeadStatus[] = [
    'New',
    'Contacted',
    'Interested',
    'Follow-up',
    'Converted',
    'Not Interested',
  ];

  const sources: LeadSource[] = [
    'WhatsApp Direct',
    'Instagram',
    'Google Search',
    'Referral',
    'Walk-in',
    'IndiaMART / Justdial',
    'LinkedIn',
    'Facebook Ads',
    'Other',
  ];

  // Filtering & Sorting
  const filteredLeads = useMemo(() => {
    return leads
      .filter((lead) => {
        // Search
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesName = lead.name.toLowerCase().includes(q);
          const matchesPhone = lead.phone.includes(q);
          const matchesInterest = lead.businessInterest.toLowerCase().includes(q);
          const matchesCity = lead.city?.toLowerCase().includes(q);
          const matchesNotes = lead.notes.some((n) => n.text.toLowerCase().includes(q));
          if (!matchesName && !matchesPhone && !matchesInterest && !matchesCity && !matchesNotes) {
            return false;
          }
        }

        // Status filter
        if (statusFilter !== 'all' && lead.status !== statusFilter) {
          return false;
        }

        // Source filter
        if (sourceFilter !== 'all' && lead.source !== sourceFilter) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'value') {
          return (b.estimatedValue || 0) - (a.estimatedValue || 0);
        }
        if (sortBy === 'followup') {
          return new Date(a.nextFollowUpDate).getTime() - new Date(b.nextFollowUpDate).getTime();
        }
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [leads, searchQuery, statusFilter, sourceFilter, sortBy]);

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Customer Leads Directory
          </h2>
          <p className="text-xs text-slate-500">
            Manage your pipeline, record notes, and send WhatsApp follow-ups
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shadow-2xs"
            title="Download CSV spreadsheet"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
          <button
            onClick={() => setActivePage('add-lead')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Add New Lead
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by customer name, phone (+91), requirement, or notes..."
              className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Statuses ({leads.length})</option>
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {s} ({leads.filter((l) => l.status === s).length})
                </option>
              ))}
            </select>

            {/* Source Filter */}
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Sources</option>
              {sources.map((src) => (
                <option key={src} value={src}>
                  {src}
                </option>
              ))}
            </select>

            {/* Sort Dropdown */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="newest">Sort: Newest First</option>
              <option value="value">Sort: Highest Deal Value</option>
              <option value="followup">Sort: Follow-up Date</option>
            </select>

            {/* View layout switcher */}
            <div className="hidden sm:flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              <button
                onClick={() => setViewLayout('table')}
                className={`p-1.5 rounded-lg ${
                  viewLayout === 'table'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Table view"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewLayout('cards')}
                className={`p-1.5 rounded-lg ${
                  viewLayout === 'cards'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Card grid view"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Active Filters count */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
          <span>
            Showing <strong className="text-slate-800 dark:text-slate-200 font-mono">{filteredLeads.length}</strong> of{' '}
            <span className="font-mono">{leads.length}</span> total leads
          </span>
          {(statusFilter !== 'all' || sourceFilter !== 'all' || searchQuery.trim()) && (
            <button
              onClick={() => {
                setStatusFilter('all');
                setSourceFilter('all');
                setSearchQuery('');
              }}
              className="text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Main Leads Render */}
      {filteredLeads.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            No leads match your search criteria
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search terms, changing the status filter, or register a new customer enquiry.
          </p>
          <button
            onClick={() => setActivePage('add-lead')}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl"
          >
            <Plus className="w-3.5 h-3.5" />
            Add New Lead
          </button>
        </div>
      ) : viewLayout === 'table' ? (
        /* High-Density Data Table */
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 bg-slate-50/50 dark:bg-slate-800/30">
                  <th className="py-3 px-4 font-semibold">Customer Details</th>
                  <th className="py-3 px-4 font-semibold">Service / Requirement</th>
                  <th className="py-3 px-4 font-semibold">Source</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Value (₹)</th>
                  <th className="py-3 px-4 font-semibold">Next Follow-up</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredLeads.map((lead) => {
                  const statusStyle = getStatusStyle(lead.status);
                  const urgency = getFollowUpUrgency(lead.nextFollowUpDate);

                  return (
                    <tr
                      key={lead.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3.5 px-4">
                        <div
                          onClick={() => setSelectedLead(lead)}
                          className="font-bold text-slate-900 dark:text-slate-100 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer"
                        >
                          {lead.name}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                          <span className="font-mono tabular-nums">{lead.phone}</span>
                          {lead.city && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{lead.city}</span>
                            </>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-medium text-slate-800 dark:text-slate-200 block max-w-xs truncate">
                          {lead.businessInterest}
                        </span>
                        {lead.notes.length > 0 && (
                          <span className="text-[11px] text-slate-400 block truncate max-w-xs mt-0.5">
                            Latest: {lead.notes[0].text}
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400 whitespace-nowrap">
                        {lead.source}
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${statusStyle.bg}`}
                        >
                          {lead.status}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right font-bold tabular-nums text-slate-900 dark:text-slate-100">
                        {formatINR(lead.estimatedValue)}
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`text-[11px] font-medium ${
                            urgency.status === 'overdue'
                              ? 'text-rose-600 dark:text-rose-400 font-semibold'
                              : urgency.status === 'today'
                              ? 'text-amber-600 dark:text-amber-400 font-semibold'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {urgency.label}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-1">
                        <button
                          onClick={() => setWhatsAppModalLead(lead)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors font-medium text-[11px]"
                          title="Open WhatsApp Click-to-Chat"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Chat</span>
                        </button>
                        <button
                          onClick={() => setSelectedLead(lead)}
                          className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                          title="View Full Details & History"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Card Grid View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLeads.map((lead) => {
            const statusStyle = getStatusStyle(lead.status);
            const urgency = getFollowUpUrgency(lead.nextFollowUpDate);

            return (
              <div
                key={lead.id}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${statusStyle.bg}`}
                    >
                      {lead.status}
                    </span>
                    <span className="text-sm font-bold tabular-nums text-slate-900 dark:text-slate-100">
                      {formatINR(lead.estimatedValue)}
                    </span>
                  </div>

                  <h3
                    onClick={() => setSelectedLead(lead)}
                    className="text-base font-bold text-slate-900 dark:text-slate-100 hover:text-indigo-600 cursor-pointer"
                  >
                    {lead.name}
                  </h3>
                  <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400 mt-0.5">
                    {lead.businessInterest}
                  </p>

                  <div className="mt-3 space-y-1 text-xs text-slate-500">
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-mono tabular-nums">{lead.phone}</span>
                    </div>
                    {lead.city && (
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span>{lead.city}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Next: {urgency.label}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">{lead.source}</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setWhatsAppModalLead(lead)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      WhatsApp
                    </button>
                    <button
                      onClick={() => setSelectedLead(lead)}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition-colors"
                    >
                      Details
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
