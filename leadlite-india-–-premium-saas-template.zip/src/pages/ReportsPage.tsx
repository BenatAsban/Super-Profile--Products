import React from 'react';
import {
  BarChart3,
  Download,
  Printer,
  TrendingUp,
  PieChart,
  Users,
  CheckCircle2,
  Clock,
  IndianRupee,
  Sparkles,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { LeadSource } from '../types';
import { formatINR } from '../utils/helpers';

export const ReportsPage: React.FC = () => {
  const { leads, exportCSV, settings } = useLeadLite();

  const totalLeads = leads.length;
  const convertedLeads = leads.filter((l) => l.status === 'Converted');
  const convertedCount = convertedLeads.length;
  const conversionRate = totalLeads > 0 ? Math.round((convertedCount / totalLeads) * 100) : 0;

  const totalPipelineINR = leads.reduce((acc, curr) => acc + (curr.estimatedValue || 0), 0);
  const convertedINR = convertedLeads.reduce((acc, curr) => acc + (curr.estimatedValue || 0), 0);
  const averageDealSize = convertedCount > 0 ? Math.round(convertedINR / convertedCount) : 0;

  const sourcesList: LeadSource[] = [
    'WhatsApp Direct',
    'Instagram',
    'Google Search',
    'Referral',
    'Walk-in',
    'IndiaMART / Justdial',
    'LinkedIn',
    'Facebook Ads',
    'Other',
  ];

  // Group by Source
  const sourceBreakdown = sourcesList
    .map((source) => {
      const sourceLeads = leads.filter((l) => l.source === source);
      const count = sourceLeads.length;
      const converted = sourceLeads.filter((l) => l.status === 'Converted').length;
      const totalVal = sourceLeads.reduce((acc, curr) => acc + (curr.estimatedValue || 0), 0);
      const convRate = count > 0 ? Math.round((converted / count) * 100) : 0;
      return {
        source,
        count,
        converted,
        totalVal,
        convRate,
      };
    })
    .filter((s) => s.count > 0)
    .sort((a, b) => b.count - a.count);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Pipeline Analytics & Lead Reports
          </h2>
          <p className="text-xs text-slate-500">
            Insights on customer acquisition channels, conversion rates, and closed deal values in INR
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="no-print inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Report
          </button>
          <button
            onClick={exportCSV}
            className="no-print inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Export Raw CSV Data
          </button>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Total Inquiries</span>
          <div className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
            {totalLeads}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Recorded across all channels</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Won Customers</span>
          <div className="text-2xl font-bold tracking-tight text-emerald-600 dark:text-emerald-400 tabular-nums">
            {convertedCount}
          </div>
          <p className="text-[11px] text-emerald-600 font-semibold mt-1">
            {conversionRate}% conversion rate
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Closed Revenue (INR)</span>
          <div className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
            {formatINR(convertedINR)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Total value from won deals</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Average Deal Size</span>
          <div className="text-xl font-bold tracking-tight text-indigo-600 dark:text-indigo-400 tabular-nums">
            {formatINR(averageDealSize)}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Per converted client</p>
        </div>
      </div>

      {/* Channel Breakdown Table */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Lead Source Performance & Conversion
            </h3>
            <p className="text-xs text-slate-500">
              Compare inquiry volume and closed deals across marketing and inquiry channels
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2.5 px-3 font-semibold">Lead Source</th>
                <th className="py-2.5 px-3 font-semibold text-center">Total Enquiries</th>
                <th className="py-2.5 px-3 font-semibold text-center">Converted</th>
                <th className="py-2.5 px-3 font-semibold text-center">Win Rate (%)</th>
                <th className="py-2.5 px-3 font-semibold text-right">Pipeline Volume (₹)</th>
                <th className="py-2.5 px-3 font-semibold">Channel Share</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {sourceBreakdown.map((item) => {
                const sharePercent = totalLeads > 0 ? Math.round((item.count / totalLeads) * 100) : 0;

                return (
                  <tr key={item.source} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-bold text-slate-900 dark:text-slate-100">
                      {item.source}
                    </td>
                    <td className="py-3 px-3 text-center font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {item.count}
                    </td>
                    <td className="py-3 px-3 text-center font-mono tabular-nums text-emerald-600 font-semibold">
                      {item.converted}
                    </td>
                    <td className="py-3 px-3 text-center font-mono tabular-nums">
                      <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold">
                        {item.convRate}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-slate-900 dark:text-slate-100">
                      {formatINR(item.totalVal)}
                    </td>
                    <td className="py-3 px-3 w-48">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div
                            style={{ width: `${sharePercent}%` }}
                            className="bg-indigo-600 h-full rounded-full"
                          />
                        </div>
                        <span className="font-mono text-[11px] tabular-nums text-slate-500 w-8 text-right">
                          {sharePercent}%
                        </span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recommendations Card for Indian Small Businesses */}
      <div className="p-5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-900/40 text-xs text-indigo-950 dark:text-indigo-200 space-y-2">
        <h4 className="font-bold flex items-center gap-1.5 text-indigo-900 dark:text-indigo-100">
          <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          Pro-Tip for Indian Agency & Real-Estate Operators
        </h4>
        <p className="leading-relaxed">
          Leads coming through <strong>WhatsApp Direct</strong> and <strong>Referrals</strong> have up to a 60% higher close rate than cold directory listings. Make sure you respond to WhatsApp enquiries within 15 minutes and schedule an in-person or video consultation within 48 hours.
        </p>
      </div>
    </div>
  );
};
