import React, { useState } from 'react';
import {
  CalendarDays,
  Plus,
  Clock,
  MapPin,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Share2,
  Trash2,
  Video,
  PhoneCall,
  User,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { Appointment, AppointmentLocation } from '../types';
import { formatDateNice, buildWhatsAppLink } from '../utils/helpers';

export const AppointmentsPage: React.FC = () => {
  const {
    appointments,
    addAppointment,
    updateAppointment,
    deleteAppointment,
    leads,
    settings,
  } = useLeadLite();

  const [filterStatus, setFilterStatus] = useState<string>('Scheduled');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingApt, setEditingApt] = useState<Appointment | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    customerName: '',
    customerPhone: '',
    date: new Date().toISOString().split('T')[0],
    time: '11:00',
    purpose: '',
    locationType: 'In-person / Site Visit' as AppointmentLocation,
    notes: '',
  });

  const locationOptions: AppointmentLocation[] = [
    'In-person / Site Visit',
    'Phone Call',
    'WhatsApp Video',
    'Google Meet / Zoom',
    'Office Meeting',
  ];

  const filteredAppointments = appointments.filter((apt) => {
    if (filterStatus === 'all') return true;
    return apt.status === filterStatus;
  });

  const handleOpenCreate = () => {
    setEditingApt(null);
    setFormData({
      customerName: '',
      customerPhone: '',
      date: new Date().toISOString().split('T')[0],
      time: '11:00',
      purpose: '',
      locationType: 'In-person / Site Visit',
      notes: '',
    });
    setIsCreateModalOpen(true);
  };

  const handleSelectExistingLead = (leadId: string) => {
    const lead = leads.find((l) => l.id === leadId);
    if (lead) {
      setFormData((prev) => ({
        ...prev,
        customerName: lead.name,
        customerPhone: lead.phone,
        purpose: `Discussion regarding ${lead.businessInterest}`,
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerName.trim() || !formData.date || !formData.time) return;

    if (editingApt) {
      updateAppointment(editingApt.id, {
        customerName: formData.customerName.trim(),
        customerPhone: formData.customerPhone.trim(),
        date: formData.date,
        time: formData.time,
        purpose: formData.purpose.trim(),
        locationType: formData.locationType,
        notes: formData.notes.trim() || undefined,
      });
    } else {
      addAppointment({
        customerName: formData.customerName.trim(),
        customerPhone: formData.customerPhone.trim(),
        date: formData.date,
        time: formData.time,
        purpose: formData.purpose.trim(),
        locationType: formData.locationType,
        status: 'Scheduled',
        notes: formData.notes.trim() || undefined,
      });
    }

    setIsCreateModalOpen(false);
    setEditingApt(null);
  };

  const handleSendReminderWhatsApp = (apt: Appointment) => {
    const message = `Namaste ${apt.customerName}, this is a gentle reminder regarding our scheduled appointment on ${formatDateNice(
      apt.date
    )} at ${apt.time} (${apt.locationType}) for "${apt.purpose}". Looking forward to our discussion! - ${settings.businessName || 'LeadLite'}`;
    const link = buildWhatsAppLink(apt.customerPhone, message);
    window.open(link, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Customer Appointments & Site Visits
          </h2>
          <p className="text-xs text-slate-500">
            Schedule consultations, client demos, property visits, and send automated WhatsApp reminders
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          Schedule Appointment
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-fit">
        <button
          onClick={() => setFilterStatus('Scheduled')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            filterStatus === 'Scheduled'
              ? 'bg-indigo-600 text-white shadow-2xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          Upcoming ({appointments.filter((a) => a.status === 'Scheduled').length})
        </button>
        <button
          onClick={() => setFilterStatus('Completed')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            filterStatus === 'Completed'
              ? 'bg-emerald-600 text-white shadow-2xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          Completed ({appointments.filter((a) => a.status === 'Completed').length})
        </button>
        <button
          onClick={() => setFilterStatus('Cancelled')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            filterStatus === 'Cancelled'
              ? 'bg-rose-600 text-white shadow-2xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          Cancelled ({appointments.filter((a) => a.status === 'Cancelled').length})
        </button>
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            filterStatus === 'all'
              ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          All ({appointments.length})
        </button>
      </div>

      {/* Appointments List */}
      {filteredAppointments.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
          <CalendarDays className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            No appointments found
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Book meetings or site visits with customers to keep your calendar organized.
          </p>
          <button
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="w-3.5 h-3.5" />
            Book Meeting
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAppointments.map((apt) => (
            <div
              key={apt.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-4 hover:border-slate-300 dark:hover:border-slate-700 transition-all shadow-2xs"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        apt.status === 'Scheduled'
                          ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300'
                          : apt.status === 'Completed'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                          : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                      }`}
                    >
                      {apt.status}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-500 font-medium">
                      {apt.locationType}
                    </span>
                  </div>

                  <span className="text-xs font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                    {apt.time}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {apt.customerName}
                </h3>
                <p className="text-xs font-medium text-slate-600 dark:text-slate-400 mt-0.5">
                  {apt.purpose}
                </p>

                <div className="mt-3 space-y-1 text-xs text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <CalendarDays className="w-3.5 h-3.5 text-slate-400" />
                    <span>{formatDateNice(apt.date)}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-mono tabular-nums">{apt.customerPhone}</span>
                  </div>
                  {apt.notes && (
                    <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 text-[11px] text-slate-600 dark:text-slate-400 mt-2">
                      {apt.notes}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-1">
                  {apt.status === 'Scheduled' && (
                    <>
                      <button
                        onClick={() => updateAppointment(apt.id, { status: 'Completed' })}
                        className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 rounded-lg text-xs"
                        title="Mark Completed"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => updateAppointment(apt.id, { status: 'Cancelled' })}
                        className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/60 rounded-lg text-xs"
                        title="Cancel Appointment"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => deleteAppointment(apt.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <button
                  onClick={() => handleSendReminderWhatsApp(apt)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  WhatsApp Reminder
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Appointment Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                Schedule Customer Appointment
              </h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Optional Lead Autocomplete */}
              {leads.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    Or select an existing enquiry from your pipeline:
                  </label>
                  <select
                    onChange={(e) => handleSelectExistingLead(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    defaultValue=""
                  >
                    <option value="" disabled>
                      -- Choose a customer lead --
                    </option>
                    {leads.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name} ({l.phone}) - {l.businessInterest}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                    placeholder="e.g. Ramesh Patel"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={formData.customerPhone}
                    onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
                    placeholder="+91 98200 12345"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Time *
                  </label>
                  <input
                    type="time"
                    required
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Meeting Location / Format
                  </label>
                  <select
                    value={formData.locationType}
                    onChange={(e) => setFormData({ ...formData, locationType: e.target.value as any })}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                  >
                    {locationOptions.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Meeting Agenda / Purpose *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.purpose}
                    onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                    placeholder="e.g. Site measurement & sample review"
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Preparation Notes
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Items or documents to bring along..."
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl"
                >
                  Save Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
