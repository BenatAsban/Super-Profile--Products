import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Trash2,
  Printer,
  Share2,
  Calendar,
  IndianRupee,
  Building,
  User,
  CheckCircle2,
  Sparkles,
  Info,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { Quotation, QuotationItem } from '../types';
import { formatINR, formatDateNice, buildWhatsAppLink } from '../utils/helpers';

export const QuotationsPage: React.FC = () => {
  const {
    quotations,
    addQuotation,
    deleteQuotation,
    setSelectedQuotation,
    settings,
    leads,
  } = useLeadLite();

  const [isBuilderOpen, setIsBuilderOpen] = useState(false);

  // Builder form state
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [validUntilDays, setValidUntilDays] = useState(14);
  const [notes, setNotes] = useState(
    'Payment Terms: 50% advance on sign-off, balance upon completion. Valid for 14 days.'
  );

  const [items, setItems] = useState<QuotationItem[]>([
    {
      id: 'item-1',
      description: 'Consultation & Initial Deliverable Scope',
      quantity: 1,
      unitPrice: 25000,
      amount: 25000,
    },
  ]);

  const [discountType, setDiscountType] = useState<'fixed' | 'percentage'>('fixed');
  const [discountValue, setDiscountValue] = useState<number>(0);
  const [isGstEnabled, setIsGstEnabled] = useState<boolean>(true);
  const [gstRate, setGstRate] = useState<number>(settings.defaultGstRate || 18);

  // Mathematical Calculations
  const subtotal = items.reduce((acc, it) => acc + (it.amount || 0), 0);
  const discountAmount =
    discountType === 'percentage'
      ? Math.round((subtotal * discountValue) / 100)
      : Math.min(discountValue, subtotal);
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const gstAmount = isGstEnabled ? Math.round((taxableAmount * gstRate) / 100) : 0;
  const grandTotal = taxableAmount + gstAmount;

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: `item-${Date.now()}`,
        description: '',
        quantity: 1,
        unitPrice: 0,
        amount: 0,
      },
    ]);
  };

  const handleUpdateItem = (
    id: string,
    field: 'description' | 'quantity' | 'unitPrice',
    val: any
  ) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id === id) {
          const updated = { ...it, [field]: val };
          const qty = Number(field === 'quantity' ? val : it.quantity) || 0;
          const price = Number(field === 'unitPrice' ? val : it.unitPrice) || 0;
          updated.amount = qty * price;
          return updated;
        }
        return it;
      })
    );
  };

  const handleRemoveItem = (id: string) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((it) => it.id !== id));
  };

  const handleSelectLead = (leadId: string) => {
    const lead = leads.find((l) => l.id === leadId);
    if (lead) {
      setCustomerName(lead.name);
      setCustomerPhone(lead.phone);
      if (lead.email) setCustomerEmail(lead.email);
      if (lead.city) setCustomerAddress(lead.city);
      if (lead.businessInterest) {
        setItems([
          {
            id: `item-${Date.now()}`,
            description: lead.businessInterest,
            quantity: 1,
            unitPrice: lead.estimatedValue || 50000,
            amount: lead.estimatedValue || 50000,
          },
        ]);
      }
    }
  };

  const handleSaveQuotation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || items.length === 0) return;

    const today = new Date();
    const validUntilDate = new Date();
    validUntilDate.setDate(today.getDate() + validUntilDays);

    const quotNumber = `QT-${today.getFullYear()}-${String(
      quotations.length + 101
    ).padStart(3, '0')}`;

    const newQuot = addQuotation({
      quotationNumber: quotNumber,
      date: today.toISOString().split('T')[0],
      validUntil: validUntilDate.toISOString().split('T')[0],
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail.trim() || undefined,
      customerAddress: customerAddress.trim() || undefined,
      businessName: settings.businessName,
      businessPhone: settings.businessPhone,
      businessEmail: settings.businessEmail,
      businessAddress: settings.businessAddress,
      gstNumber: settings.gstNumber,
      items,
      subtotal,
      discountAmount,
      discountType,
      discountValue,
      gstRate,
      isGstEnabled,
      gstAmount,
      totalAmount: grandTotal,
      notes,
      bankDetails: `HDFC Bank | Current A/c: 50200012345678 | IFSC: HDFC0000123`,
      status: 'Sent',
    });

    setIsBuilderOpen(false);
    setSelectedQuotation(newQuot);
  };

  return (
    <div className="space-y-6">
      {/* Disclaimer Banner */}
      <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300">
        <Info className="w-4 h-4 text-indigo-600 shrink-0" />
        <span>
          <strong>Simple Quotation Builder:</strong> Designed for rapid commercial estimates and WhatsApp sharing. This is not a complex GST accounting ledger or formal e-way billing software.
        </span>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Quotation & Estimate Builder
          </h2>
          <p className="text-xs text-slate-500">
            Generate clean, professional commercial quotations with GST calculations and printable layouts
          </p>
        </div>

        <button
          onClick={() => setIsBuilderOpen(!isBuilderOpen)}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          {isBuilderOpen ? 'Close Builder' : 'Create New Quotation'}
        </button>
      </div>

      {/* Interactive Quotation Builder Drawer/Card */}
      {isBuilderOpen && (
        <form
          onSubmit={handleSaveQuotation}
          className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-md space-y-6 animate-in fade-in"
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
              New Commercial Quotation
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Auto-numbered on save
            </span>
          </div>

          {/* Customer Selection */}
          <div className="space-y-4">
            {leads.length > 0 && (
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">
                  Load customer from active pipeline:
                </label>
                <select
                  onChange={(e) => handleSelectLead(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                  defaultValue=""
                >
                  <option value="" disabled>
                    -- Select a lead to auto-fill details --
                  </option>
                  {leads.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.phone}) - {l.businessInterest}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Client / Company Name *
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                  placeholder="e.g. Dr. Rajesh Sharma"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Client Mobile Number
                </label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
                  placeholder="+91 98200 12345"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Client Email (Optional)
                </label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                  placeholder="client@gmail.com"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Validity Period (Days)
                </label>
                <input
                  type="number"
                  min="1"
                  value={validUntilDays}
                  onChange={(e) => setValidUntilDays(Number(e.target.value) || 14)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Scope / Service Items ({items.length})
              </span>
              <button
                type="button"
                onClick={handleAddItem}
                className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                <Plus className="w-3.5 h-3.5" /> Add Line Item
              </button>
            </div>

            <div className="space-y-2">
              {items.map((item, index) => (
                <div
                  key={item.id}
                  className="flex flex-col sm:flex-row items-start sm:items-center gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700"
                >
                  <span className="text-xs font-mono text-slate-400 w-5">
                    {index + 1}.
                  </span>

                  <input
                    type="text"
                    required
                    placeholder="Description of service, materials, or deliverables..."
                    value={item.description}
                    onChange={(e) => handleUpdateItem(item.id, 'description', e.target.value)}
                    className="flex-1 text-xs px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                  />

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <div className="w-20">
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) =>
                          handleUpdateItem(item.id, 'quantity', Number(e.target.value))
                        }
                        className="w-full text-xs px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-center font-mono tabular-nums"
                        title="Quantity"
                      />
                    </div>

                    <div className="w-32">
                      <input
                        type="number"
                        min="0"
                        step="100"
                        placeholder="Rate ₹"
                        value={item.unitPrice}
                        onChange={(e) =>
                          handleUpdateItem(item.id, 'unitPrice', Number(e.target.value))
                        }
                        className="w-full text-xs px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-right font-mono tabular-nums"
                      />
                    </div>

                    <div className="w-28 text-right font-mono font-bold text-xs tabular-nums text-slate-900 dark:text-slate-100 px-2">
                      {formatINR(item.amount)}
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveItem(item.id)}
                      disabled={items.length <= 1}
                      className="p-1.5 text-slate-400 hover:text-rose-600 disabled:opacity-30 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pricing Adjustments & Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100 dark:border-slate-800">
            {/* Left Terms & GST Toggles */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Payment Terms & Scope Notes
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950"
                />
              </div>

              {/* GST Slab Selector */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Include Goods & Services Tax (GST)
                  </label>
                  <input
                    type="checkbox"
                    checked={isGstEnabled}
                    onChange={(e) => setIsGstEnabled(e.target.checked)}
                    className="rounded text-indigo-600 w-4 h-4"
                  />
                </div>

                {isGstEnabled && (
                  <div className="flex items-center gap-2 pt-1 text-xs">
                    <span className="text-slate-500">GST Slab:</span>
                    {[0, 5, 12, 18, 28].map((rate) => (
                      <button
                        key={rate}
                        type="button"
                        onClick={() => setGstRate(rate)}
                        className={`px-2.5 py-1 rounded-md font-mono text-xs font-medium ${
                          gstRate === rate
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {rate}%
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right Summary Calculations */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-2.5 text-xs">
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>Subtotal ({items.length} items)</span>
                <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100 font-semibold">
                  {formatINR(subtotal)}
                </span>
              </div>

              {/* Discount Row */}
              <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-1.5">
                  <span>Discount:</span>
                  <select
                    value={discountType}
                    onChange={(e) => setDiscountType(e.target.value as any)}
                    className="text-[11px] px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                  >
                    <option value="fixed">Fixed ₹</option>
                    <option value="percentage">% Off</option>
                  </select>
                  <input
                    type="number"
                    min="0"
                    value={discountValue}
                    onChange={(e) => setDiscountValue(Number(e.target.value) || 0)}
                    className="w-16 text-[11px] px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-right font-mono"
                  />
                </div>
                <span className="font-mono tabular-nums text-emerald-600 dark:text-emerald-400 font-semibold">
                  -{formatINR(discountAmount)}
                </span>
              </div>

              {/* GST Row */}
              {isGstEnabled && (
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>GST ({gstRate}%)</span>
                  <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    +{formatINR(gstAmount)}
                  </span>
                </div>
              )}

              {/* Total Row */}
              <div className="flex justify-between pt-2 border-t-2 border-slate-300 dark:border-slate-600 text-sm font-bold text-slate-900 dark:text-slate-100">
                <span>Grand Total (INR)</span>
                <span className="font-mono tabular-nums text-indigo-600 dark:text-indigo-400 text-base">
                  {formatINR(grandTotal)}
                </span>
              </div>
            </div>
          </div>

          {/* Builder Submit */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsBuilderOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors"
            >
              Generate Quotation & Print
            </button>
          </div>
        </form>
      )}

      {/* Quotations List */}
      {quotations.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
          <FileSpreadsheet className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            No quotations prepared yet
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Click "Create New Quotation" above to draft an itemized estimate for your customer.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quotations.map((quot) => (
            <div
              key={quot.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-4 hover:border-slate-300 dark:hover:border-slate-700 transition-all shadow-2xs"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-indigo-700 dark:text-indigo-300">
                    {quot.quotationNumber}
                  </span>
                  <span className="text-xs text-slate-400">
                    {formatDateNice(quot.date)}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {quot.customerName}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5 font-mono tabular-nums">
                  {quot.customerPhone}
                </p>

                <div className="mt-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Items Count</span>
                    <span className="font-mono tabular-nums font-semibold">{quot.items.length} services</span>
                  </div>
                  {quot.isGstEnabled && (
                    <div className="flex justify-between text-slate-500">
                      <span>GST Applied</span>
                      <span className="font-mono tabular-nums">{quot.gstRate}%</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-900 dark:text-slate-100 font-bold pt-1 border-t border-slate-200 dark:border-slate-700">
                    <span>Total Quote</span>
                    <span className="font-mono tabular-nums text-indigo-600 dark:text-indigo-400">
                      {formatINR(quot.totalAmount)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => deleteQuotation(quot.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg text-xs"
                  title="Delete Quotation"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedQuotation(quot)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-2xs"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Print / View
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
