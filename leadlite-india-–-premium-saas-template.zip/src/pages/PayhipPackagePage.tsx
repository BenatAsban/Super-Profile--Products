import React, { useState } from 'react';
import {
  PackageCheck,
  Download,
  Copy,
  Check,
  Code2,
  Terminal,
  Globe,
  FileCode,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Tag,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';

export const PayhipPackagePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'readme' | 'install' | 'customize' | 'deploy' | 'payhip-copy' | 'license'
  >('overview');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const readmeContent = `# LeadLite India – Premium SaaS Website Template & Local CRM

A lightweight, high-converting customer lead and follow-up management system crafted for Indian small businesses, agencies, freelancers, consultants, and real estate professionals.

## 🚀 Key Features

- **Lead & Inquiry Tracking**: Save customer requirements, deal value in ₹ INR, and next follow-up dates.
- **WhatsApp 1-Click Follow-ups**: Direct click-to-chat via \`wa.me\` with pre-formatted polite Indian business templates. No expensive official API setup required.
- **Appointment Scheduler**: Organize client consultations, site measurements, and meetings with WhatsApp reminders.
- **Simple Quotation Builder**: Itemized quotation generator with automatic GST slab calculations, discount support, and printable A4 invoice layouts.
- **Local-First & Zero Subscription**: Runs 100% on browser \`localStorage\`. Zero recurring server or SaaS fees.
- **CSV & JSON Data Portability**: Export your entire lead pipeline to CSV (Excel compatible) and full JSON database backups.
- **Modern Responsive SaaS Design**: Clean typography, high-density data tables, mobile-first layouts, and Dark Mode support.

## 🛠️ Tech Stack

- React 19 + TypeScript
- Tailwind CSS v4
- Lucide React Icons
- Vite 8 Build Tool
`;

  const installContent = `# 1. Extract or clone the template
cd leadlite-india

# 2. Install dependencies (Node.js 18+ required)
npm install

# 3. Start local development server
npm run dev

# 4. Open in browser at http://localhost:3000
# 5. Build for production
npm run build
`;

  const customizeContent = `// Customizing Branding & Default Settings:
// Open: src/data/sampleData.ts

export const defaultSettings: UserSettings = {
  businessName: 'Your Agency or Studio Name',
  businessPhone: '+91 98200 12345',
  businessEmail: 'contact@yourdomain.in',
  businessCity: 'Mumbai, Maharashtra',
  businessAddress: 'Your Office Address',
  gstNumber: '27AABCU9603R1ZM',
  currency: '₹',
  defaultGstRate: 18,
  theme: 'light',
  defaultFollowUpDays: 3,
};

// Adding or changing Lead Sources:
// Open: src/types/index.ts -> LeadSource
`;

  const deployContent = `### Deploy to Vercel in 2 Minutes:
1. Push your repository to GitHub.
2. Sign in to https://vercel.com and click "Add New Project".
3. Select your repository. Vercel automatically detects Vite.
4. Output Directory: 'dist'
5. Click "Deploy". Your SaaS CRM is live!

### Deploy to Netlify:
1. Build command: npm run build
2. Publish directory: dist
3. Click "Deploy Site".
`;

  const payhipListingCopy = `Title:
LeadLite India – Complete SaaS CRM & Landing Page Template (React + Tailwind)

Subheading:
Never lose a customer inquiry again. A clean, local-storage lead & follow-up manager for Indian small businesses, agencies, and consultants.

Price Recommendation:
• Indian Market: ₹799 (Discounted from ₹1,999)
• International: $29 USD

Product Description:
Are you tired of paying $30/month for bloated Western CRMs that Indian small businesses don't need?

LeadLite India is a production-ready, full-stack React SaaS website template designed specifically for Indian freelancers, consultants, real estate brokers, and agencies.

What You Get:
✅ Complete clean React 19 + TypeScript source code
✅ High-converting SaaS Marketing Landing Page
✅ Full Working CRM Applet (Dashboard, Leads, Follow-ups, Quotes, Appointments, Reports)
✅ 1-Click WhatsApp Follow-up click-to-chat integration
✅ Quotation Generator with Indian GST slabs (0%, 5%, 12%, 18%, 28%)
✅ Printable A4 invoice & quotation layouts
✅ CSV & JSON Export / Restore
✅ Commercial License (Use for unlimited personal and client projects)
✅ Step-by-step installation and customization documentation
`;

  const licenseContent = `COMMERCIAL END-USER LICENSE AGREEMENT (EULA)

Grant of License:
By purchasing or downloading LeadLite India, you are granted a non-exclusive, perpetual, worldwide license to:
- Use this template to run your own business lead management system.
- Customize the code, design, logos, and fields for unlimited client projects.
- Host the application on any hosting provider (Vercel, Netlify, Cloudflare, AWS, etc.).

Restrictions:
- You may NOT resell, redistribute, sub-license, or share the raw template source code on marketplaces (like Payhip, ThemeForest, Gumroad) as a competing website template.
- You may NOT claim copyright ownership of the original base template architecture.
`;

  return (
    <div className="max-w-4xl space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 dark:bg-amber-900/60 dark:text-amber-200 text-[10px] font-bold uppercase tracking-wider">
              Digital Product Bundle
            </span>
            <span className="text-xs text-slate-400 font-mono">v1.0.0 Production</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Payhip & Commercial Distribution Package
          </h2>
          <p className="text-xs text-slate-500">
            Everything you need to sell or deploy LeadLite India as a digital SaaS template
          </p>
        </div>

        <button
          onClick={() => copyToClipboard(readmeContent, 'all-bundle')}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors self-start sm:self-auto"
        >
          {copiedKey === 'all-bundle' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          {copiedKey === 'all-bundle' ? 'Copied to Clipboard' : 'Copy README Asset'}
        </button>
      </div>

      {/* Package Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        {[
          { id: 'overview', label: 'Package Overview', icon: PackageCheck },
          { id: 'readme', label: 'README.md', icon: FileCode },
          { id: 'install', label: 'Installation', icon: Terminal },
          { id: 'customize', label: 'Customization', icon: Code2 },
          { id: 'deploy', label: 'Deployment', icon: Globe },
          { id: 'payhip-copy', label: 'Payhip Listing Copy', icon: Tag },
          { id: 'license', label: 'Commercial License', icon: ShieldCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                isActive
                  ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content Display */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-4">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Digital Product Architecture
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                LeadLite India is structured cleanly without bloated dependencies, proprietary API keys, or hidden credentials.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-2">
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                  📁 File Structure Highlights
                </span>
                <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-1 font-mono text-[11px]">
                  <li>• /src/context/LeadLiteContext.tsx (Local-first state)</li>
                  <li>• /src/pages/* (All 10 CRM pages + Landing page)</li>
                  <li>• /src/components/* (WhatsApp & Quotation modals)</li>
                  <li>• /src/data/sampleData.ts (Indian business seeds)</li>
                  <li>• /src/utils/helpers.ts (WhatsApp links & INR math)</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-2">
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                  💎 Monetization Strategy
                </span>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Sell this template on <strong>Payhip</strong>, <strong>Gumroad</strong>, or <strong>Topmate.io</strong> to Indian digital creators, freelancers, and small businesses looking for an easy CRM solution with zero monthly fees.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'readme' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-slate-500">README.md</span>
              <button
                onClick={() => copyToClipboard(readmeContent, 'readme')}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:underline"
              >
                {copiedKey === 'readme' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'readme' ? 'Copied' : 'Copy Content'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 text-slate-100 font-mono text-xs overflow-x-auto leading-relaxed whitespace-pre-wrap">
              {readmeContent}
            </pre>
          </div>
        )}

        {activeTab === 'install' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-slate-500">Terminal Installation Steps</span>
              <button
                onClick={() => copyToClipboard(installContent, 'install')}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:underline"
              >
                {copiedKey === 'install' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'install' ? 'Copied' : 'Copy Commands'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 text-emerald-400 font-mono text-xs overflow-x-auto leading-relaxed whitespace-pre-wrap">
              {installContent}
            </pre>
          </div>
        )}

        {activeTab === 'customize' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-slate-500">Customization Guide</span>
              <button
                onClick={() => copyToClipboard(customizeContent, 'customize')}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:underline"
              >
                {copiedKey === 'customize' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'customize' ? 'Copied' : 'Copy Guide'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 text-sky-300 font-mono text-xs overflow-x-auto leading-relaxed whitespace-pre-wrap">
              {customizeContent}
            </pre>
          </div>
        )}

        {activeTab === 'deploy' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-slate-500">One-Click Production Deployment</span>
              <button
                onClick={() => copyToClipboard(deployContent, 'deploy')}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:underline"
              >
                {copiedKey === 'deploy' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'deploy' ? 'Copied' : 'Copy Guide'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 text-slate-200 font-mono text-xs overflow-x-auto leading-relaxed whitespace-pre-wrap">
              {deployContent}
            </pre>
          </div>
        )}

        {activeTab === 'payhip-copy' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-slate-500">Payhip / Gumroad Listing Copy</span>
              <button
                onClick={() => copyToClipboard(payhipListingCopy, 'payhip-copy')}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:underline"
              >
                {copiedKey === 'payhip-copy' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'payhip-copy' ? 'Copied' : 'Copy Sales Copy'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 text-amber-300 font-mono text-xs overflow-x-auto leading-relaxed whitespace-pre-wrap">
              {payhipListingCopy}
            </pre>
          </div>
        )}

        {activeTab === 'license' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-slate-500">Commercial License Terms</span>
              <button
                onClick={() => copyToClipboard(licenseContent, 'license')}
                className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 hover:underline"
              >
                {copiedKey === 'license' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'license' ? 'Copied' : 'Copy License'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 text-slate-300 font-mono text-xs overflow-x-auto leading-relaxed whitespace-pre-wrap">
              {licenseContent}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
