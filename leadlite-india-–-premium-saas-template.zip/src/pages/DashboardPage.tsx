import React from 'react';
import {
  Users,
  UserCheck,
  ClockAlert,
  TrendingUp,
  Sparkles,
  ArrowUpRight,
  MessageSquare,
  Calendar,
  AlertCircle,
  FileText,
  ChevronRight,
  Plus,
  Phone,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import {
  formatINR,
  formatDateNice,
  getStatusStyle,
  getFollowUpUrgency,
} from '../utils/helpers';
import { Lead } from '../types';

export const DashboardPage: React.FC = () => {
  const {
    leads,
    appointments,
    quotations,
    setActivePage,
    setSelectedLead,
    setWhatsAppModalLead,
  } = useLeadLite();

  // Metrics
  const totalLeads = leads.length;
  const newLeads = leads.filter((l) => l.status === 'New').length;
  const interestedLeads = leads.filter(
    (l) => l.status === 'Interested' || l.status === 'Follow-up'
  ).length;
  const convertedLeads = leads.filter((l) => l.status === 'Converted').length;

  const overdueOrTodayFollowups = leads.filter((l) => {
    if (l.status === 'Converted' || l.status === 'Not Interested') return false;
    const u = getFollowUpUrgency(l.nextFollowUpDate);
    return u.status === 'overdue' || u.status === 'today';
  });

  const conversionRate = totalLeads > 0 ? Math.round((convertedLeads / totalLeads) * 100) : 0;

  const totalPipelineINR = leads
    .filter((l) => l.status !== 'Not Interested')
    .reduce((acc, curr) => acc + (curr.estimatedValue || 0), 0);

  const convertedValueINR = leads
    .filter((l) => l.status === 'Converted')
    .reduce((acc, curr) => acc + (curr.estimatedValue || 0), 0);

  // Recent enquiries (last 5)
  const recentLeads = [...leads]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  // Upcoming appointments
  const upcomingApts = appointments
    .filter((a) => a.status === 'Scheduled')
    .slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Sample Demo Data Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/40 text-xs text-amber-900 dark:text-amber-200">
        <div className="flex items-center gap-2">
          <span className="font-semibold px-2 py-0.5 rounded bg-amber-200/80 dark:bg-amber-900 text-amber-900 dark:text-amber-100 text-[10px] uppercase tracking-wider">
            Sample Data Active
          </span>
          <span>
            Realistic Indian business enquiries loaded. You can modify, add your real leads, or reset in Settings.
          </span>
        </div>
        <button
          onClick={() => setActivePage('add-lead')}
          className="inline-flex items-center gap-1 font-semibold text-indigo-700 dark:text-indigo-300 hover:underline shrink-0"
        >
          Add Your First Real Lead &rarr;
        </button>
      </div>

      {/* Urgent Follow-ups Alert Strip (if any) */}
      {overdueOrTodayFollowups.length > 0 && (
        <div className="p-4 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/70 dark:border-rose-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-rose-900 dark:text-rose-200">
                Action Required: {overdueOrTodayFollowups.length} Follow-ups Need Attention
              </h4>
              <p className="text-xs text-rose-700/80 dark:text-rose-300/80">
                Timely follow-ups within 24 hours increase conversion rates by up to 390% in Indian small businesses.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActivePage('followups')}
            className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 shadow-xs shrink-0 self-start sm:self-auto transition-colors"
          >
            Review Follow-ups
          </button>
        </div>
      )}

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total Leads */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Total Leads</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 tabular-nums">
              {totalLeads}
            </span>
            <span className="text-[11px] text-slate-400">All time</span>
          </div>
        </div>

        {/* New Leads */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">New Enquiries</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold tracking-tight text-sky-600 dark:text-sky-400 tabular-nums">
              {newLeads}
            </span>
            <span className="text-[11px] text-slate-400">Uncontacted</span>
          </div>
        </div>

        {/* In Pipeline / Interested */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">In Discussion</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold tracking-tight text-amber-600 dark:text-amber-400 tabular-nums">
              {interestedLeads}
            </span>
            <span className="text-[11px] text-slate-400">Active deal</span>
          </div>
        </div>

        {/* Converted Leads */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Closed Wins</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold tracking-tight text-emerald-600 dark:text-emerald-400 tabular-nums">
              {convertedLeads}
            </span>
            <span className="text-[11px] text-emerald-600 font-semibold">{conversionRate}% rate</span>
          </div>
        </div>

        {/* Overdue / Due Today */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Follow-ups Due</span>
          <div className="flex items-baseline justify-between">
            <span
              className={`text-2xl font-bold tracking-tight tabular-nums ${
                overdueOrTodayFollowups.length > 0
                  ? 'text-rose-600 dark:text-rose-400'
                  : 'text-slate-900 dark:text-slate-100'
              }`}
            >
              {overdueOrTodayFollowups.length}
            </span>
            <span className="text-[11px] text-slate-400">Due now</span>
          </div>
        </div>

        {/* Pipeline Value in INR */}
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block mb-1">Total Pipeline</span>
          <div className="flex items-baseline justify-between">
            <span className="text-lg font-bold tracking-tight text-indigo-600 dark:text-indigo-400 tabular-nums">
              {formatINR(totalPipelineINR)}
            </span>
          </div>
        </div>
      </div>

      {/* Middle Grid: Activity Visualizer & Appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Pipeline Activity & Stage Breakdown */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Monthly Lead & Deal Activity
              </h3>
              <p className="text-xs text-slate-500">
                Inquiry volume across the current quarter
              </p>
            </div>
            <button
              onClick={() => setActivePage('reports')}
              className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              Detailed Reports <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Clean SVG Activity Chart */}
          <div className="pt-2">
            <div className="h-44 w-full flex items-end justify-between gap-3 px-2">
              {[
                { month: 'Jun', count: 6, val: '₹4.2L' },
                { month: 'Jul', count: 11, val: '₹8.9L' },
                { month: 'Aug', count: 14, val: '₹12.4L' },
                { month: 'Sep', count: 19, val: '₹16.8L' },
                { month: 'Oct (Current)', count: 24, val: '₹22.5L', active: true },
              ].map((bar) => {
                const maxCount = 28;
                const heightPercent = Math.round((bar.count / maxCount) * 100);

                return (
                  <div key={bar.month} className="flex-1 flex flex-col items-center gap-2 group">
                    <span className="text-[10px] font-mono tabular-nums text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      {bar.val}
                    </span>
                    <div className="w-full max-w-16 bg-slate-100 dark:bg-slate-800 rounded-t-lg h-32 flex items-end p-1">
                      <div
                        style={{ height: `${heightPercent}%` }}
                        className={`w-full rounded-t-md transition-all duration-300 ${
                          bar.active
                            ? 'bg-indigo-600 dark:bg-indigo-500'
                            : 'bg-indigo-300 dark:bg-indigo-900/60'
                        }`}
                      />
                    </div>
                    <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                      {bar.month}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pipeline Stage Bar */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
              Lead Stage Distribution
            </span>
            <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
              <div
                style={{ width: `${(newLeads / (totalLeads || 1)) * 100}%` }}
                className="bg-sky-500 h-full"
                title={`New: ${newLeads}`}
              />
              <div
                style={{
                  width: `${(leads.filter((l) => l.status === 'Contacted').length / (totalLeads || 1)) * 100}%`,
                }}
                className="bg-indigo-500 h-full"
                title="Contacted"
              />
              <div
                style={{ width: `${(interestedLeads / (totalLeads || 1)) * 100}%` }}
                className="bg-amber-500 h-full"
                title={`Interested / Follow-up: ${interestedLeads}`}
              />
              <div
                style={{ width: `${(convertedLeads / (totalLeads || 1)) * 100}%` }}
                className="bg-emerald-500 h-full"
                title={`Converted: ${convertedLeads}`}
              />
            </div>
            <div className="flex flex-wrap items-center gap-4 mt-2 text-[11px] text-slate-500">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-sky-500" /> New ({newLeads})
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-500" /> Contacted (
                {leads.filter((l) => l.status === 'Contacted').length})
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500" /> Interested (
                {interestedLeads})
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Won ({convertedLeads})
              </span>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Upcoming Appointments & Quick Links */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Upcoming Meetings
                </h3>
              </div>
              <button
                onClick={() => setActivePage('appointments')}
                className="text-xs font-medium text-indigo-600 hover:underline"
              >
                View all ({upcomingApts.length})
              </button>
            </div>

            <div className="mt-3 space-y-3">
              {upcomingApts.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No upcoming meetings scheduled.
                </div>
              ) : (
                upcomingApts.map((apt) => (
                  <div
                    key={apt.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 dark:text-slate-100 truncate">
                        {apt.customerName}
                      </span>
                      <span className="font-mono text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold">
                        {apt.time}
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 truncate">
                      {apt.purpose}
                    </p>
                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                      <span>{formatDateNice(apt.date)}</span>
                      <span className="italic">{apt.locationType}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Quick Shortcuts */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <button
              onClick={() => setActivePage('add-lead')}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Capture New Enquiry
            </button>
            <button
              onClick={() => setActivePage('quotations')}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              Generate Quotation
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Table: Recent Customer Enquiries */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Recent Customer Enquiries
            </h3>
            <p className="text-xs text-slate-500">
              Latest leads captured across WhatsApp, Google, and referrals
            </p>
          </div>
          <button
            onClick={() => setActivePage('leads')}
            className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            View All {leads.length} Leads &rarr;
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2.5 px-3 font-semibold">Customer</th>
                <th className="py-2.5 px-3 font-semibold">Interest / Requirement</th>
                <th className="py-2.5 px-3 font-semibold">Source</th>
                <th className="py-2.5 px-3 font-semibold">Status</th>
                <th className="py-2.5 px-3 font-semibold text-right">Est. Value (₹)</th>
                <th className="py-2.5 px-3 font-semibold">Next Follow-up</th>
                <th className="py-2.5 px-3 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {recentLeads.map((lead) => {
                const statusStyle = getStatusStyle(lead.status);
                const urgency = getFollowUpUrgency(lead.nextFollowUpDate);

                return (
                  <tr
                    key={lead.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-3">
                      <div
                        onClick={() => setSelectedLead(lead)}
                        className="font-semibold text-slate-900 dark:text-slate-100 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer"
                      >
                        {lead.name}
                      </div>
                      <div className="text-[11px] text-slate-400 tabular-nums">
                        {lead.phone}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-medium text-slate-800 dark:text-slate-200 block max-w-xs truncate">
                        {lead.businessInterest}
                      </span>
                      {lead.city && (
                        <span className="text-[10px] text-slate-400">{lead.city}</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {lead.source}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span
                        className={`text-[11px] font-medium px-2 py-0.5 rounded-md ${statusStyle.bg}`}
                      >
                        {lead.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-bold tabular-nums text-slate-900 dark:text-slate-100">
                      {formatINR(lead.estimatedValue)}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span
                        className={`text-[11px] font-medium ${
                          urgency.status === 'overdue'
                            ? 'text-rose-600 font-semibold'
                            : urgency.status === 'today'
                            ? 'text-amber-600 font-semibold'
                            : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {urgency.label}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap space-x-1">
                      <button
                        onClick={() => setWhatsAppModalLead(lead)}
                        className="p-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 rounded-lg transition-colors"
                        title="Chat on WhatsApp"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setSelectedLead(lead)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                        title="View Details"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
