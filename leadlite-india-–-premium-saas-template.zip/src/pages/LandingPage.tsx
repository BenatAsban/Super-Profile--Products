import React from 'react';
import {
  ArrowRight,
  CheckCircle2,
  MessageSquare,
  Clock,
  FileSpreadsheet,
  CalendarDays,
  ShieldCheck,
  Download,
  Building,
  Sparkles,
  ExternalLink,
  Zap,
  PhoneCall,
  Check,
  ChevronRight,
  HelpCircle,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { formatINR } from '../utils/helpers';

export const LandingPage: React.FC = () => {
  const { setViewMode, setActivePage, leads } = useLeadLite();

  const handleLaunchApp = () => {
    setViewMode('app');
    setActivePage('dashboard');
  };

  const handleOpenPayhipPackage = () => {
    setViewMode('app');
    setActivePage('payhip-package');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-indigo-500 selection:text-white">
      {/* 3-Zone Top Bar Navigation */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand title */}
          <div
            onClick={handleLaunchApp}
            className="flex items-center gap-2.5 cursor-pointer shrink-0"
          >
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-xs">
              L
            </div>
            <span className="text-base font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap">
              LeadLite India
            </span>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600 dark:text-slate-400">
            <a href="#features" className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors whitespace-nowrap">
              Features
            </a>
            <a href="#solutions" className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors whitespace-nowrap">
              Who It's For
            </a>
            <a href="#how-it-works" className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors whitespace-nowrap">
              How It Works
            </a>
            <a href="#pricing" className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors whitespace-nowrap">
              Pricing (INR)
            </a>
            <a href="#faq" className="hover:text-slate-900 dark:hover:text-slate-100 transition-colors whitespace-nowrap">
              FAQ
            </a>
          </nav>

          {/* Zone 3: Primary Actions */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handleLaunchApp}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors whitespace-nowrap"
            >
              Open Live App Demo &rarr;
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-16 pb-20 md:pt-24 md:pb-28 overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/80 dark:border-indigo-800/80 text-xs font-semibold text-indigo-700 dark:text-indigo-300 mx-auto">
            <span>🇮🇳 Built specifically for Indian Small Businesses & Freelancers</span>
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 leading-[1.1] max-w-4xl mx-auto text-balance">
            Never Lose Track of a Customer Again.
          </h1>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
            A simple lead and follow-up manager built for growing Indian businesses. No bloated enterprise software, no monthly USD subscriptions, and zero complex setup.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={handleLaunchApp}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md transition-all flex items-center justify-center gap-2 group"
            >
              <span>Explore Live App Demo</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={handleOpenPayhipPackage}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl text-sm font-semibold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              View Payhip Source Template (₹799)
            </button>
          </div>

          {/* Subtext Proof Points */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500 pt-4">
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" /> WhatsApp Click-to-Chat
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" /> Indian GST Quotation Builder
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" /> 100% Private Local Storage
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" /> Zero Monthly SaaS Fees
            </span>
          </div>

          {/* Interactive Live App Teaser Box */}
          <div className="pt-10 max-w-5xl mx-auto">
            <div className="p-2 sm:p-4 rounded-3xl bg-slate-200/80 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 shadow-2xl">
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden text-left p-5 sm:p-6 space-y-4">
                {/* Teaser Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-rose-400" />
                    <div className="w-3 h-3 rounded-full bg-amber-400" />
                    <div className="w-3 h-3 rounded-full bg-emerald-400" />
                    <span className="text-xs font-mono font-semibold text-slate-400 ml-2">
                      LeadLite India – Live Pipeline Preview
                    </span>
                  </div>
                  <button
                    onClick={handleLaunchApp}
                    className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                  >
                    Open Full Workspace &rarr;
                  </button>
                </div>

                {/* 4 Mini Metric Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Total Pipeline</span>
                    <span className="text-base font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                      ₹98,80,000
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Overdue Follow-ups</span>
                    <span className="text-base font-bold text-rose-600 tabular-nums">
                      2 Urgent
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Scheduled Today</span>
                    <span className="text-base font-bold text-amber-600 tabular-nums">
                      2 Meetings
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Win Rate</span>
                    <span className="text-base font-bold text-emerald-600 tabular-nums">
                      22% Closed
                    </span>
                  </div>
                </div>

                {/* Mini Lead Row Teaser */}
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-xs">
                      RS
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                        Rajesh & Kavita Sharma (Thane West)
                      </span>
                      <span className="text-[11px] text-slate-500">
                        3BHK Modular Kitchen & Living Room Interior · Due Today
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-slate-100 font-mono tabular-nums">
                      ₹4,85,000
                    </span>
                    <button
                      onClick={handleLaunchApp}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-semibold flex items-center gap-1 shadow-2xs"
                    >
                      <MessageSquare className="w-3 h-3" /> WhatsApp
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pain Point vs Solution Section */}
      <section className="py-16 bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              Stop Losing High-Paying Customers to WhatsApp Chaos
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-2">
              Indian businesses don't need complex enterprise software with 1,000 knobs. You just need to follow up on time.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* The Old Way */}
            <div className="p-6 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400">
                ❌ The Chaos: Sticky Notes & Endless Chat Scans
              </span>
              <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-rose-500 font-bold">•</span>
                  Customer inquires on Instagram or phone call; you jot the phone number on a diary page that gets lost.
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-500 font-bold">•</span>
                  You forget to follow up for 4 days; by then, they hired a competitor who sent a quote first.
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-500 font-bold">•</span>
                  Typing long, messy price breakdowns as raw WhatsApp text messages that look unprofessional.
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-rose-500 font-bold">•</span>
                  Paying ₹2,500/month for American CRM tools with features you never use.
                </li>
              </ul>
            </div>

            {/* The LeadLite Way */}
            <div className="p-6 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                ✅ The LeadLite Solution: Simple, Fast & Disciplined
              </span>
              <ul className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  Capture lead in 20 seconds with customer name, phone, requirement, and budget.
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  Smart follow-up alerts highlight overdue inquiries every single morning.
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  1-click WhatsApp follow-ups with pre-formatted polite templates (no need to save contacts first).
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  Generate branded commercial quotations with GST calculations in 60 seconds.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 6 Key Features */}
      <section id="features" className="py-20 max-w-6xl mx-auto px-4 sm:px-6 space-y-12">
        <div className="text-center max-w-2xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            Engineered For Speed
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 mt-1">
            Everything You Need to Close Deals Faster
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center">
              <MessageSquare className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              1-Click WhatsApp Follow-ups
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Launch directly into WhatsApp Web or mobile app with pre-filled professional Indian follow-up messages. No official Meta API approval required.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950 text-rose-600 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Overdue Follow-up Alerts
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Never let an enquiry go cold. The morning dashboard categorizes follow-ups into Overdue, Due Today, and Upcoming with 1-click postponement.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Instant GST Quotation Generator
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Build itemized commercial cost estimates with automatic Indian GST slabs (0%, 5%, 12%, 18%, 28%), discounts, and printable A4 layouts.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600 flex items-center justify-center">
              <CalendarDays className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Appointments & Site Visits
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Track client meetings, measurement visits, and Zoom/Google Meet calls with 1-click WhatsApp appointment reminders.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              100% Local Storage Privacy
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Your customer data stays strictly on your computer's browser. Zero third-party cloud trackers, zero data harvesting, and complete privacy.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-2xs">
            <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 flex items-center justify-center">
              <Download className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              CSV & JSON Backup Portability
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export your pipeline to CSV spreadsheet for Microsoft Excel and create full JSON database backups anytime in 1 click.
            </p>
          </div>
        </div>
      </section>

      {/* Target Audiences / Solutions Section */}
      <section id="solutions" className="py-20 bg-slate-100/70 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-12">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Domain Tailored
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 mt-1">
              Who Is LeadLite India Built For?
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'Interior Designers & Architects',
                desc: 'Track 2BHK/3BHK residential client budgets, schedule material swatch meetings, and share itemized false ceiling & modular kitchen quotes.',
              },
              {
                title: 'Real Estate Brokers & Agents',
                desc: 'Manage resale flat buyers and commercial lease inquiries across Mumbai, Delhi, Bengaluru, and Pune. Never forget a client callback.',
              },
              {
                title: 'Chartered Accountants & Tax Advisors',
                desc: 'Keep track of annual GST audit inquiries, ITR filings, and company registration leads with structured follow-up timelines.',
              },
              {
                title: 'Freelancers & Digital Agencies',
                desc: 'Manage website design, branding, and SEO leads from Instagram and LinkedIn. Send professional quotations with 50% advance terms.',
              },
              {
                title: 'Solar & Home Improvement Vendors',
                desc: 'Organize rooftop solar subsidy leads, water purifier installations, and CCTV projects with site shadow survey appointments.',
              },
              {
                title: 'Wedding & Event Photographers',
                desc: 'Follow up on pre-wedding and corporate shoot enquiries. Share package estimates and lock in booking dates before someone else.',
              },
            ].map((persona, i) => (
              <div
                key={i}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-2xs"
              >
                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  {persona.title}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {persona.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section (Payhip Digital Template) */}
      <section id="pricing" className="py-20 max-w-4xl mx-auto px-4 sm:px-6 space-y-12">
        <div className="text-center max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
            Honest Pricing
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100 mt-1">
            One-Time Purchase. No Monthly Subscriptions.
          </h2>
          <p className="text-xs text-slate-500 mt-2">
            Why pay $20 every single month when you can own the full React source code forever?
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Free Demo Experience */}
          <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-6 shadow-2xs">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Interactive Preview
              </span>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mt-1">
                Live Browser Demo
              </h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-3xl font-extrabold text-slate-900 dark:text-slate-100">
                  ₹0
                </span>
                <span className="text-xs text-slate-400">/ test in your browser</span>
              </div>
              <ul className="mt-6 space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" /> Full working dashboard
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" /> Preloaded Indian business demo data
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" /> WhatsApp click-to-chat links
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" /> Test quotation builder
                </li>
              </ul>
            </div>

            <button
              onClick={handleLaunchApp}
              className="w-full py-3 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition-colors"
            >
              Open Live App Now
            </button>
          </div>

          {/* Payhip Template Package */}
          <div className="p-8 rounded-3xl bg-indigo-600 text-white flex flex-col justify-between space-y-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-4 right-4 bg-indigo-500 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full">
              Commercial License
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-200">
                Payhip Digital Package
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                Full Source Code & Template
              </h3>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-white">
                  ₹799
                </span>
                <span className="text-xs text-indigo-200 line-through">₹1,999</span>
                <span className="text-xs text-indigo-200">or $29 USD</span>
              </div>
              <ul className="mt-6 space-y-2.5 text-xs text-indigo-100">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-300" /> Complete React 19 + TypeScript source
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-300" /> Marketing Landing Page + Full CRM App
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-300" /> Deploy to Vercel / Netlify in 2 mins
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-300" /> Use for unlimited personal & client projects
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-300" /> Complete README & installation guide
                </li>
              </ul>
            </div>

            <button
              onClick={handleOpenPayhipPackage}
              className="w-full py-3 rounded-xl text-xs font-bold text-indigo-900 bg-white hover:bg-indigo-50 shadow-md transition-colors"
            >
              Inspect Digital Product Package
            </button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                How does WhatsApp Click-to-Chat work?
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                LeadLite generates standard wa.me URLs using the customer's phone number and pre-formatted text. It opens WhatsApp Web or your mobile app directly. You don't need a Meta business API key.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                Where is customer data stored?
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Data is stored right in your browser's localStorage. It never leaves your device. You can download CSV and full JSON database backups at any time.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                Can I use this for client websites?
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Yes! The commercial license allows you to deploy and customize this template for unlimited personal and client projects.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final Call to Action Strip */}
      <section className="py-16 bg-slate-950 text-white text-center space-y-6">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-4">
          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
            Ready to Streamline Your Customer Follow-ups?
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
            Test the live application right now in your browser with realistic Indian business demo data.
          </p>
          <div className="pt-2">
            <button
              onClick={handleLaunchApp}
              className="px-8 py-3.5 rounded-xl text-xs font-bold text-slate-950 bg-white hover:bg-slate-100 shadow-lg transition-colors"
            >
              Launch Live Application Demo &rarr;
            </button>
          </div>
        </div>
      </section>

      {/* Minimal Footer */}
      <footer className="py-8 bg-slate-900 border-t border-slate-800 text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span>&copy; {new Date().getFullYear()} LeadLite India. All rights reserved.</span>
          <div className="flex items-center gap-4">
            <button onClick={handleLaunchApp} className="hover:text-slate-300">
              Live Applet
            </button>
            <button onClick={handleOpenPayhipPackage} className="hover:text-slate-300">
              Payhip Template Package
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
