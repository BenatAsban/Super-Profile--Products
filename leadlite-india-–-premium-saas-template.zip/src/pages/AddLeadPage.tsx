import React, { useState } from 'react';
import {
  UserPlus,
  CheckCircle,
  Phone,
  Mail,
  Calendar,
  IndianRupee,
  MapPin,
  FileText,
  Tag,
  Sparkles,
  ArrowLeft,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { LeadStatus, LeadSource } from '../types';

export const AddLeadPage: React.FC = () => {
  const { addLead, setActivePage, setSelectedLead, settings } = useLeadLite();

  // Helper for default follow-up date (today + defaultFollowUpDays)
  const getDefaultFollowUpDate = () => {
    const d = new Date();
    d.setDate(d.getDate() + (settings.defaultFollowUpDays || 3));
    return d.toISOString().split('T')[0];
  };

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    businessInterest: '',
    source: 'WhatsApp Direct' as LeadSource,
    status: 'New' as LeadStatus,
    estimatedValue: '',
    nextFollowUpDate: getDefaultFollowUpDate(),
    city: '',
    initialNote: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [successMsg, setSuccessMsg] = useState(false);

  const statuses: LeadStatus[] = [
    'New',
    'Contacted',
    'Interested',
    'Follow-up',
    'Converted',
    'Not Interested',
  ];

  const sources: LeadSource[] = [
    'WhatsApp Direct',
    'Instagram',
    'Google Search',
    'Referral',
    'Walk-in',
    'IndiaMART / Justdial',
    'LinkedIn',
    'Facebook Ads',
    'Other',
  ];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) {
      errs.name = 'Customer full name is required';
    }
    if (!formData.phone.trim()) {
      errs.phone = 'Customer phone number is required';
    } else {
      const clean = formData.phone.replace(/\D/g, '');
      if (clean.length < 10) {
        errs.phone = 'Please enter a valid 10-digit mobile number';
      }
    }
    if (!formData.businessInterest.trim()) {
      errs.businessInterest = 'Please describe the service, product or requirement';
    }
    if (!formData.nextFollowUpDate) {
      errs.nextFollowUpDate = 'Please select a follow-up date';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Clean phone number format: ensure +91 prefix
    let cleanPhone = formData.phone.trim();
    const digits = cleanPhone.replace(/\D/g, '');
    if (digits.length === 10) {
      cleanPhone = `+91 ${digits.slice(0, 5)} ${digits.slice(5)}`;
    } else if (digits.length === 12 && digits.startsWith('91')) {
      cleanPhone = `+91 ${digits.slice(2, 7)} ${digits.slice(7)}`;
    }

    const createdLead = addLead({
      name: formData.name.trim(),
      phone: cleanPhone,
      email: formData.email.trim() || undefined,
      businessInterest: formData.businessInterest.trim(),
      source: formData.source,
      status: formData.status,
      estimatedValue: Number(formData.estimatedValue) || 0,
      nextFollowUpDate: formData.nextFollowUpDate,
      city: formData.city.trim() || undefined,
      initialNote: formData.initialNote.trim() || undefined,
    });

    setSuccessMsg(true);
    setTimeout(() => {
      setSelectedLead(createdLead);
      setActivePage('leads');
    }, 900);
  };

  const fillQuickPreset = (type: 'interior' | 'agency' | 'property') => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    const dateStr = d.toISOString().split('T')[0];

    if (type === 'interior') {
      setFormData({
        name: 'Arjun & Sneha Singhal',
        phone: '9820987654',
        email: 'arjun.singhal@rediffmail.com',
        businessInterest: 'Complete Modular Wardrobes & False Ceiling for 2BHK',
        source: 'Instagram',
        status: 'Interested',
        estimatedValue: '350000',
        nextFollowUpDate: dateStr,
        city: 'Thane, Mumbai',
        initialNote: 'Seen our Instagram reel. Wants Italian laminate finish samples.',
      });
    } else if (type === 'agency') {
      setFormData({
        name: 'Gaurav Khanna (Apex Logistics)',
        phone: '9811099887',
        email: 'gaurav@apexlogistics.in',
        businessInterest: 'Corporate Branding, GST Invoice Portal & SEO',
        source: 'Google Search',
        status: 'Contacted',
        estimatedValue: '95000',
        nextFollowUpDate: dateStr,
        city: 'Gurugram',
        initialNote: 'Needs quote for company profile redesign and Google Business listing.',
      });
    } else {
      setFormData({
        name: 'Meenakshi Sundaram',
        phone: '9840122334',
        email: 'meenakshi.s@gmail.com',
        businessInterest: 'Villa Plot in ECR Road / Residential Inquiry',
        source: 'WhatsApp Direct',
        status: 'Follow-up',
        estimatedValue: '4500000',
        nextFollowUpDate: dateStr,
        city: 'Chennai',
        initialNote: 'Looking for 2400 sq.ft gated community plot with immediate registration.',
      });
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <button
            onClick={() => setActivePage('leads')}
            className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Leads
          </button>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Register New Customer Enquiry
          </h2>
          <p className="text-xs text-slate-500">
            Record customer contact, interest, budget, and schedule the first follow-up
          </p>
        </div>

        {/* Quick Demo Pre-fill */}
        <div className="hidden sm:flex items-center gap-1.5 text-xs">
          <span className="text-slate-400">Quick fill demo:</span>
          <button
            type="button"
            onClick={() => fillQuickPreset('interior')}
            className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-[11px] font-medium"
          >
            Interior
          </button>
          <button
            type="button"
            onClick={() => fillQuickPreset('agency')}
            className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-[11px] font-medium"
          >
            Agency
          </button>
          <button
            type="button"
            onClick={() => fillQuickPreset('property')}
            className="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-[11px] font-medium"
          >
            Real Estate
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3 animate-in fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-600" />
          <span className="text-xs font-semibold">
            Customer enquiry saved successfully! Opening lead records...
          </span>
        </div>
      )}

      {/* Main Form Card */}
      <form
        onSubmit={handleSubmit}
        className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs space-y-6"
      >
        {/* Section 1: Customer Contact Details */}
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
            01. Customer Contact Information
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Customer Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Customer / Business Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Ramesh Kulkarni / Godrej Interiors"
                className={`w-full text-xs px-3.5 py-2.5 rounded-xl border ${
                  errors.name ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                } bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500`}
              />
              {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name}</p>}
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                WhatsApp / Mobile Number <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="e.g. 98200 12345 or +91 98200 12345"
                  className={`w-full text-xs px-3.5 py-2.5 rounded-xl border ${
                    errors.phone ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  } bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500`}
                />
              </div>
              {errors.phone ? (
                <p className="text-[11px] text-rose-500 mt-1">{errors.phone}</p>
              ) : (
                <p className="text-[10px] text-slate-400 mt-1">
                  Enables 1-click WhatsApp follow-up messaging
                </p>
              )}
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Email Address (Optional)
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="e.g. ramesh@gmail.com"
                className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* City */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                City / Location
              </label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                placeholder="e.g. Mumbai, Bengaluru, Pune, Delhi"
                className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Requirement & Commercials */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
            02. Business Requirement & Deal Scope
          </h3>

          <div className="space-y-4">
            {/* Requirement / Service */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Service / Product Interested In <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={formData.businessInterest}
                onChange={(e) => setFormData({ ...formData, businessInterest: e.target.value })}
                placeholder="e.g. 3BHK Modular Kitchen, GST Audit, SEO Retainer, Rooftop Solar"
                className={`w-full text-xs px-3.5 py-2.5 rounded-xl border ${
                  errors.businessInterest
                    ? 'border-rose-500'
                    : 'border-slate-200 dark:border-slate-700'
                } bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500`}
              />
              {errors.businessInterest && (
                <p className="text-[11px] text-rose-500 mt-1">{errors.businessInterest}</p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Estimated Value */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Estimated Value (₹ INR)
                </label>
                <input
                  type="number"
                  min="0"
                  step="1000"
                  value={formData.estimatedValue}
                  onChange={(e) => setFormData({ ...formData, estimatedValue: e.target.value })}
                  placeholder="e.g. 150000"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-mono tabular-nums"
                />
              </div>

              {/* Source */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Lead Source
                </label>
                <select
                  value={formData.source}
                  onChange={(e) => setFormData({ ...formData, source: e.target.value as any })}
                  className="w-full text-xs px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
                >
                  {sources.map((src) => (
                    <option key={src} value={src}>
                      {src}
                    </option>
                  ))}
                </select>
              </div>

              {/* Pipeline Status */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Initial Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full text-xs px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
                >
                  {statuses.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Follow-up Scheduling & Notes */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
            03. Next Follow-up & Discussion Notes
          </h3>

          <div className="space-y-4">
            {/* Follow-up Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Next Follow-up Date <span className="text-rose-500">*</span>
              </label>
              <div className="flex flex-wrap items-center gap-3">
                <input
                  type="date"
                  value={formData.nextFollowUpDate}
                  onChange={(e) => setFormData({ ...formData, nextFollowUpDate: e.target.value })}
                  className="text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
                />
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-slate-400">Quick set:</span>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date();
                      setFormData({ ...formData, nextFollowUpDate: d.toISOString().split('T')[0] });
                    }}
                    className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[11px]"
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date();
                      d.setDate(d.getDate() + 1);
                      setFormData({ ...formData, nextFollowUpDate: d.toISOString().split('T')[0] });
                    }}
                    className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[11px]"
                  >
                    Tomorrow
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date();
                      d.setDate(d.getDate() + 3);
                      setFormData({ ...formData, nextFollowUpDate: d.toISOString().split('T')[0] });
                    }}
                    className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[11px]"
                  >
                    +3 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date();
                      d.setDate(d.getDate() + 7);
                      setFormData({ ...formData, nextFollowUpDate: d.toISOString().split('T')[0] });
                    }}
                    className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[11px]"
                  >
                    +1 Week
                  </button>
                </div>
              </div>
            </div>

            {/* Initial Note */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Initial Conversation / Requirements Note
              </label>
              <textarea
                rows={3}
                value={formData.initialNote}
                onChange={(e) => setFormData({ ...formData, initialNote: e.target.value })}
                placeholder="Log key discussion points, customer preferences, budget limits, or specific questions asked..."
                className="w-full text-xs p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setActivePage('leads')}
            className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            Save & Schedule Follow-up
          </button>
        </div>
      </form>
    </div>
  );
};
