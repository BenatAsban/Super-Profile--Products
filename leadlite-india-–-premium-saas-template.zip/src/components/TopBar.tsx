import React, { useState } from 'react';
import {
  Menu,
  X,
  Search,
  Plus,
  Sun,
  Moon,
  ExternalLink,
  Download,
  RotateCcw,
  PackageCheck,
  ChevronRight,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { ActivePage } from '../types';

export const TopBar: React.FC = () => {
  const {
    activePage,
    setActivePage,
    viewMode,
    setViewMode,
    settings,
    updateSettings,
    searchQuery,
    setSearchQuery,
    resetToSampleData,
    leads,
  } = useLeadLite();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getPageTitle = (page: ActivePage): string => {
    switch (page) {
      case 'dashboard':
        return 'Dashboard Overview';
      case 'leads':
        return 'All Customer Leads';
      case 'add-lead':
        return 'Register New Lead';
      case 'followups':
        return 'Follow-up Pipeline';
      case 'appointments':
        return 'Scheduled Appointments';
      case 'quotations':
        return 'Quotation Builder';
      case 'reports':
        return 'Analytics & Conversion Reports';
      case 'settings':
        return 'Business & Storage Settings';
      case 'guide':
        return 'LeadLite Operating Manual';
      case 'payhip-package':
        return 'Payhip Product Package';
    }
  };

  const toggleTheme = () => {
    updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' });
  };

  const navItems: { id: ActivePage; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'leads', label: 'Leads' },
    { id: 'followups', label: 'Follow-ups' },
    { id: 'appointments', label: 'Appointments' },
    { id: 'quotations', label: 'Quotations' },
    { id: 'reports', label: 'Reports' },
    { id: 'payhip-package', label: 'Payhip Bundle' },
  ];

  return (
    <header className="no-print sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="flex items-center justify-between gap-4 px-4 sm:px-6 h-16">
        {/* Zone 1: Brand / Breadcrumb */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-lg"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2 truncate">
            <span
              onClick={() => setActivePage('dashboard')}
              className="text-sm font-bold tracking-tight text-slate-900 dark:text-slate-100 cursor-pointer hidden sm:inline whitespace-nowrap shrink-0"
            >
              LeadLite India
            </span>
            <span className="text-slate-300 dark:text-slate-700 hidden sm:inline">/</span>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 truncate">
              {getPageTitle(activePage)}
            </span>
          </div>
        </div>

        {/* Zone 2: Search or Mode Switch */}
        <div className="hidden lg:flex items-center gap-2 flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (activePage !== 'leads' && e.target.value.trim()) {
                  setActivePage('leads');
                }
              }}
              placeholder="Search by customer name, phone, or service..."
              className="w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition-all"
            />
          </div>
        </div>

        {/* Zone 3: Actions (Theme, View Landing, New Lead CTA) */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Landing Page Button */}
          <button
            onClick={() => setViewMode('landing')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            <span>Public Site</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Toggle theme"
          >
            {settings.theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-600" />
            )}
          </button>

          {/* Primary Action Button */}
          <button
            onClick={() => setActivePage('add-lead')}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Lead</span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-2">
          <div className="relative mb-3">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setActivePage('leads');
                setMobileMenuOpen(false);
              }}
              placeholder="Search leads..."
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActivePage(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`text-left px-3 py-2 text-xs font-semibold rounded-lg ${
                  activePage === item.id
                    ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between">
            <button
              onClick={() => {
                setViewMode('landing');
                setMobileMenuOpen(false);
              }}
              className="text-xs text-indigo-600 dark:text-indigo-400 font-medium flex items-center gap-1"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Visit Landing Page
            </button>

            <button
              onClick={() => {
                resetToSampleData();
                setMobileMenuOpen(false);
              }}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              Reset Demo
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
