import React, { useState, useEffect } from 'react';
import { MessageSquare, X, Send, Copy, Check, ExternalLink, Sparkles } from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { buildWhatsAppLink, getWhatsAppTemplates, formatPhoneForWhatsApp } from '../utils/helpers';

export const WhatsAppModal: React.FC = () => {
  const { whatsAppModalLead, setWhatsAppModalLead, settings, addLeadNote } = useLeadLite();
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('initial-greeting');
  const [customMessage, setCustomMessage] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (whatsAppModalLead) {
      const templates = getWhatsAppTemplates(whatsAppModalLead, settings);
      const defaultTpl = templates.find((t) => t.id === selectedTemplateId) || templates[0];
      setCustomMessage(defaultTpl.message);
    }
  }, [whatsAppModalLead, selectedTemplateId, settings]);

  if (!whatsAppModalLead) return null;

  const templates = getWhatsAppTemplates(whatsAppModalLead, settings);
  const waUrl = buildWhatsAppLink(whatsAppModalLead.phone, customMessage);
  const formattedDigits = formatPhoneForWhatsApp(whatsAppModalLead.phone);

  const handleOpenWhatsApp = () => {
    // Add an automatic note in the lead history for accountability
    addLeadNote(
      whatsAppModalLead.id,
      `WhatsApp message launched: "${customMessage.slice(0, 80)}..."`
    );
    window.open(waUrl, '_blank', 'noopener,noreferrer');
    setWhatsAppModalLead(null);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(customMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100">
                WhatsApp Follow-up
              </h3>
              <p className="text-xs text-slate-500">
                Direct Click-to-Chat with {whatsAppModalLead.name} (+{formattedDigits})
              </p>
            </div>
          </div>
          <button
            onClick={() => setWhatsAppModalLead(null)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          {/* Transparency Notice */}
          <div className="px-3.5 py-2.5 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/50 text-xs text-emerald-800 dark:text-emerald-300">
            <strong>Direct Click-to-Chat:</strong> Uses standard WhatsApp wa.me link. Opens WhatsApp Web or your phone app directly. No third-party API subscriptions or verified business accounts needed.
          </div>

          {/* Preset Template Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
              Select Message Template
            </label>
            <div className="grid grid-cols-2 gap-2">
              {templates.map((tpl) => (
                <button
                  key={tpl.id}
                  onClick={() => {
                    setSelectedTemplateId(tpl.id);
                    setCustomMessage(tpl.message);
                  }}
                  className={`text-left p-2.5 rounded-lg text-xs font-medium border transition-colors ${
                    selectedTemplateId === tpl.id
                      ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  {tpl.title}
                </button>
              ))}
            </div>
          </div>

          {/* Editable Text Area */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
                Message Preview (Editable)
              </label>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy Text'}
              </button>
            </div>
            <textarea
              rows={5}
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="w-full text-sm p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              placeholder="Type your message..."
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setWhatsAppModalLead(null)}
            className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleOpenWhatsApp}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs transition-colors"
          >
            <Send className="w-4 h-4" />
            Open in WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
};
