import React from 'react';
import {
  LayoutDashboard,
  Users,
  UserPlus,
  Clock,
  CalendarDays,
  FileSpreadsheet,
  BarChart3,
  Settings,
  HelpCircle,
  PackageCheck,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Sparkles,
  Zap,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { ActivePage } from '../types';
import { getFollowUpUrgency } from '../utils/helpers';

export const Sidebar: React.FC = () => {
  const {
    activePage,
    setActivePage,
    isSidebarCollapsed,
    setIsSidebarCollapsed,
    leads,
    appointments,
    settings,
    setViewMode,
  } = useLeadLite();

  // Calculate urgency counts
  const pendingFollowupsCount = leads.filter((l) => {
    if (l.status === 'Converted' || l.status === 'Not Interested') return false;
    const u = getFollowUpUrgency(l.nextFollowUpDate);
    return u.status === 'overdue' || u.status === 'today';
  }).length;

  const upcomingAppointmentsCount = appointments.filter(
    (a) => a.status === 'Scheduled'
  ).length;

  const navItems: {
    id: ActivePage;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number | string;
    badgeColor?: string;
  }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'leads', label: 'All Leads', icon: Users, badge: leads.length },
    { id: 'add-lead', label: 'Add New Lead', icon: UserPlus },
    {
      id: 'followups',
      label: 'Follow-ups',
      icon: Clock,
      badge: pendingFollowupsCount > 0 ? pendingFollowupsCount : undefined,
      badgeColor: 'bg-rose-500 text-white',
    },
    {
      id: 'appointments',
      label: 'Appointments',
      icon: CalendarDays,
      badge: upcomingAppointmentsCount > 0 ? upcomingAppointmentsCount : undefined,
      badgeColor: 'bg-indigo-500 text-white',
    },
    { id: 'quotations', label: 'Quotations', icon: FileSpreadsheet },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'guide', label: 'Help & Guide', icon: HelpCircle },
    {
      id: 'payhip-package',
      label: 'Payhip Digital Package',
      icon: PackageCheck,
      badge: 'Package',
      badgeColor: 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300',
    },
  ];

  return (
    <aside
      className={`no-print hidden md:flex flex-col bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-all duration-200 shrink-0 select-none ${
        isSidebarCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-slate-200 dark:border-slate-800">
        {!isSidebarCollapsed && (
          <div
            onClick={() => setActivePage('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-xs">
              L
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 text-sm tracking-tight block">
                LeadLite India
              </span>
              <span className="text-[10px] text-slate-500 font-medium uppercase tracking-wider block">
                SaaS CRM Template
              </span>
            </div>
          </div>
        )}

        {isSidebarCollapsed && (
          <div
            onClick={() => setActivePage('dashboard')}
            className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-sm mx-auto cursor-pointer"
          >
            L
          </div>
        )}

        <button
          onClick={() => setIsSidebarCollapsed((prev) => !prev)}
          className={`p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
            isSidebarCollapsed ? 'mx-auto mt-2' : ''
          }`}
          title={isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isSidebarCollapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <ChevronLeft className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors group relative ${
                isActive
                  ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-100'
              } ${isSidebarCollapsed ? 'justify-center px-0' : ''}`}
              title={isSidebarCollapsed ? item.label : undefined}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-colors ${
                  isActive
                    ? 'text-indigo-600 dark:text-indigo-400'
                    : 'text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300'
                }`}
              />

              {!isSidebarCollapsed && (
                <>
                  <span className="truncate flex-1 text-left">{item.label}</span>
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                        item.badgeColor ||
                        'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </>
              )}

              {isSidebarCollapsed && item.badge !== undefined && (
                <span className="absolute top-1.5 right-2 w-2 h-2 rounded-full bg-rose-500" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Switch to Landing Page & User Info */}
      <div className="p-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
        {!isSidebarCollapsed ? (
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-semibold text-slate-800 dark:text-slate-200 truncate">
                {settings.businessName || 'My Business'}
              </span>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono">
                Active
              </span>
            </div>
            <button
              onClick={() => setViewMode('landing')}
              className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-[11px] font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <ExternalLink className="w-3 h-3 text-slate-400" />
              View Landing Page
            </button>
          </div>
        ) : (
          <button
            onClick={() => setViewMode('landing')}
            className="w-full p-2.5 flex items-center justify-center text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="View Public Landing Page"
          >
            <ExternalLink className="w-4 h-4" />
          </button>
        )}
      </div>
    </aside>
  );
};
