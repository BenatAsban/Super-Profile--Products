import React, { useState } from 'react';
import {
  X,
  Phone,
  Mail,
  Calendar,
  IndianRupee,
  MapPin,
  Clock,
  MessageSquare,
  FileText,
  CalendarDays,
  Plus,
  Trash2,
  CheckCircle2,
  Tag,
  Share2,
} from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { LeadStatus } from '../types';
import {
  formatINR,
  formatDateNice,
  getStatusStyle,
  getFollowUpUrgency,
} from '../utils/helpers';

export const LeadDetailModal: React.FC = () => {
  const {
    selectedLead,
    setSelectedLead,
    updateLead,
    deleteLead,
    addLeadNote,
    updateFollowUpDate,
    setWhatsAppModalLead,
    setActivePage,
  } = useLeadLite();

  const [newNote, setNewNote] = useState('');
  const [isEditingFollowUp, setIsEditingFollowUp] = useState(false);
  const [customDate, setCustomDate] = useState('');
  const [rescheduleNote, setRescheduleNote] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (!selectedLead) return null;

  const statusStyle = getStatusStyle(selectedLead.status);
  const urgency = getFollowUpUrgency(selectedLead.nextFollowUpDate);

  const statuses: LeadStatus[] = [
    'New',
    'Contacted',
    'Interested',
    'Follow-up',
    'Converted',
    'Not Interested',
  ];

  const handleStatusChange = (newStatus: LeadStatus) => {
    updateLead(selectedLead.id, { status: newStatus });
    addLeadNote(selectedLead.id, `Status updated to "${newStatus}"`);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    addLeadNote(selectedLead.id, newNote.trim());
    setNewNote('');
  };

  const handleQuickReschedule = (daysToAdd: number) => {
    const d = new Date();
    d.setDate(d.getDate() + daysToAdd);
    const dateStr = d.toISOString().split('T')[0];
    updateFollowUpDate(selectedLead.id, dateStr, `Quick postponed by ${daysToAdd} days`);
    setIsEditingFollowUp(false);
  };

  const handleCustomReschedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customDate) return;
    updateFollowUpDate(selectedLead.id, customDate, rescheduleNote || undefined);
    setIsEditingFollowUp(false);
    setRescheduleNote('');
  };

  const handleDelete = () => {
    deleteLead(selectedLead.id);
    setSelectedLead(null);
  };

  const handleCreateQuotation = () => {
    setSelectedLead(null);
    setActivePage('quotations');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
        {/* Top Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1 text-xs text-slate-500">
              <span>{selectedLead.source}</span>
              <span aria-hidden="true">·</span>
              <span>Added {formatDateNice(selectedLead.createdAt)}</span>
              {selectedLead.isSample && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-600 dark:text-amber-400 font-medium">Demo Lead</span>
                </>
              )}
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
              {selectedLead.name}
            </h2>
            <p className="text-sm font-medium text-indigo-600 dark:text-indigo-400 mt-0.5">
              {selectedLead.businessInterest}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedLead(null)}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-500">Status:</span>
            <select
              value={selectedLead.status}
              onChange={(e) => handleStatusChange(e.target.value as LeadStatus)}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
            >
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setWhatsAppModalLead(selectedLead)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              WhatsApp
            </button>
            <button
              onClick={handleCreateQuotation}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              Build Quote
            </button>
          </div>
        </div>

        {/* Content Details */}
        <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
          {/* Key Metrics Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
            <div>
              <span className="text-xs text-slate-500 block mb-1">Estimated Value</span>
              <span className="text-base font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                {formatINR(selectedLead.estimatedValue)}
              </span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block mb-1">Follow-up Urgency</span>
              <span
                className={`text-xs font-semibold block capitalize ${
                  urgency.status === 'overdue'
                    ? 'text-rose-600 dark:text-rose-400'
                    : urgency.status === 'today'
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {urgency.label}
              </span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block mb-1">Contact Phone</span>
              <span className="text-xs font-medium text-slate-900 dark:text-slate-100 tabular-nums">
                {selectedLead.phone}
              </span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block mb-1">City / Region</span>
              <span className="text-xs font-medium text-slate-900 dark:text-slate-100">
                {selectedLead.city || 'Not specified'}
              </span>
            </div>
          </div>

          {/* Follow-up Rescheduling Box */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                  Next Follow-up Date: {selectedLead.nextFollowUpDate || 'None set'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsEditingFollowUp(!isEditingFollowUp)}
                className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                {isEditingFollowUp ? 'Close Reschedule' : 'Reschedule Date'}
              </button>
            </div>

            {isEditingFollowUp && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-slate-500 self-center">Quick Pick:</span>
                  <button
                    onClick={() => handleQuickReschedule(0)}
                    className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                  >
                    Today
                  </button>
                  <button
                    onClick={() => handleQuickReschedule(1)}
                    className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                  >
                    Tomorrow
                  </button>
                  <button
                    onClick={() => handleQuickReschedule(3)}
                    className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                  >
                    +3 Days
                  </button>
                  <button
                    onClick={() => handleQuickReschedule(7)}
                    className="px-2.5 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                  >
                    +1 Week
                  </button>
                </div>

                <form onSubmit={handleCustomReschedule} className="flex gap-2">
                  <input
                    type="date"
                    value={customDate}
                    onChange={(e) => setCustomDate(e.target.value)}
                    className="text-xs px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                  <input
                    type="text"
                    placeholder="Reason (optional)"
                    value={rescheduleNote}
                    onChange={(e) => setRescheduleNote(e.target.value)}
                    className="text-xs px-3 py-1.5 flex-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
                  >
                    Save
                  </button>
                </form>
              </div>
            )}
          </div>

          {/* Customer History & Notes */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
              Conversation & Follow-up History ({selectedLead.notes.length})
            </h4>

            {/* Add Note Form */}
            <form onSubmit={handleAddNote} className="mb-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Log a call, meeting result, or WhatsApp update..."
                  className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  disabled={!newNote.trim()}
                  className="inline-flex items-center gap-1 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-xl transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Note
                </button>
              </div>
            </form>

            {/* Notes List */}
            {selectedLead.notes.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-3 text-center">
                No notes logged yet. Use the field above to record discussions.
              </p>
            ) : (
              <div className="space-y-2.5">
                {selectedLead.notes.map((note) => (
                  <div
                    key={note.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs"
                  >
                    <div className="flex items-center justify-between text-slate-400 mb-1">
                      <span className="font-mono text-[11px] tabular-nums">
                        {note.timestamp}
                      </span>
                    </div>
                    <p className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap">
                      {note.text}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800">
          <div>
            {!confirmDelete ? (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 font-medium"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete Lead
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <span className="text-xs text-rose-600 font-medium">Confirm delete?</span>
                <button
                  type="button"
                  onClick={handleDelete}
                  className="px-2.5 py-1 text-xs font-semibold text-white bg-rose-600 rounded-md hover:bg-rose-700"
                >
                  Yes, Delete
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="px-2 py-1 text-xs text-slate-500"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => setSelectedLead(null)}
            className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
