import React, { useRef } from 'react';
import { X, Printer, Share2, Download, Building, Phone, Mail, MapPin, IndianRupee } from 'lucide-react';
import { useLeadLite } from '../context/LeadLiteContext';
import { formatINR, formatDateNice, buildWhatsAppLink } from '../utils/helpers';

export const QuotationPrintModal: React.FC = () => {
  const { selectedQuotation, setSelectedQuotation, settings } = useLeadLite();
  const printRef = useRef<HTMLDivElement>(null);

  if (!selectedQuotation) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleShareWhatsApp = () => {
    const summaryLines = [
      `*QUOTATION: ${selectedQuotation.quotationNumber}*`,
      `From: ${selectedQuotation.businessName || settings.businessName}`,
      `To: ${selectedQuotation.customerName}`,
      `Date: ${formatDateNice(selectedQuotation.date)}`,
      '',
      '*Items / Scope:*',
      ...selectedQuotation.items.map(
        (it, idx) => `${idx + 1}. ${it.description} (x${it.quantity}) - ${formatINR(it.amount)}`
      ),
      '',
      `Subtotal: ${formatINR(selectedQuotation.subtotal)}`,
      selectedQuotation.discountAmount > 0 ? `Discount: -${formatINR(selectedQuotation.discountAmount)}` : '',
      selectedQuotation.isGstEnabled ? `GST (${selectedQuotation.gstRate}%): ${formatINR(selectedQuotation.gstAmount)}` : '',
      `*Grand Total: ${formatINR(selectedQuotation.totalAmount)}*`,
      '',
      selectedQuotation.notes ? `Note: ${selectedQuotation.notes}` : '',
      '',
      'Generated via LeadLite India',
    ]
      .filter(Boolean)
      .join('\n');

    const link = buildWhatsAppLink(selectedQuotation.customerPhone, summaryLines);
    window.open(link, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      {/* Container */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl my-8 overflow-hidden print-container">
        {/* Modal Controls (Hidden in print) */}
        <div className="no-print flex items-center justify-between px-6 py-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Quotation Preview & Print
            </span>
            <span className="text-xs font-mono font-medium bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded text-slate-700 dark:text-slate-300">
              {selectedQuotation.quotationNumber}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShareWhatsApp}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              Send on WhatsApp
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={() => setSelectedQuotation(null)}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Quotation Sheet */}
        <div ref={printRef} className="p-8 sm:p-12 bg-white text-slate-900 space-y-8">
          {/* Top Brand & Quotation Number */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-6 pb-6 border-b border-slate-200">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                {selectedQuotation.businessName || settings.businessName || 'Business Name'}
              </h1>
              <p className="text-xs text-slate-600 mt-1 max-w-sm">
                {selectedQuotation.businessAddress || settings.businessAddress}
              </p>
              <div className="flex flex-wrap gap-4 mt-2 text-xs text-slate-600">
                <span>Phone: {selectedQuotation.businessPhone || settings.businessPhone}</span>
                {settings.businessEmail && <span>Email: {settings.businessEmail}</span>}
              </div>
              {(selectedQuotation.gstNumber || settings.gstNumber) && (
                <div className="mt-1 text-xs font-mono font-medium text-slate-700">
                  GSTIN: {selectedQuotation.gstNumber || settings.gstNumber}
                </div>
              )}
            </div>

            <div className="sm:text-right">
              <span className="text-xs uppercase font-bold tracking-wider text-indigo-700 block">
                COMMERCIAL ESTIMATE
              </span>
              <div className="text-xl font-bold font-mono tracking-tight text-slate-900 mt-0.5">
                {selectedQuotation.quotationNumber}
              </div>
              <div className="text-xs text-slate-500 mt-2 space-y-0.5">
                <div>Date: {formatDateNice(selectedQuotation.date)}</div>
                <div>Valid Until: {formatDateNice(selectedQuotation.validUntil)}</div>
              </div>
            </div>
          </div>

          {/* Customer Bill To */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-[11px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
                Quotation Prepared For
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                {selectedQuotation.customerName}
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Phone: {selectedQuotation.customerPhone}
              </p>
              {selectedQuotation.customerEmail && (
                <p className="text-xs text-slate-600">
                  Email: {selectedQuotation.customerEmail}
                </p>
              )}
              {selectedQuotation.customerAddress && (
                <p className="text-xs text-slate-600 mt-1">
                  {selectedQuotation.customerAddress}
                </p>
              )}
            </div>

            <div className="sm:text-right flex flex-col justify-end">
              <span className="text-[11px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
                Currency & Terms
              </span>
              <p className="text-xs font-medium text-slate-800">
                Indian Rupees (INR)
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Payment Milestone: 50% Advance / Balance upon milestone delivery
              </p>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-900 text-slate-900">
                  <th className="py-2.5 font-bold uppercase tracking-wider w-10">#</th>
                  <th className="py-2.5 font-bold uppercase tracking-wider">Item / Description</th>
                  <th className="py-2.5 font-bold uppercase tracking-wider text-center w-16">Qty</th>
                  <th className="py-2.5 font-bold uppercase tracking-wider text-right w-28">Rate (₹)</th>
                  <th className="py-2.5 font-bold uppercase tracking-wider text-right w-32">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {selectedQuotation.items.map((item, idx) => (
                  <tr key={item.id}>
                    <td className="py-3 font-mono text-slate-400">{idx + 1}</td>
                    <td className="py-3 font-medium text-slate-800">{item.description}</td>
                    <td className="py-3 text-center tabular-nums text-slate-700">{item.quantity}</td>
                    <td className="py-3 text-right tabular-nums text-slate-700">{formatINR(item.unitPrice)}</td>
                    <td className="py-3 text-right tabular-nums font-semibold text-slate-900">
                      {formatINR(item.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Calculation Summary */}
          <div className="flex flex-col sm:flex-row justify-between gap-6 pt-4 border-t border-slate-200">
            {/* Left Bank Details / Notes */}
            <div className="max-w-md space-y-3 text-xs">
              {selectedQuotation.notes && (
                <div>
                  <span className="font-semibold text-slate-800 block mb-0.5">Special Terms:</span>
                  <p className="text-slate-600 leading-relaxed">{selectedQuotation.notes}</p>
                </div>
              )}
              {selectedQuotation.bankDetails && (
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 font-mono text-[11px] text-slate-700">
                  <span className="font-semibold block text-slate-900 mb-0.5 font-sans">
                    Bank Account Details for NEFT/RTGS/UPI:
                  </span>
                  {selectedQuotation.bankDetails}
                </div>
              )}
            </div>

            {/* Right Amounts Box */}
            <div className="w-full sm:w-72 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums text-slate-800">
                  {formatINR(selectedQuotation.subtotal)}
                </span>
              </div>

              {selectedQuotation.discountAmount > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-100 text-emerald-700">
                  <span>Discount</span>
                  <span className="font-mono tabular-nums">
                    -{formatINR(selectedQuotation.discountAmount)}
                  </span>
                </div>
              )}

              {selectedQuotation.isGstEnabled && (
                <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                  <span>GST ({selectedQuotation.gstRate}%)</span>
                  <span className="font-mono tabular-nums text-slate-800">
                    +{formatINR(selectedQuotation.gstAmount)}
                  </span>
                </div>
              )}

              <div className="flex justify-between py-2 border-b-2 border-slate-900 text-sm font-bold text-slate-900">
                <span>Grand Total</span>
                <span className="font-mono tabular-nums text-indigo-700">
                  {formatINR(selectedQuotation.totalAmount)}
                </span>
              </div>
            </div>
          </div>

          {/* Legal / Simple Quotation Disclaimer */}
          <div className="pt-6 border-t border-slate-200 text-center">
            <p className="text-[11px] text-slate-500">
              *Disclaimer: This is a commercial quotation and cost estimate generated using LeadLite India. It does not constitute a legal GST tax invoice until formal invoicing.*
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
