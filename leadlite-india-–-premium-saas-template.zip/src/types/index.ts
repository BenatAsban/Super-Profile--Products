export type LeadStatus =
  | 'New'
  | 'Contacted'
  | 'Interested'
  | 'Follow-up'
  | 'Converted'
  | 'Not Interested';

export type LeadSource =
  | 'WhatsApp Direct'
  | 'Instagram'
  | 'Google Search'
  | 'Referral'
  | 'Walk-in'
  | 'IndiaMART / Justdial'
  | 'LinkedIn'
  | 'Facebook Ads'
  | 'Other';

export interface LeadNote {
  id: string;
  timestamp: string;
  text: string;
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  email?: string;
  businessInterest: string;
  source: LeadSource;
  status: LeadStatus;
  estimatedValue: number; // in INR
  nextFollowUpDate: string; // YYYY-MM-DD
  notes: LeadNote[];
  city?: string;
  createdAt: string;
  updatedAt: string;
  isSample?: boolean;
}

export type AppointmentLocation =
  | 'Phone Call'
  | 'WhatsApp Video'
  | 'In-person / Site Visit'
  | 'Google Meet / Zoom'
  | 'Office Meeting';

export interface Appointment {
  id: string;
  leadId?: string;
  customerName: string;
  customerPhone: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  purpose: string;
  locationType: AppointmentLocation;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  notes?: string;
  createdAt: string;
}

export interface QuotationItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
}

export interface Quotation {
  id: string;
  quotationNumber: string;
  date: string;
  validUntil: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  customerAddress?: string;
  businessName: string;
  businessPhone: string;
  businessEmail?: string;
  businessAddress?: string;
  gstNumber?: string;
  items: QuotationItem[];
  subtotal: number;
  discountAmount: number;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  gstRate: number; // 0, 5, 12, 18, 28
  isGstEnabled: boolean;
  gstAmount: number;
  totalAmount: number;
  notes?: string;
  bankDetails?: string;
  status: 'Draft' | 'Sent' | 'Approved' | 'Declined';
  createdAt: string;
}

export interface UserSettings {
  businessName: string;
  businessPhone: string;
  businessEmail: string;
  businessCity: string;
  businessAddress: string;
  gstNumber: string;
  currency: string;
  defaultGstRate: number;
  theme: 'light' | 'dark';
  defaultFollowUpDays: number;
}

export type ActivePage =
  | 'dashboard'
  | 'leads'
  | 'add-lead'
  | 'followups'
  | 'appointments'
  | 'quotations'
  | 'reports'
  | 'settings'
  | 'guide'
  | 'payhip-package';

export type AppViewMode = 'app' | 'landing';
