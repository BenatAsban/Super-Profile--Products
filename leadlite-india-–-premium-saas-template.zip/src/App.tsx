import React from 'react';
import { LeadLiteProvider, useLeadLite } from './context/LeadLiteContext';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { WhatsAppModal } from './components/WhatsAppModal';
import { LeadDetailModal } from './components/LeadDetailModal';
import { QuotationPrintModal } from './components/QuotationPrintModal';

// Pages
import { DashboardPage } from './pages/DashboardPage';
import { AllLeadsPage } from './pages/AllLeadsPage';
import { AddLeadPage } from './pages/AddLeadPage';
import { FollowupsPage } from './pages/FollowupsPage';
import { AppointmentsPage } from './pages/AppointmentsPage';
import { QuotationsPage } from './pages/QuotationsPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { GuidePage } from './pages/GuidePage';
import { PayhipPackagePage } from './pages/PayhipPackagePage';
import { LandingPage } from './pages/LandingPage';

const AppContent: React.FC = () => {
  const { viewMode, activePage } = useLeadLite();

  // If user is viewing marketing landing page
  if (viewMode === 'landing') {
    return (
      <>
        <LandingPage />
        <WhatsAppModal />
        <LeadDetailModal />
        <QuotationPrintModal />
      </>
    );
  }

  // Active CRM Workspace view
  const renderActivePage = () => {
    switch (activePage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'leads':
        return <AllLeadsPage />;
      case 'add-lead':
        return <AddLeadPage />;
      case 'followups':
        return <FollowupsPage />;
      case 'appointments':
        return <AppointmentsPage />;
      case 'quotations':
        return <QuotationsPage />;
      case 'reports':
        return <ReportsPage />;
      case 'settings':
        return <SettingsPage />;
      case 'guide':
        return <GuidePage />;
      case 'payhip-package':
        return <PayhipPackagePage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden font-sans">
      {/* Desktop Sidebar Navigation */}
      <Sidebar />

      {/* Main Viewport */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden">
        {/* Top Header */}
        <TopBar />

        {/* Page Content Scroll Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">{renderActivePage()}</div>
        </main>
      </div>

      {/* Global Modals */}
      <WhatsAppModal />
      <LeadDetailModal />
      <QuotationPrintModal />
    </div>
  );
};

export default function App() {
  return (
    <LeadLiteProvider>
      <AppContent />
    </LeadLiteProvider>
  );
}
