import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Lead,
  Appointment,
  Quotation,
  UserSettings,
  ActivePage,
  AppViewMode,
} from '../types';
import {
  sampleLeads,
  sampleAppointments,
  sampleQuotations,
  defaultSettings,
} from '../data/sampleData';
import { exportLeadsToCSV, exportBackupJSON } from '../utils/helpers';

interface LeadLiteContextType {
  leads: Lead[];
  appointments: Appointment[];
  quotations: Quotation[];
  settings: UserSettings;
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  viewMode: AppViewMode;
  setViewMode: (mode: AppViewMode) => void;
  isSidebarCollapsed: boolean;
  setIsSidebarCollapsed: (collapsed: boolean | ((prev: boolean) => boolean)) => void;
  
  // Selection modals
  selectedLead: Lead | null;
  setSelectedLead: (lead: Lead | null) => void;
  selectedQuotation: Quotation | null;
  setSelectedQuotation: (quotation: Quotation | null) => void;
  whatsAppModalLead: Lead | null;
  setWhatsAppModalLead: (lead: Lead | null) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  // Lead CRUD
  addLead: (leadData: {
    name: string;
    phone: string;
    email?: string;
    businessInterest: string;
    source: Lead['source'];
    status: Lead['status'];
    estimatedValue: number;
    nextFollowUpDate: string;
    city?: string;
    initialNote?: string;
  }) => Lead;
  updateLead: (id: string, updates: Partial<Lead>) => void;
  deleteLead: (id: string) => void;
  addLeadNote: (leadId: string, noteText: string) => void;
  updateFollowUpDate: (leadId: string, nextDate: string, note?: string) => void;
  markFollowUpComplete: (
    leadId: string,
    resolutionNote?: string,
    nextDate?: string
  ) => void;

  // Appointment CRUD
  addAppointment: (apt: Omit<Appointment, 'id' | 'createdAt'>) => Appointment;
  updateAppointment: (id: string, updates: Partial<Appointment>) => void;
  deleteAppointment: (id: string) => void;

  // Quotation CRUD
  addQuotation: (quot: Omit<Quotation, 'id' | 'createdAt'>) => Quotation;
  updateQuotation: (id: string, updates: Partial<Quotation>) => void;
  deleteQuotation: (id: string) => void;

  // Settings & Utilities
  updateSettings: (updates: Partial<UserSettings>) => void;
  resetToSampleData: () => void;
  clearAllData: () => void;
  importJSONBackup: (jsonString: string) => { success: boolean; message: string };
  exportCSV: () => void;
  exportJSON: () => void;
}

const LeadLiteContext = createContext<LeadLiteContextType | undefined>(undefined);

const STORAGE_KEYS = {
  LEADS: 'leadlite_leads_v1',
  APPOINTMENTS: 'leadlite_appointments_v1',
  QUOTATIONS: 'leadlite_quotations_v1',
  SETTINGS: 'leadlite_settings_v1',
  THEME: 'leadlite_theme_v1',
};

export const LeadLiteProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  // 1. Settings State
  const [settings, setSettings] = useState<UserSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return stored ? { ...defaultSettings, ...JSON.parse(stored) } : defaultSettings;
    } catch {
      return defaultSettings;
    }
  });

  // 2. Leads State
  const [leads, setLeads] = useState<Lead[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LEADS);
      return stored ? JSON.parse(stored) : sampleLeads;
    } catch {
      return sampleLeads;
    }
  });

  // 3. Appointments State
  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.APPOINTMENTS);
      return stored ? JSON.parse(stored) : sampleAppointments;
    } catch {
      return sampleAppointments;
    }
  });

  // 4. Quotations State
  const [quotations, setQuotations] = useState<Quotation[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.QUOTATIONS);
      return stored ? JSON.parse(stored) : sampleQuotations;
    } catch {
      return sampleQuotations;
    }
  });

  // 5. Navigation & UI state
  const [activePage, setActivePage] = useState<ActivePage>('dashboard');
  const [viewMode, setViewMode] = useState<AppViewMode>('landing');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);
  const [whatsAppModalLead, setWhatsAppModalLead] = useState<Lead | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LEADS, JSON.stringify(leads));
  }, [leads]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.QUOTATIONS, JSON.stringify(quotations));
  }, [quotations]);

  // Lead Operations
  const addLead = (leadData: {
    name: string;
    phone: string;
    email?: string;
    businessInterest: string;
    source: Lead['source'];
    status: Lead['status'];
    estimatedValue: number;
    nextFollowUpDate: string;
    city?: string;
    initialNote?: string;
  }): Lead => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().slice(0, 5);

    const newLead: Lead = {
      id: `lead-${Date.now()}`,
      name: leadData.name.trim(),
      phone: leadData.phone.trim(),
      email: leadData.email?.trim() || undefined,
      businessInterest: leadData.businessInterest.trim(),
      source: leadData.source,
      status: leadData.status,
      estimatedValue: Number(leadData.estimatedValue) || 0,
      nextFollowUpDate: leadData.nextFollowUpDate || dateStr,
      city: leadData.city?.trim() || undefined,
      createdAt: dateStr,
      updatedAt: dateStr,
      isSample: false,
      notes: leadData.initialNote?.trim()
        ? [
            {
              id: `note-${Date.now()}`,
              timestamp: `${dateStr} ${timeStr}`,
              text: leadData.initialNote.trim(),
            },
          ]
        : [],
    };

    setLeads((prev) => [newLead, ...prev]);
    return newLead;
  };

  const updateLead = (id: string, updates: Partial<Lead>) => {
    const today = new Date().toISOString().split('T')[0];
    setLeads((prev) =>
      prev.map((l) => (l.id === id ? { ...l, ...updates, updatedAt: today } : l))
    );
    // Also sync selected lead if open
    setSelectedLead((prev) => (prev?.id === id ? { ...prev, ...updates, updatedAt: today } : prev));
  };

  const deleteLead = (id: string) => {
    setLeads((prev) => prev.filter((l) => l.id !== id));
    if (selectedLead?.id === id) {
      setSelectedLead(null);
    }
  };

  const addLeadNote = (leadId: string, noteText: string) => {
    if (!noteText.trim()) return;
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().slice(0, 5);

    const newNote = {
      id: `note-${Date.now()}`,
      timestamp: `${dateStr} ${timeStr}`,
      text: noteText.trim(),
    };

    setLeads((prev) =>
      prev.map((l) => {
        if (l.id === leadId) {
          return {
            ...l,
            notes: [newNote, ...l.notes],
            updatedAt: dateStr,
          };
        }
        return l;
      })
    );

    setSelectedLead((prev) => {
      if (prev?.id === leadId) {
        return {
          ...prev,
          notes: [newNote, ...prev.notes],
          updatedAt: dateStr,
        };
      }
      return prev;
    });
  };

  const updateFollowUpDate = (leadId: string, nextDate: string, note?: string) => {
    const today = new Date().toISOString().split('T')[0];
    const now = new Date();
    const timeStr = now.toTimeString().slice(0, 5);

    setLeads((prev) =>
      prev.map((l) => {
        if (l.id === leadId) {
          const updatedNotes = note?.trim()
            ? [
                {
                  id: `note-${Date.now()}`,
                  timestamp: `${today} ${timeStr}`,
                  text: `Rescheduled follow-up to ${nextDate}. Note: ${note.trim()}`,
                },
                ...l.notes,
              ]
            : l.notes;

          return {
            ...l,
            nextFollowUpDate: nextDate,
            updatedAt: today,
            notes: updatedNotes,
          };
        }
        return l;
      })
    );
  };

  const markFollowUpComplete = (
    leadId: string,
    resolutionNote?: string,
    nextDate?: string
  ) => {
    const today = new Date().toISOString().split('T')[0];
    const now = new Date();
    const timeStr = now.toTimeString().slice(0, 5);

    setLeads((prev) =>
      prev.map((l) => {
        if (l.id === leadId) {
          const notes = [...l.notes];
          if (resolutionNote?.trim()) {
            notes.unshift({
              id: `note-${Date.now()}`,
              timestamp: `${today} ${timeStr}`,
              text: `Follow-up completed: ${resolutionNote.trim()}`,
            });
          }

          // Default next follow-up: +3 days or nextDate provided or keep empty if converted
          const updatedNextDate = nextDate || '';

          return {
            ...l,
            nextFollowUpDate: updatedNextDate,
            updatedAt: today,
            notes,
          };
        }
        return l;
      })
    );
  };

  // Appointment operations
  const addAppointment = (
    aptData: Omit<Appointment, 'id' | 'createdAt'>
  ): Appointment => {
    const today = new Date().toISOString().split('T')[0];
    const newApt: Appointment = {
      ...aptData,
      id: `apt-${Date.now()}`,
      createdAt: today,
    };
    setAppointments((prev) => [newApt, ...prev]);
    return newApt;
  };

  const updateAppointment = (id: string, updates: Partial<Appointment>) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ...updates } : a))
    );
  };

  const deleteAppointment = (id: string) => {
    setAppointments((prev) => prev.filter((a) => a.id !== id));
  };

  // Quotation operations
  const addQuotation = (quotData: Omit<Quotation, 'id' | 'createdAt'>): Quotation => {
    const today = new Date().toISOString().split('T')[0];
    const newQuot: Quotation = {
      ...quotData,
      id: `quot-${Date.now()}`,
      createdAt: today,
    };
    setQuotations((prev) => [newQuot, ...prev]);
    return newQuot;
  };

  const updateQuotation = (id: string, updates: Partial<Quotation>) => {
    setQuotations((prev) =>
      prev.map((q) => (q.id === id ? { ...q, ...updates } : q))
    );
    setSelectedQuotation((prev) => (prev?.id === id ? { ...prev, ...updates } : prev));
  };

  const deleteQuotation = (id: string) => {
    setQuotations((prev) => prev.filter((q) => q.id !== id));
    if (selectedQuotation?.id === id) {
      setSelectedQuotation(null);
    }
  };

  // Settings
  const updateSettings = (updates: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  };

  // Reset to Sample Data
  const resetToSampleData = () => {
    setLeads(sampleLeads);
    setAppointments(sampleAppointments);
    setQuotations(sampleQuotations);
    setSettings(defaultSettings);
    localStorage.setItem(STORAGE_KEYS.LEADS, JSON.stringify(sampleLeads));
    localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(sampleAppointments));
    localStorage.setItem(STORAGE_KEYS.QUOTATIONS, JSON.stringify(sampleQuotations));
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(defaultSettings));
  };

  // Clear all data
  const clearAllData = () => {
    setLeads([]);
    setAppointments([]);
    setQuotations([]);
    localStorage.removeItem(STORAGE_KEYS.LEADS);
    localStorage.removeItem(STORAGE_KEYS.APPOINTMENTS);
    localStorage.removeItem(STORAGE_KEYS.QUOTATIONS);
  };

  // Import JSON Backup
  const importJSONBackup = (jsonString: string): { success: boolean; message: string } => {
    try {
      const data = JSON.parse(jsonString);
      if (!data.leads || !Array.isArray(data.leads)) {
        return { success: false, message: 'Invalid backup file format: missing leads array' };
      }

      setLeads(data.leads);
      if (Array.isArray(data.appointments)) setAppointments(data.appointments);
      if (Array.isArray(data.quotations)) setQuotations(data.quotations);
      if (data.settings && typeof data.settings === 'object') {
        setSettings((prev) => ({ ...prev, ...data.settings }));
      }

      return {
        success: true,
        message: `Successfully imported ${data.leads.length} leads and workspace data.`,
      };
    } catch (err: any) {
      return { success: false, message: `Failed to parse backup JSON: ${err.message}` };
    }
  };

  // Export CSV
  const exportCSV = () => {
    exportLeadsToCSV(leads, settings.businessName);
  };

  // Export JSON
  const exportJSON = () => {
    exportBackupJSON({
      leads,
      appointments,
      quotations,
      settings,
    });
  };

  return (
    <LeadLiteContext.Provider
      value={{
        leads,
        appointments,
        quotations,
        settings,
        activePage,
        setActivePage,
        viewMode,
        setViewMode,
        isSidebarCollapsed,
        setIsSidebarCollapsed,
        selectedLead,
        setSelectedLead,
        selectedQuotation,
        setSelectedQuotation,
        whatsAppModalLead,
        setWhatsAppModalLead,
        searchQuery,
        setSearchQuery,
        addLead,
        updateLead,
        deleteLead,
        addLeadNote,
        updateFollowUpDate,
        markFollowUpComplete,
        addAppointment,
        updateAppointment,
        deleteAppointment,
        addQuotation,
        updateQuotation,
        deleteQuotation,
        updateSettings,
        resetToSampleData,
        clearAllData,
        importJSONBackup,
        exportCSV,
        exportJSON,
      }}
    >
      {children}
    </LeadLiteContext.Provider>
  );
};

export const useLeadLite = () => {
  const context = useContext(LeadLiteContext);
  if (!context) {
    throw new Error('useLeadLite must be used within a LeadLiteProvider');
  }
  return context;
};
