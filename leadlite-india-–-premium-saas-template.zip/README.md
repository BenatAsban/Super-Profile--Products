# LeadLite India – Premium SaaS Website Template & Local CRM

**LeadLite India** is a clean, modern, responsive SaaS web application template and local customer relationship manager (CRM) designed specifically for Indian small businesses, freelancers, consultants, agencies, contractors, and real-estate agents.

---

## 🌟 Key Capabilities

1. **Dashboard Overview**
   - KPI metrics: Total Leads, New Enquiries, In Discussion, Converted Wins, Pending Follow-ups, and Conversion Rate.
   - Monthly deal volume and pipeline activity charts in Indian Rupees (₹).
   - Urgent follow-up alert banner with quick 1-click actions.
   - Upcoming scheduled client appointments and site visits.

2. **Lead Management**
   - Save enquiries with customer name, phone number (auto-formatted with Indian `+91`), email, service interest, lead source, status, estimated deal value in ₹ INR, and next follow-up dates.
   - Instant search across customer name, phone, service interest, and notes history.
   - Filter by status (`New`, `Contacted`, `Interested`, `Follow-up`, `Converted`, `Not Interested`) and source.
   - High-density data table & card grid layout switcher.
   - Full customer history timeline with multi-note logging.

3. **WhatsApp 1-Click Follow-up**
   - Direct click-to-chat integration (`https://wa.me/91...`).
   - Pre-formatted polite Indian business templates (Namaste & Inquiry Greeting, Gentle Follow-up Check, Quotation Follow-up, Meeting Confirmation).
   - Zero Meta developer approval, third-party API keys, or recurring API subscription fees required.

4. **Daily Follow-up Pipeline**
   - Dedicated management view with **Overdue**, **Due Today**, and **Upcoming** buckets.
   - One-click completion with outcome note prompts.
   - Quick postponement shortcuts (`+1 Day`, `+3 Days`, `+1 Week`).

5. **Client Appointments & Site Visits**
   - Schedule consultations, site measurements, Zoom/Google Meet calls, and office visits.
   - 1-click WhatsApp appointment reminders.
   - Filter by scheduled, completed, or cancelled statuses.

6. **Commercial Quotation Builder**
   - Dynamic line items with quantities, rates, and automatic line totals.
   - Discount support (Fixed ₹ or % discount).
   - Indian GST tax calculation with standard slabs (0%, 5%, 12%, 18%, 28%).
   - Clean printable A4 layout with `@media print` support and WhatsApp shareable text summaries.

7. **Reports & Channel Analytics**
   - Lead acquisition channel comparison (WhatsApp Direct, Instagram, Google Search, Referrals, Justdial, etc.).
   - Win rates and pipeline values per channel.
   - Raw CSV spreadsheet export for Microsoft Excel and Google Sheets.

8. **Local-First Privacy & Settings**
   - Operates 100% on browser `localStorage` — customer data never leaves the device.
   - One-click JSON backup export and restore.
   - Demo dataset reset option.
   - Business branding configuration (Name, phone, address, GSTIN).
   - Light and Dark mode theme support.

9. **High-Converting SaaS Marketing Landing Page**
   - "Never Lose Track of a Customer Again" hero section.
   - Interactive live dashboard preview teaser.
   - Problem vs Solution comparison for Indian business owners.
   - Persona-tailored solutions (Interior designers, real estate, CA/tax consultants, freelancers, contractors).
   - Pricing comparison and FAQ section.

10. **Payhip Digital Product Package**
   - Ready-to-sell assets, installation instructions, customization guide, deployment instructions, listing copy, and commercial license terms.

---

## 💻 Tech Stack

- **Framework**: React 19 + TypeScript
- **Styling**: Tailwind CSS v4 (`@import "tailwindcss";` with `@custom-variant dark`)
- **Icons**: Lucide React
- **Build Tool**: Vite 8
- **Typography**: Google Fonts (*Plus Jakarta Sans* & *JetBrains Mono*)

---

## 🚀 Quick Start Guide

### 1. Installation
\`\`\`bash
# Install dependencies
npm install

# Start local development server
npm run dev
\`\`\`
The application will run at \`http://localhost:3000\`.

### 2. Build for Production
\`\`\`bash
npm run build
\`\`\`
The compiled static assets will be created in the \`dist/\` directory.

---

## 🌐 2-Minute Deployment

### Deploy to Vercel
1. Push your repository to GitHub.
2. Sign in to [Vercel](https://vercel.com) and click **"Add New Project"**.
3. Import your repository (Vercel automatically detects Vite).
4. Click **"Deploy"**.

### Deploy to Netlify
1. Connect your repository to [Netlify](https://netlify.com).
2. Set Build Command: \`npm run build\`
3. Set Publish Directory: \`dist\`
4. Click **"Deploy site"**.

---

## 📦 Selling on Payhip / Gumroad

LeadLite India is packaged for distribution as a digital website template:
- **Recommended Price**: ₹799 INR (or $29 USD)
- **Target Audience**: Indian freelancers, web agencies, real-estate brokers, and business consultants.
- Read \`Payhip Listing Copy\` in the in-app **Payhip Digital Package** tab for ready-to-paste sales copy.

---

## 📄 License

Commercial End-User License: You are granted rights to customize, deploy, and use this template for unlimited personal and client projects. Reselling the raw template source code on competing template marketplaces is prohibited.
